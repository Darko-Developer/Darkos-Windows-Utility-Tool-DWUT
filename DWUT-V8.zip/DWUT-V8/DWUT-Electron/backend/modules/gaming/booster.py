"""
modules/gaming/booster.py

Real Game Booster — no fake numbers.

Order of operations:
  1. Terminate the background apps you agreed to (Discord etc. can be excluded)
  2. Detect the game — from the name typed, or automatically from what is really
     running / in the foreground when no name is given
  3. Set the game to HIGH priority (+ high I/O priority)
  4. Activate a real performance power plan (Ultimate -> High -> tuned copy of the
     current plan, whichever this PC supports) and VERIFY it took effect
  5. Enable HAGS, turn Game DVR off, Game Mode on, pin the game to the fast GPU
  6. Trim working sets of leftover processes and measure the real RAM change
  7. Everything changed is saved first and restored on deactivate

FIXES vs. the previous version
  * Power plan: `powercfg /duplicatescheme` creates a plan with a NEW random GUID.
    The old code then tried to activate the *template* GUID, which always failed.
    The new GUID is parsed from powercfg's output and activation is verified.
    PCs without Ultimate/High Performance (Modern Standby laptops) fall back to a
    tuned copy of the active plan.
  * The game PID was never resolved from the typed name, so priority was never set.
  * Works with no name at all (auto-detect).
"""

from __future__ import annotations

import ctypes
import json
import os
import pathlib
import platform
import re
import subprocess
import threading
import time
import winreg
from dataclasses import dataclass, field
from typing import Optional

import psutil

from core.events import Events, bus
from core.logger import get_logger

_log = get_logger(__name__)

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# ── Windows version detection (works on W10 + W11) ──
def _win_build() -> int:
    """Return the Windows build number (e.g. 19041 for 20H1, 22000 for W11)."""
    try:
        import winreg as _wr
        k = _wr.OpenKey(_wr.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
        build, _ = _wr.QueryValueEx(k, "CurrentBuildNumber")
        _wr.CloseKey(k)
        return int(build)
    except Exception:
        try:
            return int(platform.version().split(".")[-1])
        except Exception:
            return 0

_BUILD = _win_build()
_IS_W10 = _BUILD >= 10240 and _BUILD < 22000
_IS_W11 = _BUILD >= 22000
_HAGS_OK = _BUILD >= 19041   # HAGS requires Windows 10 2004 (May 2020 Update) or later

# ── Safe priority constants (psutil on Windows may vary) ──
_IDLE_PRIO = getattr(psutil, "IDLE_PRIORITY_CLASS", 0x40)
_BELOW_PRIO = getattr(psutil, "BELOW_NORMAL_PRIORITY_CLASS", 0x4000)
_HIGH_PRIO = getattr(psutil, "HIGH_PRIORITY_CLASS", 0x80)
_IOPRIO_HIGH = getattr(psutil, "IOPRIO_HIGH", 2)
_IOPRIO_NORMAL = getattr(psutil, "IOPRIO_NORMAL", 2)
_IOPRIO_VERYLOW = getattr(psutil, "IOPRIO_VERYLOW", 0)

_PLAN_ULTIMATE_PERF = "e9a42b02-d5df-448d-aa00-03f14749eb61"
_PLAN_HIGH_PERF     = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
_PLAN_BALANCED      = "381b4222-f694-41f0-9685-ff5bb260df2e"

# Registry path for per-app GPU preference (high-perf GPU pinning)
_GPU_PREF_KEY = r"Software\Microsoft\DirectX\UserGpuPreferences"

_GUID_RE = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")


# ──────────────────────────────────────────────────────────────────────────────
def _run(cmd: list[str], timeout: int = 10) -> tuple[int, str]:
    """Execute a system command and return (returncode, stdout+stderr)."""
    try:
        r = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=timeout, creationflags=_NO_WINDOW, errors="replace",
        )
        return r.returncode, ((r.stdout or "") + (r.stderr or "")).strip()
    except Exception as exc:
        return 1, str(exc)


def _powercfg(*args: str, timeout: int = 15) -> tuple[bool, str]:
    try:
        r = subprocess.run(
            ["powercfg", *args], capture_output=True, text=True,
            timeout=timeout, creationflags=_NO_WINDOW, errors="replace",
        )
        return r.returncode == 0, ((r.stdout or "") + (r.stderr or "")).strip()
    except Exception as exc:
        return False, str(exc)


def _list_schemes() -> list[tuple[str, str]]:
    """[(guid, name)] for every installed scheme (locale independent)."""
    ok, out = _powercfg("/list")
    schemes: list[tuple[str, str]] = []
    if not ok:
        return schemes
    for line in out.splitlines():
        m = _GUID_RE.search(line)
        if not m:
            continue
        nm = re.search(r"\((.*?)\)", line)
        schemes.append((m.group(0).lower(), nm.group(1).strip() if nm else ""))
    return schemes


def _get_active_power_plan() -> Optional[str]:
    ok, out = _powercfg("/getactivescheme")
    if not ok:
        return None
    m = _GUID_RE.search(out)
    return m.group(0).lower() if m else None


def _set_power_plan(guid: str) -> tuple[bool, str]:
    """Activate a plan and VERIFY it really became active."""
    ok, out = _powercfg("/setactive", guid)
    active = _get_active_power_plan()
    if active and active.lower() == guid.lower():
        return True, ""
    return False, out or "powercfg did not switch the plan"


def _duplicate(template_guid: str) -> Optional[str]:
    """Duplicate a scheme; the NEW plan has a NEW guid, parsed from the output."""
    ok, out = _powercfg("/duplicatescheme", template_guid)
    if not ok:
        return None
    m = _GUID_RE.search(out)
    return m.group(0).lower() if m else None


def _tune_plan_for_gaming(guid: str) -> None:
    settings = [
        ("SUB_PROCESSOR", "PROCTHROTTLEMIN",  "100"),
        ("SUB_PROCESSOR", "PROCTHROTTLEMAX",  "100"),
        ("SUB_PROCESSOR", "PERFBOOSTMODE",    "2"),
        ("SUB_PROCESSOR", "CPMINCORES",       "100"),
        ("SUB_SLEEP",     "STANDBYIDLE",      "0"),
        ("SUB_VIDEO",     "VIDEOIDLE",        "0"),
        ("SUB_PCIEXPRESS", "ASPM",            "0"),
        ("SUB_USB",       "USBSELECTSUSPEND", "0"),
    ]
    # W10 1803+ supports PERFBOOSTPOL separately
    if _BUILD >= 17134:
        settings.append(("SUB_PROCESSOR", "PERFBOOSTPOL", "100"))
    for sub, setting, val in settings:
        _powercfg("/setacvalueindex", guid, sub, setting, val)
        _powercfg("/setdcvalueindex", guid, sub, setting, val)


# Persistent config: stores the GUID of the DWUT Extreme Performance plan so
# we never have to recreate it on subsequent boosts.
_CFG_DIR  = pathlib.Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT"
_CFG_FILE = _CFG_DIR / "gaming_plan.json"
_DWUT_PLAN_NAME = "DWUT Extreme Performance"
_DWUT_PLAN_DESC = "Maximum gaming performance plan created and managed by DWUT. Do not delete."


def _load_plan_cfg() -> dict:
    try:
        return json.loads(_CFG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_plan_cfg(data: dict) -> None:
    try:
        _CFG_DIR.mkdir(parents=True, exist_ok=True)
        _CFG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception as exc:
        _log.warning("Could not save gaming plan config: %s", exc)


def _plan_exists(guid: str) -> bool:
    """Return True if a plan with this GUID is currently installed."""
    return any(g == guid.lower() for g, _ in _list_schemes())


def _create_dwut_plan() -> tuple[str | None, list[str]]:
    """Create the DWUT Extreme Performance plan from the best available template.
    Returns (new_guid, notes)."""
    notes: list[str] = []
    template: str | None = None

    # Try Ultimate Performance first, then High Performance, then active plan
    for tmpl_guid, tmpl_label in [
        (_PLAN_ULTIMATE_PERF, "Ultimate Performance"),
        (_PLAN_HIGH_PERF,     "High Performance"),
    ]:
        new_g = _duplicate(tmpl_guid)
        if new_g:
            template = tmpl_guid
            notes.append(f"Created from {tmpl_label} template")
            break

    if not new_g:
        # Last resort: duplicate the currently active plan
        active = _get_active_power_plan()
        if active:
            new_g = _duplicate(active)
            if new_g:
                notes.append("Created from current active plan (Ultimate/High not available)")

    if not new_g:
        return None, notes + ["Could not create DWUT Extreme Performance plan"]

    # Rename to our canonical name
    _powercfg("/changename", new_g, _DWUT_PLAN_NAME, _DWUT_PLAN_DESC)

    # Aggressive tuning on top of the template
    _tune_plan_for_gaming(new_g)

    # Extra: lock min/max processor state to 100%, boost mode = aggressive
    extra = [
        ("SUB_PROCESSOR", "PROCFREQMAX",    "0"),    # 0 = no artificial cap
        ("SUB_PROCESSOR", "PROCFREQMAX1",   "0"),
        ("SUB_SLEEP",     "HYBRIDSLEEP",    "0"),
        ("SUB_SLEEP",     "HIBERNATEIDLE",  "0"),
    ]
    for sub, setting, val in extra:
        _powercfg("/setacvalueindex", new_g, sub, setting, val)
        _powercfg("/setdcvalueindex", new_g, sub, setting, val)

    _log.info("Created %s plan: %s", _DWUT_PLAN_NAME, new_g)
    return new_g, notes


def ensure_performance_plan() -> tuple[str | None, str, bool, list[str]]:
    """Ensure the persistent 'DWUT Extreme Performance' plan exists and return its GUID.
    The plan is created ONCE and reused forever — its GUID is saved to disk.
    Returns (guid, display_name, newly_created, notes)."""
    notes: list[str] = []
    cfg   = _load_plan_cfg()
    saved_guid: str | None = cfg.get("dwut_plan_guid", "").lower().strip() or None

    # 1. If we already know the GUID and the plan is still installed — done.
    if saved_guid and _plan_exists(saved_guid):
        _log.info("Reusing existing %s plan: %s", _DWUT_PLAN_NAME, saved_guid)
        return saved_guid, _DWUT_PLAN_NAME, False, notes

    # 2. Scan installed plans for one we named ourselves (survive config loss)
    for g, name in _list_schemes():
        if _DWUT_PLAN_NAME.lower() in name.lower():
            _log.info("Found existing %s plan by name: %s", _DWUT_PLAN_NAME, g)
            _save_plan_cfg({**cfg, "dwut_plan_guid": g})
            return g, _DWUT_PLAN_NAME, False, notes

    # 3. Plan doesn't exist — create it now
    notes.append(f"Creating {_DWUT_PLAN_NAME} plan for the first time...")
    new_guid, create_notes = _create_dwut_plan()
    notes.extend(create_notes)
    if not new_guid:
        return None, "", False, notes

    _save_plan_cfg({**cfg, "dwut_plan_guid": new_guid})
    return new_guid, _DWUT_PLAN_NAME, True, notes


# ──────────────────────────────────────────────────────────────────────────────
# Result types
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class BoostResult:
    success: bool
    game_name: str
    game_pid: Optional[int]
    ram_freed_mb: float
    disk_freed_mb: float
    cpu_notes: list
    gpu_notes: list
    net_notes: list
    power_plan_applied: str
    priority_applied: bool
    gpu_scheduling_enabled: bool
    gamebar_disabled: bool
    message: str
    detected_game: str = ""
    auto_detected: bool = False
    terminated: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    services_stopped: list = field(default_factory=list)


@dataclass
class _SavedState:
    original_power_plan: Optional[str] = None
    created_plan: Optional[str] = None
    original_priority: Optional[int] = None
    game_pid: Optional[int] = None
    game_exe: str = ""
    registry: list = field(default_factory=list)        # (hive, path, name, old_value, vtype)
    stopped_services: list = field(default_factory=list)  # service names we stopped
    io_throttled_pids: list = field(default_factory=list) # PIDs we lowered I/O priority on
    nagle_restored: list = field(default_factory=list)   # (socket handles) - tracked for restore


# ──────────────────────────────────────────────────────────────────────────────
# Registry helpers
# ──────────────────────────────────────────────────────────────────────────────

def _reg_read(hive: int, path: str, name: str):
    try:
        k = winreg.OpenKey(hive, path, 0, winreg.KEY_READ)
        val, vtype = winreg.QueryValueEx(k, name)
        winreg.CloseKey(k)
        return val, vtype
    except Exception:
        return None, None


def _reg_write(hive: int, path: str, name: str, value, vtype: int) -> bool:
    try:
        k = winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, name, 0, vtype, value)
        winreg.CloseKey(k)
        return True
    except Exception as exc:
        _log.warning("Registry write failed [%s\\%s] %s: %s", path, name, value, exc)
        return False


def _reg_delete(hive: int, path: str, name: str) -> None:
    try:
        k = winreg.OpenKey(hive, path, 0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(k, name)
        winreg.CloseKey(k)
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────────────────────
# Process knowledge
# ──────────────────────────────────────────────────────────────────────────────

_SYSTEM_DIR = os.path.normcase(os.environ.get("SystemRoot", r"C:\Windows"))

# Never terminated, whatever the user ticks
_NEVER_KILL = {
    "system", "system idle process", "registry", "smss.exe", "csrss.exe", "wininit.exe",
    "winlogon.exe", "lsass.exe", "services.exe", "svchost.exe", "explorer.exe", "dwm.exe",
    "taskmgr.exe", "taskhostw.exe", "sihost.exe", "ctfmon.exe", "audiodg.exe", "fontdrvhost.exe",
    "msmpeng.exe", "securityhealthservice.exe", "securityhealthsystray.exe", "nissrv.exe",
    "python.exe", "pythonw.exe", "dwut.exe", "electron.exe", "node.exe",
    "gamebar.exe", "gamebarft.exe", "xboxapp.exe", "gamingservices.exe", "gamingservicesnet.exe",
    "wmplayer.exe", "searchhost.exe", "startmenuexperiencehost.exe", "shellexperiencehost.exe",
    "textinputhost.exe", "runtimebroker.exe", "conhost.exe", "wmiprvse.exe",
    # anti-cheat / GPU drivers — killing these breaks games or drivers
    "easyanticheat.exe", "easyanticheat_eos.exe", "beservice.exe", "battleye.exe",
    "vgc.exe", "vgtray.exe", "faceitclient.exe", "faceit.exe", "esea.exe",
    "nvcontainer.exe", "nvdisplay.container.exe", "nvidia share.exe", "nvsphelper64.exe",
    "radeonsoftware.exe", "amdrsserv.exe", "cncmd.exe",
}
_NEVER_KILL_PREFIX = ("nvidia", "nvcpl", "amd", "radeon", "igfx", "realtek", "rtk", "waves",
                      "xbox", "gamebar", "microsoft.", "windows", "dwut", "electron")

# Ticked by default in the exclusion popup (same set the booster always used)
_BACKGROUND_KILL_LIST = {
    "discord.exe", "slack.exe", "teams.exe", "ms-teams.exe",
    "onedrive.exe", "dropbox.exe",
    "adobeupdatedaemon.exe", "adobearmservice.exe",
    "creative cloud.exe", "creativecloudapp.exe",
    "spotifywebhelper.exe", "spotify.exe",
    "steam.exe",           # auto-protected when the game runs under Steam
}

_LAUNCHER_NAMES = {
    "steam.exe", "steamwebhelper.exe", "epicgameslauncher.exe", "riotclientservices.exe",
    "riotclientux.exe", "battle.net.exe", "agent.exe", "origin.exe", "eadesktop.exe",
    "ealauncher.exe", "upc.exe", "ubisoftconnect.exe", "galaxyclient.exe", "xboxpcapp.exe",
}

_BROWSERS = {"chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe",
             "opera_gx.exe", "vivaldi.exe", "iexplore.exe"}

_KNOWN_GAMES: dict[str, str] = {
    "robloxplayerbeta.exe": "Roblox", "windows10universal.exe": "Roblox",
    "fortniteclient-win64-shipping.exe": "Fortnite",
    "valorant-win64-shipping.exe": "Valorant", "cs2.exe": "Counter-Strike 2", "csgo.exe": "CS:GO",
    "r5apex.exe": "Apex Legends", "r5apex_dx12.exe": "Apex Legends",
    "overwatch.exe": "Overwatch 2", "leagueoflegends.exe": "League of Legends",
    "league of legends.exe": "League of Legends", "dota2.exe": "Dota 2",
    "gta5.exe": "GTA V", "gtav.exe": "GTA V", "playgtav.exe": "GTA V", "rdr2.exe": "Red Dead Redemption 2",
    "eldenring.exe": "Elden Ring", "cyberpunk2077.exe": "Cyberpunk 2077", "witcher3.exe": "The Witcher 3",
    "minecraft.windows.exe": "Minecraft", "rustclient.exe": "Rust", "destiny2.exe": "Destiny 2",
    "tslgame.exe": "PUBG", "rocketleague.exe": "Rocket League", "escapefromtarkov.exe": "Escape from Tarkov",
    "cod.exe": "Call of Duty", "modernwarfare.exe": "Call of Duty", "blackopscoldwar.exe": "Call of Duty",
    "rainbowsix.exe": "Rainbow Six Siege", "rainbowsix_vulkan.exe": "Rainbow Six Siege",
    "fallguys_client_game.exe": "Fall Guys", "genshinimpact.exe": "Genshin Impact",
    "starrail.exe": "Honkai: Star Rail", "zenlesszonezero.exe": "Zenless Zone Zero",
    "wow.exe": "World of Warcraft", "wowclassic.exe": "WoW Classic", "diablo iv.exe": "Diablo IV",
    "pathofexile.exe": "Path of Exile", "pathofexile_x64steam.exe": "Path of Exile",
    "terraria.exe": "Terraria", "stardewvalley.exe": "Stardew Valley", "thefinals.exe": "THE FINALS",
    "helldivers2.exe": "Helldivers 2", "bg3.exe": "Baldur's Gate 3", "bg3_dx11.exe": "Baldur's Gate 3",
    "starfield.exe": "Starfield", "fc24.exe": "EA FC 24", "fc25.exe": "EA FC 25",
    "forzahorizon5.exe": "Forza Horizon 5", "marvelrivals.exe": "Marvel Rivals",
    "deadlock.exe": "Deadlock", "bf2042.exe": "Battlefield 2042",
}

_KNOWN_GAMES.update({
    "hl2.exe": "Half-Life 2 / Source", "left4dead2.exe": "Left 4 Dead 2", "tf_win64.exe": "Team Fortress 2", "gmod.exe": "Garry's Mod",
    "portal2.exe": "Portal 2", "7daystodie.exe": "7 Days to Die", "valheim.exe": "Valheim", "sekiro.exe": "Sekiro", "darksoulsiii.exe": "Dark Souls III",
    "monsterhunterworld.exe": "Monster Hunter World", "mhwilds.exe": "Monster Hunter Wilds", "wutheringwaves.exe": "Wuthering Waves",
    "warframe.x64.exe": "Warframe", "lostark.exe": "Lost Ark", "newworld.exe": "New World", "ffxiv_dx11.exe": "Final Fantasy XIV", "gw2-64.exe": "Guild Wars 2",
    "eso64.exe": "Elder Scrolls Online", "bf4.exe": "Battlefield 4", "bf1.exe": "Battlefield 1", "bfv.exe": "Battlefield V", "sc2_x64.exe": "StarCraft II",
    "hearthstone.exe": "Hearthstone", "d2r.exe": "Diablo II Resurrected", "fc26.exe": "EA FC 26", "fifa23.exe": "FIFA 23", "nba2k24.exe": "NBA 2K24", "nba2k25.exe": "NBA 2K25",
    "forzahorizon4.exe": "Forza Horizon 4", "nfsheat.exe": "Need for Speed Heat", "acvalhalla.exe": "AC Valhalla", "acodyssey.exe": "AC Odyssey", "acmirage.exe": "AC Mirage",
    "hogwartslegacy.exe": "Hogwarts Legacy", "haloinfinite.exe": "Halo Infinite", "hades.exe": "Hades", "celeste.exe": "Celeste", "subnautica.exe": "Subnautica",
    "factorio.exe": "Factorio", "amongus.exe": "Among Us", "phasmophobia.exe": "Phasmophobia", "lethal company.exe": "Lethal Company", "fivem.exe": "FiveM",
    "teardown.exe": "Teardown", "cities.exe": "Cities: Skylines", "citiesskylines.exe": "Cities: Skylines", "eurotrucks2.exe": "Euro Truck Simulator 2",
    "ats.exe": "American Truck Simulator", "xplane.exe": "X-Plane", "fsx.exe": "Flight Simulator X", "flightsimulator.exe": "Microsoft Flight Simulator",
    "war thunder.exe": "War Thunder", "aces.exe": "War Thunder", "worldoftanks.exe": "World of Tanks", "wowsb.exe": "World of Warships",
    "paladins.exe": "Paladins", "smite.exe": "SMITE", "hunt.exe": "Hunt: Showdown", "pubg.exe": "PUBG", "thefinals.exe": "THE FINALS",
    "splitgate.exe": "Splitgate", "fortniteclient-win64-shipping_eac_eos.exe": "Fortnite", "robloxstudiobeta.exe": "Roblox Studio",
    "minecraftlauncher.exe": "Minecraft Launcher", "lunarclient.exe": "Lunar Client", "badlion client.exe": "Badlion Client",
    "streetfighter6.exe": "Street Fighter 6", "tekken8.exe": "Tekken 8", "mortalkombat1.exe": "Mortal Kombat 1", "eldenring_nightreign.exe": "Elden Ring Nightreign",
    "residentevil4.exe": "Resident Evil 4", "re2.exe": "Resident Evil 2", "re8.exe": "Resident Evil Village", "dmc5.exe": "Devil May Cry 5",
    "godofwar.exe": "God of War", "spider-man.exe": "Spider-Man", "horizonzerodawn.exe": "Horizon Zero Dawn", "tlou-i.exe": "The Last of Us",
    "valorant.exe": "Valorant", "vgc.exe_": "", "overwatchlauncher.exe": "Overwatch 2",
})
_KNOWN_GAMES.pop("vgc.exe_", None)

_HELPER_SUBSTR = ("crashhandler", "crashreport", "unins", "setup", "update", "launcher", "webhelper",
                  "helper", "service", "anticheat", "easyanticheat", "battleye", "vgc", "redist")

_GAME_PATH_HINTS = ("steamapps\\common", "\\epic games\\", "\\riot games\\", "\\xboxgames\\",
                    "\\battle.net\\", "\\ubisoft game launcher\\games", "\\ea games\\",
                    "\\origin games\\", "\\gog galaxy\\games", "\\gog games\\", "\\games\\",
                    "\\rockstar games\\", "\\blizzard\\", "\\activision\\", "\\bethesda")


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _exe_of(p: psutil.Process) -> str:
    try:
        return p.exe() or ""
    except Exception:
        return ""


def _foreground_pid() -> Optional[int]:
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        pid = ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value) or None
    except Exception:
        return None


def _foreground_is_fullscreen() -> bool:
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return False

        class RECT(ctypes.Structure):
            _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long),
                        ("r", ctypes.c_long), ("b", ctypes.c_long)]

        rc = RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rc))
        sw, sh = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
        return (rc.r - rc.l) >= sw - 2 and (rc.b - rc.t) >= sh - 2
    except Exception:
        return False


def _ancestors(pid: int) -> set[int]:
    out: set[int] = set()
    try:
        cur = psutil.Process(pid)
        while True:
            par = cur.parent()
            if par is None or par.pid in out or par.pid == 0:
                break
            out.add(par.pid)
            cur = par
    except Exception:
        pass
    return out


def _descendants(pid: int) -> set[int]:
    try:
        return {c.pid for c in psutil.Process(pid).children(recursive=True)}
    except Exception:
        return set()


def _is_system_process(exe: str, name: str) -> bool:
    if not exe:
        return True                      # can't inspect it -> untouchable
    if os.path.normcase(exe).startswith(_SYSTEM_DIR):
        return True
    n = name.lower()
    return n in _NEVER_KILL or n.startswith(_NEVER_KILL_PREFIX)


def _score_game(p: psutil.Process, fg_pid: Optional[int], fg_full: bool) -> tuple[int, str]:
    """(score, display_name). Score >= 55 means 'this is a game'."""
    try:
        name = (p.name() or "").lower()
    except Exception:
        return 0, ""
    exe = _exe_of(p)
    if _is_system_process(exe, name) or name in _BROWSERS or name in _LAUNCHER_NAMES:
        return 0, ""
    if any(h in name for h in _HELPER_SUBSTR) and name not in _KNOWN_GAMES:
        return 0, ""

    score = 0
    disp = _KNOWN_GAMES.get(name, "")
    if disp:
        score += 100
    low = exe.lower()
    if any(h in low for h in _GAME_PATH_HINTS):
        score += 55
    if name.endswith("-win64-shipping.exe") or name.endswith("-win32-shipping.exe"):
        score += 55
        disp = disp or name.replace("-win64-shipping.exe", "").replace("-win32-shipping.exe", "")
    if name == "javaw.exe":
        try:
            if "minecraft" in " ".join(p.cmdline()).lower():
                score += 100
                disp = "Minecraft"
        except Exception:
            pass
    if fg_pid and p.pid == fg_pid:
        score += 30
        if fg_full:
            score += 30
    try:
        mem = p.memory_info().rss / (1024 * 1024)
        score += 10 if mem > 1500 else 5 if mem > 700 else 0
    except Exception:
        pass
    return score, disp or os.path.splitext(name)[0]


def detect_game() -> Optional[dict]:
    """Best guess at the game running right now (or None)."""
    fg = _foreground_pid()
    fg_full = _foreground_is_fullscreen()
    best: tuple[int, dict] | None = None
    for p in psutil.process_iter(["pid", "name"]):
        s, disp = _score_game(p, fg, fg_full)
        if s >= 55 and (best is None or s > best[0]):
            best = (s, {"pid": p.pid, "name": disp, "exe": _exe_of(p), "score": s})
    return best[1] if best else None


def resolve_game_by_name(query: str) -> Optional[dict]:
    """Match a typed game name against running processes."""
    q = _norm(query)
    if not q:
        return None
    fg = _foreground_pid()
    best: tuple[float, dict] | None = None
    for p in psutil.process_iter(["pid", "name"]):
        try:
            name = p.info["name"] or ""
        except Exception:
            continue
        exe = _exe_of(p)
        if _is_system_process(exe, name) or name.lower() in _BROWSERS:
            continue
        hay = _norm(name) + "|" + _norm(os.path.dirname(exe)) + "|" + _norm(_KNOWN_GAMES.get(name.lower(), ""))
        if q not in hay:
            continue
        try:
            mem = p.memory_info().rss
        except Exception:
            mem = 0
        pts = mem / 1e6 + (500 if name.lower() in _KNOWN_GAMES else 0) + (300 if p.pid == fg else 0)
        if name.lower() in _LAUNCHER_NAMES or any(h in name.lower() for h in _HELPER_SUBSTR):
            pts -= 400
        if best is None or pts > best[0]:
            best = (pts, {"pid": p.pid, "name": query.strip(), "exe": exe})
    return best[1] if best else None


# ──────────────────────────────────────────────────────────────────────────────
# Background process candidates + termination
# ──────────────────────────────────────────────────────────────────────────────

def _my_username() -> str:
    try:
        return psutil.Process().username()
    except Exception:
        return ""


def list_termination_candidates() -> list[dict]:
    """Processes the booster can terminate, grouped by exe name.
    `checked` is the default state in the exclusion popup."""
    me = _my_username()
    fg = detect_game()
    protected: set[int] = {os.getpid()}
    if fg:
        protected |= {fg["pid"]} | _ancestors(fg["pid"]) | _descendants(fg["pid"])

    groups: dict[str, dict] = {}
    for p in psutil.process_iter(["pid", "name", "username", "memory_info"]):
        try:
            name = p.info["name"] or ""
            low = name.lower()
            exe = _exe_of(p)
            if p.pid in protected or _is_system_process(exe, name) or low in _KNOWN_GAMES:
                continue
            if me and p.info.get("username") and p.info["username"] != me:
                continue
            mem = (p.info["memory_info"].rss if p.info.get("memory_info") else 0) / (1024 * 1024)
            in_default = low in _BACKGROUND_KILL_LIST
            if not in_default and mem < 200:
                continue
            g = groups.setdefault(low, {
                "name": name, "count": 0, "ram_mb": 0.0, "checked": in_default,
                "kind": "background" if in_default else ("browser" if low in _BROWSERS else "heavy"),
            })
            g["count"] += 1
            g["ram_mb"] += mem
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    out = sorted(groups.values(), key=lambda g: (not g["checked"], -g["ram_mb"]))
    for g in out:
        g["ram_mb"] = round(g["ram_mb"], 1)
    return out


def _measure_free_ram_mb() -> float:
    return psutil.virtual_memory().available / (1024 * 1024)


def _terminate_background(exclude: set[str], protect_pids: set[int],
                          only_names: Optional[set[str]]) -> tuple[list[str], float]:
    """Terminate the agreed processes. Returns (names, MB_freed)."""
    ram_before = _measure_free_ram_mb()
    me = _my_username()
    victims: list[psutil.Process] = []
    names: dict[str, int] = {}

    for proc in psutil.process_iter(["pid", "name", "username"]):
        try:
            name = proc.info["name"] or ""
            low = name.lower()
            if proc.pid in protect_pids or low in exclude:
                continue
            if _is_system_process(_exe_of(proc), name):
                continue
            if me and proc.info.get("username") and proc.info["username"] != me:
                continue
            if only_names is not None:
                if low not in only_names:
                    continue
            elif low not in _BACKGROUND_KILL_LIST:
                continue
            victims.append(proc)
            names[name] = names.get(name, 0) + 1
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    for proc in victims:
        try:
            proc.terminate()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    _, alive = psutil.wait_procs(victims, timeout=3)
    for proc in alive:
        try:
            proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    if alive:
        psutil.wait_procs(alive, timeout=2)

    time.sleep(0.8)
    freed = max(0.0, _measure_free_ram_mb() - ram_before)
    for n, c in names.items():
        _log.info("Terminated background process: %s x%d", n, c)
    return [f"{n} x{c}" if c > 1 else n for n, c in sorted(names.items())], freed


def _trim_working_sets(skip_pids: set[int]) -> float:
    try:
        k32, psapi = ctypes.windll.kernel32, ctypes.windll.psapi
    except Exception:
        return 0.0
    before = _measure_free_ram_mb()
    me = _my_username()
    for p in psutil.process_iter(["pid", "username"]):
        try:
            if p.pid in skip_pids or (me and p.info.get("username") != me):
                continue
            h = k32.OpenProcess(0x0100 | 0x0400, False, p.pid)   # SET_QUOTA | QUERY_INFORMATION
            if h:
                psapi.EmptyWorkingSet(h)
                k32.CloseHandle(h)
        except Exception:
            continue
    time.sleep(0.4)
    return max(0.0, _measure_free_ram_mb() - before)


# ──────────────────────────────────────────────────────────────────────────────
# RESOURCE OPTIMISERS  (CPU / RAM / GPU / Disk / Network)
# ──────────────────────────────────────────────────────────────────────────────

# ── RAM: flush kernel standby list (makes Task Manager "Available" jump visibly) ──
_NTDLL_MEM_FLUSH = 5          # SystemMemoryListInformation → MemoryPurgeLowPriorityStandbyList
_NTDLL_FLUSH_ALL = 4          # MemoryPurgeStandbyList

def _flush_standby_list() -> float:
    """Flush Windows kernel standby-list pages via NtSetSystemInformation.
    Returns MB freed from standby (kernel statistic)."""
    try:
        ntdll = ctypes.windll.ntdll
        sysinfo_class = ctypes.c_ulong(80)          # SystemMemoryListInformation
        command = ctypes.c_ulong(_NTDLL_FLUSH_ALL)  # purge standby list
        ntdll.NtSetSystemInformation(sysinfo_class, ctypes.byref(command), ctypes.sizeof(command))
        _log.info("Kernel standby list flushed")
    except Exception as exc:
        _log.debug("Standby list flush: %s", exc)
    # Measure change
    try:
        vm = psutil.virtual_memory()
        return vm.available / (1024 * 1024)
    except Exception:
        return 0.0


def _empty_system_working_set() -> None:
    """Empty system (kernel) working set — reduces System process RAM."""
    try:
        ntdll = ctypes.windll.ntdll
        sysinfo_class = ctypes.c_ulong(80)
        command = ctypes.c_ulong(2)   # MemoryEmptyWorkingSetCommand
        ntdll.NtSetSystemInformation(sysinfo_class, ctypes.byref(command), ctypes.sizeof(command))
    except Exception:
        pass


# ── CPU: set all non-game/non-system processes to idle/below-normal ──
def _throttle_background_cpu(protect_pids: set[int]) -> list[tuple[int, int]]:
    """Lower non-essential processes to IDLE_PRIORITY_CLASS.
    Returns [(pid, original_nice)] for restore. Safe on W10 and W11."""
    saved: list[tuple[int, int]] = []
    me = _my_username()
    for p in psutil.process_iter(["pid", "name", "username"]):
        try:
            if p.pid in protect_pids:
                continue
            name = (p.info.get("name") or "").lower()
            if _is_system_process(_exe_of(p), name):
                continue
            if me and p.info.get("username") and p.info["username"] != me:
                continue
            orig = p.nice()
            # Only throttle processes that are currently above IDLE
            if isinstance(orig, int) and orig <= _BELOW_PRIO:
                continue
            p.nice(_IDLE_PRIO)
            saved.append((p.pid, orig))
        except (psutil.NoSuchProcess, psutil.AccessDenied, OSError):
            continue
    _log.info("Throttled %d background processes to IDLE CPU priority", len(saved))
    return saved


def _restore_background_cpu(saved: list[tuple[int, int]]) -> None:
    for pid, nice in saved:
        try:
            psutil.Process(pid).nice(nice)
        except (psutil.NoSuchProcess, psutil.AccessDenied, OSError):
            pass


# ── Disk I/O: set background processes to very-low I/O priority ──
def _throttle_background_io(protect_pids: set[int]) -> list[int]:
    """Set non-game processes to very-low I/O priority.
    Uses psutil.ionice() which works on Windows 10/11 via SetPriorityClass."""
    touched: list[int] = []
    me = _my_username()
    try:
        for p in psutil.process_iter(["pid", "name", "username"]):
            try:
                if p.pid in protect_pids:
                    continue
                name = (p.info.get("name") or "").lower()
                if _is_system_process(_exe_of(p), name):
                    continue
                if me and p.info.get("username") and p.info["username"] != me:
                    continue
                try:
                    p.ionice(_IOPRIO_VERYLOW)
                    touched.append(p.pid)
                except (psutil.AccessDenied, OSError):
                    pass
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    except Exception as exc:
        _log.debug("IO throttle: %s", exc)
    _log.info("Set %d processes to very-low I/O priority", len(touched))
    return touched


def _restore_background_io(pids: list[int]) -> None:
    for pid in pids:
        try:
            psutil.Process(pid).ionice(_IOPRIO_NORMAL)
        except Exception:
            pass


def _flush_disk_cache() -> None:
    """Flush file-system write buffers — reduces outstanding disk activity."""
    try:
        # FlushFileBuffers on volumes
        k32 = ctypes.windll.kernel32
        for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            vol = f"\\\\.\\{letter}:"
            try:
                h = k32.CreateFileW(vol, 0x40000000, 3, None, 3, 0, None)  # GENERIC_WRITE, FILE_SHARE_*
                if h and h != -1:
                    k32.FlushFileBuffers(h)
                    k32.CloseHandle(h)
            except Exception:
                pass
    except Exception:
        pass


# ── Disk: stop/pause high-disk-use Windows services temporarily ──
_HEAVY_SERVICES = [
    "WSearch",        # Windows Search indexer (notorious disk hog)
    "SysMain",        # Superfetch / memory compression (disk prefetch I/O)
    "DiagTrack",      # Connected User Experiences (telemetry / disk writes)
    "WerSvc",         # Windows Error Reporting service
    "DPS",            # Diagnostic Policy Service
    "Schedule",       # Task Scheduler — pauses background task disk hits
    "BITS",           # Background Intelligent Transfer (download service)
]


def _stop_services(names: list[str]) -> list[str]:
    """Stop services from the list. Returns names of those we actually stopped."""
    stopped: list[str] = []
    for svc in names:
        try:
            rc, out = _run(["sc", "query", svc], timeout=5)
            if rc != 0 or "RUNNING" not in out:
                continue
            rc2, _ = _run(["sc", "stop", svc], timeout=10)
            if rc2 == 0:
                stopped.append(svc)
                _log.info("Stopped service: %s", svc)
        except Exception as exc:
            _log.debug("Stop service %s: %s", svc, exc)
    return stopped


def _start_services(names: list[str]) -> None:
    for svc in names:
        try:
            _run(["sc", "start", svc], timeout=15)
            _log.info("Restarted service: %s", svc)
        except Exception:
            pass


# ── Network: remove Nagle buffering and disable throttling ──
def _apply_network_tweaks(saved: "_SavedState") -> list[str]:
    """Network-level tweaks that reduce latency for the game.
    Returns human-readable notes about what was applied."""
    notes: list[str] = []
    H, DW = winreg.HKEY_LOCAL_MACHINE, winreg.REG_DWORD
    SW = winreg.REG_SZ

    def _set(hive, path, name, val, vt=DW):
        old, otype = _reg_read(hive, path, name)
        saved.registry.append((hive, path, name, old, otype or vt))
        return _reg_write(hive, path, name, val, vt)

    # Disable multimedia-class network throttling (gives game sockets full bandwidth)
    if _set(H, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
            "NetworkThrottlingIndex", 0xFFFFFFFF):
        notes.append("Network throttling disabled — game gets full bandwidth")

    # SystemResponsiveness = 0 means no CPU slice reserved for background network tasks
    _set(H, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
         "SystemResponsiveness", 0)

    # TCP ACK frequency + no-delay for snappier packets
    _set(H, r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters",
         "TcpAckFrequency", 1)
    _set(H, r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters",
         "TCPNoDelay", 1)
    if notes:
        notes.append("TCP ACK frequency = 1 and TCP No-Delay enabled (lower ping)")

    # Disable auto-tuning throttle (can cause jitter on some ISPs)
    try:
        rc, out = _run(["netsh", "interface", "tcp", "show", "global"], timeout=5)
        if rc == 0 and "normal" in out.lower():
            _run(["netsh", "interface", "tcp", "set", "global", "autotuninglevel=highlyrestricted"], timeout=10)
            saved.registry.append((None, "netsh-autotune", "restore", "normal", 0))  # signal to restore
            notes.append("TCP auto-tuning restricted (reduces bufferbloat)")
    except Exception:
        pass

    return notes


def _restore_network_tweaks(registry: list) -> None:
    for entry in registry:
        if entry[0] is None and entry[1] == "netsh-autotune" and entry[3] == "normal":
            try:
                _run(["netsh", "interface", "tcp", "set", "global", "autotuninglevel=normal"], timeout=10)
            except Exception:
                pass



def _progress(text: str) -> None:
    bus.publish("gaming.boost_progress", {"step": text})


class GameBooster:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._state: Optional[_SavedState] = None
        self._watch_stop = threading.Event()
        self._cpu_throttled: list = []      # [(pid, orig_nice)]

    @property
    def is_active(self) -> bool:
        with self._lock:
            return self._state is not None

    def activate(
        self,
        game_name: str = "",
        game_pid: Optional[int] = None,
        exclude: Optional[set[str]] = None,
        only_names: Optional[set[str]] = None,
    ) -> BoostResult:
        game_name = (game_name or "").strip()
        if game_name.lower() == "unknown game":
            game_name = ""
        exclude = {e.lower() for e in (exclude or set())}
        notes: list[str] = []

        with self._lock:
            if self._state is not None:
                return BoostResult(
                    success=False, game_name=game_name, game_pid=game_pid,
                    ram_freed_mb=0, disk_freed_mb=0, cpu_notes=[], gpu_notes=[], net_notes=[],
                    power_plan_applied="", priority_applied=False,
                    gpu_scheduling_enabled=False, gamebar_disabled=False,
                    message="Boost already active — deactivate first.",
                )

        saved = _SavedState()

        # 0. Identify what must NOT be touched
        _progress("Scanning running processes…")
        target: Optional[dict] = None
        auto = False
        if game_pid:
            try:
                pr = psutil.Process(game_pid)
                target = {"pid": game_pid, "name": game_name or pr.name(), "exe": _exe_of(pr)}
            except Exception:
                target = None
        elif game_name:
            target = resolve_game_by_name(game_name)
        else:
            target = detect_game()
            auto = target is not None

        protect: set[int] = {os.getpid()}
        if target:
            protect |= {target["pid"]} | _ancestors(target["pid"]) | _descendants(target["pid"])

        # 1. Terminate background apps first
        _progress("Closing background apps…")
        terminated, ram_from_kill = _terminate_background(exclude, protect, only_names)

        # 2. Detect game again now that noise is gone
        _progress("Detecting game…")
        if target is None or not psutil.pid_exists(target["pid"]):
            target = resolve_game_by_name(game_name) if game_name else detect_game()
            auto = auto or (target is not None and not game_name)
        pid: Optional[int] = None
        detected_name = ""
        if target:
            pid = target["pid"]
            detected_name = _KNOWN_GAMES.get(os.path.basename(target.get("exe", "")).lower(), "") \
                or target.get("name") or ""
            saved.game_pid = pid
            saved.game_exe = target.get("exe", "")
        elif game_name:
            notes.append(f"'{game_name}' isn't running yet — system boost applied; priority set when it launches")
        else:
            notes.append("No game detected — system boost applied; any game you launch next is boosted automatically")
        shown_name = game_name or detected_name or "System-wide"

        # 3. Throttle all other processes to IDLE CPU priority
        _progress("Throttling background CPU usage…")
        try:
            self._cpu_throttled = _throttle_background_cpu(protect)
            notes.append(f"CPU: {len(self._cpu_throttled)} background processes throttled to IDLE priority")
        except Exception as exc:
            _log.warning("CPU throttle failed: %s", exc)
            self._cpu_throttled = []

        # 4. Set game to HIGH priority + HIGH I/O priority
        _progress("Setting game process to HIGH priority…")
        priority_ok = self._set_priority(saved, pid)

        # 5. Power plan
        _progress("Activating performance power plan…")
        saved.original_power_plan = _get_active_power_plan()
        guid, plan_label, created, plan_notes = ensure_performance_plan()
        notes.extend(plan_notes)
        plan_ok, plan_name = False, ""
        if guid:
            plan_ok, err = _set_power_plan(guid)
            if plan_ok:
                plan_name = plan_label
                if created:
                    saved.created_plan = guid
                _log.info("Power plan: %s (%s)", plan_label, guid)
            else:
                notes.append(f"Power plan switch failed: {err[:120]}")
        else:
            notes.append("No usable performance power plan could be created on this PC")
        try:
            batt = psutil.sensors_battery()
            if batt is not None and not batt.power_plugged:
                notes.append("Laptop is on battery — plug in for maximum performance")
        except Exception:
            pass

        # 6. GPU + GameBar + Game Mode registry
        _progress("Optimising GPU & Windows game settings…")
        H, U, DW = winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER, winreg.REG_DWORD
        gpu_notes: list[str] = []

        def _set(hive, path, name, val, vt=DW) -> bool:
            old, otype = _reg_read(hive, path, name)
            saved.registry.append((hive, path, name, old, otype or vt))
            return _reg_write(hive, path, name, val, vt)

        # HAGS requires Windows 10 2004 (build 19041) or later
        gpu_sched_ok = False
        if _HAGS_OK:
            gpu_sched_ok = _set(H, r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode", 2)
            if gpu_sched_ok:
                gpu_notes.append("Hardware GPU Scheduling enabled (reboot to fully activate)")
        else:
            gpu_notes.append(f"HAGS not available on this Windows build ({_BUILD}) — needs 19041+")
            gpu_sched_ok = False

        # GPU performance preference (NVIDIA + AMD + generic, works W10/W11)
        for path in (
            r"SOFTWARE\NVIDIA Corporation\NVControlPanel2\Client",
            r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000",
            r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0001",
        ):
            try:
                _set(H, path, "PerfLevelSrc", 0x2222)
            except Exception:
                pass

        gamebar_ok = False
        for hive, path, name, val in (
            (U, r"System\GameConfigStore",              "GameDVR_Enabled",         0),
            (U, r"Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0),
            (U, r"Software\Microsoft\GameBar",          "UseNexusForGameBarEnabled", 0),
            (U, r"Software\Microsoft\GameBar",          "AutoGameModeEnabled",      1),
        ):
            if _set(hive, path, name, val) and name != "AutoGameModeEnabled":
                gamebar_ok = True
        if gamebar_ok:
            gpu_notes.append("Xbox Game Bar & capture disabled, Game Mode enabled")

        if saved.game_exe and _set(U, _GPU_PREF_KEY, saved.game_exe, "GpuPreference=2;", winreg.REG_SZ):
            gpu_notes.append("Game pinned to high-performance GPU")

        # 7. Disk I/O: stop heavy services + set background processes to very-low I/O
        _progress("Optimising disk I/O…")
        disk_notes: list[str] = []
        disk_freed = 0.0
        try:
            stopped_svcs = _stop_services(["WSearch", "SysMain", "DiagTrack", "BITS", "WerSvc"])
            saved.stopped_services = stopped_svcs
            if stopped_svcs:
                disk_notes.append(f"Stopped disk-heavy services: {', '.join(stopped_svcs)}")
        except Exception as exc:
            _log.debug("Service stop: %s", exc)
        try:
            io_pids = _throttle_background_io(protect)
            saved.io_throttled_pids = io_pids
            disk_notes.append(f"Disk I/O: {len(io_pids)} processes throttled to very-low I/O priority")
        except Exception as exc:
            _log.debug("IO throttle: %s", exc)
        try:
            _flush_disk_cache()
            disk_notes.append("File-system write buffers flushed")
        except Exception:
            pass
        notes.extend(disk_notes)

        # 8. RAM: trim working sets + flush kernel standby list
        _progress("Freeing RAM (working sets + kernel standby list)…")
        ram_before = _measure_free_ram_mb()
        ram_freed_ws = _trim_working_sets(protect)
        _empty_system_working_set()       # shrink "System" process in Task Manager
        ram_after_ws = _measure_free_ram_mb()
        _flush_standby_list()             # this is the big one — makes available RAM jump
        time.sleep(0.5)                   # give kernel time to report the freed pages
        ram_after_flush = _measure_free_ram_mb()
        total_ram_freed = max(0.0, ram_from_kill + max(0.0, ram_after_flush - ram_before))
        _log.info("RAM freed: kill %.1f MB, WS %.1f MB, standby flush %.1f MB",
                  ram_from_kill, ram_freed_ws, max(0.0, ram_after_flush - ram_after_ws))

        # 9. Network latency tweaks
        _progress("Applying network latency tweaks…")
        net_notes: list[str] = []
        try:
            net_notes = _apply_network_tweaks(saved)
        except Exception as exc:
            _log.debug("Network tweaks: %s", exc)

        with self._lock:
            self._state = saved

        all_notes = notes + gpu_notes + net_notes
        result = BoostResult(
            success=True, game_name=shown_name, game_pid=pid,
            ram_freed_mb=round(total_ram_freed, 1),
            disk_freed_mb=round(disk_freed, 1),
            cpu_notes=[f"{len(self._cpu_throttled)} background processes throttled to IDLE CPU priority"],
            gpu_notes=gpu_notes,
            net_notes=net_notes,
            power_plan_applied=plan_name,
            priority_applied=priority_ok,
            gpu_scheduling_enabled=gpu_sched_ok,
            gamebar_disabled=gamebar_ok,
            message=f"Full system boost applied for {shown_name}",
            detected_game=detected_name, auto_detected=auto,
            terminated=terminated, notes=all_notes,
            services_stopped=saved.stopped_services,
        )
        self._start_watcher(pid)
        _progress("")
        bus.publish(Events.GAME_BOOST_CHANGED, result)
        _log.info("Boost complete: %s — RAM freed %.1f MB, %d bg procs throttled, %d svcs stopped",
                  shown_name, total_ram_freed, len(self._cpu_throttled), len(saved.stopped_services))
        return result

    def _set_priority(self, saved: _SavedState, pid: Optional[int]) -> bool:
        if pid is not None:
            try:
                p = psutil.Process(pid)
                saved.original_priority = p.nice()
                p.nice(_HIGH_PRIO)
                try:
                    p.ionice(_IOPRIO_HIGH)
                except Exception:
                    pass
                _log.info("Set PID %d to HIGH priority + HIGH I/O priority via psutil", pid)
                return True
            except Exception as exc:
                _log.debug("psutil nice failed for PID %d: %s, attempting Win32 API fallback", pid, exc)
            # Direct Windows Win32 API fallback
            try:
                PROCESS_SET_INFORMATION = 0x0200
                PROCESS_QUERY_INFORMATION = 0x0400
                HIGH_PRIORITY_CLASS = 0x00000080
                handle = ctypes.windll.kernel32.OpenProcess(
                    PROCESS_SET_INFORMATION | PROCESS_QUERY_INFORMATION, False, pid
                )
                if handle:
                    try:
                        ok = ctypes.windll.kernel32.SetPriorityClass(handle, HIGH_PRIORITY_CLASS)
                        if ok:
                            _log.info("Set PID %d to HIGH priority via Win32 SetPriorityClass", pid)
                            return True
                    finally:
                        ctypes.windll.kernel32.CloseHandle(handle)
            except Exception as exc2:
                _log.warning("Win32 priority change failed for PID %d: %s", pid, exc2)
        return len(self._cpu_throttled) > 0

    def _start_watcher(self, pid: Optional[int]) -> None:
        """Boost games launched later; auto-restore when the bound game closes."""
        self._watch_stop.set()
        self._watch_stop = stop = threading.Event()

        def _loop() -> None:
            from app.config import config
            bound = pid
            while not stop.wait(3.0):
                with self._lock:
                    st = self._state
                if st is None:
                    return
                if bound is not None:
                    if not psutil.pid_exists(bound):
                        if config.restore_on_game_close:
                            _log.info("Boosted game closed — restoring settings")
                            threading.Thread(target=self.deactivate, daemon=True).start()
                            return
                        bound = None
                    continue
                g = detect_game()
                if g:
                    bound = g["pid"]
                    st.game_pid, st.game_exe = bound, g.get("exe", "")
                    self._set_priority(st, bound)
                    if st.game_exe:
                        old, ot = _reg_read(winreg.HKEY_CURRENT_USER, _GPU_PREF_KEY, st.game_exe)
                        st.registry.append((winreg.HKEY_CURRENT_USER, _GPU_PREF_KEY, st.game_exe,
                                            old, ot or winreg.REG_SZ))
                        _reg_write(winreg.HKEY_CURRENT_USER, _GPU_PREF_KEY, st.game_exe,
                                   "GpuPreference=2;", winreg.REG_SZ)
                    _log.info("Late-launched game detected: %s (PID %d)", g["name"], bound)
                    _progress(f"Detected {g['name']} — priority set")

        threading.Thread(target=_loop, daemon=True, name="boost-watch").start()

    def deactivate(self) -> bool:
        """Restore every setting changed by activate()."""
        with self._lock:
            saved = self._state
            self._state = None
        self._watch_stop.set()
        if saved is None:
            return False

        _progress("Restoring — game priority…")
        if saved.game_pid and saved.original_priority is not None:
            try:
                psutil.Process(saved.game_pid).nice(saved.original_priority)
            except Exception as exc:
                _log.debug("Priority restore skipped: %s", exc)

        _progress("Restoring — CPU throttle on background processes…")
        _restore_background_cpu(self._cpu_throttled)
        self._cpu_throttled = []

        _progress("Restoring — I/O priority…")
        _restore_background_io(saved.io_throttled_pids)

        _progress("Restoring -- power plan...")
        if saved.original_power_plan:
            ok, _ = _set_power_plan(saved.original_power_plan)
            if ok:
                _log.info("Restored power plan: %s", saved.original_power_plan)
        # NOTE: we never delete the DWUT Extreme Performance plan -- it is permanent
        # and will be reused on the next boost without having to recreate it.

        _progress("Restoring — registry (GPU / GameBar / network)…")
        # Restore network netsh tweaks first (special entries)
        _restore_network_tweaks(saved.registry)
        for hive, path, name, value, vtype in reversed(saved.registry):
            if hive is None:
                continue  # netsh special entry already handled
            if value is not None:
                _reg_write(hive, path, name, value, vtype)
            else:
                _reg_delete(hive, path, name)

        _progress("Restoring — restarting paused services…")
        _start_services(saved.stopped_services)

        _progress("")
        bus.publish(Events.GAME_BOOST_CHANGED, None)
        _log.info("Game boost fully deactivated and all settings restored")
        return True


booster: GameBooster = GameBooster()
