"""
modules/proxy/checker.py  —  Business-grade proxy validation, v4: LATENCY + THROUGHPUT + JITTER

Four-stage pipeline:
  Stage A   TCP scan of every candidate (high concurrency, fast drop of dead hosts).
  Stage B   Protocol auto-detect + verified HTTPS on an already-open keep-alive connection.
  Stage C1  Throughput test  — download 256 KB through the proxy, measure real MB/s.
  Stage C2  Jitter measurement — 10 pings over ~4 s, report median AND std-dev (jitter).
  Stage C3  YouTube / streaming reachability.
  Stage C4  Anonymity probe (SOCKS = elite by design; HTTP probed via three fallback endpoints).

Tiers (what the user sees):
  GAMING    SOCKS5, latency ≤ 50 ms, jitter ≤ 15 ms, throughput ≥ 0.5 MB/s, YouTube OK.
  ELITE     Any protocol, latency ≤ 50 ms, jitter ≤ 20 ms, throughput ≥ 1 MB/s.
  GOOD      Latency ≤ 80 ms, throughput ≥ 0.25 MB/s — solid for streaming and browsing.
  FAIR      Latency ≤ 80 ms (or ≤ 150 ms for browsing), HTTPS verified.
  REJECTED  Failed TLS cert check, transparent IP leak, or too slow.
  DEAD      No TCP response.

The 80 ms rule is kept for the Accepted tiers (gaming/elite/good) to deliver the snappy
feel needed for real use.  The FAIR tier accepts up to 150 ms so borderline proxies that
still work for general browsing are kept visible rather than silently dropped.
"""
from __future__ import annotations

import ipaddress
import json as _json
import math
import platform
import socket
import ssl
import statistics
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from dataclasses import dataclass, field, replace
from typing import Optional

import requests

from core.events import Events, bus
from core.logger import get_logger
from modules.proxy.relay import Upstream, open_tunnel
from modules.proxy.sources import ProxyRecord

_log = get_logger(__name__)

DEFAULT_MAX_LATENCY_MS = 80.0
DEFAULT_TARGET = 200           # collect this many good proxies then stop

_SOCKS_PORTS = {1080, 1081, 1085, 1086, 4145, 4153, 5678, 9050, 9051, 9150,
                10800, 10801, 7890, 7891, 20000}
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
       "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
_DATACENTER_ASNS = {
    "AS14618", "AS16509", "AS15169", "AS8075", "AS20473", "AS14061",
    "AS16276", "AS24940", "AS63949", "AS9009", "AS60781", "AS197540",
}
_REVEALING_HEADERS = {
    "x-forwarded-for", "x-real-ip", "via", "proxy-connection",
    "x-proxy-id", "forwarded",
}

# Targets: (host, path).  Tried in order; first success wins.
_TARGETS = [
    ("www.cloudflare.com",  "/cdn-cgi/trace"),
    ("one.one.one.one",     "/cdn-cgi/trace"),
    ("www.google.com",      "/generate_204"),
]

# Throughput test: download this many bytes through the proxy and measure real speed.
# Cloudflare's speed endpoint is reliably fast from almost everywhere.
_SPEED_HOST  = "speed.cloudflare.com"
_SPEED_PATH  = "/__down?bytes=262144"   # 256 KB
_SPEED_BYTES = 262144

_CC = {
    "US": "United States", "GB": "United Kingdom", "DE": "Germany",
    "FR": "France",        "NL": "Netherlands",    "CA": "Canada",
    "RU": "Russia",        "CN": "China",          "JP": "Japan",
    "KR": "South Korea",   "IN": "India",          "BR": "Brazil",
    "SG": "Singapore",     "HK": "Hong Kong",      "TW": "Taiwan",
    "AU": "Australia",     "ID": "Indonesia",       "TH": "Thailand",
    "VN": "Vietnam",       "TR": "Turkey",          "PL": "Poland",
    "UA": "Ukraine",       "IT": "Italy",           "ES": "Spain",
    "SE": "Sweden",        "CH": "Switzerland",     "AT": "Austria",
    "CZ": "Czechia",       "RO": "Romania",         "BG": "Bulgaria",
    "FI": "Finland",       "NO": "Norway",          "DK": "Denmark",
    "IE": "Ireland",       "PT": "Portugal",        "GR": "Greece",
    "HU": "Hungary",       "MX": "Mexico",          "AR": "Argentina",
    "CL": "Chile",         "CO": "Colombia",        "PE": "Peru",
    "ZA": "South Africa",  "EG": "Egypt",           "NG": "Nigeria",
    "IL": "Israel",        "AE": "UAE",             "SA": "Saudi Arabia",
    "IR": "Iran",          "PK": "Pakistan",        "BD": "Bangladesh",
    "PH": "Philippines",   "MY": "Malaysia",        "NZ": "New Zealand",
    "BE": "Belgium",       "LU": "Luxembourg",
}


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class CheckResult:
    proxy:               ProxyRecord
    tcp_ok:              bool          = False
    tcp_latency_ms:      Optional[float] = None   # final median ping through proxy
    rtt_ms:              Optional[float] = None   # raw TCP connect time (Stage A)
    protocol_ok:         bool          = False
    https_ok:            bool          = False
    browse_ok:           bool          = False
    youtube_ok:          bool          = False
    secure:              bool          = False
    exit_ip:             Optional[str] = None
    is_transparent:      bool          = False
    is_pooled_candidate: bool          = False
    country:             Optional[str] = None
    country_code:        Optional[str] = None
    isp:                 Optional[str] = None
    asn:                 Optional[str] = None
    timezone:            Optional[str] = None
    anonymity:           Optional[str] = None
    revealing_headers:   list          = field(default_factory=list)
    pool_flags:          list          = field(default_factory=list)
    # new quality fields
    throughput_mbps:     Optional[float] = None   # real download speed in MB/s
    jitter_ms:           Optional[float] = None   # std-dev of pings
    score:               int           = 0
    tier:                str           = "dead"
    reject_reason:       Optional[str] = None
    _best_up:            Optional[Upstream] = None

    def update_proxy(self) -> ProxyRecord:
        return replace(
            self.proxy, status=self.tier,
            latency_ms=self.tcp_latency_ms,
            country=self.country, country_code=self.country_code,
            isp=self.isp, asn=self.asn, anonymity=self.anonymity,
            exit_ip=self.exit_ip, is_pooled=bool(self.pool_flags),
            score=self.score, youtube_ok=self.youtube_ok,
        )


STATS: dict = {}


# ---------------------------------------------------------------------------
# TLS context — certifi bundle on top of system store
# ---------------------------------------------------------------------------
_ctx: Optional[ssl.SSLContext] = None
_ctx_lock = threading.Lock()


def _tls_ctx() -> ssl.SSLContext:
    global _ctx
    with _ctx_lock:
        if _ctx is None:
            c = ssl.create_default_context()
            try:
                import certifi
                c.load_verify_locations(cafile=certifi.where())
            except Exception:
                pass
            c.minimum_version = ssl.TLSVersion.TLSv1_2
            _ctx = c
        return _ctx


# ---------------------------------------------------------------------------
# Real IP / geolocation
# ---------------------------------------------------------------------------
_real_ip_cache: Optional[str] = None
_real_ip_lock = threading.Lock()


def get_my_ip() -> Optional[str]:
    global _real_ip_cache
    with _real_ip_lock:
        if _real_ip_cache is None:
            s = requests.Session()
            s.trust_env = False
            for url in ("https://api.ipify.org", "https://api.my-ip.io/ip",
                        "https://ifconfig.me/ip", "https://icanhazip.com"):
                try:
                    ip = s.get(url, timeout=6).text.strip()
                    ipaddress.ip_address(ip)
                    _real_ip_cache = ip
                    break
                except Exception:
                    continue
        return _real_ip_cache


_geo_cache: dict = {}
_geo_lock = threading.Lock()


def _geo_quick(ip: str) -> dict:
    with _geo_lock:
        if ip in _geo_cache:
            return _geo_cache[ip]
    try:
        s = requests.Session()
        s.trust_env = False
        d = s.get(
            f"http://ip-api.com/json/{ip}?fields=country,countryCode,isp,org,as,timezone,status",
            timeout=3.0,
        ).json()
        if d.get("status") == "success":
            with _geo_lock:
                _geo_cache[ip] = d
            return d
    except Exception:
        pass
    return {}


# ---------------------------------------------------------------------------
# Stage A: TCP scan
# ---------------------------------------------------------------------------

def _tcp_timeout(limit_ms: Optional[float]) -> float:
    if not limit_ms or limit_ms >= 9999:
        return 2.5
    return max(0.35, min(2.5, limit_ms * 2.8 / 1000.0))


def _tcp_rtt(proxy: ProxyRecord, limit_ms: Optional[float]) -> Optional[float]:
    """Best of two TCP connect times (ms).  None = unreachable."""
    timeout = _tcp_timeout(limit_ms)
    best = None
    for _ in range(2):
        t0 = time.perf_counter()
        try:
            with socket.create_connection((proxy.ip, proxy.port), timeout=timeout):
                pass
        except OSError:
            return best
        rtt = (time.perf_counter() - t0) * 1000.0
        best = rtt if best is None else min(best, rtt)
        if not limit_ms or limit_ms >= 9999 or best <= limit_ms * 0.5 or best > limit_ms * 1.8:
            break
    return best


# ---------------------------------------------------------------------------
# Stage B / C: keep-alive HTTPS session through the proxy
# ---------------------------------------------------------------------------

class _Fail(Exception):
    def __init__(self, kind: str, msg: str = ""):
        super().__init__(msg or kind)
        self.kind = kind  # "handshake" | "refused" | "cert" | "io"


def _read_response(tls: ssl.SSLSocket, buf: bytearray) -> tuple:
    while b"\r\n\r\n" not in buf:
        chunk = tls.recv(8192)
        if not chunk:
            raise _Fail("io", "connection closed")
        buf += chunk
        if len(buf) > 65536:
            raise _Fail("io", "oversized header")
    head, _, rest = bytes(buf).partition(b"\r\n\r\n")
    lines = head.split(b"\r\n")
    try:
        status = int(lines[0].split()[1])
    except Exception:
        raise _Fail("io", "bad HTTP reply")
    clen = 0
    for ln in lines[1:]:
        k, _, v = ln.partition(b":")
        if k.strip().lower() == b"content-length":
            try:
                clen = int(v.strip())
            except ValueError:
                clen = 0
    body = bytearray(rest)
    while len(body) < clen:
        chunk = tls.recv(8192)
        if not chunk:
            break
        body += chunk
    del buf[:]
    buf += body[clen:]
    return status, bytes(body[:clen])


def _op_timeout(limit_ms: Optional[float]) -> float:
    """Per-step socket timeout — must cover TLS handshake + one response."""
    if not limit_ms or limit_ms >= 9999:
        return 9.0
    # At 80 ms limit → 4.5 s per step.  Enough for TLS handshake on any real proxy.
    return max(4.0, min(12.0, limit_ms * 56 / 1000.0))


def _session(up: Upstream, host: str, path: str, n: int, timeout: float) -> dict:
    """Tunnel → verified TLS → n keep-alive requests.
    Returns {status, body, pings:[ms...], first_ms, tls}.
    pings EXCLUDE the first request (handshake cost); they are genuine round-trips."""
    t0 = time.perf_counter()
    try:
        raw = open_tunnel(up, host, 443, timeout)
    except Exception as exc:
        msg = str(exc)
        raise _Fail("refused" if msg.startswith("CONNECT refused") else "handshake", msg)
    tls = None
    try:
        raw.settimeout(timeout)
        try:
            tls = _tls_ctx().wrap_socket(raw, server_hostname=host)
        except ssl.SSLCertVerificationError as exc:
            raise _Fail("cert", str(exc))
        except (ssl.SSLError, OSError) as exc:
            raise _Fail("io", f"TLS: {exc}")
        tls.settimeout(timeout)
        req = (f"GET {path} HTTP/1.1\r\nHost: {host}\r\n"
               f"User-Agent: {_UA}\r\nAccept: */*\r\nConnection: keep-alive\r\n\r\n").encode()
        buf, pings, status, body = bytearray(), [], 0, b""
        first_ms = None
        for i in range(max(1, n)):
            t1 = time.perf_counter()
            tls.sendall(req)
            st, bd = _read_response(tls, buf)
            dt = (time.perf_counter() - t1) * 1000.0
            if i == 0:
                status, body = st, bd
                first_ms = (time.perf_counter() - t0) * 1000.0
                if status >= 500:
                    raise _Fail("io", f"HTTP {status}")
            else:
                pings.append(dt)
        return {"status": status, "body": body.decode("utf-8", "replace"),
                "pings": pings, "first_ms": first_ms, "tls": tls.version()}
    except (OSError, ssl.SSLError) as exc:
        raise _Fail("io", str(exc))
    finally:
        for s in (tls, raw):
            try:
                if s:
                    s.close()
            except OSError:
                pass


def _trace(body: str) -> dict:
    d = {}
    for line in body.splitlines():
        if "=" in line:
            k, _, v = line.partition("=")
            d[k.strip()] = v.strip()
    return d


def _protocol_order(proxy: ProxyRecord) -> list:
    base = (["socks5", "socks4", "http"] if proxy.port in _SOCKS_PORTS
            else ["http", "socks5", "socks4"])
    order = []
    for p in [proxy.protocol, *getattr(proxy, "hints", ()), *base]:
        if p in ("http", "socks4", "socks5") and p not in order:
            order.append(p)
    return order


# ---------------------------------------------------------------------------
# Stage B: protocol detect + HTTPS verify (2 pings — faster verify pool)
# ---------------------------------------------------------------------------

def _probe(proxy: ProxyRecord, limit_ms: Optional[float],
           stop: Optional[threading.Event], pings: int = 2) -> CheckResult:
    r = CheckResult(proxy=proxy, tcp_ok=True)
    tmo = _op_timeout(limit_ms)
    for proto in _protocol_order(proxy):
        if stop is not None and stop.is_set():
            return r
        up = Upstream(proxy.ip, proxy.port, proto)
        for host, path in _TARGETS:
            try:
                s = _session(up, host, path, pings, tmo)
            except _Fail as f:
                if f.kind == "cert":
                    r.protocol_ok, r.tier = True, "rejected"
                    r.reject_reason = "intercepts HTTPS — certificate not trusted"
                    r.proxy = replace(proxy, protocol=proto)
                    return r
                if f.kind in ("handshake", "refused"):
                    if f.kind == "refused":
                        r.protocol_ok, r.reject_reason = True, "refuses HTTPS tunnels"
                    break
                continue
            tr = _trace(s["body"]) if s["status"] == 200 and "ip=" in s["body"] else {}
            ok_content = bool(tr) or (s["status"] == 204 and host == "www.google.com")
            r.proxy = replace(proxy, protocol=proto)
            r.protocol_ok = r.https_ok = r.browse_ok = True
            r.secure = ok_content and bool(s.get("tls"))
            r._best_up = up
            r.exit_ip = tr.get("ip")
            if tr.get("loc"):
                r.country_code = tr["loc"]
            if s["pings"]:
                r.tcp_latency_ms = statistics.median(s["pings"])
            r.reject_reason = None if r.secure else "response did not look genuine"
            return r
    r.tier = "rejected" if r.protocol_ok else "dead"
    return r


# ---------------------------------------------------------------------------
# Stage C1: real throughput test through the proxy
# ---------------------------------------------------------------------------

def _throughput(r: CheckResult, timeout: float = 10.0) -> Optional[float]:
    """Download 256 KB through the proxy.  Returns MB/s or None on failure."""
    up = r._best_up
    if up is None:
        return None
    try:
        raw = open_tunnel(up, _SPEED_HOST, 443, timeout)
        try:
            raw.settimeout(timeout)
            tls = _tls_ctx().wrap_socket(raw, server_hostname=_SPEED_HOST)
            tls.settimeout(timeout)
            req = (f"GET {_SPEED_PATH} HTTP/1.1\r\nHost: {_SPEED_HOST}\r\n"
                   f"User-Agent: {_UA}\r\nAccept: */*\r\nConnection: close\r\n\r\n").encode()
            tls.sendall(req)
            # skip headers
            hbuf = b""
            while b"\r\n\r\n" not in hbuf:
                c = tls.recv(4096)
                if not c:
                    return None
                hbuf += c
                if len(hbuf) > 32768:
                    return None
            # read body
            t0 = time.perf_counter()
            received = len(hbuf.split(b"\r\n\r\n", 1)[1])
            while received < _SPEED_BYTES:
                chunk = tls.recv(16384)
                if not chunk:
                    break
                received += len(chunk)
            elapsed = time.perf_counter() - t0
            if elapsed < 0.01 or received < 32768:
                return None
            return (received / elapsed) / (1024 * 1024)   # MB/s
        finally:
            try:
                raw.close()
            except OSError:
                pass
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Stage C2: jitter — 10 pings, report median AND std-dev
# ---------------------------------------------------------------------------

def _measure_jitter(r: CheckResult, n: int = 10,
                    timeout: float = 8.0) -> tuple[Optional[float], Optional[float]]:
    """Returns (median_ms, jitter_ms=std_dev) or (None, None) on failure."""
    up = r._best_up
    if up is None:
        return None, None
    for host, path in _TARGETS[:2]:
        try:
            s = _session(up, host, path, n + 1, timeout)
        except _Fail:
            continue
        pings = s["pings"]
        if len(pings) < 3:
            continue
        med = statistics.median(pings)
        jitter = statistics.stdev(pings) if len(pings) >= 2 else 0.0
        return med, jitter
    return None, None


# ---------------------------------------------------------------------------
# Stage C3: anonymity probe (three fallback endpoints)
# ---------------------------------------------------------------------------

_ANON_ENDPOINTS = [
    ("azenv.net",    80, b"GET / HTTP/1.1\r\nHost: azenv.net\r\nConnection: close\r\n\r\n"),
    ("httpbin.org",  80, b"GET /headers HTTP/1.1\r\nHost: httpbin.org\r\nConnection: close\r\n\r\n"),
    ("eth0.me",      80, b"GET /headers HTTP/1.1\r\nHost: eth0.me\r\nConnection: close\r\n\r\n"),
]


def _anonymity(proxy: ProxyRecord, my_ip: Optional[str]) -> tuple:
    if proxy.protocol != "http":
        return "elite", []     # SOCKS adds no headers by design
    for ahost, aport, areq in _ANON_ENDPOINTS:
        try:
            with socket.create_connection((proxy.ip, proxy.port), timeout=4) as s:
                s.settimeout(4)
                s.sendall(areq)
                data = b""
                while len(data) < 16384:
                    c = s.recv(4096)
                    if not c:
                        break
                    data += c
            body = data.partition(b"\r\n\r\n")[2] if b"\r\n\r\n" in data else data
            text = body.decode("utf-8", "replace").lower()
            found = [h for h in _REVEALING_HEADERS if h in text]
            if my_ip and my_ip in text:
                return "transparent", found
            return ("anonymous" if found else "elite"), found
        except Exception:
            continue
    return "anonymous", []


# ---------------------------------------------------------------------------
# Stage C4: YouTube + geo + full finish
# ---------------------------------------------------------------------------

def _finish(r: CheckResult, my_ip: Optional[str], with_youtube: bool = True) -> CheckResult:
    up = r._best_up
    if r.exit_ip and my_ip and r.exit_ip == my_ip:
        r.is_transparent = True
        r.tier, r.reject_reason, r.score = "rejected", "transparent — leaks your real IP", 0
        return r
    if with_youtube and up is not None:
        try:
            s = _session(up, "www.youtube.com", "/generate_204", 1, 6.0)
            r.youtube_ok = s["status"] == 204
        except _Fail:
            r.youtube_ok = False
    geo = _geo_quick(r.exit_ip or r.proxy.ip)
    r.country_code = geo.get("countryCode") or r.country_code
    r.country = geo.get("country") or _CC.get(r.country_code or "", r.country_code)
    r.isp = geo.get("isp") or geo.get("org")
    r.asn = geo.get("as")
    r.timezone = geo.get("timezone")
    r.anonymity, r.revealing_headers = _anonymity(r.proxy, my_ip)
    if r.anonymity == "transparent":
        r.is_transparent = True
        r.tier, r.reject_reason, r.score = "rejected", "transparent — forwards your real IP", 0
        return r
    flags = []
    if r.exit_ip and r.exit_ip != r.proxy.ip:
        r.is_pooled_candidate = True
        flags.append(f"exit IP ({r.exit_ip}) ≠ proxy IP ({r.proxy.ip})")
    if any(dc in (r.asn or "") for dc in _DATACENTER_ASNS):
        flags.append(f"datacenter ASN ({r.asn})")
    r.pool_flags = flags
    r.score = _score(r)
    r.tier = _tier(r)
    return r


# ---------------------------------------------------------------------------
# Scoring + tiering (throughput and jitter now matter)
# ---------------------------------------------------------------------------

def _score(r: CheckResult) -> int:
    p  = r.tcp_latency_ms   or 9999.0
    jt = r.jitter_ms        or 999.0
    tp = r.throughput_mbps  or 0.0

    # Latency (0–35 pts)
    s = (35 if p <= 20  else 30 if p <= 35 else 25 if p <= 50
         else 18 if p <= 80 else 10 if p <= 120 else 4)

    # Throughput (0–25 pts)  — real download speed matters for streaming/gaming
    s += (25 if tp >= 3.0  else 20 if tp >= 1.5 else 14 if tp >= 0.5
          else 8  if tp >= 0.1 else 2)

    # Jitter (0–15 pts) — critical for gaming; low variance = stable connection
    s += (15 if jt <= 5   else 12 if jt <= 10 else 8 if jt <= 15
          else 4  if jt <= 30  else 0)

    # Verification bonuses
    s += 10 if r.secure      else 0
    s += 8  if r.youtube_ok  else 0
    s += {"elite": 8, "anonymous": 4}.get(r.anonymity or "", 1)
    s += {"socks5": 6, "socks4": 3}.get(r.proxy.protocol, 2)
    if not r.pool_flags: s += 2
    if r.country:         s += 1

    return min(100, s)


def _tier(r: CheckResult) -> str:
    if r.is_transparent:
        return "rejected"
    if not r.browse_ok and not r.secure and not r.tcp_ok:
        return "dead"

    p  = r.tcp_latency_ms  or 9999.0
    jt = r.jitter_ms       or 999.0
    tp = r.throughput_mbps or 0.0
    s5 = r.proxy.protocol in ("socks5", "socks4")

    # Gaming tier: SOCKS5/SOCKS4, fast and stable for games, Discord, and streaming
    if s5 and p <= 80:
        if p <= 50 and (r.youtube_ok or tp >= 0.5):
            return "gaming"
        return "excellent" if p <= 55 else "good"

    # Elite / Excellent: very fast (<= 50ms)
    if p <= 50 and (r.browse_ok or r.secure):
        return "excellent"

    # Good: solid for streaming, browsing and general use (<= 80ms)
    if p <= 80 and (r.browse_ok or r.secure):
        return "good"

    # Fair: usable for general browsing (<= 150ms)
    if p <= 150 and (r.browse_ok or r.secure):
        return "fair"

    return "rejected"


# ---------------------------------------------------------------------------
# Single-proxy entry (tests / UI "check one" paths)
# ---------------------------------------------------------------------------

def check_one(proxy: ProxyRecord, my_ip: Optional[str] = None,
              stop_event: Optional[threading.Event] = None,
              max_latency_ms: Optional[float] = None) -> CheckResult:
    rtt = _tcp_rtt(proxy, max_latency_ms)
    if rtt is None:
        return CheckResult(proxy=proxy)
    r = _probe(proxy, max_latency_ms, stop_event)
    r.rtt_ms = rtt
    if r.browse_ok and r.secure:
        tp = _throughput(r)
        if tp is not None:
            r.throughput_mbps = tp
        med, jt = _measure_jitter(r)
        if med is not None:
            r.tcp_latency_ms, r.jitter_ms = med, jt
        _finish(r, my_ip)
    return r


# ---------------------------------------------------------------------------
# Re-verify before connect (always check the proxy is alive right now)
# ---------------------------------------------------------------------------

def verify_live(proxy: ProxyRecord, timeout_ms: float = 2000.0) -> bool:
    """Quick liveness check — used by connect_best before actually connecting."""
    rtt = _tcp_rtt(proxy, timeout_ms)
    if rtt is None:
        return False
    try:
        r = _probe(proxy, timeout_ms, None, pings=1)
        return r.browse_ok and r.secure
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Full pipeline
# ---------------------------------------------------------------------------

def check_all(
    proxies: list,
    max_workers: int = 300,
    region_filter: Optional[str] = None,
    protocol_filter: Optional[str] = None,
    min_anonymity: Optional[str] = None,
    max_latency_ms: Optional[float] = DEFAULT_MAX_LATENCY_MS,
    stop_event: Optional[threading.Event] = None,
    target: int = DEFAULT_TARGET,
    **_ignored,
) -> list:
    limit = None if (max_latency_ms is None or max_latency_ms >= 9999) else float(max_latency_ms)
    _ANON = {"transparent": 0, "anonymous": 1, "elite": 2}
    stop = stop_event or threading.Event()

    try:
        from modules.cleaner.speed import is_low_end
        low = is_low_end()
    except Exception:
        low = False

    scan_workers    = max(60, min(int(max_workers), 200 if low else 500))
    verify_workers  = max(12, min(int(max_workers) // 3, 50  if low else 120))
    measure_workers = 8  if low else 16   # throughput + jitter in parallel

    queue = sorted(proxies, key=lambda p: (-getattr(p, "votes", 1), getattr(p, "tier_rank", 1)))
    total = len(queue)
    my_ip = get_my_ip()
    t_start = time.monotonic()

    stats = {
        "total": total, "scanned": 0, "reachable": 0, "fast": 0,
        "verified": 0, "accepted": 0, "best_rtt": None,
        "fallback_ping": None, "limit": limit, "stage": "scan",
    }
    STATS.clear()
    STATS.update(stats)
    lock = threading.Lock()
    results: list = []
    survivors: list = []

    _log.info(
        "Proxy check: %d candidates, limit %s ms, workers scan/verify/measure = %d/%d/%d",
        total, limit, scan_workers, verify_workers, measure_workers,
    )

    def progress(stage: str, done: int, tot: int, msg: str) -> None:
        stats["stage"] = stage
        STATS.update(stats)
        bus.publish(Events.PROXY_CHECK_PROGRESS, {
            "completed": done, "total": tot, "working": stats["accepted"],
            "stage": stage, "msg": msg, "last_proxy": "", "last_tier": "",
        })

    # ── Stage A: TCP scan ────────────────────────────────────────────────────
    def scan_one(p: ProxyRecord):
        if stop.is_set():
            return None
        rtt = _tcp_rtt(p, limit)
        with lock:
            stats["scanned"] += 1
            if rtt is not None:
                stats["reachable"] += 1
                stats["best_rtt"] = rtt if stats["best_rtt"] is None else min(stats["best_rtt"], rtt)
        if rtt is None:
            return None
        return p, rtt

    # ── Stages B + C: verify → throughput + jitter → finish ─────────────────
    accepted_lock = threading.Lock()
    measure_pool  = ThreadPoolExecutor(max_workers=measure_workers, thread_name_prefix="px-measure")
    verify_pool   = ThreadPoolExecutor(max_workers=verify_workers,  thread_name_prefix="px-verify")
    measure_futs: list = []
    verify_futs: list = []
    verified = [0]

    def passes_filters(r: CheckResult) -> bool:
        if region_filter and region_filter.lower() != "any":
            if not r.country or r.country.lower() != region_filter.lower():
                return False
        if min_anonymity and min_anonymity.lower() != "any":
            if _ANON.get((r.anonymity or "").lower(), -1) < _ANON.get(min_anonymity.lower(), 0):
                return False
        if protocol_filter and protocol_filter.lower() != "any":
            if r.proxy.protocol.lower() != protocol_filter.lower():
                return False
        return True

    def measure_task(r: CheckResult):
        """Stage C: throughput + jitter + full finish for proxies that passed Stage B."""
        if stop.is_set():
            return

        # C1: throughput
        tp = _throughput(r, timeout=8.0)
        if tp is not None:
            r.throughput_mbps = tp

        # C2: jitter
        med, jt = _measure_jitter(r, n=8, timeout=7.0)
        if med is not None:
            r.tcp_latency_ms = med
            r.jitter_ms = jt

        # C3 + C4: YouTube, anonymity, geo
        _finish(r, my_ip, with_youtube=True)

        if r.tier in ("gaming", "excellent", "good", "fair") and passes_filters(r):
            # Re-emit enriched result live to update row in UI
            bus.publish(Events.PROXY_RESULT_BATCH, [r])

    def verify_task(item):
        p, rtt = item
        if stop.is_set():
            return
        r = _probe(p, limit, stop)
        r.rtt_ms = rtt
        verified[0] += 1
        if not r.browse_ok or not r.secure:
            return
        stats["verified"] += 1

        # Quick finish: evaluate tier & geo immediately so it shows up live in UI right away
        _finish(r, my_ip, with_youtube=False)

        if r.tier in ("gaming", "excellent", "good", "fair") and passes_filters(r):
            with accepted_lock:
                if r not in results:
                    results.append(r)
                    stats["accepted"] = len(results)
                    if len(results) >= target:
                        stop.set()
            # EMIT WORKING PROXY LIVE IMMEDIATELY AS FOUND!
            bus.publish(Events.PROXY_RESULT_BATCH, [r])
            measure_futs.append(measure_pool.submit(measure_task, r))

    pool = ThreadPoolExecutor(max_workers=scan_workers, thread_name_prefix="px-scan")
    try:
        futs = [pool.submit(scan_one, p) for p in queue]
        pending = set(futs)
        last = 0.0
        while pending and not stop.is_set():
            done, pending = wait(pending, timeout=0.25, return_when=FIRST_COMPLETED)
            for f in done:
                try:
                    res = f.result()
                except Exception:
                    res = None
                if res is not None:
                    p, rtt = res
                    if limit is None or rtt <= limit * 1.2:
                        survivors.append((p, rtt))
                        # PIPELINE IMMEDIATELY: submit to verify without waiting for scan to finish!
                        verify_futs.append(verify_pool.submit(verify_task, (p, rtt)))
                    elif rtt <= limit * 4:
                        with lock:
                            stats.setdefault("_slow", []).append((p, rtt))
            now = time.monotonic()
            if now - last > 0.3:
                last = now
                stats["fast"] = len(survivors)
                progress("scan", stats["scanned"], total,
                         f"Scanning {stats['scanned']:,}/{total:,}  —  {stats['accepted']} working live ({len(survivors)} fast)")
        for f in pending:
            f.cancel()
    finally:
        pool.shutdown(wait=False, cancel_futures=True)

    stats["fast"] = len(survivors)
    _log.info("Stage A: %d/%d reachable, %d in budget (%.1fs)",
              stats["reachable"], total, len(survivors), time.monotonic() - t_start)

    try:
        pending_v = set(verify_futs)
        last = 0.0
        while pending_v and not stop.is_set():
            done, pending_v = wait(pending_v, timeout=0.25, return_when=FIRST_COMPLETED)
            now = time.monotonic()
            if now - last > 0.3:
                last = now
                progress("verify", verified[0], max(1, len(survivors)),
                         f"Verifying {verified[0]:,}/{max(1, len(survivors)):,}  —  {stats['accepted']} working live")
        for f in pending_v:
            f.cancel()
        wait([f for f in measure_futs], timeout=None if not stop.is_set() else 8)
    finally:
        verify_pool.shutdown(wait=False, cancel_futures=True)
        measure_pool.shutdown(wait=True, cancel_futures=True)

    # Fallback: if nothing passed the budget, find out what the best working proxy was
    if limit is not None and stats["accepted"] < 3 and stats["fallback_ping"] is None:
        slow = sorted(stats.get("_slow", []), key=lambda x: x[1])[:30]
        if slow:
            progress("fallback", 0, len(slow), "Nothing under the limit — checking the fastest slower proxies for a hint…")
            with ThreadPoolExecutor(max_workers=min(15, len(slow))) as fp:
                def fb(it):
                    r = _probe(it[0], limit * 4, None, pings=1)
                    return r.tcp_latency_ms if r.browse_ok and r.secure else None
                for v in fp.map(fb, slow):
                    if v is not None and (stats["fallback_ping"] is None
                                         or v < stats["fallback_ping"]):
                        stats["fallback_ping"] = v

    stats.pop("_slow", None)
    results.sort(key=lambda r: (r.tcp_latency_ms or 9999))
    stats["elapsed"] = round(time.monotonic() - t_start, 1)
    STATS.clear()
    STATS.update(stats)
    _log.info(
        "Proxy check done: %d accepted of %d (%d fast, %d verified) in %.1fs",
        len(results), total, stats["fast"], stats["verified"], stats["elapsed"],
    )
    bus.publish(Events.PROXY_CHECK_DONE, results)
    return results
