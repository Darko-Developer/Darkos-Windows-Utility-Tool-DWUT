"""
modules/proxy/connect.py — Set / clear the Windows system HTTP/HTTPS proxy.

Uses the WinInet registry key so every WinInet-aware app (Chrome, Edge, curl,
requests, IE, etc.) picks it up without a restart.

Smart connect_best():
  1. Prefers Gaming-tier SOCKS5 proxies (needed for games and real-time apps).
  2. Falls back to Elite, then Good, then Fair in that order.
  3. Re-verifies the chosen proxy is actually alive right NOW before writing
     the registry — dead proxies from a stale scan are silently skipped and
     the next-best candidate is tried instead.
  4. Reports throughput and jitter alongside latency in the status message.
"""
from __future__ import annotations

import threading
import winreg
from typing import Optional

from core.logger import get_logger

_log = get_logger(__name__)

_REG_PATH = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"


def _reg_set(name: str, value, val_type=winreg.REG_SZ) -> bool:
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_PATH, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, name, 0, val_type, value)
        winreg.CloseKey(key)
        return True
    except Exception as exc:
        _log.warning("reg_set %s: %s", name, exc)
        return False


def _notify_wininet() -> None:
    """Flush WinInet proxy cache so settings are picked up immediately."""
    try:
        import ctypes
        wininet = ctypes.windll.wininet
        wininet.InternetSetOptionW(0, 39, 0, 0)  # INTERNET_OPTION_SETTINGS_CHANGED
        wininet.InternetSetOptionW(0, 37, 0, 0)  # INTERNET_OPTION_REFRESH
    except Exception as exc:
        _log.debug("WinInet refresh failed (non-fatal): %s", exc)


def enable_proxy(host: str, port: int, protocol: str = "http") -> tuple[bool, str]:
    """
    Write the system proxy to the WinInet registry.

    SOCKS proxies MUST use 'socks=' prefix — without it Windows sends HTTP
    CONNECT to a SOCKS daemon, which immediately resets the connection.
    HTTP proxies cover both http:// and https:// traffic.
    """
    proto = (protocol or "http").lower()
    if proto in ("socks", "socks4", "socks5"):
        proxy_str = f"socks={host}:{port}"
    else:
        proxy_str = f"http={host}:{port};https={host}:{port}"

    ok1 = _reg_set("ProxyEnable", 1, winreg.REG_DWORD)
    ok2 = _reg_set("ProxyServer", proxy_str)
    # Bypass local ranges — games/apps talking to local servers still work
    _reg_set("ProxyOverride",
             "localhost;127.*;10.*;172.16.*;172.17.*;172.18.*;172.19.*;172.20.*;172.21.*;"
             "172.22.*;172.23.*;172.24.*;172.25.*;172.26.*;172.27.*;172.28.*;172.29.*;"
             "172.30.*;172.31.*;192.168.*;<local>")
    _notify_wininet()

    if ok1 and ok2:
        _log.info("System proxy enabled: %s (%s)", proxy_str, proto)
        return True, f"System proxy set → {proxy_str}"
    return False, "Failed to write proxy settings to registry"


def disable_proxy() -> tuple[bool, str]:
    ok = _reg_set("ProxyEnable", 0, winreg.REG_DWORD)
    _notify_wininet()
    if ok:
        _log.info("System proxy disabled")
        return True, "System proxy disabled — direct internet restored"
    return False, "Failed to disable proxy in registry"


def get_active_proxy() -> Optional[str]:
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _REG_PATH, 0, winreg.KEY_READ)
        enabled, _ = winreg.QueryValueEx(key, "ProxyEnable")
        if not enabled:
            winreg.CloseKey(key)
            return None
        server, _ = winreg.QueryValueEx(key, "ProxyServer")
        winreg.CloseKey(key)
        return server or None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Smart connect — re-verify + prefer gaming/elite tiers
# ---------------------------------------------------------------------------

# Tier priority order for selecting the best proxy
_TIER_RANK = {"gaming": 0, "excellent": 1, "good": 2, "fair": 3}


def connect_best(results: list, max_candidates: int = 15) -> dict:
    """
    Pick the best verified-live proxy from a list of CheckResult objects.

    Process:
      1. Sort candidates by tier rank, then score descending, then latency.
      2. For each candidate (up to max_candidates) call verify_live().
      3. Connect to the first one that answers.
      4. Return {ok, message, ip, port, protocol, tier, latency_ms, throughput_mbps, jitter_ms}.
    """
    from modules.proxy.checker import verify_live

    if not results:
        return {"ok": False, "message": "No proxies available — run Check All first."}

    # Filter to working tiers only
    working = [r for r in results if r.tier in _TIER_RANK]
    if not working:
        return {"ok": False, "message": "No working proxies found — run Check All and wait for results."}

    # Sort: best tier first, then highest score, then lowest latency
    working.sort(key=lambda r: (
        _TIER_RANK.get(r.tier, 99),
        -(r.score or 0),
        r.tcp_latency_ms or 9999,
    ))

    candidates = working[:max_candidates]
    _log.info("connect_best: trying %d candidates (best tier=%s, lat=%.0fms)",
              len(candidates), candidates[0].tier, candidates[0].tcp_latency_ms or 0)

    for r in candidates:
        _log.debug("connect_best: verifying %s:%d (%s tier=%s)",
                   r.proxy.ip, r.proxy.port, r.proxy.protocol, r.tier)
        if not verify_live(r.proxy, timeout_ms=3000.0):
            _log.debug("connect_best: %s:%d dead, skipping", r.proxy.ip, r.proxy.port)
            continue

        ok, msg = enable_proxy(r.proxy.ip, r.proxy.port, r.proxy.protocol)
        if not ok:
            return {"ok": False, "message": msg}

        lat  = f"{r.tcp_latency_ms:.0f} ms"  if r.tcp_latency_ms  else "?"
        tp   = f"{r.throughput_mbps:.2f} MB/s" if r.throughput_mbps else "?"
        jt   = f"±{r.jitter_ms:.1f} ms" if r.jitter_ms else ""
        tier = r.tier.upper()

        msg = (f"[{tier}] Connected → {r.proxy.ip}:{r.proxy.port} "
               f"({r.proxy.protocol.upper()})  "
               f"ping {lat}  speed {tp}"
               + (f"  jitter {jt}" if jt else ""))

        _log.info(msg)
        return {
            "ok":              True,
            "message":         msg,
            "ip":              r.proxy.ip,
            "port":            r.proxy.port,
            "protocol":        r.proxy.protocol,
            "tier":            r.tier,
            "latency_ms":      r.tcp_latency_ms,
            "throughput_mbps": r.throughput_mbps,
            "jitter_ms":       r.jitter_ms,
            "score":           r.score,
            "country":         r.country,
        }

    return {
        "ok":      False,
        "message": (f"All {len(candidates)} candidates are dead right now. "
                    "Free proxies go offline fast — try fetching fresh ones and checking again."),
    }
