"""modules/usb/catalog.py — every OS the flasher knows, and how to find its CURRENT download.

mode:
  dd      raw-write a hybrid ISO/IMG (all mainstream Linux ISOs are hybrid)
  winiso  Windows-style ISO: FAT32 + copy files + split install.wim + boot code (works for UEFI and BIOS)
  ventoy  install Ventoy, then copy the ISO onto it (for ISOs that are not hybrid, e.g. TempleOS)
  ventoy_only  just install Ventoy (multi-boot stick)

src:
  fido     Microsoft ISO via the Fido script (the only legitimate automated route)
  fixed    stable URL(s)
  listing  scrape a mirror's directory listing for the newest file  (never goes stale)
  github   newest release asset
"""
from __future__ import annotations

OS_LIST: list[dict] = [
    # ── Windows ──
    dict(id="win11", name="Windows 11", group="Windows", mode="winiso", src="fido", win="11", size_gb=6.5,
         desc="Official Microsoft ISO (latest release, x64, English). Works on UEFI and BIOS PCs."),
    dict(id="win10", name="Windows 10", group="Windows", mode="winiso", src="fido", win="10", size_gb=5.8,
         desc="Official Microsoft ISO (latest 22H2, x64, English)."),
    # ── Mainstream Linux ──
    dict(id="ubuntu", name="Ubuntu 24.04 LTS", group="Linux", mode="dd", src="listing", size_gb=6.0,
         alt_bases=["https://mirror.us.leaseweb.net/ubuntu-releases/24.04/", "https://mirrors.kernel.org/ubuntu-releases/24.04/"], base="https://releases.ubuntu.com/24.04/", file=r"^ubuntu-24\.04(\.\d+)?-desktop-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="The most popular desktop Linux. Long-term support until 2029."),
    dict(id="mint", name="Linux Mint (Cinnamon)", group="Linux", mode="dd", src="listing", size_gb=2.9,
         alt_bases=["https://mirror.csclub.uwaterloo.ca/linuxmint/stable/", "https://mirrors.layeronline.com/linuxmint/stable/"], base="https://mirrors.edge.kernel.org/linuxmint/stable/", subdir=r"^\d+(\.\d+)?/$", file=r"^linuxmint-[\d.]+-cinnamon-64bit\.iso$", checksum_files=["sha256sum.txt"],
         desc="Friendly, Windows-like desktop. Great first Linux."),
    dict(id="mint_xfce", name="Linux Mint (Xfce)", group="Linux", mode="dd", src="listing", size_gb=2.9,
         alt_bases=["https://mirror.csclub.uwaterloo.ca/linuxmint/stable/", "https://mirrors.layeronline.com/linuxmint/stable/"], base="https://mirrors.edge.kernel.org/linuxmint/stable/", subdir=r"^\d+(\.\d+)?/$", file=r"^linuxmint-[\d.]+-xfce-64bit\.iso$", checksum_files=["sha256sum.txt"],
         desc="Lightweight Mint for older PCs."),
    dict(id="fedora", name="Fedora Workstation", group="Linux", mode="dd", src="listing", size_gb=2.3,
         alt_bases=["https://mirrors.kernel.org/fedora/releases/", "https://download.fedoraproject.org/pub/fedora/linux/releases/"], base="https://dl.fedoraproject.org/pub/fedora/linux/releases/", subdir=r"^\d+/$", subpath="Workstation/x86_64/iso/",
         file=r"^Fedora-Workstation-Live.*x86_64.*\.iso$", checksum_re=r"CHECKSUM$",
         desc="Cutting-edge GNOME desktop from Red Hat's community."),
    dict(id="debian", name="Debian Live (GNOME)", group="Linux", mode="dd", src="listing", size_gb=3.1,
         alt_bases=["https://cdimage.debian.org/cdimage/release/current-live/amd64/iso-hybrid/"], base="https://cdimage.debian.org/debian-cd/current-live/amd64/iso-hybrid/", file=r"^debian-live-[\d.]+-amd64-gnome\.iso$", checksum_files=["SHA256SUMS"],
         desc="Rock-solid and stable. Boots live, installer included."),
    dict(id="arch", name="Arch Linux", group="Linux", mode="dd", src="fixed", size_gb=1.3,
         urls=["https://geo.mirror.pkgbuild.com/iso/latest/archlinux-x86_64.iso", "https://mirrors.kernel.org/archlinux/iso/latest/archlinux-x86_64.iso"],
         checksum_urls=["https://geo.mirror.pkgbuild.com/iso/latest/sha256sums.txt", "https://mirrors.kernel.org/archlinux/iso/latest/sha256sums.txt"],
         desc="Rolling release for people who like to build their own system. Command-line installer."),
    dict(id="opensuse", name="openSUSE Tumbleweed", group="Linux", mode="dd", src="fixed", size_gb=4.5,
         urls=["https://download.opensuse.org/tumbleweed/iso/openSUSE-Tumbleweed-DVD-x86_64-Current.iso"],
         checksum_urls=["https://download.opensuse.org/tumbleweed/iso/openSUSE-Tumbleweed-DVD-x86_64-Current.iso.sha256"],
         desc="Rolling release with excellent KDE and YaST tools."),
    dict(id="alpine", name="Alpine Linux", group="Linux", mode="dd", src="listing", size_gb=0.2,
         alt_bases=["https://mirrors.edge.kernel.org/alpine/latest-stable/releases/x86_64/"], base="https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases/x86_64/", file=r"^alpine-standard-[\d.]+-x86_64\.iso$", checksum_re=r"^alpine-standard-[\d.]+-x86_64\.iso\.sha256$",
         desc="Tiny (200 MB), security-oriented. Runs from RAM."),
    # ── Security / hacking ──
    dict(id="kali", name="Kali Linux", group="Security", mode="dd", src="listing", size_gb=4.4,
         alt_bases=["https://kali.download/base-images/current/"], base="https://cdimage.kali.org/current/", file=r"^kali-linux-[\d.]+-live-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="Penetration-testing distro. Live image (boots without installing)."),
    dict(id="kali_purple", name="Kali Linux Purple", group="Security", mode="dd", src="listing", size_gb=4.5,
         alt_bases=["https://kali.download/base-images/current/"], base="https://cdimage.kali.org/current/", file=r"^kali-linux-[\d.]+-installer-purple-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="Kali's defensive (blue-team) edition with SOC tooling. Installer image."),
    dict(id="parrot_sec", name="Parrot Security", group="Security", mode="dd", src="listing", size_gb=5.0,
         base="https://deb.parrot.sh/parrot/iso/", subdir=r"^\d+(\.\d+)*/$", file=r"^Parrot-security-[\d.]+_amd64\.iso$", checksum_re=r"hashes|SHA256|sha256",
         desc="Pentesting + privacy tools in a lighter package than Kali."),
    dict(id="parrot_home", name="Parrot Home", group="Security", mode="dd", src="listing", size_gb=4.0,
         base="https://deb.parrot.sh/parrot/iso/", subdir=r"^\d+(\.\d+)*/$", file=r"^Parrot-home-[\d.]+_amd64\.iso$", checksum_re=r"hashes|SHA256|sha256",
         desc="Everyday privacy-focused desktop (no hacking tools)."),
    dict(id="blackarch", name="BlackArch Linux (Slim)", group="Security", mode="dd", src="listing", size_gb=4.6,
         base="https://ftp.halifax.rwth-aachen.de/blackarch/iso/", file=r"^blackarch-linux-slim-[\d.]+-x86_64\.iso$",
         desc="Arch-based with 2800+ security tools."),
    # ── Privacy ──
    dict(id="qubes", name="Qubes OS", group="Privacy", mode="dd", src="listing", size_gb=6.8,
         base="https://mirrors.edge.kernel.org/qubes/iso/", file=r"^Qubes-R[\d.]+-x86_64\.iso$",
         desc="Security by compartmentalisation: every app in its own VM. Needs 16 GB RAM and VT-x/VT-d.",
         warn="Qubes needs a modern PC (16 GB RAM, virtualisation + IOMMU) - check hardware compatibility first."),
    dict(id="tails", name="Tails", group="Privacy", mode="dd", src="listing", size_gb=1.4,
         base="https://download.tails.net/tails/stable/", subdir=r"^tails-amd64-[\d.]+/$", file=r"^tails-amd64-[\d.]+\.img$",
         desc="Amnesic OS that routes everything through Tor and leaves no trace."),
    # ── Other / fun ──
    dict(id="templeos", name="TempleOS", group="Other", mode="ventoy", src="fixed", size_gb=0.02,
         urls=["https://templeos.org/Downloads/TempleOS.ISO", "https://www.templeos.org/Downloads/TempleOS.ISO"],
         desc="Terry Davis's 64-bit hobby OS. Not a hybrid ISO, so DWUT installs Ventoy and adds it.",
         warn="TempleOS is designed for a VM; on real PCs it needs legacy BIOS/CSM boot and may not run on all hardware."),
    dict(id="hbcd", name="Hiren's BootCD PE", group="Other", mode="winiso", src="fixed", size_gb=3.0,
         urls=["https://www.hirensbootcd.org/files/HBCD_PE_x64.iso"],
         desc="Windows PE rescue toolkit: disk, password, recovery and diagnostic tools."),
    dict(id="ventoy", name="Ventoy (multi-boot stick)", group="Other", mode="ventoy_only", src="github", size_gb=0.02,
         repo="ventoy/Ventoy", asset=r"^ventoy-[\d.]+-windows\.zip$",
         desc="Install once, then just drag-and-drop any number of ISOs onto the stick and pick one at boot."),
    # ---- Gaming / SteamOS-style ----
    dict(id="bazzite", name="Bazzite (Desktop - AMD / Intel graphics)", group="Gaming", mode="dd", src="fixed", size_gb=8.5,
         urls=["https://download.bazzite.gg/bazzite-stable-amd64.iso", "https://download.bazzite.gg/bazzite-stable.iso"],
         checksum_urls=["https://download.bazzite.gg/bazzite-stable-amd64.iso-CHECKSUM", "https://download.bazzite.gg/bazzite-stable.iso-CHECKSUM"],
         desc="SteamOS-style gaming Linux for normal PCs: Steam, Proton, Game Mode and automatic updates. KDE Plasma desktop."),
    dict(id="bazzite_nvidia", name="Bazzite (Desktop - NVIDIA graphics)", group="Gaming", mode="dd", src="fixed", size_gb=9.0,
         urls=["https://download.bazzite.gg/bazzite-nvidia-stable-amd64.iso", "https://download.bazzite.gg/bazzite-nvidia-stable.iso"],
         checksum_urls=["https://download.bazzite.gg/bazzite-nvidia-stable-amd64.iso-CHECKSUM", "https://download.bazzite.gg/bazzite-nvidia-stable.iso-CHECKSUM"],
         desc="Bazzite with the NVIDIA driver built in - pick this if your PC has a GeForce card."),
    dict(id="bazzite_deck", name="Bazzite (Steam Deck / handheld / couch PC)", group="Gaming", mode="dd", src="fixed", size_gb=9.0,
         urls=["https://download.bazzite.gg/bazzite-deck-stable-amd64.iso", "https://download.bazzite.gg/bazzite-deck-stable.iso"],
         checksum_urls=["https://download.bazzite.gg/bazzite-deck-stable-amd64.iso-CHECKSUM", "https://download.bazzite.gg/bazzite-deck-stable.iso-CHECKSUM"],
         desc="The closest thing to SteamOS: boots straight into Steam Game Mode. For Steam Deck, ROG Ally, Legion Go and living-room PCs."),
    dict(id="bazzite_gnome", name="Bazzite (GNOME desktop)", group="Gaming", mode="dd", src="fixed", size_gb=8.5,
         urls=["https://download.bazzite.gg/bazzite-gnome-stable-amd64.iso", "https://download.bazzite.gg/bazzite-gnome-stable.iso"],
         checksum_urls=["https://download.bazzite.gg/bazzite-gnome-stable-amd64.iso-CHECKSUM", "https://download.bazzite.gg/bazzite-gnome-stable.iso-CHECKSUM"],
         desc="Bazzite with the GNOME desktop instead of KDE Plasma."),
    dict(id="nobara", name="Nobara (Fedora for gaming)", group="Gaming", mode="dd", src="listing", size_gb=3.9,
         base="https://nobara-images.nobaraproject.org/", file=r"^Nobara-\d+-Official-[\d-]+\.iso$", checksum_re=r"sha256",
         desc="Fedora tuned for gaming and streaming by GloriousEggroll: drivers, codecs, Steam and Proton ready out of the box."),
    dict(id="cachyos", name="CachyOS (fastest gaming Arch)", group="Gaming", mode="dd", src="listing", size_gb=3.0,
         base="https://cdn77.cachyos.org/ISO/desktop/", subdir=r"^\d{6}/$", file=r"^cachyos-desktop-linux-\d{6}\.iso$", checksum_re=r"sha256",
         desc="Arch-based with performance-tuned kernels and a graphical installer. Popular with gamers."),
    dict(id="garuda_gaming", name="Garuda Linux (Dr460nized Gaming)", group="Gaming", mode="dd", src="fixed", size_gb=3.6, filename="garuda-dr460nized-gaming.iso",
         urls=["https://iso.builds.garudalinux.org/iso/latest/garuda/dr460nized-gaming/latest.iso"],
         desc="Arch-based, beautiful KDE desktop with gaming tools preinstalled (Steam, Lutris, Proton-GE)."),
    # ---- more desktop Linux ----
    dict(id="kubuntu", name="Kubuntu 24.04 (KDE Plasma)", group="Linux", mode="dd", src="listing", size_gb=4.4,
         base="https://cdimage.ubuntu.com/kubuntu/releases/24.04/release/", file=r"^kubuntu-24\.04(\.\d+)?-desktop-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="Ubuntu with the KDE Plasma desktop: modern, customisable, Windows-like."),
    dict(id="xubuntu", name="Xubuntu 24.04 (Xfce)", group="Linux", mode="dd", src="listing", size_gb=3.9,
         base="https://cdimage.ubuntu.com/xubuntu/releases/24.04/release/", file=r"^xubuntu-24\.04(\.\d+)?-desktop-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="Ubuntu with the light Xfce desktop - good for older PCs."),
    dict(id="lubuntu", name="Lubuntu 24.04 (LXQt)", group="Linux", mode="dd", src="listing", size_gb=3.1,
         base="https://cdimage.ubuntu.com/lubuntu/releases/24.04/release/", file=r"^lubuntu-24\.04(\.\d+)?-desktop-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="The lightest Ubuntu - runs well on very old or low-end computers."),
    dict(id="ubuntu_mate", name="Ubuntu MATE 24.04", group="Linux", mode="dd", src="listing", size_gb=4.2,
         base="https://cdimage.ubuntu.com/ubuntu-mate/releases/24.04/release/", file=r"^ubuntu-mate-24\.04(\.\d+)?-desktop-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="Classic, traditional desktop on top of Ubuntu."),
    dict(id="debian_netinst", name="Debian (network installer)", group="Linux", mode="dd", src="listing", size_gb=0.7,
         base="https://cdimage.debian.org/debian-cd/current/amd64/iso-cd/", file=r"^debian-[\d.]+-amd64-netinst\.iso$", checksum_files=["SHA256SUMS"],
         desc="Small Debian installer (about 700 MB). Downloads the rest while installing."),
    dict(id="endeavouros", name="EndeavourOS", group="Linux", mode="dd", src="listing", size_gb=2.9,
         base="https://mirror.alpix.eu/endeavouros/iso/", file=r"^EndeavourOS_[A-Za-z-]+-[\d.]+\.iso$", checksum_re=r"sha512|sha256",
         desc="Friendly Arch with a graphical installer - Arch power without the command-line setup."),
    dict(id="manjaro_kde", name="Manjaro (KDE Plasma)", group="Linux", mode="dd", src="listing", size_gb=3.8,
         base="https://download.manjaro.org/kde/", subdir=r"^\d+(\.\d+)*/$", file=r"^manjaro-kde-[\d.]+-\d+-linux\d+\.iso$", checksum_re=r"sha256",
         desc="User-friendly Arch with a graphical installer and automatic hardware detection."),
    dict(id="nixos", name="NixOS (GNOME, rolling channel)", group="Linux", mode="dd", src="fixed", size_gb=2.8, filename="nixos-gnome-x86_64.iso",
         urls=["https://channels.nixos.org/nixos-unstable/latest-nixos-gnome-x86_64-linux.iso"],
         checksum_urls=["https://channels.nixos.org/nixos-unstable/latest-nixos-gnome-x86_64-linux.iso.sha256"],
         desc="Declarative Linux: your whole system is one config file. Rollbacks built in."),
    dict(id="void", name="Void Linux (Xfce)", group="Linux", mode="dd", src="listing", size_gb=1.1,
         base="https://repo-default.voidlinux.org/live/current/", file=r"^void-live-x86_64-\d+-xfce\.iso$", checksum_files=["sha256sum.txt"],
         desc="Independent, fast, minimal. runit init instead of systemd."),
    dict(id="gentoo", name="Gentoo (minimal installer)", group="Linux", mode="dd", src="listing", size_gb=0.5,
         base="https://distfiles.gentoo.org/releases/amd64/autobuilds/current-install-amd64-minimal/", file=r"^install-amd64-minimal-\d+T\d+Z\.iso$", checksum_re=r"\.iso\.sha256$|DIGESTS",
         desc="Build everything from source, tuned to your CPU. Command-line only; for experienced users."),
    # ---- Servers ----
    dict(id="ubuntu_server", name="Ubuntu Server 24.04 LTS", group="Servers", mode="dd", src="listing", size_gb=2.6,
         alt_bases=["https://mirror.us.leaseweb.net/ubuntu-releases/24.04/"], base="https://releases.ubuntu.com/24.04/", file=r"^ubuntu-24\.04(\.\d+)?-live-server-amd64\.iso$", checksum_files=["SHA256SUMS"],
         desc="Headless Ubuntu for servers, home labs and Docker hosts."),
    dict(id="rocky", name="Rocky Linux 9 (DVD)", group="Servers", mode="dd", src="fixed", size_gb=9.0,
         urls=["https://download.rockylinux.org/pub/rocky/9/isos/x86_64/Rocky-9-latest-x86_64-dvd.iso"],
         checksum_urls=["https://download.rockylinux.org/pub/rocky/9/isos/x86_64/CHECKSUM"],
         desc="Free, enterprise-grade RHEL-compatible server OS."),
    dict(id="alma", name="AlmaLinux 9 (minimal)", group="Servers", mode="dd", src="fixed", size_gb=1.9,
         urls=["https://repo.almalinux.org/almalinux/9/isos/x86_64/AlmaLinux-9-latest-x86_64-minimal.iso"],
         checksum_urls=["https://repo.almalinux.org/almalinux/9/isos/x86_64/CHECKSUM"],
         desc="Community RHEL-compatible server OS (minimal installer)."),
    dict(id="centos_stream", name="CentOS Stream 9 (boot)", group="Servers", mode="dd", src="fixed", size_gb=1.2,
         urls=["https://mirror.stream.centos.org/9-stream/BaseOS/x86_64/iso/CentOS-Stream-9-latest-x86_64-boot.iso"],
         checksum_urls=["https://mirror.stream.centos.org/9-stream/BaseOS/x86_64/iso/CentOS-Stream-9-latest-x86_64-boot.iso.SHA256SUM"],
         desc="Rolling preview of the next RHEL. Network installer."),
    dict(id="proxmox", name="Proxmox VE (virtualisation server)", group="Servers", mode="dd", src="listing", size_gb=1.6,
         base="https://enterprise.proxmox.com/iso/", file=r"^proxmox-ve_[\d.-]+\.iso$", checksum_re=r"SHA256SUMS",
         desc="Turn a spare PC into a VM + container host with a web interface."),
    dict(id="freebsd", name="FreeBSD (USB memstick image)", group="Servers", mode="dd", src="listing", size_gb=1.2,
         base="https://download.freebsd.org/releases/ISO-IMAGES/", subdir=r"^\d+\.\d+/$", file=r"^FreeBSD-[\d.]+-RELEASE-amd64-memstick\.img$", checksum_re=r"CHECKSUM\.SHA256",
         desc="The classic BSD: rock-solid networking and the ZFS file system."),
    # ---- Rescue / tools ----
    dict(id="rescuezilla", name="Rescuezilla (disk backup & restore)", group="Rescue", mode="dd", src="github", size_gb=1.7,
         repo="rescuezilla/rescuezilla", asset=r"^rescuezilla-[\d.]+-64bit\.noble\.iso$",
         desc="Easy graphical disk imaging and cloning - back up or restore a whole PC."),
]

GROUPS = ["Windows", "Gaming", "Linux", "Servers", "Security", "Privacy", "Rescue", "Other"]


def public() -> list[dict]:
    keys = ("id", "name", "group", "mode", "size_gb", "desc", "warn")
    return [{k: o.get(k, "") for k in keys} for o in OS_LIST]


def get(os_id: str) -> dict | None:
    return next((o for o in OS_LIST if o["id"] == os_id), None)
