"""
api/cosmetics_api.py - personalisation: imported images / GIFs / videos / sounds and the audio-reactive meter.
Everything here is free for everyone.

AUDIO SYNC  (backgrounds only)
  Reads the loudness of individual apps' audio sessions (Windows audio session meters) and uses ONLY browsers and games.
  Calls/voice apps (Discord, Teams, Zoom, Skype ...) are never read: they are excluded by name, and if one of them has live
  audio the sync pauses.  Only the loudness number is read - never the audio itself.
"""
from __future__ import annotations

import hashlib
import math
import os
import re
import shutil
import threading
import time
from pathlib import Path

from core.logger import get_logger
from server import emit, rpc

_log = get_logger("api.cosmetics")

BASE = Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT"
ASSET_DIR = BASE / "cosmetics"

# ----------------------------------------------------------------------------------------------------------------------
# imported assets (images / GIFs / videos / sounds)
# ----------------------------------------------------------------------------------------------------------------------

_KINDS = {
    "image": ({".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".mp4", ".webm"}, 120 * 1024 * 1024),
    "sound": ({".wav", ".mp3", ".ogg", ".m4a", ".flac"}, 8 * 1024 * 1024),
}


@rpc("cosmetics.import_asset")
def cosmetics_import_asset(path: str, kind: str):
    exts, limit = _KINDS.get(kind, (set(), 0))
    src = Path(path)
    if not src.is_file() or src.suffix.lower() not in exts:
        return {"ok": False, "error": f"Pick a {'/'.join(sorted(exts))} file."}
    if src.stat().st_size > limit:
        return {"ok": False, "error": f"That file is too large (limit {limit // 1048576} MB)."}
    folder = ASSET_DIR / kind
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / (re.sub(r"[^A-Za-z0-9._-]", "_", src.stem)[:40] + "_" + hashlib.sha1(str(src).encode()).hexdigest()[:6] + src.suffix.lower())
    shutil.copy2(src, dest)
    return {"ok": True, "path": str(dest), "name": src.name}


@rpc("cosmetics.assets")
def cosmetics_assets(kind: str):
    folder = ASSET_DIR / kind
    out = []
    if folder.is_dir():
        for f in sorted(folder.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
            out.append({"path": str(f), "name": re.sub(r"_[0-9a-f]{6}(\.[^.]+)$", r"\1", f.name)})
    return out


@rpc("cosmetics.delete_asset")
def cosmetics_delete_asset(path: str):
    p = Path(path)
    try:
        if ASSET_DIR in p.resolve().parents:
            p.unlink()
            return True
    except OSError:
        pass
    return False


PREFS_FILE = ASSET_DIR / "prefs.json"


@rpc("cosmetics.get_prefs")
def cosmetics_get_prefs():
    try:
        if PREFS_FILE.is_file():
            import json
            return {"ok": True, "prefs": json.loads(PREFS_FILE.read_text(encoding="utf-8"))}
    except Exception as e:
        _log.warning(f"Failed to read cosmetics prefs: {e}")
    return {"ok": False, "prefs": {}}


@rpc("cosmetics.set_prefs")
def cosmetics_set_prefs(prefs: dict):
    try:
        import json
        ASSET_DIR.mkdir(parents=True, exist_ok=True)
        PREFS_FILE.write_text(json.dumps(prefs, indent=2), encoding="utf-8")
        return {"ok": True}
    except Exception as e:
        _log.warning(f"Failed to write cosmetics prefs: {e}")
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------------------------------------------------
# audio-reactive meter: browsers + games only
# ----------------------------------------------------------------------------------------------------------------------

_BROWSERS = {"chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe", "opera_gx.exe", "vivaldi.exe", "arc.exe", "chromium.exe",
             "librewolf.exe", "waterfox.exe", "tor.exe", "yandex.exe", "iexplore.exe"}
_MUSIC_APPS = {"spotify.exe", "itunes.exe", "applemusic.exe", "vlc.exe", "foobar2000.exe", "musicbee.exe",
               "tidal.exe", "deezer.exe", "wmplayer.exe", "mediaplayer.exe", "aimp.exe", "winamp.exe",
               "qobuz.exe", "amazon music.exe", "amazonmusic.exe", "plexamp.exe"}
# NEVER read: voice / video call apps (matched on the exe name, ignoring case)
_CALLS = {"discord.exe", "discordptb.exe", "discordcanary.exe", "discorddevelopment.exe", "update.exe", "teams.exe", "ms-teams.exe", "msteams.exe",
          "zoom.exe", "zoomit.exe", "skype.exe", "skypeapp.exe", "slack.exe", "webex.exe", "webexmta.exe", "telegram.exe", "whatsapp.exe",
          "signal.exe", "viber.exe", "mumble.exe", "ts3client_win64.exe", "teamspeak.exe", "teamspeak3.exe", "ventrilo.exe", "element.exe",
          "line.exe", "wechat.exe", "dingtalk.exe", "lark.exe", "feishu.exe", "guilded.exe", "revolt.exe", "jitsi meet.exe", "gotomeeting.exe",
          "bluejeans.exe", "ringcentral.exe", "messenger.exe", "meetingsapp.exe"}
_GAME_PATH = re.compile(r"\\(steamapps\\common|epic games|gog galaxy\\games|gog games|riot games|battle\.net|xboxgames|ubisoft game launcher\\games|"
                        r"ea games|origin games|rockstar games|games|itch\\apps|heroic)\\", re.I)
_CALL_TITLE = re.compile(r"meet\s[-\u2013]|google meet|zoom meeting|zoom\.us|microsoft teams|\bteams\b.*\bmeeting|discord|skype|whereby|jitsi|webex|"
                         r"huddle|facetime|messenger call|whatsapp.*call|on a call|video call|voice chat|telegram.*call", re.I)

_audio_thread: threading.Thread | None = None
_audio_stop = threading.Event()
_audio_status = {"running": False, "source": "", "paused": "", "available": True}


def _window_titles_by_pid(pids: set[int]) -> dict[int, list[str]]:
    import ctypes
    from ctypes import wintypes
    u32 = ctypes.windll.user32
    out: dict[int, list[str]] = {}
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _lp):
        if not u32.IsWindowVisible(hwnd):
            return True
        pid = wintypes.DWORD()
        u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value in pids:
            n = u32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                u32.GetWindowTextW(hwnd, buf, n + 1)
                out.setdefault(pid.value, []).append(buf.value)
        return True

    try:
        u32.EnumWindows(proc(cb), 0)
    except Exception:
        pass
    return out


def _classify(name: str, exe: str) -> str:
    """'call' | 'browser' | 'game' | ''  - only browser/music/game are measured."""
    n = (name or "").lower()
    if n in _CALLS:
        return "call"
    if n in _BROWSERS or n in _MUSIC_APPS:
        return "browser"
    if exe and _GAME_PATH.search(exe):
        return "game"
    return ""


def _get_master_meter():
    try:
        from pycaw.pycaw import AudioUtilities, IAudioMeterInformation
        import comtypes
        try:
            comtypes.CoInitialize()
        except Exception:
            pass
        sp = AudioUtilities.GetSpeakers()
        if sp and getattr(sp, "_dev", None):
            return sp._dev.Activate(IAudioMeterInformation._iid_, comtypes.CLSCTX_ALL, None).QueryInterface(IAudioMeterInformation)
    except Exception:
        pass
    return None


class _BeatDetector:
    """Frame-rate independent loudness follower + onset (beat) detector.

    Everything is driven by real elapsed time (not loop iterations), so the result is the same whether the loop
    runs at 60 or 110 Hz.  A beat needs: a fast envelope that jumps clearly above the short-term average
    (adaptive threshold = mean + k*deviation), a positive slope, a minimum gap, and a re-arm below the threshold -
    so one drum hit fires once, and sustained loud notes do not machine-gun."""

    def __init__(self) -> None:
        self.peak = 0.10        # slow peak follower (volume invariance)
        self.fast = 0.0         # fast envelope
        self.mean = 0.0         # short-term average (~0.5 s)
        self.dev = 0.0          # short-term mean deviation
        self.prev_fast = 0.0
        self.last_beat = 0.0
        self.armed = True
        self.last_t = 0.0

    @staticmethod
    def _a(dt: float, tau: float) -> float:
        return 1.0 - math.exp(-dt / tau)

    def update(self, raw: float, now: float) -> tuple[float, bool, float]:
        """-> (level 0..1, beat, beat strength 0..1)"""
        dt = min(0.08, max(0.001, now - self.last_t)) if self.last_t else 0.01
        self.last_t = now
        if raw > self.peak:
            self.peak = raw
        else:
            self.peak = max(0.03, self.peak - 0.22 * dt)
        x = min(1.0, raw / self.peak) if (self.peak > 0.004 and raw > 0.002) else 0.0
        self.fast += (x - self.fast) * self._a(dt, 0.012 if x > self.fast else 0.060)
        self.mean += (self.fast - self.mean) * self._a(dt, 0.45)
        self.dev += (abs(self.fast - self.mean) - self.dev) * self._a(dt, 0.60)
        thr = self.mean + max(0.07, 1.5 * self.dev)
        slope = (self.fast - self.prev_fast) / dt
        self.prev_fast = self.fast
        beat, strength = False, 0.0
        if self.fast < thr * 0.92:
            self.armed = True
        if (self.armed and self.fast > 0.14 and self.fast > thr and slope > 0.35
                and (now - self.last_beat) > 0.11):
            beat = True
            self.armed = False
            self.last_beat = now
            strength = max(0.55, min(1.0, (self.fast - self.mean) / 0.45 + 0.35))
        return x, beat, strength


def _audio_loop() -> None:
    try:
        import ctypes
        import comtypes
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioMeterInformation
        import psutil
    except Exception as exc:
        _audio_status.update(running=False, available=False, paused="Audio sync needs the 'pycaw' package (re-run the installer).")
        _log.info("audio sync unavailable: %s", exc)
        emit("cosmetics.audio_status", dict(_audio_status))
        return

    # Enable 1ms high-precision Windows multimedia timer
    try:
        ctypes.windll.winmm.timeBeginPeriod(1)
    except Exception:
        pass

    comtypes.CoInitialize()
    _audio_status.update(running=True, available=True, paused="", source="")
    emit("cosmetics.audio_status", dict(_audio_status))

    master_meter = _get_master_meter()
    active_src = ""
    call_active = False
    last_emit = 0.0
    last_level = 0.0
    last_session_scan = 0.0

    def scan_sessions():
        nonlocal active_src, call_active
        try:
            import comtypes
            comtypes.CoInitialize()
            from pycaw.pycaw import AudioUtilities, IAudioMeterInformation
            loudest_src = ""
            loudest_pk = 0.0
            call_speaking = False
            for s in AudioUtilities.GetAllSessions():
                try:
                    pr = s.Process
                    if pr is None:
                        continue
                    pname = pr.name()
                    try:
                        exe = pr.exe()
                    except Exception:
                        exe = ""
                    kind = _classify(pname, exe)
                    meter = s._ctl.QueryInterface(IAudioMeterInformation)
                    pk = float(meter.GetPeakValue())
                    if kind == "call":
                        if pk > 0.06:
                            call_speaking = True
                    else:
                        if pk > loudest_pk:
                            loudest_pk = pk
                            loudest_src = pname.replace(".exe", "").capitalize()
                except Exception:
                    continue
            if loudest_src and loudest_pk > 0.005:
                active_src = loudest_src
            call_active = call_speaking
        except Exception:
            pass
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass

    det = _BeatDetector()

    try:
        scan_sessions()
        while not _audio_stop.is_set():
            try:
                now = time.time()

                # Periodic non-blocking session scan every 3s for app source names and call apps
                if now - last_session_scan > 3.0:
                    last_session_scan = now
                    threading.Thread(target=scan_sessions, daemon=True, name="audio-session-scan").start()

                # Re-acquire master meter if needed (e.g. device switch or initial failure)
                if master_meter is None:
                    master_meter = _get_master_meter()
                    if master_meter is None:
                        time.sleep(0.08)
                        continue

                try:
                    raw_pk = float(master_meter.GetPeakValue())
                except Exception:
                    master_meter = None
                    time.sleep(0.04)
                    continue

                paused = ""
                if call_active and raw_pk < 0.04:
                    # Only voice call is active — pause reaction
                    raw_pk = 0.0
                    paused = "Call active (voice ignored)"

                norm, is_beat, strength = det.update(raw_pk, now)

                # Stream to Electron: ~60 Hz level updates (cheap, never floods the UI), beats go out IMMEDIATELY.
                # Every message carries its capture time so the UI can drop anything that arrived late.
                if is_beat or (norm > 0 and now - last_emit >= 0.016) or (norm == 0 and last_level > 0):
                    last_emit, last_level = now, norm
                    emit("cosmetics.audio", {"level": round(norm, 4), "beat": is_beat, "s": round(strength, 2), "t": round(now * 1000), "src": active_src})
                elif norm == 0 and now - last_emit > 0.25:
                    last_emit = now
                    emit("cosmetics.audio", {"level": 0.0, "beat": False, "s": 0, "t": round(now * 1000), "src": active_src})

                if paused != _audio_status["paused"] or active_src != _audio_status["source"]:
                    _audio_status.update(paused=paused, source=active_src)
                    emit("cosmetics.audio_status", dict(_audio_status))

                # ~125 Hz sampling (peak meter reports the max since the last read, so nothing is missed)
                time.sleep(0.008 if norm > 0 else 0.016)

            except Exception as loop_exc:
                _log.debug("audio loop error, auto-recovering: %s", loop_exc)
                master_meter = None
                time.sleep(0.08)

    finally:
        _audio_status.update(running=False, source="")
        emit("cosmetics.audio", {"level": 0.0, "beat": False, "src": ""})
        emit("cosmetics.audio_status", dict(_audio_status))
        try:
            ctypes.windll.winmm.timeEndPeriod(1)
        except Exception:
            pass
        try:
            comtypes.CoUninitialize()
        except Exception:
            pass


@rpc("cosmetics.audio")
def cosmetics_audio(enable: bool):
    """Start / stop the audio-reactive meter."""
    global _audio_thread
    if enable:
        _audio_stop.clear()
        if _audio_thread is not None and _audio_thread.is_alive():
            return {"ok": True, **_audio_status}
        _audio_thread = threading.Thread(target=_audio_loop, daemon=True, name="cosmetics-audio")
        _audio_thread.start()
    else:
        _audio_stop.set()
        if _audio_thread is not None and _audio_thread.is_alive():
            try:
                _audio_thread.join(timeout=0.25)
            except Exception:
                pass
        _audio_thread = None
    return {"ok": True, **_audio_status}
