"""api/gaming_api.py — FPS unlocker + Game Booster."""
from __future__ import annotations

from core.events import Events, bus
from core.logger import get_logger
from core.worker import worker
from server import emit, rpc

_log = get_logger("api.gaming")


# ── FPS unlocker ──────────────────────────────────────────────────────────────

@rpc("gaming.fps_games")
def fps_games():
    from modules.gaming.fps_unlock import fps_unlocker
    return fps_unlocker.list_games()


@rpc("gaming.fps_enable")
def fps_enable():
    from modules.gaming.fps_unlock import fps_unlocker
    worker.submit(fps_unlocker.enable)
    return True


@rpc("gaming.fps_disable")
def fps_disable():
    from modules.gaming.fps_unlock import fps_unlocker
    worker.submit(fps_unlocker.disable)
    return True


@rpc("gaming.fps_target")
def fps_target(fps: int):
    from modules.gaming.fps_unlock import fps_unlocker
    fps_unlocker.set_target_fps(int(fps))
    return True


@rpc("gaming.fps_game")
def fps_game(game: str):
    from modules.gaming.fps_unlock import fps_unlocker
    worker.submit(fps_unlocker.set_game, game)
    return True


# ── Game booster ──────────────────────────────────────────────────────────────

@rpc("gaming.boost_candidates")
def boost_candidates():
    from modules.gaming.booster import list_termination_candidates
    return list_termination_candidates()


@rpc("gaming.boost_apply")
def boost_apply(game_name: str = "", only: list | None = None):
    """only = exe names (lower-case) the user left ticked in the popup; None = defaults."""
    from modules.gaming.booster import booster

    def _run():
        return booster.activate(game_name, only_names={n.lower() for n in only} if only is not None else None)

    def _err(e):
        _log.error("Boost activate failed: %s", e)
        emit("gaming.boost_error", {"message": str(e)})

    worker.submit(_run, on_error=_err)
    return True


@rpc("gaming.boost_restore")
def boost_restore():
    from modules.gaming.booster import booster
    worker.submit(booster.deactivate)
    return True


@rpc("gaming.boost_state")
def boost_state():
    from modules.gaming.booster import booster
    return {"active": booster.is_active}


# Live system performance stats — polled every second by the frontend graphs
_last_net  = None
_last_disk = None
_last_ts   = None

@rpc("gaming.system_stats")
def system_stats():
    """Return live CPU %, RAM %, disk MB/s and network Mbps for the performance graphs."""
    import psutil, time
    global _last_net, _last_disk, _last_ts

    now = time.monotonic()

    from modules.system.perfsample import perf
    c = perf.cpu()
    cpu = c.get("total") if c else None
    if cpu is None:
        cpu = psutil.cpu_percent(interval=None)
    vm  = psutil.virtual_memory()
    ram = round(((vm.total - vm.available) / vm.total) * 100.0, 1) if vm.total else vm.percent

    # Disk I/O delta
    try:
        d = psutil.disk_io_counters()
        disk_mbps = 0.0
        if _last_disk and _last_ts:
            dt = max(0.01, now - _last_ts)
            read_mb  = (d.read_bytes  - _last_disk.read_bytes)  / 1_048_576 / dt
            write_mb = (d.write_bytes - _last_disk.write_bytes) / 1_048_576 / dt
            disk_mbps = round(read_mb + write_mb, 2)
        _last_disk = d
    except Exception:
        disk_mbps = 0.0

    # Network I/O delta
    try:
        n = psutil.net_io_counters()
        net_mbps = 0.0
        if _last_net and _last_ts:
            dt = max(0.01, now - _last_ts)
            net_mbps = round(((n.bytes_sent + n.bytes_recv) - (_last_net.bytes_sent + _last_net.bytes_recv)) / 1_048_576 / dt, 2)
        _last_net = n
    except Exception:
        net_mbps = 0.0

    # GPU utilization
    gpu_pct = 0.0
    try:
        from modules.system.perfsample import perf
        g = perf.gpu()
        gpu_pct = round(float(g.get("total", 0.0)), 1)
    except Exception:
        pass

    _last_ts = now

    return {
        "cpu":  round(cpu,  1),
        "gpu":  gpu_pct,
        "ram":  round(ram,  1),
        "disk": disk_mbps,
        "net":  net_mbps,
    }


@rpc("gaming.fps_close_game")
def fps_close_game():
    from modules.gaming.fps_unlock import fps_unlocker
    return fps_unlocker.restart_game()


def _detect_running_game() -> tuple[str, str]:
    """Scans running processes and returns (game_id, display_name) for any active game."""
    try:
        import psutil
        from modules.gaming.booster import _KNOWN_GAMES
        for p in psutil.process_iter(["pid", "name"]):
            try:
                n = (p.info["name"] or "").lower()
                if n in _KNOWN_GAMES:
                    dname = _KNOWN_GAMES[n]
                    gid = "roblox" if "roblox" in n else ("fortnite" if "fortnite" in n else ("minecraft" if "minecraft" in n or "javaw" in n else "roblox"))
                    return gid, dname
            except Exception:
                pass
    except Exception:
        pass
    return "roblox", "Auto-Detect"


@rpc("gaming.detected_game")
def gaming_detected_game():
    """Returns the currently running detected game, or auto-detect."""
    from modules.gaming.fps_unlock import fps_unlocker
    gid, dname = _detect_running_game()
    return {
        "detected": dname != "Auto-Detect",
        "game_id": gid,
        "game_name": dname,
        "active": fps_unlocker.is_active,
    }


@rpc("gaming.fps_state")
def fps_state():
    """Return current FPS unlocker state — used by the tray to label the menu item."""
    from modules.gaming.fps_unlock import fps_unlocker
    gid, dname = _detect_running_game()
    return {"active": fps_unlocker.is_active, "game_name": dname, "game_id": gid}


@rpc("gaming.fps_toggle")
def fps_toggle():
    """Toggle FPS unlock on/off — called from the system tray context menu with auto-detected game."""
    from modules.gaming.fps_unlock import fps_unlocker
    gid, dname = _detect_running_game()
    if fps_unlocker.is_active:
        worker.submit(fps_unlocker.disable)
        return {"active": False, "game_name": dname, "game_id": gid}
    else:
        fps_unlocker.set_game(gid)
        worker.submit(fps_unlocker.enable)
        return {"active": True, "game_name": dname, "game_id": gid}
