'use strict';
/* Instant theme token applicator — runs synchronously in <head> to prevent theme flash */
(function() {
  try {
    const saved = localStorage.getItem('dwut_theme') || 'dark';
    const T = window.DW_THEMES;
    if (T && T.themes) {
      const theme = Object.assign({}, T.base, T.themes[saved] || {});
      const a = theme.accent;
      if (a) {
        theme.success = a;
        theme.success_bg = theme.accent_subtle || 'transparent';
        theme.warning = a;
        theme.warning_bg = theme.accent_subtle || 'transparent';
        theme.tag_low = a;
        theme.tag_medium = a;
        theme['running-col'] = a;
        theme.warn = a;
      }
      const st = document.documentElement.style;
      for (const [k, v] of Object.entries(theme)) {
        st.setProperty('--' + k, v);
      }
      document.documentElement.dataset.light = (T.light && T.light.includes(saved)) ? '1' : '0';
    }
    const cos = JSON.parse(localStorage.getItem('dwut_cosmetics') || '{}');
    document.documentElement.dataset.sbAnim   = cos.sb || 'sweep';
    document.documentElement.dataset.sbToggle = cos.sbToggle || 'elastic';
    document.documentElement.dataset.clickAnim = cos.click || 'glitch';
  } catch (e) {}
})();
