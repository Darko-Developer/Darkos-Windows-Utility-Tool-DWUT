'use strict';
/* bgfield - the animated background, shared by the main window, the Task Manager and the Run window.

   DEFAULT: the theme-coloured gradient with flickering dot stars.  Every colour is read from the LIVE CSS theme variables on <html>,
   so it is the user's selected theme in every window and cross-fades when it changes (a MutationObserver watches them).

   PERSONALISATION (free for everyone - see js/cosmetics.js, config in localStorage 'dwut_cosmetics'):
     mode 'gradient'  animated, colour-cycling gradient (presets or your own colours) with the particles on top
     mode 'media'     your own image / GIF / video as the background, particles on top
     particles        stars | sakura | embers | rain | leaves | snow | fireflies | none
     audio            particles + gradient pulse to music playing in browsers/games (loudness only; never calls)
   The other windows pick the same settings up through the 'storage' event, so all windows always match. */
(function () {
  const cv = document.createElement('canvas');
  cv.id = 'bgfield'; cv.setAttribute('aria-hidden', 'true');
  document.body.insertBefore(cv, document.body.firstChild);
  const ctx = cv.getContext('2d');
  const reduce = false;                                    // the stars always animate (they used to freeze with 'reduce motion')
  const lowCpu = (navigator.hardwareConcurrency || 4) <= 2;
  let w = 0, h = 0, parts = [], raf = 0, last = 0, perfScale = lowCpu ? 0.55 : 1, slowFrames = 0, ema = 16;
  let cur = null, prev = null, fade = 1;
  const rnd = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  // ---- config (set by cosmetics.js / read from localStorage) ----
  const DEF = { mode: 'default', preset: 'aurora', colors: [], speed: 1, particleSpeed: 1, particles: 'stars', density: 1, media: '', dim: 0.35, audio: false, emberColor: '', particleColors: {} };
  let cfg = Object.assign({}, DEF);
  let audio = { raw: 0, prevRaw: 0, peak: 0.15, lvl: 0, fast: 0, slow: 0, beat: 0, beatCd: 0, at: 0 };
  let mediaEl = null, mediaSrc = '';

  // ---- colour helpers ----
  function rgb(c, fb) {
    c = String(c || '').trim();
    let m = /^#([0-9a-f]{6})$/i.exec(c);
    if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
    m = /^#([0-9a-f]{3})$/i.exec(c);
    if (m) return m[1].split('').map((x) => parseInt(x + x, 16));
    m = /rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i.exec(c);
    if (m) return [+m[1], +m[2], +m[3]];
    return fb || [20, 24, 32];
  }
  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
  }
  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s /= 100; l /= 100;
    const k = (n) => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
  }
  const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
  const css = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  const lum = (c) => (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
  const fileUrl = (p) => /^(file|https?|data|blob):/i.test(p) ? p : 'file:///' + String(p).replace(/\\/g, '/').split('/').map((s, i) => (i === 0 ? s : encodeURIComponent(s))).join('/');

  const PRESETS = {
    aurora: ['#041512', '#00ffa3', '#031926', '#03e1ff', '#0d0722', '#7a5cff', '#1a061b', '#ff3df0'],
    sunset: ['#180608', '#ff512f', '#1a0b03', '#f09819', '#1a0410', '#ff2e63', '#100521', '#6a11cb'],
    ocean:  ['#020b18', '#00c6ff', '#041630', '#0072ff', '#021814', '#00f5a0', '#080d24', '#1b2b6b'],
    neon:   ['#1a0018', '#ff00cc', '#060624', '#3333ff', '#001a18', '#00ffd5', '#1a000d', '#ff0066'],
    forest: ['#051410', '#134e5e', '#091c13', '#71b280', '#121f0b', '#a8e063', '#04140e', '#0f6b4a'],
    candy:  ['#1b0b14', '#ff9a9e', '#0e0b1d', '#a18cd1', '#1d0e1c', '#fbc2eb', '#081714', '#84fab0'],
    fire:   ['#1a0202', '#b30000', '#1f0900', '#ff6600', '#1f1600', '#ffcc00', '#140005', '#7a0019'],
    galaxy: ['#080315', '#2b1055', '#0a0e20', '#7597de', '#180411', '#d53369', '#070a1a', '#1a2a6c'],
  };

  const palette = () => {
    const cs = getComputedStyle(document.documentElement), V = (k) => cs.getPropertyValue('--' + k).trim();
    const shell = rgb(V('bg_shell'), [13, 15, 18]);
    const base  = rgb(V('bg_base'),  [19, 22, 26]);
    const acc   = rgb(V('accent'),   [74, 124, 255]);
    const info  = rgb(V('info') || V('accent_dim') || V('accent'), acc);
    const dim   = rgb(V('accent_dim') || V('accent'), acc);
    const warn  = rgb(V('warning') || V('error') || V('accent'), acc);
    const light = lum(base) > .6;
    const white = [255, 255, 255], black = [0, 0, 0];
    // Derive a richer set of gradient stops — pulled slightly more toward shell for darker centers
    const c0 = mix(shell, acc,  light ? 0.22 : 0.30);
    const c1 = mix(base,  info, light ? 0.16 : 0.24);
    const c2 = mix(shell, dim,  light ? 0.14 : 0.22);
    const c3 = mix(shell, warn, light ? 0.08 : 0.14);
    // Orb definitions: [relX, relY, radiusFrac, color, peakAlpha, phaseOffset, wobbleSpeed]
    // Alphas kept ~30% lower than before so centers feel rich but not glaring
    const blobs = [
      [.12, .14, .70, acc,                    light ? .26 : .38, 0, 1.0],
      [.88, .85, .65, info,                   light ? .20 : .32, 2, 1.3],
      [.70, .12, .52, mix(acc, info, .5),     light ? .16 : .26, 4, 0.8],
      [.28, .84, .48, dim,                    light ? .13 : .22, 1, 1.6],
      [.50, .50, .40, mix(info, dim, .5),     light ? .10 : .18, 3, 1.1],
      [.82, .30, .36, mix(acc, warn, .3),     light ? .07 : .14, 5, 0.9],
    ];
    const star  = light ? mix(dim, black, .35) : mix(white, acc,  .22);
    const star2 = light ? dim                  : mix(white, info, .35);
    return {
      light, shell, base, acc, info, dim, warn,
      stops: [c0, c1, c2, c3], blobs, star, star2,
      sig: [shell, base, acc, info, dim, warn].join('|'),
    };
  };

  // ---- animated gradient (mode: 'gradient') ----
  function gradColors(p) {
    if (cfg.preset === 'custom' && cfg.colors && cfg.colors.length >= 2) return cfg.colors.map(rgb);
    if (cfg.preset === 'theme') {
      const [h, s, l] = rgbToHsl(p.acc[0], p.acc[1], p.acc[2]);
      const deepAnchor = mix(p.acc, p.shell, p.light ? 0.35 : 0.72);
      const brightTint = hslToRgb(h, Math.min(100, s + 5), Math.min(88, l + 18));
      const analog1    = hslToRgb((h + 26) % 360, Math.min(100, Math.max(40, s)), Math.min(75, l + 6));
      const analog2    = hslToRgb((h - 24 + 360) % 360, Math.min(100, Math.max(45, s + 8)), Math.min(70, Math.max(30, l - 4)));
      const deepAccent = hslToRgb((h + 12) % 360, Math.min(100, s), Math.max(14, l - 18));
      const glowTop    = hslToRgb((h - 8 + 360) % 360, Math.max(25, s - 10), Math.min(94, l + 25));
      return [
        deepAnchor,
        p.acc,
        analog1,
        deepAccent,
        brightTint,
        analog2,
        mix(p.acc, p.info, 0.45),
        glowTop,
      ];
    }
    return (PRESETS[cfg.preset] || PRESETS.aurora).map(rgb);
  }
  const css2hex = (c) => '#' + c.map((x) => x.toString(16).padStart(2, '0')).join('');
  const sample  = (cols, f) => { f = ((f % 1) + 1) % 1; const n = cols.length, x = f * n, i = Math.floor(x) % n; return mix(cols[i], cols[(i + 1) % n], x - Math.floor(x)); };

  function paintGradient(p, alpha, t) {
    ctx.globalAlpha = alpha;
    // Gradients do NOT sync to music (only particles sync to music)
    const sp  = (cfg.speed || 1);
    const cols = gradColors(p), tt = t * 0.000034 * sp;
    const R = Math.max(w, h);

    // 1. Rich diagonal base gradient with vibrant theme colours that slowly rotates
    const ang   = t * 0.000045 * sp;
    const cx    = w / 2, cy = h / 2;
    const gLen  = Math.hypot(w, h) * 0.72;
    const g = ctx.createLinearGradient(
      cx + Math.cos(ang)         * gLen, cy + Math.sin(ang)         * gLen,
      cx + Math.cos(ang + Math.PI) * gLen, cy + Math.sin(ang + Math.PI) * gLen);
    const stops = 6;
    for (let i = 0; i < stops; i++) {
      // Balanced blend so vibrant theme colours shine through instead of looking solid black
      const c = mix(sample(cols, tt + i / stops), p.shell, p.light ? 0.22 : 0.38);
      g.addColorStop(i / (stops - 1), css(c, 1));
    }
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

    // 2. Five colour orbs on independent Lissajous-like paths (No music audio pulse)
    const pulse = 1;
    const aBoost = 1;
    const orbData = [
      { fr: 0.00020, fc: 0.00016, pr: 0, pc: 1.1, rad: .60, ci: 0, ai: p.light ? .24 : .36 },
      { fr: 0.00015, fc: 0.00019, pr: 2, pc: 3.3, rad: .55, ci: 1, ai: p.light ? .20 : .30 },
      { fr: 0.00026, fc: 0.00013, pr: 4, pc: 0.7, rad: .48, ci: 2, ai: p.light ? .16 : .25 },
      { fr: 0.00012, fc: 0.00023, pr: 1, pc: 2.2, rad: .44, ci: 3, ai: p.light ? .13 : .20 },
      { fr: 0.00022, fc: 0.00017, pr: 3, pc: 4.1, rad: .38, ci: 4, ai: p.light ? .10 : .16 },
    ];
    for (const o of orbData) {
      const c  = sample(cols, tt * 1.8 + o.ci / cols.length + .07);
      const px = w * (.5 + .44 * Math.sin(t * o.fr * sp + o.pr));
      const py = h * (.5 + .44 * Math.cos(t * o.fc * sp + o.pc));
      const gr = ctx.createRadialGradient(px, py, 0, px, py, R * o.rad * pulse);
      gr.addColorStop(0,   css(c, Math.min(1, o.ai * aBoost)));
      gr.addColorStop(0.5, css(c, Math.min(1, o.ai * .35 * aBoost)));
      gr.addColorStop(1,   css(c, 0));
      ctx.fillStyle = gr; ctx.fillRect(0, 0, w, h);
    }

    // 3. Chromatic shimmer band (diagonal streak that drifts slowly)
    const bAng  = t * 0.000024 * sp + Math.PI * .3;
    const bOff  = ((t * 0.000035 * sp) % 1) * Math.hypot(w, h) * 2 - Math.hypot(w, h) * .5;
    const bCx   = cx + Math.cos(bAng) * bOff, bCy = cy + Math.sin(bAng) * bOff;
    const bLen  = Math.hypot(w, h) * .45;
    const bCol  = sample(cols, tt * 2.1 + .33);
    const gb = ctx.createLinearGradient(bCx - Math.cos(bAng) * bLen, bCy - Math.sin(bAng) * bLen,
                                        bCx + Math.cos(bAng) * bLen, bCy + Math.sin(bAng) * bLen);
    gb.addColorStop(0,    css(bCol, 0));
    gb.addColorStop(0.45, css(bCol, p.light ? .09 : .16));
    gb.addColorStop(0.55, css(bCol, p.light ? .12 : .21));
    gb.addColorStop(1,    css(bCol, 0));
    ctx.fillStyle = gb; ctx.fillRect(0, 0, w, h);

    // 4. Edge vignette for deep, dark cinematic richness
    const vg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.05);
    vg.addColorStop(0,    'rgba(0,0,0,0)');
    vg.addColorStop(0.65, 'rgba(0,0,0,0.18)');
    vg.addColorStop(1,    'rgba(0,0,0,0.48)');
    ctx.fillStyle = vg; ctx.fillRect(0, 0, w, h);

    ctx.globalAlpha = 1;
  }

  function paintTheme(p, alpha, t) {
    ctx.globalAlpha = alpha;
    // Gradients do NOT sync to music (only particles sync to music)
    const sp = (cfg.speed || 1);
    const R  = Math.max(w, h);
    const pulse = 1;
    const aBoost = 1;

    // 1. Rich multi-stop base (diagonal, slowly rotates)
    const ang = t * 0.000042 * sp;
    const gLen = Math.hypot(w, h) * 0.68;
    const cx = w / 2, cy = h / 2;
    const g = ctx.createLinearGradient(
      cx + Math.cos(ang) * gLen,           cy + Math.sin(ang) * gLen,
      cx + Math.cos(ang + Math.PI) * gLen, cy + Math.sin(ang + Math.PI) * gLen);
    const sc = p.stops;
    g.addColorStop(0,    css(sc[0], 1));
    g.addColorStop(0.38, css(sc[1], 1));
    g.addColorStop(0.68, css(sc[2], 1));
    g.addColorStop(1,    css(sc[3] || sc[2], 1));
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

    // 2. Six breathing colour orbs — each on independent sinusoidal path
    for (const [xf, yf, rf, c, a, ph, spd] of p.blobs) {
      const px = w * (xf + .30 * Math.sin(t * 0.00016 * sp * spd + ph));
      const py = h * (yf + .28 * Math.cos(t * 0.00013 * sp * spd + ph * 1.4));
      const r  = R * rf * pulse;
      const gr = ctx.createRadialGradient(px, py, 0, px, py, r);
      gr.addColorStop(0,    css(c, Math.min(1, a * aBoost)));
      gr.addColorStop(0.45, css(c, Math.min(1, a * .45 * aBoost)));
      gr.addColorStop(1,    css(c, 0));
      ctx.fillStyle = gr; ctx.fillRect(0, 0, w, h);
    }

    // 3. Two slow sweeping lens-flare streaks
    for (let i = 0; i < 2; i++) {
      const c   = i ? p.blobs[1][3] : p.blobs[0][3];
      const ph  = t * 0.000068 * sp * (i ? -1 : 1) + i * 2.4;
      const scx = w * (.5 + .52 * Math.sin(ph));
      const scy = h * (.28 + .36 * i + .10 * Math.cos(ph * 1.6));
      const len = R * .80;
      const gr  = ctx.createRadialGradient(scx, scy, 0, scx, scy, len * .55);
      gr.addColorStop(0, css(c, p.light ? .16 : .26));
      gr.addColorStop(1, css(c, 0));
      ctx.save();
      ctx.translate(scx, scy); ctx.rotate(-.38 + .18 * Math.sin(ph));
      ctx.scale(1, .18);        ctx.translate(-scx, -scy);
      ctx.fillStyle = gr; ctx.fillRect(scx - len, scy - len, len * 2, len * 2);
      ctx.restore();
    }

    // 4. Center-to-edge vignette — dims the bright core so it never glares
    const vg = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.05);
    vg.addColorStop(0,    p.light ? 'rgba(0,0,0,0.06)' : 'rgba(0,0,0,0.18)');
    vg.addColorStop(0.45, 'rgba(0,0,0,0)');
    vg.addColorStop(1,    p.light ? 'rgba(0,0,0,0.14)' : 'rgba(0,0,0,0.36)');
    ctx.fillStyle = vg; ctx.fillRect(0, 0, w, h);

    ctx.globalAlpha = 1;
  }

  // ---- particles ----
  const COUNT = {
    stars:   () => clamp(Math.floor(w * h / 3800),  180, 560),
    sakura:  () => clamp(Math.floor(w * h / 26000),  24,  90),
    cherry:  () => clamp(Math.floor(w * h / 20000),  30, 110),
    embers:  () => clamp(Math.floor(w * h / 14000),  40, 140),
    rain:    () => clamp(Math.floor(w * h / 7000),   90, 260),
    leaves:  () => clamp(Math.floor(w * h / 38000),  16,  55),
    snow:    () => clamp(Math.floor(w * h / 9000),   70, 220),
    fireflies:() => clamp(Math.floor(w * h / 30000), 20,  70),
    none:    () => 0,
  };
  function spawn(type, initial) {
    const p = { x: rnd(0, w), y: initial ? rnd(0, h) : -20, ph: rnd(0, 6.28), ph2: rnd(0, 6.28), rot: rnd(0, 6.28), life: rnd(0, 1) };
    switch (type) {
      case 'stars': { const u = Math.random(), r = .45 + Math.pow(u, 2.6) * 2.4, big = (r - .45) / 2.4;
        Object.assign(p, { y: rnd(0, h), r, a: .45 + .55 * Math.min(1, big * 1.4 + Math.random() * .5), tw: rnd(1.2, 5.5), tw2: rnd(.4, 2.2), v: (5 + big * 22) * rnd(.7, 1.4), ang: rnd(0, 6.28), turn: rnd(-.5, .5), wob: rnd(.4, 1.6), alt: Math.random() < .3 }); break; }
      case 'sakura': Object.assign(p, { s: rnd(6, 13), vy: rnd(28, 62), sw: rnd(.6, 1.6), amp: rnd(14, 34), vr: rnd(-1.4, 1.4), tint: Math.random(), pink: rnd(0, 1) }); break;
      case 'cherry': Object.assign(p, { s: rnd(7, 15), vy: rnd(30, 70), sw: rnd(.5, 1.8), amp: rnd(18, 42), vr: rnd(-2.0, 2.0), tint: Math.random(), pink: rnd(0, 1), flip: rnd(0, 6.28) }); break;
      case 'leaves': {
        // Crisp petiole stem extending from the leaf base — always spawns above screen to fall down smoothly
        const stemLen = rnd(4.5, 7.5);
        Object.assign(p, { y: initial ? rnd(-20, h) : -(20 + stemLen + 20), x: rnd(0, w), s: rnd(10, 21), stemLen, vy: rnd(26, 56), sw: rnd(.5, 1.3), amp: rnd(16, 40), vr: rnd(-1.1, 1.1), tint: Math.random() });
        break; }
      case 'embers': Object.assign(p, { y: initial ? rnd(0, h) : h + 10, r: rnd(.8, 3.2), vy: rnd(28, 100), sw: rnd(.6, 2), amp: rnd(8, 26), fl: rnd(1.5, 5), hot: Math.random(), streakLen: rnd(2, 7) }); break;
      case 'rain': Object.assign(p, { len: rnd(11, 26), vy: rnd(620, 1020), a: rnd(.18, .42) }); p.vx = -p.vy * .13; break;
      case 'snow': Object.assign(p, { r: rnd(.8, 3), vy: rnd(14, 52), sw: rnd(.4, 1.2), amp: rnd(8, 24), a: rnd(.45, .95) }); break;
      case 'fireflies': Object.assign(p, { y: rnd(0, h), r: rnd(1.2, 2.8), ang: rnd(0, 6.28), v: rnd(8, 24), turn: rnd(-.8, .8), fl: rnd(.5, 1.6) }); break;
      default: break;
    }
    return p;
  }
  function build() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth; h = window.innerHeight;
    cv.width = Math.floor(w * dpr); cv.height = Math.floor(h * dpr); cv.style.width = w + 'px'; cv.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    rebuildParts();
  }
  function rebuildParts() {
    const t = cfg.particles in COUNT ? cfg.particles : 'stars';
    const n = Math.max(0, Math.floor((COUNT[t]() || 0) * clamp(cfg.density, .2, 2.5) * perfScale));
    parts = Array.from({ length: n }, () => spawn(t, true));
  }

  // Sakura petal: 5-petal compound with notch and gradient fill
  const petalPath = (s) => {
    const petals = 5;
    for (let i = 0; i < petals; i++) {
      const a = (i / petals) * Math.PI * 2 - Math.PI / 2;
      const bx = Math.cos(a) * s * .38, by = Math.sin(a) * s * .38;
      const tip = Math.cos(a) * s, tipY = Math.sin(a) * s;
      const cp1x = bx + Math.cos(a - 1.1) * s * .78, cp1y = by + Math.sin(a - 1.1) * s * .78;
      const cp2x = bx + Math.cos(a + 1.1) * s * .78, cp2y = by + Math.sin(a + 1.1) * s * .78;
      if (i === 0) ctx.moveTo(bx, by); else ctx.lineTo(bx, by);
      ctx.bezierCurveTo(cp1x, cp1y, tip + Math.cos(a) * s * .12, tipY + Math.sin(a) * s * .12, tip, tipY);
      ctx.bezierCurveTo(tip - Math.cos(a) * s * .12, tipY - Math.sin(a) * s * .12, cp2x, cp2y, bx, by);
    }
  };

  // Cherry blossom: single heart-shaped petal with characteristic notch at tip
  const cherryPetalPath = (s) => {
    // Petal: wide oval base, narrows to notched tip — the defining shape of Prunus serrulata
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(-s * 0.52, -s * 0.18, -s * 0.68, -s * 0.72, -s * 0.18, -s * 0.96);
    // Notch indent at tip
    ctx.bezierCurveTo(-s * 0.06, -s * 0.82,  s * 0.06, -s * 0.82,  s * 0.18, -s * 0.96);
    ctx.bezierCurveTo( s * 0.68, -s * 0.72,  s * 0.52, -s * 0.18,  0,         0);
  };

  const leafPath = (s) => {  // 7-lobed weed leaf fanned from local origin
    for (let i = -3; i <= 3; i++) {
      const a = i * .44, len = s * (1 - Math.abs(i) * .12), wd = s * .14;
      ctx.save(); ctx.rotate(a);
      ctx.moveTo(0, 0); ctx.quadraticCurveTo(wd, -len * .5, 0, -len); ctx.quadraticCurveTo(-wd, -len * .5, 0, 0);
      ctx.restore();
    }
  };

  function drawParts(type, dt, ts, p) {
    const A = cfg.audio ? audio : { lvl: 0, beat: 0 };
    const psp = (cfg.particleSpeed != null ? cfg.particleSpeed : 1);
    const sp = psp * (1 + A.lvl * 1.6 + A.beat * 2.2), t = ts / 1000;
    const customCol = (cfg.particleColors && cfg.particleColors[type]) || (type === 'embers' ? cfg.emberColor : '');
    const userRgb = customCol ? rgb(customCol) : null;
    const userHsl = userRgb ? rgbToHsl(userRgb[0], userRgb[1], userRgb[2]) : null;

    let c1 = `rgb(${p.star})`, c2 = `rgb(${p.star2})`;
    if (userRgb) {
      c1 = `rgb(${userRgb[0]},${userRgb[1]},${userRgb[2]})`;
      c2 = `rgb(${Math.min(255, userRgb[0] + 45)},${Math.min(255, userRgb[1] + 45)},${Math.min(255, userRgb[2] + 45)})`;
    }
    ctx.save();
    if (type === 'embers' || type === 'fireflies') ctx.globalCompositeOperation = 'lighter';
    for (const q of parts) {
      switch (type) {
        case 'stars': {
          let k = .12 + .88 * (.5 + .5 * Math.sin(t * q.tw + q.ph)) * (.55 + .45 * Math.sin(t * q.tw2 + q.ph2));
          if (Math.random() < .004) k *= .15;
          k = Math.min(2.5, k * (1 + A.lvl * .8 + A.beat * 1.4));
          q.ang += q.turn * dt + (Math.random() - .5) * .6 * dt;
          q.x += (Math.cos(q.ang) * q.v * sp + Math.cos(t * q.wob + q.ph) * 3) * dt; q.y += (Math.sin(q.ang) * q.v * sp + Math.sin(t * q.wob * .8 + q.ph) * 3) * dt;
          if (q.x > w + 4) q.x = -4; else if (q.x < -4) q.x = w + 4; if (q.y > h + 4) q.y = -4; else if (q.y < -4) q.y = h + 4;
          if (A.beat > 0.06) {
            ctx.beginPath(); ctx.arc(q.x, q.y, q.r * (2.8 + A.beat * 2.4), 0, 6.2832);
            ctx.fillStyle = c2; ctx.globalAlpha = A.beat * 0.36; ctx.fill();
          }
          ctx.globalAlpha = Math.min(1, q.a * k) * (p.light ? .85 : 1); ctx.fillStyle = q.alt ? c2 : c1;
          ctx.beginPath(); ctx.arc(q.x, q.y, q.r * (1 + A.beat * .6), 0, 6.2832); ctx.fill();
          break; }
        case 'sakura': case 'cherry': case 'leaves': {
          q.y += q.vy * sp * dt; q.x += (Math.sin(t * q.sw + q.ph) * q.amp + 12) * dt; q.rot += q.vr * dt * (1 + A.lvl * 0.5);
          if (type === 'sakura') {
            if (q.y > h + 40 || q.x > w + 40) { q.y = -28; q.x = rnd(-40, w); }
            ctx.save();
            ctx.translate(q.x, q.y); ctx.rotate(q.rot);
            ctx.scale(1, .5 + .5 * Math.abs(Math.sin(t * q.sw * 1.7 + q.ph2)));
            // gradient fill -- custom hue if specified, otherwise natural pink
            const pg = ctx.createRadialGradient(0, 0, 0, 0, 0, q.s);
            const hue = userHsl ? (userHsl[0] + (q.pink - 0.5) * 20 + 360) % 360 : (340 + q.pink * 15);
            const sat = userHsl ? userHsl[1] : 90;
            const lit = userHsl ? userHsl[2] : 88;
            pg.addColorStop(0,   `hsla(${hue},${sat}%,${Math.min(98, lit + A.beat * 8)}%,0.95)`);
            pg.addColorStop(0.6, `hsla(${hue},${Math.max(15, sat - 10)}%,${Math.max(20, lit - 10 + A.beat * 10)}%,0.80)`);
            pg.addColorStop(1,   `hsla(${hue},${Math.max(10, sat - 20)}%,${Math.max(15, lit - 25)}%,0.60)`);
            ctx.beginPath(); petalPath(q.s);
            ctx.fillStyle = pg; ctx.globalAlpha = Math.min(1, .85 + .15 * q.tint + A.beat * 0.15); ctx.fill();
            // petal veins + edge
            ctx.strokeStyle = `hsla(${hue - 10},${sat}%,${Math.max(20, lit - 30)}%,0.30)`; ctx.lineWidth = .6; ctx.stroke();
            // stamen dot in center
            ctx.beginPath(); ctx.arc(0, 0, q.s * .12, 0, 6.2832);
            ctx.fillStyle = `hsla(${hue + 20},95%,65%,0.9)`; ctx.globalAlpha = 1; ctx.fill();
            // stamens: 5 tiny dots arranged in a circle
            for (let si = 0; si < 5; si++) {
              const sa = si / 5 * 6.2832 - 1.57, sd = q.s * .22;
              ctx.beginPath(); ctx.arc(Math.cos(sa) * sd, Math.sin(sa) * sd, q.s * .055, 0, 6.2832);
              ctx.fillStyle = `hsla(50,95%,60%,0.85)`; ctx.fill();
            }
            ctx.restore();
          } else if (type === 'cherry') {
            // Individual cherry blossom petals
            if (q.y > h + 30 || q.x > w + 50) { q.y = rnd(-40, -10); q.x = rnd(-40, w + 40); }
            const flipScale = Math.sin(t * q.sw * 1.9 + q.flip);
            ctx.save();
            ctx.translate(q.x, q.y);
            ctx.rotate(q.rot);
            ctx.scale(Math.abs(flipScale) * 0.55 + 0.45, 1);
            const hue  = userHsl ? (userHsl[0] + (q.pink - 0.5) * 20 + 360) % 360 : (338 + q.pink * 18);
            const sat  = userHsl ? userHsl[1] : (72 + q.tint * 18);
            const lite = userHsl ? userHsl[2] : (78 + q.tint * 14);
            const pg = ctx.createLinearGradient(0, 0, 0, -q.s);
            pg.addColorStop(0,   `hsla(${hue},${sat}%,${Math.min(98, lite + 8 + A.beat * 8)}%,0.92)`);
            pg.addColorStop(0.4, `hsla(${hue},${sat}%,${Math.min(95, lite + A.beat * 10)}%,0.85)`);
            pg.addColorStop(1,   `hsla(${hue - 8},${Math.max(10, sat - 10)}%,${Math.max(15, lite - 18)}%,0.65)`);
            ctx.beginPath(); cherryPetalPath(q.s);
            ctx.fillStyle = pg; ctx.globalAlpha = Math.min(1, 0.82 + 0.18 * q.tint + A.beat * 0.15); ctx.fill();
            ctx.beginPath();
            ctx.moveTo(0, -q.s * 0.06);
            ctx.quadraticCurveTo(0, -q.s * 0.5, 0, -q.s * 0.88);
            ctx.strokeStyle = `hsla(${hue - 15},${sat}%,${Math.max(20, lite - 25)}%,0.28)`;
            ctx.lineWidth = 0.7; ctx.stroke();
            ctx.beginPath(); cherryPetalPath(q.s);
            ctx.strokeStyle = `hsla(${hue - 5},55%,90%,0.35)`;
            ctx.lineWidth = 0.9; ctx.stroke();
            ctx.restore();
          } else {
            // WEED LEAVES -- always falling consistently from top to bottom, never disappearing
            if (q.y > h + q.s + q.stemLen + 20) {
              q.y = -(q.s + q.stemLen + 20);
              q.x = rnd(-20, w + 20);
              q.rot = rnd(0, 6.28);
            }
            if (q.x > w + 40) q.x = -20;
            else if (q.x < -40) q.x = w + 20;

            const beatGlow = A.beat;
            const stemHue = userHsl ? (userHsl[0] + (q.tint - 0.5) * 15 + 360) % 360 : (120 + q.tint * 20);
            const leafSat = userHsl ? userHsl[1] : 75;
            const baseLit = userHsl ? userHsl[2] : 36;
            const leafLight = Math.min(95, baseLit + beatGlow * 26);
            const leafLight2 = Math.max(12, leafLight - 10);

            ctx.save();
            ctx.translate(q.x, q.y);
            ctx.rotate(q.rot + q.vr * t * .0002);

            // Fast hardware halo on beat
            if (beatGlow > 0.06) {
              ctx.beginPath();
              leafPath(q.s * (1 + beatGlow * 0.15));
              ctx.fillStyle = userRgb ? `rgba(${userRgb[0]}, ${userRgb[1]}, ${userRgb[2]}, ${beatGlow * 0.28})` : `rgba(74, 222, 128, ${beatGlow * 0.28})`;
              ctx.globalAlpha = beatGlow * 0.5;
              ctx.fill();
            }

            // Crisp petiole stem
            const stemLight = Math.min(90, Math.max(15, baseLit - 4) + beatGlow * 25);
            ctx.strokeStyle = `hsla(${stemHue}, ${leafSat}%, ${stemLight}%, ${0.9 + 0.1 * q.tint})`;
            ctx.lineWidth = 1.9;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(0, q.stemLen);
            ctx.stroke();

            // 7-lobed leaf
            ctx.beginPath();
            leafPath(q.s);
            const g2 = ctx.createRadialGradient(0, -q.s * .4, 0, 0, -q.s * .4, q.s);
            g2.addColorStop(0, `hsla(${stemHue}, ${Math.min(100, leafSat + beatGlow * 20)}%, ${leafLight}%, 0.95)`);
            g2.addColorStop(1, `hsla(${(stemHue - 10 + 360) % 360}, ${leafSat}%, ${leafLight2}%, ${0.7 + beatGlow * 0.25})`);
            ctx.fillStyle = g2;
            ctx.globalAlpha = Math.min(1, .85 + .15 * q.tint + beatGlow * 0.15);
            ctx.fill();

            // Vein & contour outline
            ctx.strokeStyle = `hsla(${stemHue}, ${Math.min(100, leafSat + 10)}%, ${Math.min(98, leafLight + 10)}%, ${0.5 + beatGlow * 0.4})`;
            ctx.lineWidth = 0.9;
            ctx.stroke();
            ctx.restore();
          }
          break; }
        case 'embers': {
          q.y -= q.vy * sp * dt * (1 + A.beat * 0.7);
          q.x += Math.sin(t * q.sw + q.ph) * q.amp * dt;
          q.life -= dt * .15;
          if (q.y < -10 || q.life <= 0) { q.y = h + 8; q.x = rnd(0, w); q.life = rnd(.6, 1); }
          const fl   = .5 + .5 * Math.sin(t * q.fl + q.ph);
          const life = Math.min(1, clamp(q.life, 0, 1));
          const al   = Math.min(1, fl * life * (1 + A.beat * .85));
          let baseR = 255, baseG = Math.round(110 + q.hot * 100), baseB = 30;
          if (userRgb) {
            baseR = userRgb[0]; baseG = userRgb[1]; baseB = userRgb[2];
          }
          const beatBoost = A.beat;

          // 1. Soft corona bloom
          const coronaRadius = q.r * (4.2 + beatBoost * 3.2);
          ctx.beginPath();
          ctx.arc(q.x, q.y, coronaRadius, 0, 6.2832);
          ctx.fillStyle = `rgba(${baseR}, ${baseG}, ${baseB}, ${al * (0.15 + beatBoost * 0.22)})`;
          ctx.fill();

          // 2. Mid aura flare
          const midRadius = q.r * (2.1 + beatBoost * 1.4);
          ctx.beginPath();
          ctx.arc(q.x, q.y, midRadius, 0, 6.2832);
          ctx.fillStyle = `rgba(${baseR}, ${Math.min(255, baseG + 35)}, ${baseB}, ${al * (0.36 + beatBoost * 0.24)})`;
          ctx.fill();

          // 3. Hot core spark
          const coreRadius = q.r * (1 + beatBoost * 0.35);
          const bright = q.hot > .55 || beatBoost > 0.25;
          ctx.beginPath();
          ctx.arc(q.x, q.y, coreRadius, 0, 6.2832);
          ctx.fillStyle = bright
            ? `rgba(255, 248, 220, ${al * 0.95})`
            : `rgba(${baseR}, ${Math.min(255, baseG + 70)}, ${Math.min(255, baseB + 40)}, ${al * 0.85})`;
          ctx.fill();

          // Rising streak
          if (q.streakLen > 0 && al > .2) {
            ctx.strokeStyle = `rgba(${baseR}, ${Math.min(255, baseG + 40)}, ${baseB}, ${al * .4})`;
            ctx.lineWidth = q.r * .7;
            ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(q.x, q.y + q.streakLen * sp);
            ctx.stroke();
          }
          break; }
        case 'rain': {
          q.y += q.vy * sp * dt; q.x += q.vx * sp * dt; if (q.y > h + 30) { q.y = -30; q.x = rnd(0, w + 200); }
          ctx.globalAlpha = Math.min(1, q.a * (1 + A.lvl * .6 + A.beat * .45));
          ctx.strokeStyle = userRgb ? `rgb(${userRgb[0]},${userRgb[1]},${userRgb[2]})` : (p.light ? 'rgb(70,100,150)' : 'rgb(185,205,255)');
          ctx.lineWidth = 1 + A.beat * .5;
          ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(q.x + q.vx * .022 * q.len / 10, q.y - q.len); ctx.stroke();
          break; }
        case 'snow': {
          q.y += q.vy * sp * dt; q.x += Math.sin(t * q.sw + q.ph) * q.amp * dt; if (q.y > h + 6) { q.y = -6; q.x = rnd(0, w); } if (q.x > w + 6) q.x = -6; else if (q.x < -6) q.x = w + 6;
          ctx.globalAlpha = Math.min(1, q.a * (1 + A.beat * .35)) * (p.light ? .8 : 1);
          ctx.fillStyle = userRgb ? `rgb(${userRgb[0]},${userRgb[1]},${userRgb[2]})` : (p.light ? 'rgb(120,150,200)' : '#fff');
          ctx.beginPath(); ctx.arc(q.x, q.y, q.r * (1 + A.beat * .25), 0, 6.2832); ctx.fill();
          break; }
        case 'fireflies': {
          q.ang += q.turn * dt + (Math.random() - .5) * 1.2 * dt; q.x += Math.cos(q.ang) * q.v * sp * dt; q.y += Math.sin(q.ang) * q.v * sp * dt;
          if (q.x > w + 10) q.x = -10; else if (q.x < -10) q.x = w + 10; if (q.y > h + 10) q.y = -10; else if (q.y < -10) q.y = h + 10;
          const al = Math.max(0, Math.sin(t * q.fl + q.ph)) ** 2 * (1 + A.beat * 1.1);
          const fCol = userRgb ? `${userRgb[0]},${userRgb[1]},${userRgb[2]}` : '190,255,120';
          ctx.fillStyle = `rgba(${fCol},${Math.min(1, al)})`; ctx.beginPath(); ctx.arc(q.x, q.y, q.r * (1 + A.beat * .35), 0, 6.2832); ctx.fill();
          ctx.fillStyle = `rgba(${fCol},${Math.min(1, al) * (.22 + A.beat * .2)})`; ctx.beginPath(); ctx.arc(q.x, q.y, q.r * (3.8 + A.beat * 2.2), 0, 6.2832); ctx.fill();
          break; }
        default: break;
      }
    }
    ctx.restore(); ctx.globalAlpha = 1;
  }

  // ---- media layer (own image / GIF / video) ----
  function applyMedia() {
    const want = cfg.mode === 'media' && cfg.media ? fileUrl(cfg.media) : '';
    if (!want) { if (mediaEl) { mediaEl.remove(); mediaEl = null; mediaSrc = ''; } return; }
    if (mediaEl && mediaSrc === want) return;
    if (mediaEl) mediaEl.remove();
    const isVideo = /\.(mp4|webm)(\?|$)/i.test(want);
    mediaEl = document.createElement(isVideo ? 'video' : 'img');
    if (isVideo) Object.assign(mediaEl, { autoplay: true, loop: true, muted: true, playsInline: true });
    mediaEl.src = want; mediaSrc = want; mediaEl.setAttribute('aria-hidden', 'true'); mediaEl.id = 'bgmedia';
    const z = getComputedStyle(cv).zIndex; mediaEl.style.cssText = `position:fixed;inset:0;width:100%;height:100%;object-fit:cover;pointer-events:none;z-index:${z === 'auto' ? 0 : z}`;
    mediaEl.onerror = () => { if (mediaEl) { mediaEl.remove(); mediaEl = null; mediaSrc = ''; } cfg.mode = 'default'; };
    cv.parentNode.insertBefore(mediaEl, cv);
  }

  // ---- main loop ----
  function frame(ts) {
    raf = requestAnimationFrame(frame);
    const minDt = lowCpu ? 33 : 10;
    if (ts - last < minDt) return;
    const rawDt = ts - last, dt = Math.min(.05, rawDt / 1000); last = ts;
    if (rawDt < 400) { ema = ema * .93 + rawDt * .07; if (ema > 52 && perfScale > .3) { if (++slowFrames > 40) { slowFrames = 0; perfScale = Math.max(.3, perfScale * .75); rebuildParts(); } } else slowFrames = 0; }   // weak PC: thin the particles out automatically
    if (fade < 1) fade = Math.min(1, fade + dt / .6);
    // Music sync: the backend already normalises the level and detects beats (single source of truth - detecting a
    // second time here only added delay and smeared the hits).  We just smooth the level and decay the beat flash.
    if (cfg.audio && audio.at && performance.now() - audio.at > 700) audio.raw = 0;     // stream stopped: fall to silence
    const raw = cfg.audio ? audio.raw : 0;
    const attack = 1 - Math.exp(-60 * dt);
    const decay  = 1 - Math.exp(-9 * dt);
    audio.lvl += (raw - audio.lvl) * (raw > audio.lvl ? attack : decay);
    audio.beat *= Math.exp(-13 * dt);                  // flash decays in ~0.25 s, frame-rate independent
    if (audio.beat < 0.005) audio.beat = 0;
    audio.prevRaw = raw;

    ctx.clearRect(0, 0, w, h);
    const media = cfg.mode === 'media' && mediaEl;
    if (media) { ctx.fillStyle = css(cur.shell, clamp(cfg.dim, 0, .9)); ctx.fillRect(0, 0, w, h); }
    else if (cfg.mode === 'gradient') paintGradient(cur, 1, ts);
    else if (prev && fade < 1) { paintTheme(prev, 1, ts); paintTheme(cur, fade, ts); } else { prev = null; paintTheme(cur, 1, ts); }
    drawParts(cfg.particles in COUNT ? cfg.particles : 'stars', dt, ts, cur);
  }

  function refresh() { const n = palette(); if (cur && n.sig === cur.sig) return; prev = cur; cur = n; fade = prev ? 0 : 1; }

  // ---- public API + cross-window settings ----
  function configure(c) {
    const old = cfg;
    cfg = Object.assign({}, DEF, c || {});
    if (cfg.preset !== 'custom' && !PRESETS[cfg.preset] && cfg.preset !== 'theme') cfg.preset = 'aurora';
    if (old.particles !== cfg.particles || old.density !== cfg.density) rebuildParts();
    applyMedia();
    if (!cfg.audio) {
      audio.raw = 0; audio.prevRaw = 0; audio.peak = 0.15; audio.lvl = 0; audio.fast = 0; audio.slow = 0; audio.beat = 0; audio.beatCd = 0; audio.at = 0;
    }
  }
  function fromStorage() {
    try {
      const j = JSON.parse(localStorage.getItem('dwut_cosmetics') || 'null');
      configure(j && j.bg ? j.bg : null);
    } catch { configure(null); }
  }
  window.DwutBg = {
    configure,
    // v = level 0..1, beat = onset flag, strength = 0..1 (optional), t = capture time in ms epoch (optional)
    setAudio: (v, beat, strength, t) => {
      audio.raw = clamp(+v || 0, 0, 1);
      audio.at = performance.now();
      // a beat that sat in a queue for >150 ms is history - flashing for it now would look out of sync, so skip it
      if (beat && !(t && Date.now() - t > 150)) {
        audio.beat = Math.max(audio.beat, clamp(+strength || 1.0, 0.5, 1.0));
      }
    },
    triggerBeat: (intensity = 1.0) => {
      audio.beat = Math.max(audio.beat, clamp(+intensity || 1.0, 0.5, 1.0));
      audio.beatCd = 0.10;
    },
    presets: PRESETS,
    types: ['stars','sakura','cherry','embers','rain','leaves','snow','fireflies','none'],
    fileUrl,
  };
  window.addEventListener('storage', (e) => { if (e.key === 'dwut_cosmetics') fromStorage(); });
  window.addEventListener('dwut-theme', refresh);
  try { new MutationObserver(refresh).observe(document.documentElement, { attributes: true, attributeFilter: ['style', 'class', 'data-light', 'data-theme'] }); } catch { /* old engine */ }
  window.addEventListener('resize', build);
  document.addEventListener('visibilitychange', () => { if (document.hidden) cancelAnimationFrame(raf); else { last = 0; raf = requestAnimationFrame(frame); } });
  try { if (window.require) window.require('electron').ipcRenderer.on('cosmetics:audio', (_e, v, b, st, t) => window.DwutBg.setAudio(v, b, st, t)); } catch { /* not a node window */ }
  cur = palette(); fromStorage(); build(); raf = requestAnimationFrame(frame);
})();
