'use strict';
/* Virtualised table (only visible rows are in the DOM) — mirrors the original canvas ScrolledTable */
function VTable(columns, onRowClick) {
  const ROW_H = 26, HDR_H = 28, BUF = 4;
  const colors = { gaming: '#FFD700', excellent: 'var(--success)', good: 'var(--accent)', fair: 'var(--warning)', rejected: 'var(--error)', dead: 'var(--text_disabled)', '': 'var(--text_primary)' };
  const total = columns.reduce((a, c) => a + c[1], 0);
  let rows = [], first = -1, last = -1;
  const hdr = h('div', { style: `height:${HDR_H}px;background:var(--bg_input);border-bottom:1px solid var(--border);min-width:${total}px;position:relative;flex:none` });
  let x = 0; columns.forEach(([t, w]) => { hdr.append(h('div', { class: 'f10', text: t, style: `position:absolute;left:${x + 4}px;top:0;height:${HDR_H}px;line-height:${HDR_H}px;color:var(--text_secondary);white-space:nowrap` })); x += w; });
  const spacer = h('div', { style: 'position:relative;min-width:' + total + 'px;height:0' });
  const body = h('div', { style: 'flex:1;overflow:auto;min-height:0;position:relative', onscroll: () => { hdr.style.transform = `translateX(${-body.scrollLeft}px)`; render(); } }, spacer);
  const hdrWrap = h('div', { style: 'overflow:hidden;flex:none' }, hdr);
  const el = h('div', { class: 'col', style: 'background:var(--bg_card);flex:1;min-height:0' }, hdrWrap, body);
  const rowEl = (i) => {
    const [cells, tag] = rows[i];
    const r = h('div', { style: `position:absolute;left:0;top:${i * ROW_H}px;height:${ROW_H}px;width:${total}px;background:var(${i % 2 === 0 ? '--bg_input' : '--bg_card'});border-bottom:1px solid var(--border);cursor:default` });
    let cx = 0;
    cells.forEach((c, ci) => {
      const col = ci === cells.length - 1 ? (colors[tag] || colors['']) : ci === 0 ? 'var(--text_primary)' : 'var(--text_secondary)';
      r.append(h('div', { class: 'f10', text: c, style: `position:absolute;left:${cx + 4}px;width:${columns[ci][1] - 6}px;top:0;height:${ROW_H}px;line-height:${ROW_H}px;color:${col};white-space:nowrap;overflow:hidden;text-overflow:ellipsis` }));
      cx += columns[ci][1];
    });
    r.addEventListener('click', (e) => onRowClick && onRowClick(i, cells, tag, e));
    r.addEventListener('contextmenu', (e) => { e.preventDefault(); onRowClick && onRowClick(i, cells, tag, e); });
    return r;
  };
  function render(force) {
    const top = body.scrollTop, vh = body.clientHeight || 400;
    const a = Math.max(0, Math.floor(top / ROW_H) - BUF), b = Math.min(rows.length, Math.ceil((top + vh) / ROW_H) + BUF);
    if (!force && a === first && b === last) return;
    first = a; last = b;
    [...spacer.children].forEach((c) => c.remove());
    const frag = document.createDocumentFragment();
    for (let i = a; i < b; i++) frag.append(rowEl(i));
    spacer.append(frag);
  }
  const rowMap = new Map();
  const rebuildMap = () => { rowMap.clear(); rows.forEach((r, i) => { if (r[0] && r[0][0]) rowMap.set(r[0][0], i); }); };
  const resize = () => { spacer.style.height = rows.length * ROW_H + 'px'; render(true); };
  el.setRows = (r) => { rows = r.slice(); rebuildMap(); body.scrollTop = 0; resize(); };
  el.appendRows = (r) => {
    r.forEach((item) => {
      const k = item[0] && item[0][0];
      if (k) rowMap.set(k, rows.length);
      rows.push(item);
    });
    spacer.style.height = rows.length * ROW_H + 'px';
    render(true);
    const stick = body.scrollTop + body.clientHeight >= rows.length * ROW_H - ROW_H * 3;
    if (stick) requestAnimationFrame(() => { body.scrollTop = body.scrollHeight; });
  };
  el.upsertRows = (rList) => {
    let changed = false;
    for (const item of rList) {
      const key = item[0] && item[0][0];
      if (key && rowMap.has(key)) {
        rows[rowMap.get(key)] = item;
        changed = true;
      } else {
        if (key) rowMap.set(key, rows.length);
        rows.push(item);
        changed = true;
      }
    }
    if (changed) {
      spacer.style.height = rows.length * ROW_H + 'px';
      render(true);
    }
  };
  el.clear = () => { rows = []; rowMap.clear(); resize(); };
  el.onShow = () => render(true);
  new ResizeObserver(() => render(true)).observe(body);
  return el;
}

Pages.register('proxy', () => {
  const PROTOCOLS = ['any', 'http', 'socks4', 'socks5'], ANON = ['any', 'elite', 'anonymous', 'transparent'];
  const PING = { '50ms': 50, '80ms': 80, '100ms': 100, '150ms': 150, '300ms': 300, '1000ms': 1000, any: 9999 };
  const REGIONS = ['Any', 'Canada', 'United States', 'United Kingdom', 'Germany', 'France', 'Netherlands', 'Switzerland', 'Japan', 'South Korea', 'Australia', 'Singapore', 'Brazil', 'India', 'Russia'];
  const EXPORT = ['ip:port', 'protocol://ip:port', 'ip:port:protocol', 'Proxifier (*.ppx)', 'ProxyCap', 'Shadowsocks JSON', 'Windows system proxy command'];
  const ROUTING = ['Strict (fail if any hop fails)', 'Fail closed', 'Automatic'];
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (t) => { status.textContent = t; };
  const progress = Progress({ height: 2, radius: 0 }); progress.style.borderRadius = '0';
  const content = h('div', { style: 'flex:1;min-height:0;margin:8px 20px 16px;position:relative' });
  const tabs = {}, history = [];
  let historyBox = null, checkRunning = false, liveStats = {}, liveRows = [], statTimer = null, chain = [];
  const vals = { proto: 'any', region: 'Any', anon: 'any', ping: '80ms', checkerRegion: 'Any' };
  const group = (label, tipText, widget) => h('div', { class: 'col', style: 'margin-right:16px;align-items:flex-start' }, h('div', { class: 'row' }, h('span', { class: 'f11 ts', text: label }), h('span', { style: 'margin-left:4px' }, Info(tipText))), h('div', { style: 'margin-top:4px' }, widget));
  const combo = (values, key, w, onch) => { const o = Option(values, { w, f: 12, value: vals[key], onchange: (v) => { vals[key] = v; onch && onch(v); } }); o.classList.add('bordered'); return o; };

  // ── Generator ──
  let fetchBtn, countLbl, rawBox;
  function buildGenerator() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    fetchBtn = Btn('Fetch Proxies', { h: 34, tip: 'Downloads proxy lists from 90+ public sources in parallel.\\nMerges duplicates and ranks every proxy by how many sources list it\\n(widely-listed proxies are far more likely to be alive) - those get checked first.\\nHuge unchecked dumps are only sampled. Takes 10-30 seconds.', onclick: () => { fetchBtn.disabled = true; progress.set(0); countLbl.textContent = ''; setStatus('Starting fetch...'); rawBox.textContent = ''; rpc('proxy.fetch'); } });
    countLbl = h('div', { class: 'f10 ts', style: 'margin-top:4px;text-align:center' });
    rawBox = h('div', { class: 'textbox', style: 'flex:1;margin-top:4px;background:var(--bg_card);border-radius:6px;font-size:calc(10px*var(--fs));white-space:pre' });
    f.append(Card([h('div', { class: 'f12 b tp', text: 'Source Filters', style: 'padding:10px 14px 6px' }),
      h('div', { class: 'row', style: 'padding:0 14px 10px;align-items:flex-start' },
        group('Protocol', "The proxy protocol to fetch.\n\nHTTP — basic web proxies\nSOCKS4 — faster, no auth support\nSOCKS5 — best: UDP support + authentication\n'any' fetches all three types.", combo(PROTOCOLS, 'proto', 110)),
        group('Region', 'Filter proxies by country of their exit IP.\n\nApplied during the Check phase — the Generator fetches all regions and the region filter is used when checking to discard proxies whose geo-IP does not match your selection.', combo(REGIONS, 'region', 140)),
        group('Min Anonymity', "The minimum anonymity level to accept.\n\nElite       — no identifying headers forwarded to destination\nAnonymous — some headers stripped but Via/Proxy-Connection present\nTransparent — your real IP is forwarded (not private)\n\n'Elite' is recommended for privacy. 'any' accepts all.", combo(ANON, 'anon', 110)),
        h('div', { class: 'col', style: 'margin-left:20px;align-items:center' }, fetchBtn, countLbl))], 'col', { flex: 'none' }), rawBox);
    return f;
  }

  // ── Checker ──
  let pvpnBtn, pvpnOn = false, vpnTunnelOn = false, pvpnStacked = false;
  let checkBtn, stopBtn, table, statLabels = {}, activeLbl, hideDead, customLat, workersIn;
  let stackedLbl = null;
  const rowsOf = (list) => list
    .filter((r) => !(hideDead && hideDead.checked && (r.tier === 'dead' || r.tier === 'rejected')))
    .map((r) => [[
      r.address, r.protocol.toUpperCase(), r.https,
      r.country, r.latency, r.throughput || '—', r.jitter || '—',
      r.anonymity, String(r.score), r.tier.toUpperCase(),
    ], r.tier]);
  function flushStats() {
    const s = liveStats;
    const tot = Object.entries(s).filter(([k]) => !['elite','youtube'].includes(k)).reduce((a,[,v]) => a+v, 0);
    if (statLabels.total)     statLabels.total.textContent     = `Total: ${tot.toLocaleString()}`;
    if (statLabels.gaming)    statLabels.gaming.textContent    = `Gaming: ${s.gaming    || 0}`;
    if (statLabels.excellent) statLabels.excellent.textContent = `Elite: ${s.excellent  || 0}`;
    if (statLabels.youtube)   statLabels.youtube.textContent   = `YouTube: ${s.youtube   || 0}`;
    if (statLabels.good)      statLabels.good.textContent      = `Good: ${s.good       || 0}`;
    if (statLabels.fair)      statLabels.fair.textContent      = `Fair: ${s.fair       || 0}`;
    if (statLabels.rejected)  statLabels.rejected.textContent  = `Rejected: ${(s.rejected||0)+(s.dead||0)}`;
    if (statLabels.elite)     statLabels.elite.textContent     = `Anon: ${s.elite      || 0}`;
  }
  async function refreshActive() {
    try {
      const raw = await rpc('proxy.active');
      const cur = typeof raw === 'string' && raw ? raw : '';
      activeLbl.textContent = cur ? `Active: ${cur}` : 'No proxy active';
      activeLbl.style.color = cur ? 'var(--success)' : 'var(--text_disabled)';
    } catch { /* ignore */ }
  }
  const proxyAction = async (p) => { setStatus('Connecting - testing proxies against YouTube...'); try { const r = await p; setStatus(r.message); if (!r.ok) warn('Proxy', r.message); refreshActive(); } catch (e) { setStatus('Failed: ' + e.message); } };
  function rowMenu(i, cells, tag, e) {
    closeMenus();
    const addr = cells[0], working = ['excellent', 'good', 'fair'].includes(tag), items = [];
    if (working && addr) { const [ip, port] = [addr.slice(0, addr.lastIndexOf(':')), parseInt(addr.slice(addr.lastIndexOf(':') + 1), 10)]; const proto = cells[1].toLowerCase(); items.push([`Enable  ${addr}  (${cells[1]})`, () => proxyAction(rpc('proxy.enable', { ip, port, protocol: proto })), true]); }
    if (addr) { items.push(['Copy  ip:port', () => copyText(addr)]); items.push(['Copy all columns', () => copyText(cells.join('  |  '))]); }
    if (!items.length) return;
    const pop = h('div', { class: 'menu-pop f11', style: `left:${e.clientX}px;top:${e.clientY}px` }, items.map(([t, fn, b]) => h('div', { text: t, style: b ? 'font-weight:700' : '', onclick: () => { closeMenus(); fn(); } })));
    document.body.append(pop); e.stopPropagation();
    if (e.clientX + pop.offsetWidth > innerWidth) pop.style.left = innerWidth - pop.offsetWidth - 4 + 'px';
    if (e.clientY + pop.offsetHeight > innerHeight) pop.style.top = innerHeight - pop.offsetHeight - 4 + 'px';
  }
  async function check() {
    const c = await rpc('proxy.counts'); if (!c.raw) return setStatus('Fetch proxies first.');
    table.clear(); liveStats = {}; liveRows = []; Object.entries(statLabels).forEach(([k, l]) => { l.textContent = l.textContent.split(':')[0] + ': 0'; });
    checkRunning = true; checkBtn.disabled = true; stopBtn.disabled = false; progress.set(0);
    let w = parseInt(workersIn.value, 10); if (Number.isNaN(w)) w = 300; w = Math.max(40, Math.min(w, 600));
    let maxLat = null; const ct = customLat.value.trim();
    if (ct) { const n = parseFloat(ct); if (!Number.isNaN(n)) maxLat = n; }
    if (maxLat == null && PING[vals.ping] < 9999) maxLat = PING[vals.ping];
    rpc('proxy.check', { workers: w, region: vals.checkerRegion, protocol: vals.proto, min_anonymity: vals.anon, max_latency_ms: maxLat }).catch((e) => { setStatus(e.message); checkBtn.disabled = false; });
  }
  async function exportWorking(fmt) {
    const r = await rpc('proxy.export', { fmt });
    if (!r.count) return setStatus('No working proxies to export — run Check first.');
    copyText(r.text); setStatus(`Copied ${r.count} proxies to clipboard in '${fmt}' format`);
  }
  function importDialog() {
    let proto = 'http';
    Modal.custom((close) => {
      const box = h('textarea', { class: 'entry mono', style: 'width:100%;height:210px;font-size:calc(10px*var(--fs));background:var(--bg_card);border:0;resize:none' });
      const st = h('div', { class: 'f10 ts', style: 'min-height:14px;margin:6px 0' });
      const protoOpt = Option(['http', 'socks4', 'socks5'], { w: 110, f: 11, onchange: (v) => { proto = v; } }); protoOpt.classList.add('bordered');
      return h('div', { class: 'modal', style: 'width:520px;background:var(--bg_base)' }, h('h3', { text: 'Paste proxy list', style: 'font-size:13px' }),
        h('div', { class: 'f10 ts', text: 'One proxy per line.  Accepted formats:\n  host:port  |  protocol://host:port  |  host:port:protocol', style: 'white-space:pre;margin-bottom:6px' }),
        h('div', { class: 'row', style: 'margin-bottom:6px' }, h('span', { class: 'f11 ts', text: 'Default protocol:', style: 'margin-right:8px' }), protoOpt), box, st,
        h('div', { class: 'row', style: 'gap:8px' }, Btn('Import', { h: 32, onclick: async () => {
          const text = box.value.trim(); if (!text) return close();
          const r = await rpc('proxy.import', { text, default_protocol: proto });
          if (!r.ok) { st.textContent = `No valid proxies found (${r.skipped} lines skipped).`; st.style.color = 'var(--error)'; return; }
          let m = `Imported ${r.new} new proxies  (${r.dupes} dupes skipped)`; if (r.skipped) m += `  |  ${r.skipped} unparseable lines skipped`;
          setStatus(m); if (countLbl) countLbl.textContent = `${r.total.toLocaleString()} proxies ready`; close();
        } }), Btn('Cancel', { variant: 'ghost', h: 32, onclick: () => close() })));
    });
  }
  function buildChecker() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const ping = combo(Object.keys(PING), 'ping', 100); ping.set('80ms', true);
    customLat = Entry({ placeholder: 'e.g. 800', w: 100, h: 28 }); workersIn = Entry({ w: 70, h: 28, value: '300' });
    checkBtn = Btn('Check All', { h: 34, onclick: check, tip: 'Finds proxies that are FAST and actually work:\\n\\n1. Scans every fetched proxy - hosts too far away to hit your ping limit are dropped instantly\\n2. Detects the real protocol (HTTP / SOCKS5 / SOCKS4) - list labels are often wrong\\n3. Verifies a real HTTPS request through it with full certificate checking (proxies that intercept TLS are rejected)\\n4. Measures the real ping on an open connection, several times, with few workers so the load of this PC cannot skew it\\n5. Checks for IP leaks, anonymity and YouTube, then scores it\\n\\nResults appear fastest-first. Free proxies can still see which sites you visit - never log in to anything through one.' });
    stopBtn = Btn('Stop', { variant: 'ghost', h: 28, style: { color: 'var(--error)' }, tip: 'Forcefully stops the current check.\n\nNo new proxies are started. Anything already mid-check finishes quietly in the background and is discarded — results collected so far are kept.',
      onclick: () => { rpc('proxy.stop'); checkRunning = false; stopBtn.disabled = true; checkBtn.disabled = false; setStatus('Check stopped.'); } });
    stopBtn.disabled = true;
    const exp = Btn('Export Working', { variant: 'ghost', h: 28, tip: 'Export all working proxies (Excellent + Good + Fair) to the clipboard.\n\nEach line is in the format selected under Configure → Export Format.', onclick: () => exportWorking(exportFmt) });
    const imp = Btn('Import List', { variant: 'ghost', h: 28, onclick: importDialog, tip: 'Paste in your own proxy list to add it to the current pool.\n\nAccepted formats:\n  ip:port\n  ip:port:protocol\n  protocol://ip:port\n\nDuplicates are skipped automatically.  Use Check All to validate them.' });
    hideDead = Check('Hide Dead/Rejected', { sm: true, checked: true, themed: true, color: 'var(--text_secondary)', f: 11, onchange: () => table.setRows(rowsOf(liveRows)) });
    tip(hideDead, 'When checked, proxies that failed all check stages are hidden from the results table to reduce clutter.\n\nDead proxies are still counted in the stats bar and included in the full results — only the table view is filtered.\n\nUncheck to see every proxy including dead ones.');
  const tipsS = {
    total: 'Total proxies checked in this session.',
    gaming: 'GAMING tier: SOCKS5, ≤50ms latency, ≤15ms jitter, ≥0.5 MB/s throughput, YouTube OK. Ready for games, streaming, and real-time apps.',
    excellent: 'Score 60+. Fast HTTPS, good throughput, low jitter.',
    youtube: 'Verified 100% working on YouTube and Google.',
    good: 'Solid for streaming and browsing. ≤80ms, ≥0.25 MB/s throughput.',
    fair: 'Working HTTPS, higher latency. OK for light browsing.',
    rejected: 'Failed TLS, HTTPS, or transparent IP leak. Not usable.',
    elite: 'No identifying headers forwarded (X-Forwarded-For etc.).',
  };
  const stats = h('div', { class: 'row', style: 'padding:0 14px 10px;flex-wrap:wrap;gap:4px' });
  [['total','Total: 0','var(--text_primary)'], ['gaming','Gaming: 0','#FFD700'], ['excellent','Elite: 0','var(--success)'],
   ['youtube','YouTube: 0','#FF4444'], ['good','Good: 0','var(--accent)'], ['fair','Fair: 0','var(--warning)'],
   ['rejected','Rejected: 0','var(--error)'], ['elite','Anon: 0','var(--info)']]
    .forEach(([k, t, c]) => { const l = h('span', { class: 'f11 b', text: t, style: `color:${c};margin:0 6px` }); tip(l, tipsS[k]); statLabels[k] = l; stats.append(l); });
    f.append(Card([h('div', { class: 'row', style: 'padding:10px 14px;align-items:flex-start;flex-wrap:wrap;gap:6px' },
      group('Max Ping', 'Maximum latency accepted.\n\n80ms = proxies physically close to you.\nGaming needs ≤50ms ideally.\nRaise to 150ms+ only if you find nothing.', ping),
      group('Custom Ping (ms)', 'Type an exact max ping to override the preset. Leave blank to use the preset.', customLat),
      group('Region', "Only keep proxies in this country. 'Any' = no restriction.", combo(REGIONS, 'checkerRegion', 130)),
      group('Workers', 'Simultaneous checks. 300 is a good balance. Higher = faster but heavier.', workersIn),
      h('div', { class: 'col', style: 'gap:4px' }, checkBtn, stopBtn, exp, imp),
      h('div', { style: 'margin-left:16px;align-self:flex-start' }, hideDead)), stats], 'col', { marginBottom: '8px', flex: 'none' }));
    const connect = Btn('Connect to Best', { h: 32, w: 150, bold: true, f: 12,
      tip: 'Picks the best VERIFIED-LIVE proxy right now.\n\nPriority: Gaming (SOCKS5 + fast + low jitter) → Elite → Good → Fair.\nRe-checks the proxy is actually alive before connecting — stale/dead entries are skipped automatically.\n\nFor gaming: SOCKS5 proxies tunnel any protocol. HTTP proxies only work for web traffic.\nAuto-failover switches to the next-best proxy if the current one drops.',
      onclick: () => proxyAction(rpc('proxy.connect_best')),
    });
    activeLbl = h('span', { class: 'f11 td', text: 'No proxy active', style: 'margin-left:14px' });

    f.append(Card([h('div', { class: 'row', style: 'padding:8px 14px;flex-wrap:wrap;gap:6px' },
      connect,
      Btn('Disconnect Proxy', { variant: 'ghost', h: 32, w: 130, style: { marginLeft: '8px' },
        tip: 'Disables the Windows system proxy, restoring direct internet access.',
        onclick: async () => { await rpc('proxy.disconnect'); refreshActive(); }
      }),
      activeLbl)], 'col', { marginBottom: '6px', flex: 'none' }));
    f.append(h('div', { class: 'f9 td', text: 'Click any working row to enable that proxy  |  Right-click to copy  |  GAMING = SOCKS5 ready for games  |  Speed = real download throughput', style: 'padding:0 4px 2px' }));
    table = VTable([
      ['IP : Port', 146], ['Protocol', 62], ['HTTPS', 50], ['Country', 80],
      ['Latency', 58], ['Speed', 66], ['Jitter', 56], ['Anonymity', 76], ['Score', 42], ['Status', 78],
    ], rowMenu);
    f.append(table); setTimeout(refreshActive, 200);
    f.__show = () => table.onShow();
    return f;
  }
  let exportFmt = EXPORT[0];

  // ── Configure ──
  function swRow(label, tipText, checked) {
    const sw = Switch({ big: true, checked });
    return h('div', { class: 'row', style: 'padding:3px 14px' }, h('div', { class: 'row grow' }, h('span', { class: 'f11 ts', text: label }), h('span', { style: 'margin-left:4px' }, Info(tipText))), sw);
  }
  function renderChain() {
    chainList.textContent = '';
    if (!chain.length) { chainList.append(h('div', { class: 'f10 td', text: 'No proxies in chain.  Add below or Import from Checker.', style: 'text-align:center;padding:20px' })); chainStatus.textContent = '● No chain'; chainStatus.style.color = 'var(--text_disabled)'; return; }
    rpc('proxy.chain_info', { addrs: chain }).then((info) => {
      chainList.textContent = '';
      chain.forEach((node, i) => {
        const pc = { SOCKS5: 'var(--accent)', SOCKS4: 'var(--info)', HTTP: 'var(--warning)' }[info[i].proto] || 'var(--text_secondary)';
        chainList.append(h('div', { class: 'row', style: `background:var(${i % 2 === 0 ? '--bg_card' : '--bg_input'});border-radius:4px;margin:2px 4px` },
          h('span', { class: 'f10 b c-acc', text: `#${i + 1}`, style: 'width:30px;text-align:center;margin:6px 4px 6px 8px' }), h('span', { class: 'f10 td', text: i < chain.length - 1 ? '->' : '', style: 'width:16px;text-align:center' }),
          h('span', { class: 'f11 b tp', text: node, style: 'margin:0 6px' }),
          info[i].proto !== '?' ? h('span', { class: 'f9 b', text: info[i].proto, style: `color:#000;background:${pc};border-radius:3px;width:50px;text-align:center;margin:0 4px` }) : null,
          info[i].latency ? h('span', { class: 'f10 ts', text: info[i].latency, style: 'margin:0 2px' }) : null, h('div', { class: 'grow' }),
          Btn('X', { variant: 'plain', w: 28, h: 24, f: 12, style: { minWidth: '28px', margin: '0 6px', color: 'var(--text_disabled)' }, onclick: () => { chain.splice(i, 1); renderChain(); } })));
      });
      const n = chain.length; chainStatus.textContent = `${n} hop${n !== 1 ? 's' : ''}`; chainStatus.style.color = 'var(--success)';
    });
  }
  let chainList, chainStatus;
  function buildConfigure() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0;padding-right:4px' });
    chainList = h('div', { class: 'scroll', style: 'height:190px;margin:2px' }); chainStatus = h('span', { class: 'f10 b td', text: 'No chain' });
    const chainTest = h('div', { class: 'f10 ts', style: 'padding:0 14px 4px' });
    const chainBtn = (t, v, tp, fn) => Btn(t, { variant: v, h: 30, tip: tp, onclick: fn, cls: 'auto' });
    const addBest = async () => { const r = await rpc('proxy.chain_candidates', { used: chain, limit: 1 }); if (r.none) return setStatus('No good proxies available — run Check first.'); if (!r.addrs.length) return setStatus('All good proxies already added to chain.'); chain.push(r.addrs[0]); renderChain(); };
    const impChk = async () => { const r = await rpc('proxy.chain_candidates', { used: chain, limit: 8 - chain.length }); if (r.none) return setStatus('No good proxies to import — run Check All first.'); chain.push(...r.addrs.slice(0, Math.max(0, 8 - chain.length))); renderChain(); setStatus(`Imported ${r.addrs.length} proxies into chain.`); };
    const testChain = async () => {
      if (!chain.length) return setStatus('Add nodes to the chain first.');
      setStatus(`Testing chain (${chain.length} hops)…`);
      try {
        const r = await rpc('proxy.chain_test', { nodes: chain }); const failed = r.hops.filter((x) => !x[1]).map((x) => x[0]);
        const hs = failed.length ? `TCP fail: ${failed.join(', ')}` : `All ${r.hops.length} hops reachable`;
        setStatus(r.success ? `Chain OK — exit IP: ${r.exit_ip}  (${r.exit_ms})  |  ${hs}` : `Chain FAILED — ${(r.error || 'unknown error').slice(0, 60)}  |  ${hs}`);
      } catch (e) { setStatus('Chain test error: ' + e.message); }
    };
    const routing = Option(ROUTING, { w: 240, f: 12 }); routing.classList.add('bordered');
    f.append(Card([h('div', { class: 'row', style: 'padding:12px 14px 4px' }, h('span', { class: 'f13 b tp', text: 'Proxy Chain Builder' }), h('span', { style: 'margin-left:6px' }, Info('Routes traffic through multiple proxies in sequence.\n\nExample: You → US → DE → NL → Target\n\nOnly Good/Excellent proxies from the Checker can be added.')), h('div', { class: 'grow' }), chainStatus),
      h('div', { style: 'background:var(--bg_input);border-radius:6px;margin:0 14px 6px' }, chainList),
      h('div', { class: 'row', style: 'padding:0 14px 6px;gap:4px' }, chainBtn('+ Add Best Proxy', 'ghost', 'Add the highest-scoring checked proxy not already in the chain.', addBest), chainBtn('Import from Checker', 'ghost', 'Fill chain with best proxies from Checker results (max 8 hops).', impChk),
        chainBtn('Clear', 'ghost', 'Remove all nodes.', () => { chain = []; renderChain(); }), chainBtn('Test Chain', 'primary', 'Route a live request through the chain. Failing hops auto-removed.', testChain),
        chainBtn('Export', 'ghost', 'Copy the chain to clipboard.', () => { if (chain.length) { copyText(chain.join('\n')); setStatus(`Chain (${chain.length} nodes) copied to clipboard.`); } })),
      chainTest,
      h('div', { style: 'background:var(--bg_input);border-radius:6px;margin:0 14px 12px' }, h('div', { class: 'row', style: 'padding:8px 12px' }, h('span', { class: 'f11 ts', text: 'Routing:' }), h('span', { style: 'margin-left:10px' }, routing)),
        h('div', { class: 'row', style: 'padding:0 12px 8px' }, h('span', { class: 'f11 ts', text: 'DNS through proxy:' }), h('span', { style: 'margin-left:10px' }, Switch({ big: true, checked: true })))) ], 'col', { marginBottom: '12px' }));
    renderChain();
    const fmtOpt = Option(EXPORT, { w: 240, f: 12, onchange: (v) => { exportFmt = v; } }); fmtOpt.classList.add('bordered');
    f.append(Card([h('div', { class: 'row', style: 'padding:12px 14px 6px' }, h('span', { class: 'f13 b tp', text: 'Export Format' }), h('span', { style: 'margin-left:6px' }, Info('Choose the format for exporting your checked proxy list.\n\nip:port is the simplest and works with most tools.\nProxifier and ProxyCap formats can be imported directly into those apps.\nShadowsocks JSON is used by shadowsocks-ng / Clash / v2ray.'))),
      h('div', { class: 'row', style: 'padding:0 14px 10px;gap:8px' }, h('span', { class: 'f11 ts', text: 'Format:' }), fmtOpt, Btn('Export List', { h: 30, onclick: () => exportWorking(exportFmt), tip: 'Export all working proxies in the selected format to the clipboard.\n\nYou must run Check All before exporting — exporting before checking will produce an empty result since no proxies have been validated yet.' }))], 'col', { marginBottom: '12px' }));
    f.append(Card([h('div', { class: 'f13 b tp', text: 'Checker Settings', style: 'padding:12px 14px 6px' }),
      swRow('Verify exit IP through proxy', 'Route a request through the proxy to confirm the exit IP differs from yours.\nDetects transparent proxies. Adds ~2s per proxy to check time.', true),
      swRow('Test anonymity headers', 'Send a request to httpbin.org/headers through the proxy and check if identifying headers (X-Forwarded-For, Via, etc.) are present.\nAdds ~3s per proxy but is the only reliable way to detect elite vs anonymous.', true),
      swRow('Detect pooled/datacenter proxies', 'Flag proxies on known datacenter ASNs (AWS, Azure, Hetzner, OVH, etc.).\nThese are often blocked by sites that detect hosting provider IPs.', true),
      swRow('Multi-request pool detection', 'Send 3 requests through the same proxy and compare exit IPs.\nIf they differ, the proxy is confirmed to use a shared pool.\nAdds ~5s per proxy but is the most reliable pool detection method.', true), h('div', { style: 'height:8px' })], 'col', { marginBottom: '12px' }));
    const defaults = h('div', { class: 'col', style: 'padding:0' });
    rpc('proxy.defaults').then((d) => {
      const erow = (label, tipText, widget) => h('div', { class: 'row', style: 'padding:4px 14px' }, h('div', { class: 'row grow' }, h('span', { class: 'f11 ts', text: label }), h('span', { style: 'margin-left:4px' }, Info(tipText))), widget);
      const wIn = Entry({ w: 72, value: String(d.workers), onchange: (v) => { const n = parseInt(v, 10); if (n >= 1 && n <= 500) Cfg.set({ proxy_max_workers: n }); } }); wIn.style.textAlign = 'right';
      const tIn = Entry({ w: 72, value: String(d.timeout), onchange: (v) => { const n = parseInt(v, 10); if (n >= 1 && n <= 120) Cfg.set({ proxy_timeout_s: n }); } }); tIn.style.textAlign = 'right';
      const an = Option(['any', 'elite', 'anonymous'], { w: 140, f: 12, value: d.anonymity, onchange: (v) => Cfg.set({ proxy_default_anonymity: v }) });
      const pr = Option(PROTOCOLS, { w: 140, f: 12, value: d.protocol, onchange: (v) => Cfg.set({ proxy_default_protocol: v }) });
      an.classList.add('bordered'); pr.classList.add('bordered');
      defaults.append(erow('Max concurrent workers', 'How many proxies are checked simultaneously.\n\nHigher = faster but heavier on CPU/RAM.\n50 is a good balance.', wIn), erow('Check timeout (seconds)', 'Max wait per proxy during a check.\n\nLower = faster but may reject slow working proxies.\nDefault: 10s.', tIn),
        erow('Default anonymity filter', 'Pre-selected anonymity level in the Checker.\n\nElite = no identifying headers (most private)\nAnonymous = some headers stripped\nAny = all levels accepted.', an), erow('Default protocol', 'Pre-selected protocol filter in the Generator and Checker.\n\nSOCKS5 is the most capable.  \'any\' fetches all three types.', pr), h('div', { style: 'height:6px' }));
    });
    f.append(Card([h('div', { class: 'row', style: 'padding:12px 14px 4px' }, h('span', { class: 'f13 b tp', text: 'Proxy Defaults' }), h('span', { style: 'margin-left:6px' }, Info('These defaults are also editable in Settings → Proxy Defaults.\n\nChanges take effect immediately for new check/fetch operations.'))), defaults], 'col', { marginBottom: '12px' }));
    return f;
  }

  // ── History ──
  function historyRow(kind, ts, total, ex, good, fair) {
    let summary = `${total.toLocaleString()} proxies`; if (kind === 'Check') summary += `  |  ${ex + good + fair} working (${ex} excellent, ${good} good, ${fair} fair)`;
    return h('div', { class: 'row', style: 'background:var(--bg_input);border-radius:4px;margin:2px 0' }, h('span', { class: 'f10 td', text: ts, style: 'width:70px;margin:6px 8px' }), h('span', { class: 'f11 b tp', text: kind, style: 'width:60px' }), h('span', { class: 'f11 ts', text: summary, style: 'margin-left:8px' }));
  }
  function buildHistory() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    historyBox = h('div', { class: 'scroll', style: 'flex:1;background:var(--bg_card);border-radius:6px;padding:4px' });
    f.append(h('div', { class: 'f14 b tp', text: 'Session History', style: 'margin-bottom:10px' }), historyBox);
    if (history.length) history.forEach((x) => historyBox.append(historyRow(...x))); else historyBox.append(h('div', { class: 'f11 td', text: 'No sessions yet. Fetch and check proxies to see history here.', style: 'padding:30px;text-align:center', 'data-empty': '1' }));
    return f;
  }
  function addHistory(kind, total, ex, good, fair) {
    const d = new Date(), ts = [d.getHours(), d.getMinutes(), d.getSeconds()].map((n) => String(n).padStart(2, '0')).join(':');
    history.push([kind, ts, total, ex, good, fair]);
    if (historyBox) { $$('[data-empty]', historyBox).forEach((n) => n.remove()); historyBox.append(historyRow(kind, ts, total, ex, good, fair)); }
  }

  // ── events ──
  on(EV_FETCH_PROGRESS(), (d) => { progress.set(d.completed / Math.max(d.total, 1)); setStatus(`Fetching ${d.completed}/${d.total}  —  ${d.running_total} found`); });
  function EV_FETCH_PROGRESS() { return 'proxy.fetch_progress'; }
  on('proxy.connect_progress', (m) => setStatus(m));
  on('proxy.fetch_done', (d) => {
    if (fetchBtn) fetchBtn.disabled = false; progress.set(1);
    setStatus(`Fetch done  —  ${d.count.toLocaleString()} unique proxies`);
    if (countLbl) countLbl.textContent = `${d.count.toLocaleString()} proxies fetched`;
    if (rawBox) { rawBox.textContent = d.preview.join('\n') + (d.count > 3000 ? `\n... ${d.count - 3000} more (showing first 3000)\n` : '\n'); }
    addHistory('Fetch', d.count, 0, 0, 0);
  });
  on('proxy.check_progress', (d) => { progress.set(d.completed / Math.max(d.total, 1)); if (statLabels.total) statLabels.total.textContent = `Total: ${(d.total || 0).toLocaleString()}`; setStatus(d.msg || `Checking ${d.completed.toLocaleString()}/${d.total.toLocaleString()}  -  ${d.working || 0} good so far`); });
  on('proxy.batch', (batch) => {
    for (const r of batch) {
      const idx = liveRows.findIndex((x) => x.address === r.address);
      if (idx >= 0) {
        const old = liveRows[idx];
        if (old.tier) liveStats[old.tier] = Math.max(0, (liveStats[old.tier] || 1) - 1);
        if (old.yt) liveStats.youtube = Math.max(0, (liveStats.youtube || 1) - 1);
        if (old.elite && old.tier !== 'dead') liveStats.elite = Math.max(0, (liveStats.elite || 1) - 1);
        liveRows[idx] = r;
      } else {
        liveRows.push(r);
      }
      liveStats[r.tier] = (liveStats[r.tier] || 0) + 1;
      if (r.yt) liveStats.youtube = (liveStats.youtube || 0) + 1;
      if (r.elite && r.tier !== 'dead') liveStats.elite = (liveStats.elite || 0) + 1;
    }
    if (!table) return;
    const rows = rowsOf(batch);
    if (rows.length) {
      if (table.upsertRows) table.upsertRows(rows);
      else table.appendRows(rows);
    }
    flushStats();
    if (checkRunning) {
      const gaming  = liveStats.gaming   || 0;
      const good    = gaming + (liveStats.excellent || 0) + (liveStats.good || 0) + (liveStats.fair || 0);
      const bad     = (liveStats.rejected || 0) + (liveStats.dead || 0);
      setStatus(`Checking...  🎮 ${gaming} gaming  ✓ ${good} working  ✗ ${bad} dead  (${liveRows.length} checked)`);
    }
  });
  on('proxy.check_done', (d) => {
    loadLocs();
    checkRunning = false; if (!checkBtn) return;
    checkBtn.disabled = false; stopBtn.disabled = true; progress.set(1);
    if (statLabels.total)     statLabels.total.textContent     = `Total: ${(d.total || 0).toLocaleString()}`;
    if (statLabels.gaming)    statLabels.gaming.textContent    = `Gaming: ${d.gaming || 0}`;
    if (statLabels.excellent) statLabels.excellent.textContent = `Elite: ${d.excellent || 0}`;
    if (statLabels.youtube)   statLabels.youtube.textContent   = `YouTube: ${d.youtube || 0}`;
    if (statLabels.good)      statLabels.good.textContent      = `Good: ${d.good || 0}`;
    if (statLabels.fair)      statLabels.fair.textContent      = `Fair: ${d.fair || 0}`;
    if (statLabels.rejected)  statLabels.rejected.textContent  = `Rejected: ${d.rejected || 0}`;
    if (statLabels.elite)     statLabels.elite.textContent     = `Anon: ${d.elite || 0}`;
    const lim = d.limit ? `${Math.round(d.limit)} ms` : 'any ping';
    const gaming = d.gaming || 0;
    if (d.working > 0) {
      const gamingStr = gaming > 0 ? `  /  ${gaming} gaming-ready` : '';
      setStatus(`Done  --  ${d.working} working proxies at ${lim} or better${gamingStr}  (fastest ${Math.round(d.best_ping || 0)} ms)  --  scanned ${(d.scanned || 0).toLocaleString()} in ${d.elapsed}s${d.stopped ? '  (stopped early)' : ''}`);
    } else if (d.fallback_ping) {
      setStatus(`No proxy at ${lim} or better right now. Fastest working one was ${Math.round(d.fallback_ping)} ms -- raise Max Ping to see it, or fetch fresh proxies and try again.`);
    } else {
      setStatus(`No working proxy found at ${lim} this scan (${(d.fast_hosts || 0).toLocaleString()} fast hosts, none passed verification). Fetch again -- the lists refresh every few minutes.`);
    }
    addHistory('Check', d.total, d.excellent || 0, d.good || 0, d.fair || 0);
  });


  const builders = { Generator: buildGenerator, Checker: buildChecker, Configure: buildConfigure, History: buildHistory };
  function switchTab(name) {
    for (const [n, t] of Object.entries(tabs)) { t.btn.classList.toggle('active', n === name); if (t.frame) t.frame.style.display = n === name ? '' : 'none'; }
    const t = tabs[name]; if (!t.frame) { t.frame = builders[name](); content.append(t.frame); }
    t.frame.style.display = ''; if (t.frame.__show) t.frame.__show();
  }
  const tabBar = h('div', { class: 'row', style: 'padding:0 20px' });
  for (const n of Object.keys(builders)) { const btn = Btn(n, { variant: 'plain', cls: 'tab f12', onclick: () => switchTab(n) }); tabs[n] = { btn, frame: null }; tabBar.append(h('span', { style: 'margin:0 2px' }, btn)); }
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' }, h('div', { class: 'title-row' }, h('h1', { text: 'Proxy Center' }), h('div', { class: 'grow' }), status), tabBar, h('div', { class: 'divider', style: 'margin:0 20px' }), progress, content);
  // build the other tabs up-front (like the original prewarm) so events always have widgets
  switchTab('Checker'); switchTab('Configure'); switchTab('History'); switchTab('Generator');
  return { el, onShow() { const t = tabs.Checker.frame; if (t && t.__show) t.__show(); } };
});
