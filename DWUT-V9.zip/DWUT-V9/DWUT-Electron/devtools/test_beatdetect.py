"""
Offline self-test for the music-sync beat detector (no Windows / audio device needed).

    python devtools/test_beatdetect.py

Builds synthetic "songs" with KNOWN drum positions - including hard cases (loud pad + bass line masking the kick, no kick at
all, very quiet playback, steady noise that must NOT trigger) - and reports how many hits were caught, how late, and how many
false triggers there were.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))
from modules.system.beatdetect import BeatDetector  # noqa: E402

SR = 48000
RNG = np.random.default_rng(7)


def env(n, decay):
    return np.exp(-np.arange(n) / (SR * decay))


def tail(clip, ms=12):
    """Short fade-out so a one-shot never ends with a click (real samples are edited that way too)."""
    n = max(1, int(SR * ms / 1000))
    clip = clip.copy()
    clip[-n:] *= np.linspace(1, 0, n)
    return clip


def kick(dur=0.30):
    n = int(SR * dur)
    t = np.arange(n) / SR
    f = 45 + 110 * np.exp(-t * 28)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return tail((np.sin(ph) * env(n, 0.09) * 0.95).astype(np.float32), 40)


def bandpass_noise(n, lo, hi):
    spec = np.fft.rfft(RNG.standard_normal(n))
    fr = np.fft.rfftfreq(n, 1 / SR)
    spec[(fr < lo) | (fr > hi)] = 0
    y = np.fft.irfft(spec, n)
    return y / (np.abs(y).max() + 1e-9)


def snare(dur=0.2):
    n = int(SR * dur)
    t = np.arange(n) / SR
    body = np.sin(2 * np.pi * 190 * t) * env(n, 0.05)
    nz = bandpass_noise(n, 1500, 9000) * env(n, 0.07)
    return tail(((0.5 * body + 0.8 * nz) * 0.8).astype(np.float32), 20)


def hat(dur=0.06):
    n = int(SR * dur)
    return tail((bandpass_noise(n, 5000, 11000) * env(n, 0.012) * 0.45).astype(np.float32), 10)


def mix(buf, clip, at):
    i = int(at * SR)
    j = min(len(buf), i + len(clip))
    if i < len(buf):
        buf[i:j] += clip[: j - i]


def saw(f, n, detune=0.0):
    t = np.arange(n) / SR
    return 2 * ((t * f * (1 + detune)) % 1.0) - 1.0


def make_song(secs=24, bpm=128, with_kick=True, pad=True, bass=True, vocal=True, hats=True, snares=True):
    n = int(SR * secs)
    y = np.zeros(n, dtype=np.float32)
    beat = 60.0 / bpm
    truth = {"kick": [], "snare": [], "hat": []}
    if pad:                                    # loud sustained chord pad (what hides the kick from a loudness meter)
        for f in (220.0, 277.2, 329.6, 440.0):
            for d in (-0.004, 0.0, 0.004):
                y += (saw(f, n, d) * 0.07).astype(np.float32)
    if bass:                                   # sustained bass line, changes note every 2 beats
        seg = int(SR * beat * 2)
        notes = np.zeros(n)
        for k, f in enumerate((55.0, 55.0, 49.0, 61.7) * 40):
            i = k * seg
            if i >= n:
                break
            notes[i:i + seg] = f
        notes = np.convolve(notes, np.ones(2400) / 2400, "same")          # glide between notes (no clicks)
        y += (np.sin(2 * np.pi * np.cumsum(notes) / SR) * 0.30).astype(np.float32)
    if vocal:                                  # vibrato "vocal": harmonic stack with slow pitch wobble
        t = np.arange(n) / SR
        f0 = 330 + 12 * np.sin(2 * np.pi * 5.5 * t)
        ph = 2 * np.pi * np.cumsum(f0) / SR
        v = sum(np.sin(ph * h) / h for h in range(1, 9))
        y += (v * 0.12 * (0.7 + 0.3 * np.sin(2 * np.pi * 0.4 * t))).astype(np.float32)
    k = kick()
    s = snare()
    h = hat()
    t = 0.5
    bi = 0
    while t < secs - 0.4:
        if with_kick:
            mix(y, k, t)
            truth["kick"].append(t)
        if snares and bi % 2 == 1:
            mix(y, s, t)
            truth["snare"].append(t)
        if hats:
            mix(y, h, t + beat / 2)
            truth["hat"].append(t + beat / 2)
        t += beat
        bi += 1
    y = y / (np.abs(y).max() + 1e-9) * 0.8
    return y.astype(np.float32), truth


def run(y, chunk=480):
    """Feed audio in chunk-sized pieces like a capture callback would. -> list of (time_s, strength, band)."""
    det = BeatDetector(SR)
    out, t0, levels = [], 0, []
    for i in range(0, len(y), chunk):
        for fr in det.process(y[i:i + chunk]):
            t0 += det.hop
            levels.append(fr.level)
            if fr.beat:
                out.append((t0 / SR - det.win / SR / 2 + det.hop / SR, fr.strength, fr.band, fr.bands))
    return out, levels


def score(events, times, early=0.015, late=0.060, bands=None):
    """Hit rate for ground-truth `times`: an event within [t-early, t+late] (optionally only of given bands) counts."""
    ev = [e for e in events if bands is None or any(b in e[3] for b in bands)]
    hit, lat = 0, []
    for tt in times:
        c = [e[0] - tt for e in ev if -early <= e[0] - tt <= late]
        if c:
            hit += 1
            lat.append(min(c, key=abs))
    return hit, len(times), (np.mean(lat) * 1000 if lat else float("nan"))


def main() -> int:
    ok = True
    cases = [
        ("full mix: loud pad + bass + vocal + kick/snare/hat", dict()),
        ("no kick (pad + vocal + snare + hats)", dict(with_kick=False, bass=False)),
        ("kick + bass only", dict(pad=False, vocal=False, hats=False, snares=False)),
        ("dense: 170 bpm", dict(bpm=170)),
    ]
    for name, kw in cases:
        y, truth = make_song(**kw)
        ev, lv = run(y)
        print(f"\n== {name}")
        allhits = sorted(truth["kick"] + truth["snare"] + truth["hat"])
        for who, tms, bands in (("kick", truth["kick"], ("bass",)), ("snare", truth["snare"], ("mid", "bass", "high")),
                                ("hat", truth["hat"], ("high",))):
            if not tms:
                continue
            h, n, lat = score(ev, tms, bands=bands)
            print(f"   {who:5s}: {h:3d}/{n:3d} caught ({100 * h / n:5.1f}%)   mean offset {lat:+5.1f} ms")
        h, n, lat = score(ev, allhits)
        fp = sum(1 for e in ev if not any(-0.02 <= e[0] - tt <= 0.07 for tt in allhits))
        print(f"   ANY   : {h:3d}/{n:3d} caught ({100 * h / n:5.1f}%)   false triggers: {fp} of {len(ev)} events ({len(ev) / (len(y) / SR):.1f}/s)")
        if kw.get("with_kick", True):
            hk, nk, _ = score(ev, truth["kick"], bands=("bass",))
            if hk / nk < 0.90:
                ok = False
                print("   !! kick hit-rate below 90%")
        if h / n < 0.85 or fp > 0.12 * max(len(ev), 1):
            ok = False
            print("   !! overall hit-rate below 85% or too many false triggers")

    # volume invariance: same song 20x quieter
    y, truth = make_song()
    ev_loud, _ = run(y)
    ev_quiet, _ = run(y * 0.05)
    hk_l = score(ev_loud, truth["kick"], bands=("bass",))[0]
    hk_q = score(ev_quiet, truth["kick"], bands=("bass",))[0]
    print(f"\n== volume invariance: kicks caught loud {hk_l}/{len(truth['kick'])}  vs 20x quieter {hk_q}/{len(truth['kick'])}")
    if hk_q < 0.9 * hk_l:
        ok = False
        print("   !! quiet playback loses hits")

    # chunk-size independence (capture callbacks come in odd sizes)
    ev_a, _ = run(y, chunk=480)
    ev_b, _ = run(y, chunk=1021)
    print(f"== chunk independence: {len(ev_a)} events with 480-sample chunks vs {len(ev_b)} with 1021-sample chunks")
    if abs(len(ev_a) - len(ev_b)) > 2:
        ok = False
        print("   !! results depend on chunk size")

    # things that must NOT trigger
    n = SR * 10
    spec = np.fft.rfft(RNG.standard_normal(n))
    fr = np.fft.rfftfreq(n, 1 / SR)
    spec[1:] /= np.sqrt(fr[1:])                                   # 1/f power = pink noise
    pink = np.fft.irfft(spec, n)
    pink = (pink / np.abs(pink).max() * 0.3).astype(np.float32)
    ev, _ = run(pink)
    print(f"== steady pink noise (10 s): {len(ev)} false triggers")
    if len(ev) > 8:
        ok = False
    white = (RNG.standard_normal(n) * 0.1).astype(np.float32)
    ev, _ = run(white)
    print(f"== steady white noise (10 s, worst case for the 3-bin bass band): {len(ev)} false triggers")
    if len(ev) > 12:
        ok = False
    tone = (np.sin(2 * np.pi * 440 * np.arange(SR * 10) / SR) * 0.4).astype(np.float32)
    ev, _ = run(tone)
    print(f"== steady tone  (10 s): {len(ev)} false triggers")
    if len(ev) > 2:
        ok = False
    ev, lv = run(np.zeros(SR * 5, dtype=np.float32))
    print(f"== digital silence (5 s): {len(ev)} triggers, max level {max(lv):.3f}")
    if ev or max(lv) > 0.01:
        ok = False

    # silence -> music: the first beats after silence must still be caught
    gap = np.zeros(SR * 3, dtype=np.float32)
    song, tr = make_song(secs=12)
    ev, _ = run(np.concatenate([gap, song]))
    shifted = [t + 3 for t in tr["kick"]]
    h, n, _ = score(ev, shifted, bands=("bass",))
    print(f"== after 3 s of silence: kicks caught {h}/{n}")
    if h / n < 0.85:
        ok = False

    print("\nRESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
