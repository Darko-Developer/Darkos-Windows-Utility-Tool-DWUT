"""
modules/proxy/checker.py  -  proxy validation v5: only proxies that REALLY work make it into the list.

Every proxy that gets past the quick TCP scan goes through ONE complete test, and a row is shown only when the test is finished
(so no half-filled "-" rows any more):

  1. TCP scan      - hosts whose connect time already exceeds the ping limit can never reach it through a proxy -> dropped.
  2. Protocol      - auto-detect HTTP / SOCKS5 / SOCKS4 and do a VERIFIED HTTPS request (full certificate check).
  3. Ping + jitter - 8 requests on one open connection; the median is the ping, the spread is the jitter.
  4. YouTube       - www.youtube.com must answer through the proxy (required by default).
  5. Discord       - discord.com API reachability (bonus flag; Cloudflare blocks many datacenter proxies, so not required).
  6. Speed         - a real multi-MB download through the proxy, measured after TCP warm-up (a few at a time so they do not
                     choke each other or your own connection).
  7. Leak check    - the exit IP must differ from yours.  Anonymity level is informational only.

Ports used by RATs, miners, Tor relays and system services are never checked (modules/proxy/ports.py).

Tiers:  GAMING   ping <= 50 ms, jitter <= 20 ms, speed >= 1.5 x minimum
        ELITE    ping <= 70 ms, speed >= minimum
        GOOD     ping <= limit (default 90 ms), speed >= minimum
        FAIR     ping <= limit, speed >= half the minimum
Anything slower, blocked from YouTube or leaking your IP is not listed.

v9 changes (why the checker used to find nothing / list dead proxies):
  * the HTTP reader now handles chunked / close-delimited replies (before, a chunked reply silently lost the exit IP and
    the leak check was skipped) and a target that answers oddly no longer kills the whole proxy - the next target is tried,
  * protocol detection is a SHORT handshake sniff (~1-2 s) instead of a full 5 s timeout per wrong guess x 3 protocols x 3 targets
    (a silent proxy used to cost 15 s of a worker, a mislabeled one 5 s),
  * ping is measured again in a QUIET pass (a few workers, nothing else running) - the number taken while hundreds of
    scan/verify threads fight over the GIL was inflated by tens of ms, which is what made the 90 ms limit unreachable,
  * that quiet pass is also the "works RIGHT NOW" re-check (fresh connection, YouTube again); proxies that died are dropped,
  * proxies a little above the ping limit (up to SOFT_PING_FACTOR x) are listed last as FAIR instead of being thrown away;
    set SOFT_PING_FACTOR = 1.0 for a hard limit.

NOTE: a system proxy carries TCP only.  Web, YouTube, downloads and Discord CHAT work; UDP traffic (Discord VOICE, most
online games) is never carried by an HTTP/SOCKS-over-system-proxy setup - that needs a VPN-style tunnel.
"""
from __future__ import annotations

import ipaddress
import json as _json
import math
import platform
import queue
import socket
import ssl
import statistics
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from dataclasses import dataclass, field, replace
from typing import Optional

import requests

from core.events import Events, bus
from core.logger import get_logger
from modules.proxy.ports import is_blocked_port
from modules.proxy.relay import Upstream, open_tunnel
from modules.proxy.sources import ProxyRecord

_log = get_logger(__name__)

DEFAULT_MAX_LATENCY_MS = 90.0
DEFAULT_MIN_SPEED_MBPS = 1.0   # MB/s of real download speed through the proxy (~8 Mbit/s: smooth 1080p YouTube + downloads)
DEFAULT_TARGET = 200           # collect this many good proxies then stop

SOFT_PING_FACTOR = 1.6         # ping between limit and limit x this is still listed (as FAIR, after every in-limit proxy). 1.0 = strict
REQUALIFY_WORKERS = 6          # quiet-pass workers: few on purpose, so the ping is measured on an idle system
REQUALIFY_BUDGET_S = 100.0     # max wall time of the quiet pass

_SOCKS_PORTS = {1080, 1081, 1085, 1086, 4145, 4153, 5678, 9050, 9051, 9150,
                10800, 10801, 7890, 7891, 20000}
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
       "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
_DATACENTER_ASNS = {
    "AS14618", "AS16509", "AS15169", "AS8075", "AS20473", "AS14061",
    "AS16276", "AS24940", "AS63949", "AS9009", "AS60781", "AS197540",
}
_REVEALING_HEADERS = {
    "x-forwarded-for", "x-real-ip", "via", "proxy-connection",
    "x-proxy-id", "forwarded",
}

# Targets: (host, path).  Tried in order; first success wins.
_TARGETS = [
    ("www.cloudflare.com",  "/cdn-cgi/trace"),
    ("one.one.one.one",     "/cdn-cgi/trace"),
    ("www.google.com",      "/generate_204"),
]

# Throughput test: download this many bytes through the proxy and measure real speed.
# Cloudflare's speed endpoint is reliably fast from almost everywhere.
_SPEED_HOST  = "speed.cloudflare.com"
_SPEED_PATH  = "/__down?bytes=262144"   # 256 KB
_SPEED_BYTES = 262144

_CC = {
    "US": "United States", "GB": "United Kingdom", "DE": "Germany",
    "FR": "France",        "NL": "Netherlands",    "CA": "Canada",
    "RU": "Russia",        "CN": "China",          "JP": "Japan",
    "KR": "South Korea",   "IN": "India",          "BR": "Brazil",
    "SG": "Singapore",     "HK": "Hong Kong",      "TW": "Taiwan",
    "AU": "Australia",     "ID": "Indonesia",       "TH": "Thailand",
    "VN": "Vietnam",       "TR": "Turkey",          "PL": "Poland",
    "UA": "Ukraine",       "IT": "Italy",           "ES": "Spain",
    "SE": "Sweden",        "CH": "Switzerland",     "AT": "Austria",
    "CZ": "Czechia",       "RO": "Romania",         "BG": "Bulgaria",
    "FI": "Finland",       "NO": "Norway",          "DK": "Denmark",
    "IE": "Ireland",       "PT": "Portugal",        "GR": "Greece",
    "HU": "Hungary",       "MX": "Mexico",          "AR": "Argentina",
    "CL": "Chile",         "CO": "Colombia",        "PE": "Peru",
    "ZA": "South Africa",  "EG": "Egypt",           "NG": "Nigeria",
    "IL": "Israel",        "AE": "UAE",             "SA": "Saudi Arabia",
    "IR": "Iran",          "PK": "Pakistan",        "BD": "Bangladesh",
    "PH": "Philippines",   "MY": "Malaysia",        "NZ": "New Zealand",
    "BE": "Belgium",       "LU": "Luxembourg",
}


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class CheckResult:
    proxy:               ProxyRecord
    tcp_ok:              bool          = False
    tcp_latency_ms:      Optional[float] = None   # final median ping through proxy
    rtt_ms:              Optional[float] = None   # raw TCP connect time (Stage A)
    protocol_ok:         bool          = False
    https_ok:            bool          = False
    browse_ok:           bool          = False
    youtube_ok:          bool          = False
    secure:              bool          = False
    exit_ip:             Optional[str] = None
    is_transparent:      bool          = False
    is_pooled_candidate: bool          = False
    country:             Optional[str] = None
    country_code:        Optional[str] = None
    isp:                 Optional[str] = None
    asn:                 Optional[str] = None
    timezone:            Optional[str] = None
    anonymity:           Optional[str] = None
    revealing_headers:   list          = field(default_factory=list)
    pool_flags:          list          = field(default_factory=list)
    # new quality fields
    throughput_mbps:     Optional[float] = None   # real download speed in MB/s
    jitter_ms:           Optional[float] = None   # std-dev of pings
    discord_ok:          bool          = False
    score:               int           = 0
    tier:                str           = "dead"
    reject_reason:       Optional[str] = None
    _best_up:            Optional[Upstream] = None

    def update_proxy(self) -> ProxyRecord:
        return replace(
            self.proxy, status=self.tier,
            latency_ms=self.tcp_latency_ms,
            country=self.country, country_code=self.country_code,
            isp=self.isp, asn=self.asn, anonymity=self.anonymity,
            exit_ip=self.exit_ip, is_pooled=bool(self.pool_flags),
            score=self.score, youtube_ok=self.youtube_ok,
        )


STATS: dict = {}


# ---------------------------------------------------------------------------
# TLS context — certifi bundle on top of system store
# ---------------------------------------------------------------------------
_ctx: Optional[ssl.SSLContext] = None
_ctx_lock = threading.Lock()


def _tls_ctx() -> ssl.SSLContext:
    global _ctx
    with _ctx_lock:
        if _ctx is None:
            c = ssl.create_default_context()
            try:
                import certifi
                c.load_verify_locations(cafile=certifi.where())
            except Exception:
                pass
            c.minimum_version = ssl.TLSVersion.TLSv1_2
            _ctx = c
        return _ctx


# ---------------------------------------------------------------------------
# Real IP / geolocation
# ---------------------------------------------------------------------------
_real_ip_cache: Optional[str] = None
_real_ip_lock = threading.Lock()


def get_my_ip(refresh: bool = False) -> Optional[str]:
    """Your real public IP (direct connection, system proxy ignored).  refresh=True re-reads it - a VPN toggled since the
    last check would otherwise leave a stale value and the leak check would compare against the wrong address."""
    global _real_ip_cache
    with _real_ip_lock:
        if refresh:
            _real_ip_cache = None
        if _real_ip_cache is None:
            s = requests.Session()
            s.trust_env = False
            for url in ("https://api.ipify.org", "https://api.my-ip.io/ip", "https://ifconfig.me/ip",
                        "https://icanhazip.com", "https://checkip.amazonaws.com"):
                try:
                    ip = s.get(url, timeout=6).text.strip()
                    ipaddress.ip_address(ip)
                    _real_ip_cache = ip
                    break
                except Exception:
                    continue
            if _real_ip_cache is None:                       # last resort: Cloudflare's own trace page
                try:
                    tr = _trace(s.get("https://www.cloudflare.com/cdn-cgi/trace", timeout=6).text)
                    ipaddress.ip_address(tr.get("ip", ""))
                    _real_ip_cache = tr["ip"]
                except Exception:
                    pass
        return _real_ip_cache


_geo_cache: dict = {}
_geo_lock = threading.Lock()


def _geo_quick(ip: str) -> dict:
    with _geo_lock:
        if ip in _geo_cache:
            return _geo_cache[ip]
    try:
        s = requests.Session()
        s.trust_env = False
        d = s.get(
            f"http://ip-api.com/json/{ip}?fields=country,countryCode,isp,org,as,timezone,status",
            timeout=3.0,
        ).json()
        if d.get("status") == "success":
            with _geo_lock:
                _geo_cache[ip] = d
            return d
    except Exception:
        pass
    return {}


# ---------------------------------------------------------------------------
# Stage A: TCP scan
# ---------------------------------------------------------------------------

def _tcp_timeout(limit_ms: Optional[float]) -> float:
    if not limit_ms or limit_ms >= 9999:
        return 2.5
    return max(0.35, min(2.5, limit_ms * 2.8 / 1000.0))


def _tcp_rtt(proxy: ProxyRecord, limit_ms: Optional[float]) -> Optional[float]:
    """Best of two TCP connect times (ms).  None = unreachable."""
    timeout = _tcp_timeout(limit_ms)
    best = None
    for _ in range(2):
        t0 = time.perf_counter()
        try:
            with socket.create_connection((proxy.ip, proxy.port), timeout=timeout):
                pass
        except OSError:
            return best
        rtt = (time.perf_counter() - t0) * 1000.0
        best = rtt if best is None else min(best, rtt)
        if not limit_ms or limit_ms >= 9999 or best <= limit_ms * 0.5 or best > limit_ms * 1.8:
            break
    return best


# ---------------------------------------------------------------------------
# Stage B / C: keep-alive HTTPS session through the proxy
# ---------------------------------------------------------------------------

class _Fail(Exception):
    def __init__(self, kind: str, msg: str = ""):
        super().__init__(msg or kind)
        self.kind = kind  # "handshake" | "refused" | "cert" | "io"


_MAX_BODY = 1_000_000


def _read_response(tls: ssl.SSLSocket, buf: bytearray) -> tuple:
    """Read ONE complete HTTP/1.x response.  Handles Content-Length, chunked and close-delimited bodies and bodiless
    statuses (204/304/1xx).  -> (status, body_bytes, reusable)   reusable=False when the server will close the connection."""
    while b"\r\n\r\n" not in buf:
        chunk = tls.recv(16384)
        if not chunk:
            raise _Fail("io", "connection closed")
        buf += chunk
        if len(buf) > 65536:
            raise _Fail("io", "oversized header")
    head, _, rest = bytes(buf).partition(b"\r\n\r\n")
    lines = head.split(b"\r\n")
    parts = lines[0].split()
    if len(parts) < 2 or not parts[0].startswith(b"HTTP/"):
        raise _Fail("io", "bad HTTP reply")
    try:
        status = int(parts[1])
    except ValueError:
        raise _Fail("io", "bad HTTP reply")
    hdr: dict = {}
    for ln in lines[1:]:
        k, _, v = ln.partition(b":")
        hdr[k.strip().lower()] = v.strip().lower()
    reusable = hdr.get(b"connection") != b"close" and parts[0] != b"HTTP/1.0"
    data = bytearray(rest)

    def fill(n: int) -> None:
        while len(data) < n:
            c = tls.recv(16384)
            if not c:
                raise _Fail("io", "connection closed mid-body")
            data.extend(c)

    def line() -> bytes:
        while True:
            i = data.find(b"\r\n")
            if i >= 0:
                out = bytes(data[:i])
                del data[: i + 2]
                return out
            c = tls.recv(16384)
            if not c:
                raise _Fail("io", "connection closed mid-body")
            data.extend(c)
            if len(data) > 65536:
                raise _Fail("io", "oversized chunk header")

    body = bytearray()
    if status in (204, 304) or 100 <= status < 200:
        pass
    elif b"chunked" in hdr.get(b"transfer-encoding", b""):
        while True:
            try:
                size = int(line().split(b";")[0].strip() or b"0", 16)
            except ValueError:
                raise _Fail("io", "bad chunk size")
            if size == 0:
                while line():                       # trailers up to the blank line
                    pass
                break
            fill(size + 2)
            body.extend(data[:size])
            del data[: size + 2]
            if len(body) > _MAX_BODY:
                raise _Fail("io", "oversized body")
    elif b"content-length" in hdr:
        try:
            clen = int(hdr[b"content-length"])
        except ValueError:
            raise _Fail("io", "bad content-length")
        if clen > _MAX_BODY:
            raise _Fail("io", "oversized body")
        fill(clen)
        body.extend(data[:clen])
        del data[:clen]
    else:                                           # close-delimited
        reusable = False
        while len(data) <= _MAX_BODY:
            c = tls.recv(16384)
            if not c:
                break
            data.extend(c)
        body.extend(data)
        data.clear()
    buf[:] = bytes(data)                            # whatever followed (pipelined bytes) stays for the next call
    return status, bytes(body), reusable


def _op_timeout(limit_ms: Optional[float]) -> float:
    """Per-step socket timeout — must cover TLS handshake + one response."""
    if not limit_ms or limit_ms >= 9999:
        return 9.0
    # At 80 ms limit → 4.5 s per step.  Enough for TLS handshake on any real proxy.
    return max(4.0, min(12.0, limit_ms * 56 / 1000.0))


def _session(up: Upstream, host: str, path: str, n: int, timeout: float) -> dict:
    """Tunnel → verified TLS → n keep-alive requests.
    Returns {status, body, pings:[ms...], first_ms, tls}.
    pings EXCLUDE the first request (handshake cost); they are genuine round-trips."""
    t0 = time.perf_counter()
    try:
        raw = open_tunnel(up, host, 443, timeout)
    except Exception as exc:
        msg = str(exc)
        raise _Fail("refused" if msg.startswith("CONNECT refused") else "handshake", msg)
    tls = None
    try:
        raw.settimeout(timeout)
        try:
            tls = _tls_ctx().wrap_socket(raw, server_hostname=host)
        except ssl.SSLCertVerificationError as exc:
            raise _Fail("cert", str(exc))
        except (ssl.SSLError, OSError) as exc:
            raise _Fail("io", f"TLS: {exc}")
        tls.settimeout(timeout)
        req = (f"GET {path} HTTP/1.1\r\nHost: {host}\r\n"
               f"User-Agent: {_UA}\r\nAccept: */*\r\nConnection: keep-alive\r\n\r\n").encode()
        buf, pings, status, body = bytearray(), [], 0, b""
        first_ms = None
        for i in range(max(1, n)):
            t1 = time.perf_counter()
            tls.sendall(req)
            st, bd, reusable = _read_response(tls, buf)
            dt = (time.perf_counter() - t1) * 1000.0
            if i == 0:
                status, body = st, bd
                first_ms = (time.perf_counter() - t0) * 1000.0
                if status >= 500:
                    raise _Fail("io", f"HTTP {status}")
            else:
                pings.append(dt)
            if not reusable and i < n - 1:
                raise _Fail("io", "server closes the connection - no keep-alive ping possible")
        return {"status": status, "body": body.decode("utf-8", "replace"),
                "pings": pings, "first_ms": first_ms, "tls": tls.version()}
    except (OSError, ssl.SSLError) as exc:
        raise _Fail("io", str(exc))
    finally:
        for s in (tls, raw):
            try:
                if s:
                    s.close()
            except OSError:
                pass


def _trace(body: str) -> dict:
    d = {}
    for line in body.splitlines():
        if "=" in line:
            k, _, v = line.partition("=")
            d[k.strip()] = v.strip()
    return d


def _protocol_order(proxy: ProxyRecord) -> list:
    base = (["socks5", "socks4", "http"] if proxy.port in _SOCKS_PORTS
            else ["http", "socks5", "socks4"])
    order = []
    for p in [proxy.protocol, *getattr(proxy, "hints", ()), *base]:
        if p in ("http", "socks4", "socks5") and p not in order:
            order.append(p)
    return order


# ---------------------------------------------------------------------------
# Protocol sniff: which language does this port speak?  (short handshake, NOT a full request)
# ---------------------------------------------------------------------------

_SNIFF_HTTP = b"CONNECT www.cloudflare.com:443 HTTP/1.1\r\nHost: www.cloudflare.com:443\r\n\r\n"
_SNIFF_SOCKS5 = b"\x05\x01\x00"
_SNIFF_SOCKS4 = b"\x04\x01\x01\xbb\x01\x01\x01\x01\x00"          # CONNECT 1.1.1.1:443, empty user id


def _handshake(ip: str, port: int, payload: bytes, timeout: float, need: int) -> Optional[bytes]:
    """Send `payload`, return the first reply bytes (stops as soon as `need` bytes arrived, keeps a partial reply on timeout).
    None = could not connect, b'' = connected but silent / closed."""
    try:
        s = socket.create_connection((ip, port), timeout=timeout)
    except OSError:
        return None
    data = b""
    try:
        s.settimeout(timeout)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        s.sendall(payload)
        while len(data) < need:
            c = s.recv(64)
            if not c:
                break
            data += c
    except OSError:
        pass
    finally:
        try:
            s.close()
        except OSError:
            pass
    return data


def _sniff_one(proxy: ProxyRecord, proto: str, t: float) -> tuple:
    """One protocol guess.  -> (detected protocol | None, note).  `detected` can differ from the guess: an HTTP server that
    answers a SOCKS greeting with an error page is, of course, an HTTP proxy."""
    if proto == "socks5":
        d = _handshake(proxy.ip, proxy.port, _SNIFF_SOCKS5, t, 2)
        if d is None:
            return None, "unreachable"
        if d[:2] == b"\x05\x00":
            return "socks5", ""
        if d[:1] == b"\x05":
            return None, "SOCKS5 needs a login"
        if d[:2] == b"HT":
            return "http", ""
    elif proto == "socks4":
        d = _handshake(proxy.ip, proxy.port, _SNIFF_SOCKS4, t, 2)
        if d is None:
            return None, "unreachable"
        if len(d) >= 2 and d[0] == 0 and d[1] in (0x5A, 0x5B, 0x5C, 0x5D):
            return "socks4", ""
    else:
        d = _handshake(proxy.ip, proxy.port, _SNIFF_HTTP, t + 1.5, 5)       # an HTTP proxy may dial out before it answers
        if d is None:
            return None, "unreachable"
        if d[:5] == b"HTTP/":
            return "http", ""
    return None, ""


def _sniff_protocol(proxy: ProxyRecord, rtt_ms: Optional[float]) -> tuple:
    """-> (protocol | None, note).  All three guesses run IN PARALLEL and the first one that gets a well-formed reply wins:
    a real proxy answers a handshake within about one round trip, a wrong guess just sits there - so a good proxy is identified
    in ~1 RTT and a non-proxy costs at most one short timeout (the old code spent a full 5 s per wrong guess, one after the other)."""
    t = min(3.0, 1.2 + (rtt_ms or 100.0) / 100.0)
    order = _protocol_order(proxy)
    q: "queue.Queue" = queue.Queue()
    for pr in order:
        threading.Thread(target=lambda pr=pr: q.put(_sniff_one(proxy, pr, t)), daemon=True, name="px-sniff").start()
    deadline = time.monotonic() + t + 1.8
    notes: list = []
    for _ in order:
        left = deadline - time.monotonic()
        if left <= 0:
            break
        try:
            det, note = q.get(timeout=left)
        except queue.Empty:
            break
        if det:
            return det, ""
        if note:
            notes.append(note)
    for n in notes:
        if "login" in n:
            return None, n
    return None, ("unreachable" if "unreachable" in notes else "not a proxy / no answer")


# ---------------------------------------------------------------------------
# Stage 2+3: verified HTTPS + ping/jitter on ONE open connection (protocol already sniffed)
# ---------------------------------------------------------------------------

_IP_ECHO = (("api.ipify.org", "/"), ("checkip.amazonaws.com", "/"))


def _exit_ip_via(up: Upstream, tmo: float) -> Optional[str]:
    """Second opinion on the exit IP when the trace page could not give it."""
    for host, path in _IP_ECHO:
        try:
            s = _session(up, host, path, 1, min(tmo, 6.0))
            if s["status"] == 200:
                ip = s["body"].strip()
                ipaddress.ip_address(ip)
                return ip
        except (_Fail, ValueError):
            continue
    return None


def _probe(proxy: ProxyRecord, limit_ms: Optional[float],
           stop: Optional[threading.Event], pings: int = 8, rtt_ms: Optional[float] = None) -> CheckResult:
    r = CheckResult(proxy=proxy, tcp_ok=True)
    tmo = _op_timeout(limit_ms)
    if stop is not None and stop.is_set():
        return r
    proto, note = _sniff_protocol(proxy, rtt_ms)
    if not proto:
        r.tier, r.reject_reason = "dead", note
        return r
    r.proxy = replace(proxy, protocol=proto)
    up = Upstream(proxy.ip, proxy.port, proto)
    saw_refusal = False
    for host, path in _TARGETS:
        if stop is not None and stop.is_set():
            return r
        try:
            s = _session(up, host, path, pings + 1, tmo)      # +1: the first request pays for the handshake
        except _Fail as f:
            if f.kind == "cert":
                r.protocol_ok, r.tier = True, "rejected"
                r.reject_reason = "intercepts HTTPS - certificate not trusted"
                return r
            if f.kind == "refused":                           # definitive and instant: this host is filtered, try the next
                saw_refusal = True
                continue
            if f.kind == "handshake":                         # tunnel never came up: the proxy is stuck, don't burn more time
                break
            continue                                          # "io": flaky reply, try the next target
        tr = _trace(s["body"]) if s["status"] == 200 and "ip=" in s["body"] else {}
        genuine = bool(tr) or (s["status"] == 204 and host == "www.google.com")
        if not genuine:                                       # e.g. a 403 block page - NOT proof against the proxy, try another host
            r.reject_reason = f"{host} answered HTTP {s['status']}"
            continue
        r.protocol_ok = r.https_ok = r.browse_ok = True
        r.secure = bool(s.get("tls"))
        r._best_up = up
        r.exit_ip = tr.get("ip")
        if tr.get("loc"):
            r.country_code = tr["loc"]
        p = s["pings"]
        if p:
            r.tcp_latency_ms = statistics.median(p)
            r.jitter_ms = statistics.pstdev(p) if len(p) >= 3 else None
        r.reject_reason = None
        if not r.exit_ip:
            r.exit_ip = _exit_ip_via(up, tmo)
        return r
    if saw_refusal:
        r.protocol_ok, r.reject_reason = True, "refuses HTTPS tunnels"
    r.tier = "rejected" if r.protocol_ok else "dead"
    return r


def _quiet_measure(r: CheckResult, limit_ms: Optional[float], pings: int = 8) -> bool:
    """Fresh keep-alive session, run while almost nothing else is running -> the REAL ping / jitter.
    False = the proxy did not answer (it died since the scan)."""
    up = r._best_up
    if up is None:
        return False
    tmo = _op_timeout(limit_ms)
    for host, path in _TARGETS:
        try:
            s = _session(up, host, path, pings + 1, tmo)
        except _Fail:
            continue
        if s["status"] not in (200, 204) or not s["pings"]:
            continue
        r.tcp_latency_ms = statistics.median(s["pings"])
        r.jitter_ms = statistics.pstdev(s["pings"]) if len(s["pings"]) >= 3 else None
        return True
    return False


# ---------------------------------------------------------------------------
# Real download speed through the proxy
# ---------------------------------------------------------------------------

_SPEED_SEM = threading.Semaphore(6)       # a few at a time: parallel downloads would only measure each other
# (host, port, path, tls)
_SPEED_TESTS = [
    ("speed.cloudflare.com", 443, "/__down?bytes=4000000", True),
    ("cachefly.cachefly.net", 80, "/10mb.test", False),
]


def _speed_once(up: Upstream, host: str, port: int, path: str, use_tls: bool, budget: float = 2.8) -> Optional[float]:
    raw = open_tunnel(up, host, port, 5.0)
    sock = raw
    try:
        raw.settimeout(4.0)
        if use_tls:
            sock = _tls_ctx().wrap_socket(raw, server_hostname=host)
            sock.settimeout(4.0)
        sock.sendall((f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: {_UA}\r\nAccept: */*\r\n"
                      f"Accept-Encoding: identity\r\nConnection: close\r\n\r\n").encode())
        hbuf = b""
        while b"\r\n\r\n" not in hbuf:
            c = sock.recv(8192)
            if not c:
                return None
            hbuf += c
            if len(hbuf) > 32768:
                return None
        head, _, body0 = hbuf.partition(b"\r\n\r\n")
        try:
            if int(head.split(None, 2)[1]) >= 400:
                return None
        except Exception:
            return None
        got = len(body0)
        t_start = time.perf_counter()
        mark_t, mark_b = (t_start, got) if got >= 65536 else (None, 0)
        while True:
            now = time.perf_counter()
            if now - t_start >= budget:
                break
            c = sock.recv(65536)
            if not c:
                break
            got += len(c)
            if mark_t is None and got >= 65536:             # ignore TCP slow-start: measure from the first 64 KB on
                mark_t, mark_b = time.perf_counter(), got
        end = time.perf_counter()
        if got < 131072:
            return None
        if mark_t is not None and end - mark_t >= 0.25:
            return ((got - mark_b) / (end - mark_t)) / (1024 * 1024)
        return (got / max(end - t_start, 0.05)) / (1024 * 1024)
    finally:
        for sk in (sock, raw):
            try:
                sk.close()
            except Exception:
                pass


def _throughput(r: CheckResult, timeout: float = 0.0) -> Optional[float]:
    """Real MB/s through the proxy, or None when no test host could be downloaded from."""
    up = r._best_up
    if up is None:
        return None
    with _SPEED_SEM:
        for host, port, path, tls in _SPEED_TESTS:
            try:
                v = _speed_once(up, host, port, path, tls)
            except Exception:
                v = None
            if v is not None:
                return v
    return None


# ---------------------------------------------------------------------------
# Streaming-site reachability
# ---------------------------------------------------------------------------

def _youtube_ok(up: Upstream) -> bool:
    for host, path in (("www.youtube.com", "/generate_204"), ("i.ytimg.com", "/generate_204")):
        try:
            s = _session(up, host, path, 1, 6.0)
            if s["status"] in (204, 200):
                return True
        except _Fail:
            continue
    return False


def _discord_ok(up: Upstream) -> bool:
    try:
        s = _session(up, "discord.com", "/api/v9/gateway", 1, 6.0)
        return s["status"] == 200 and "wss://" in s["body"]
    except _Fail:
        return False


# ---------------------------------------------------------------------------
# Anonymity probe (informational) - uses the absolute-URI form a proxy expects
# ---------------------------------------------------------------------------

_ANON_ENDPOINTS = [
    ("httpbin.org", "/headers"),
    ("azenv.net", "/"),
    ("eth0.me", "/headers"),
]


def _anonymity(proxy: ProxyRecord, my_ip: Optional[str]) -> tuple:
    if proxy.protocol != "http":
        return "elite", []     # SOCKS adds no headers by design
    for ahost, apath in _ANON_ENDPOINTS:
        try:
            req = (f"GET http://{ahost}{apath} HTTP/1.1\r\nHost: {ahost}\r\nUser-Agent: {_UA}\r\n"
                   f"Connection: close\r\n\r\n").encode()
            with socket.create_connection((proxy.ip, proxy.port), timeout=4) as s:
                s.settimeout(4)
                s.sendall(req)
                data = b""
                while len(data) < 16384:
                    c = s.recv(4096)
                    if not c:
                        break
                    data += c
            if not data.startswith(b"HTTP/") or b" 200" not in data.split(b"\r\n", 1)[0]:
                continue
            text = data.partition(b"\r\n\r\n")[2].decode("utf-8", "replace").lower()
            found = [h for h in _REVEALING_HEADERS if h in text]
            if my_ip and my_ip in text:
                return "transparent", found
            return ("anonymous" if found else "elite"), found
        except Exception:
            continue
    return "unknown", []


# ---------------------------------------------------------------------------
# Finish: leak check, country, score, tier
# ---------------------------------------------------------------------------

def _finish(r: CheckResult, my_ip: Optional[str], min_speed: float = DEFAULT_MIN_SPEED_MBPS,
            limit: Optional[float] = DEFAULT_MAX_LATENCY_MS, slack: float = 1.0) -> CheckResult:
    if r.exit_ip and my_ip and r.exit_ip == my_ip:
        r.is_transparent = True
        r.tier, r.reject_reason, r.score = "rejected", "transparent - leaks your real IP", 0
        return r
    code = r.country_code
    if code and code.upper() in _CC:
        r.country = _CC[code.upper()]
    else:                                                    # rare: no country from the trace -> one polite geo lookup
        geo = _geo_quick(r.exit_ip or r.proxy.ip)
        r.country_code = geo.get("countryCode") or code
        r.country = geo.get("country") or _CC.get((r.country_code or "").upper()) or r.country_code
        r.isp, r.asn, r.timezone = geo.get("isp") or geo.get("org"), geo.get("as"), geo.get("timezone")
    if not r.country:
        r.country = "Unknown"
    r.anonymity, r.revealing_headers = _anonymity(r.proxy, my_ip)
    if r.anonymity == "transparent":
        r.is_transparent = True
        r.tier, r.reject_reason, r.score = "rejected", "transparent - forwards your real IP", 0
        return r
    flags = []
    if r.exit_ip and r.exit_ip != r.proxy.ip:
        r.is_pooled_candidate = True
        flags.append(f"exit IP ({r.exit_ip}) differs from proxy IP ({r.proxy.ip})")
    if any(dc in (r.asn or "") for dc in _DATACENTER_ASNS):
        flags.append(f"datacenter ASN ({r.asn})")
    r.pool_flags = flags
    r.score = _score(r)
    r.tier = _tier(r, limit, min_speed, slack)
    return r


def _score(r: CheckResult) -> int:
    p = r.tcp_latency_ms or 9999.0
    jt = r.jitter_ms if r.jitter_ms is not None else 25.0
    tp = r.throughput_mbps or 0.0
    s = (35 if p <= 25 else 31 if p <= 40 else 27 if p <= 55 else 22 if p <= 70 else 17 if p <= 90 else 8)
    s += (30 if tp >= 4.0 else 25 if tp >= 2.5 else 20 if tp >= 1.5 else 14 if tp >= 1.0 else 7 if tp >= 0.5 else 2)
    s += (15 if jt <= 5 else 12 if jt <= 10 else 8 if jt <= 20 else 4 if jt <= 35 else 0)
    s += 8 if r.secure else 0
    s += 6 if r.youtube_ok else 0
    s += 4 if r.discord_ok else 0
    return min(100, s)


def _tier(r: CheckResult, limit: Optional[float] = DEFAULT_MAX_LATENCY_MS,
          min_speed: float = DEFAULT_MIN_SPEED_MBPS, slack: float = 1.0) -> str:
    if r.is_transparent:
        return "rejected"
    if not (r.browse_ok and r.secure):
        return "dead"
    p = r.tcp_latency_ms or 9999.0
    jt = r.jitter_ms if r.jitter_ms is not None else 999.0
    tp = r.throughput_mbps or 0.0
    cap = limit if limit else 9999.0
    soft_cap = cap * max(1.0, SOFT_PING_FACTOR) * slack if limit else 9999.0
    if p > soft_cap:
        return "rejected"
    if tp < min_speed * 0.5:
        return "rejected"
    if p > cap:                                   # a bit above the limit: usable, but always listed after every in-limit proxy
        return "fair"
    if p <= 50 and jt <= 20 and tp >= min_speed * 1.5:
        return "gaming"
    if p <= 70 and tp >= min_speed:
        return "excellent"
    if tp >= min_speed:
        return "good"
    return "fair"


# ---------------------------------------------------------------------------
# Quick liveness test (used right before connecting)
# ---------------------------------------------------------------------------

def live_check(ip: str, port: int, protocol: str, timeout: float = 6.0) -> dict:
    """Is this proxy answering RIGHT NOW, and can it reach YouTube?  -> {ok, ping, why}"""
    up = Upstream(ip, int(port), protocol)
    try:
        s = _session(up, "www.youtube.com", "/generate_204", 4, timeout)
    except _Fail as f:
        why = {"handshake": "no answer", "refused": "refuses HTTPS tunnels", "cert": "intercepts HTTPS", "io": "connection dropped"}.get(f.kind, f.kind)
        return {"ok": False, "ping": None, "why": why}
    if s["status"] != 204:
        return {"ok": False, "ping": None, "why": f"YouTube answered HTTP {s['status']}"}
    p = s["pings"]
    return {"ok": True, "ping": statistics.median(p) if p else s.get("first_ms"), "why": ""}


def verify_live(proxy: ProxyRecord, timeout_ms: float = 2000.0) -> bool:
    return live_check(proxy.ip, proxy.port, proxy.protocol, max(3.0, timeout_ms / 1000.0))["ok"]


def check_one(proxy: ProxyRecord, my_ip: Optional[str] = None,
              stop_event: Optional[threading.Event] = None,
              max_latency_ms: Optional[float] = None) -> CheckResult:
    rtt = _tcp_rtt(proxy, max_latency_ms)
    if rtt is None:
        return CheckResult(proxy=proxy)
    r = _probe(proxy, max_latency_ms, stop_event, rtt_ms=rtt)
    r.rtt_ms = rtt
    if r.browse_ok and r.secure:
        r.youtube_ok = _youtube_ok(r._best_up)
        r.discord_ok = _discord_ok(r._best_up)
        r.throughput_mbps = _throughput(r)
        _finish(r, my_ip, DEFAULT_MIN_SPEED_MBPS, max_latency_ms or DEFAULT_MAX_LATENCY_MS)
    return r


# ---------------------------------------------------------------------------
# Full pipeline
# ---------------------------------------------------------------------------

def check_all(
    proxies: list,
    max_workers: int = 300,
    region_filter: Optional[str] = None,
    protocol_filter: Optional[str] = None,
    min_anonymity: Optional[str] = None,
    max_latency_ms: Optional[float] = DEFAULT_MAX_LATENCY_MS,
    stop_event: Optional[threading.Event] = None,
    target: int = DEFAULT_TARGET,
    min_speed_mbps: float = DEFAULT_MIN_SPEED_MBPS,
    require_youtube: bool = True,
    **_ignored,
) -> list:
    limit = None if (max_latency_ms is None or max_latency_ms >= 9999) else float(max_latency_ms)
    min_speed = max(0.0, float(min_speed_mbps if min_speed_mbps is not None else DEFAULT_MIN_SPEED_MBPS))
    _ANON = {"unknown": 1, "transparent": 0, "anonymous": 1, "elite": 2}
    stop = stop_event or threading.Event()

    try:
        from modules.cleaner.speed import is_low_end
        low = is_low_end()
    except Exception:
        low = False

    scan_workers = max(60, min(int(max_workers), 200 if low else 500))
    verify_workers = max(12, min(int(max_workers) // 3, 50 if low else 120))

    # never touch RAT / miner / Tor / service ports
    before = len(proxies)
    proxies = [p for p in proxies if not is_blocked_port(p.port)]
    skipped_ports = before - len(proxies)
    queue = sorted(proxies, key=lambda p: (-getattr(p, "votes", 1), getattr(p, "tier_rank", 1)))
    total = len(queue)
    my_ip = get_my_ip(refresh=True)                  # fresh every run: a VPN toggled since last time must not poison the leak check
    t_start = time.monotonic()

    stats = {
        "total": total, "scanned": 0, "reachable": 0, "fast": 0, "verified": 0, "accepted": 0,
        "best_rtt": None, "fallback_ping": None, "limit": limit, "min_speed": min_speed, "stage": "scan",
        "skipped_ports": skipped_ports, "reasons": {}, "relaxed": 0, "requalified": 0, "my_ip_known": bool(my_ip),
    }
    STATS.clear()
    STATS.update(stats)
    lock = threading.Lock()
    results: list = []
    survivors: list = []
    reasons: dict = stats["reasons"]

    def reject(why: str, ping: Optional[float] = None) -> None:
        with lock:
            reasons[why] = reasons.get(why, 0) + 1
            if why == "speed" and ping is not None:
                stats["fallback_ping"] = ping if stats["fallback_ping"] is None else min(stats["fallback_ping"], ping)

    _log.info("Proxy check: %d candidates (%d on blocked ports skipped), ping <= %s ms, speed >= %.2f MB/s, workers scan/verify = %d/%d",
              total, skipped_ports, limit, min_speed, scan_workers, verify_workers)

    def progress(stage: str, done: int, tot: int, msg: str) -> None:
        stats["stage"] = stage
        STATS.update(stats)
        bus.publish(Events.PROXY_CHECK_PROGRESS, {
            "completed": done, "total": tot, "working": stats["accepted"],
            "stage": stage, "msg": msg, "last_proxy": "", "last_tier": "",
        })

    def scan_one(p: ProxyRecord):
        if stop.is_set():
            return None
        rtt = _tcp_rtt(p, limit)
        with lock:
            stats["scanned"] += 1
            if rtt is not None:
                stats["reachable"] += 1
                stats["best_rtt"] = rtt if stats["best_rtt"] is None else min(stats["best_rtt"], rtt)
        return None if rtt is None else (p, rtt)

    def passes_filters(r: CheckResult) -> bool:
        if region_filter and region_filter.lower() != "any":
            if not r.country or r.country.lower() != region_filter.lower():
                return False
        if min_anonymity and min_anonymity.lower() != "any":
            if _ANON.get((r.anonymity or "").lower(), -1) < _ANON.get(min_anonymity.lower(), 0):
                return False
        if protocol_filter and protocol_filter.lower() != "any":
            if r.proxy.protocol.lower() != protocol_filter.lower():
                return False
        return True

    # TCP connect time is the floor of the ping THROUGH the proxy.  Strict mode: limit.  Soft mode: a bit of room, because a
    # connect measured while hundreds of threads run is noisy and the proxy may sit very close to the target.
    scan_gate = (limit * 1.05) if (limit is not None and SOFT_PING_FACTOR <= 1.0) else ((limit * 1.3) if limit is not None else None)
    prov_slack = 1.5                                  # the verify-phase ping is measured under load -> be generous, the quiet pass decides

    verify_pool = ThreadPoolExecutor(max_workers=verify_workers, thread_name_prefix="px-verify")
    verify_futs: list = []
    done_count = [0]

    def verify_task(item):
        p, rtt = item
        try:
            if stop.is_set():
                return
            r = _probe(p, limit, stop, pings=8, rtt_ms=rtt)
            r.rtt_ms = rtt
            if not (r.browse_ok and r.secure):
                reject("tls" if (r.reject_reason or "").startswith("intercepts") else "dead")
                return
            ping = r.tcp_latency_ms or 9999.0
            if limit and ping > limit * max(1.0, SOFT_PING_FACTOR) * prov_slack:
                reject("ping")
                return
            if stop.is_set():
                return
            up = r._best_up
            r.youtube_ok = _youtube_ok(up)
            if require_youtube and not r.youtube_ok:
                reject("youtube")
                return
            r.discord_ok = _discord_ok(up)
            if stop.is_set():
                return
            tp = _throughput(r)
            if tp is None or tp < min_speed * 0.5:
                reject("speed", ping)
                return
            r.throughput_mbps = tp
            _finish(r, my_ip, min_speed, limit, prov_slack)
            if r.tier not in ("gaming", "excellent", "good", "fair"):
                reject("leak" if r.is_transparent else "speed")
                return
            if not passes_filters(r):
                reject("filter")
                return
            with lock:
                results.append(r)
                stats["accepted"] = len(results)
                full = len(results) >= target
            bus.publish(Events.PROXY_RESULT_BATCH, [r])          # a COMPLETE row: every column is filled in
            if full:
                stop.set()
        except Exception as exc:                                 # one bad proxy must never stop the run
            _log.debug("verify %s:%s failed: %s", p.ip, p.port, exc)
            reject("dead")
        finally:
            with lock:
                done_count[0] += 1
                stats["verified"] = done_count[0]

    pool = ThreadPoolExecutor(max_workers=scan_workers, thread_name_prefix="px-scan")
    try:
        futs = [pool.submit(scan_one, p) for p in queue]
        pending = set(futs)
        last = 0.0
        while pending and not stop.is_set():
            done, pending = wait(pending, timeout=0.25, return_when=FIRST_COMPLETED)
            for f in done:
                try:
                    res = f.result()
                except Exception:
                    res = None
                if res is None:
                    continue
                p, rtt = res
                # connect time to the proxy is the FLOOR of the ping through it: above the limit it can never qualify
                if limit is None or rtt <= scan_gate:
                    survivors.append((p, rtt))
                    verify_futs.append(verify_pool.submit(verify_task, (p, rtt)))      # pipelined: no waiting for the scan to end
                else:
                    reject("ping")
            now = time.monotonic()
            if now - last > 0.3:
                last = now
                stats["fast"] = len(survivors)
                progress("scan", stats["scanned"], total,
                         f"Scanning {stats['scanned']:,}/{total:,}  -  {len(survivors)} close enough, {stats['accepted']} fully verified")
        for f in pending:
            f.cancel()
    finally:
        pool.shutdown(wait=False, cancel_futures=True)

    stats["fast"] = len(survivors)
    _log.info("Scan: %d/%d reachable, %d within the ping budget (%.1fs)", stats["reachable"], total, len(survivors), time.monotonic() - t_start)

    try:
        pending_v = set(f for f in verify_futs if not f.done())
        last = 0.0
        while pending_v and not stop.is_set():
            done, pending_v = wait(pending_v, timeout=0.25, return_when=FIRST_COMPLETED)
            now = time.monotonic()
            if now - last > 0.3:
                last = now
                progress("verify", done_count[0], max(1, len(survivors)),
                         f"Testing ping, YouTube and speed  {done_count[0]:,}/{max(1, len(survivors)):,}  -  {stats['accepted']} fully verified")
        for f in pending_v:
            f.cancel()
    finally:
        verify_pool.shutdown(wait=False, cancel_futures=True)

    # ---- QUIET PASS: re-measure ping on an idle system + prove the proxy still works RIGHT NOW --------------------------------
    user_stopped = bool(getattr(stop, "_by_user", False))
    with lock:
        snapshot = list(results)
    if snapshot and not user_stopped:
        todo = sorted(snapshot, key=lambda r: r.tcp_latency_ms or 9999)
        q_total, q_done = len(todo), [0]
        q_deadline = time.monotonic() + REQUALIFY_BUDGET_S
        gone: list = []
        kept: list = []
        stats["stage"] = "requalify"
        progress("verify", 0, q_total, f"Re-measuring ping on {q_total} proxies with nothing else running...")

        def requalify(r: CheckResult) -> None:
            try:
                if time.monotonic() > q_deadline:
                    kept.append(r)                         # out of time: keep the provisional numbers
                    return
                alive = _quiet_measure(r, limit)
                if alive and require_youtube:
                    r.youtube_ok = _youtube_ok(r._best_up)
                    alive = r.youtube_ok
                if not alive:
                    reject("gone")
                    r.tier = "dead"
                    gone.append(r)
                    return
                r.score = _score(r)
                r.tier = _tier(r, limit, min_speed)
                if r.tier in ("gaming", "excellent", "good", "fair"):
                    kept.append(r)
                    stats["requalified"] += 1
                else:
                    reject("ping")
                    gone.append(r)
            except Exception as exc:
                _log.debug("requalify %s failed: %s", r.proxy.address(), exc)
                r.tier = "dead"
                reject("gone")
                gone.append(r)
            finally:
                with lock:
                    q_done[0] += 1
                if q_done[0] % 3 == 0 or q_done[0] == q_total:
                    progress("verify", q_done[0], q_total, f"Re-measuring ping  {q_done[0]}/{q_total}  -  {len(kept)} confirmed alive")

        with ThreadPoolExecutor(max_workers=REQUALIFY_WORKERS, thread_name_prefix="px-quiet") as qpool:
            list(qpool.map(requalify, todo))
        with lock:
            late = [r for r in results if all(r is not x for x in snapshot)]     # finished by in-flight workers meanwhile
            results[:] = kept + late
            stats["accepted"] = len(results)
        for i in range(0, len(todo), 60):
            bus.publish(Events.PROXY_RESULT_BATCH, todo[i:i + 60])               # table rows updated: new ping, or marked dead

    stats["relaxed"] = sum(1 for r in results if limit and (r.tcp_latency_ms or 0) > limit)
    results.sort(key=lambda r: ({"gaming": 0, "excellent": 1, "good": 2, "fair": 3}.get(r.tier, 9), r.tcp_latency_ms or 9999))
    stats["elapsed"] = round(time.monotonic() - t_start, 1)
    STATS.clear()
    STATS.update(stats)
    _log.info("Proxy check done: %d accepted of %d (%d close, %d tested) in %.1fs; rejected for: %s",
              len(results), total, stats["fast"], stats["verified"], stats["elapsed"], reasons)
    bus.publish(Events.PROXY_CHECK_DONE, results)
    return results
