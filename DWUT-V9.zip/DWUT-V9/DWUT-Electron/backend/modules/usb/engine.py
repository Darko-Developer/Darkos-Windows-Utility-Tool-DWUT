"""
modules/usb/engine.py — everything needed to turn a USB stick into installation media.

SAFETY (a flasher that wipes the wrong disk is a disaster, so):
  * only disks whose bus type is USB are ever listed; system/boot disks are excluded
  * the chosen disk is RE-VALIDATED (bus, size, serial, not system) immediately before it is touched
  * nothing is erased before the download + checksum has succeeded
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import string
import subprocess
import threading
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable, Optional

from core.logger import get_logger
from modules.usb import catalog

_log = get_logger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
CACHE = Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT" / "isos"
CHUNK = 4 * 1024 * 1024


class Cancelled(Exception):
    pass


class FlashError(Exception):
    pass


# ── small helpers ─────────────────────────────────────────────────────────────

def run(cmd: list[str], timeout: int = 600, cwd: Optional[str | Path] = None) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WINDOW,
                           errors="replace", stdin=subprocess.DEVNULL, cwd=str(cwd) if cwd else None)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return -2, "timed out"
    except Exception as exc:
        return -1, str(exc)


_PCT = re.compile(r"(\d{1,3}(?:\.\d+)?)\s*%")
_OEM = "oem" if os.name == "nt" else "utf-8"          # console tools (diskpart, robocopy, dism ...) talk in the OEM code page


def _kill_tree(p: subprocess.Popen) -> None:
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, creationflags=_NO_WINDOW, timeout=15)
        else:
            p.kill()
    except Exception:
        try:
            p.kill()
        except Exception:
            pass


def run_logged(cmd: list[str], log: Callable[[str], None], timeout: int = 600, cwd: Optional[str | Path] = None,
               cancel: Optional[threading.Event] = None, label: Optional[str] = None, mask: tuple = (),
               on_tick: Optional[Callable[[], None]] = None, quiet: bool = False) -> tuple[int, str]:
    """Run a program and stream everything it prints into `log` LIVE (one line at a time).

    Returns (exit code, collected output).  The command line is echoed first ("$ ..."), the exit code last, so the Activity
    log always shows exactly what ran and what it said.  `mask` hides secrets (passwords) from the echoed command.
    A set `cancel` event kills the whole process tree and raises Cancelled.  Progress lines such as "42%" are thinned out
    (one per 10%) so a DISM / installer progress bar cannot flood the log."""
    shown = label or " ".join(('"%s"' % c if " " in c else c) for c in cmd)
    for m in mask:
        if m:
            shown = shown.replace(m, "******")
    if not quiet:
        log("$ " + shown[:400])
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                             cwd=str(cwd) if cwd else None, creationflags=_NO_WINDOW)
    except Exception as exc:
        log(f"  ! could not start the program: {exc}")
        return -1, str(exc)
    out: list[str] = []
    last_pct = [-100]

    def emit_line(raw: bytes) -> None:
        txt = raw.decode(_OEM, "replace").replace("\x00", "").strip()
        if not txt:
            return
        m = _PCT.search(txt)
        if m and len(txt) < 80:
            pct = int(float(m.group(1)))
            if pct < 100 and pct - last_pct[0] < 10 and pct >= last_pct[0]:
                return
            last_pct[0] = pct
        out.append(txt)
        if len(out) > 400:
            del out[:100]
        if not quiet:
            log("  " + txt[:300])

    def reader() -> None:
        buf = b""
        try:
            while True:
                chunk = p.stdout.read1(4096) if hasattr(p.stdout, "read1") else p.stdout.read(1)
                if not chunk:
                    break
                buf += chunk
                while True:
                    cut = min([i for i in (buf.find(b"\n"), buf.find(b"\r")) if i >= 0], default=-1)
                    if cut < 0:
                        break
                    emit_line(buf[:cut])
                    buf = buf[cut + 1:]
        except Exception:
            pass
        if buf:
            emit_line(buf)

    t = threading.Thread(target=reader, daemon=True, name="proc-log")
    t.start()
    t0 = time.monotonic()
    try:
        while p.poll() is None:
            if cancel is not None and cancel.is_set():
                _kill_tree(p)
                raise Cancelled()
            if time.monotonic() - t0 > timeout:
                _kill_tree(p)
                log(f"  ! timed out after {timeout} s - stopped it")
                t.join(2)
                return -2, "\n".join(out)
            if on_tick:
                try:
                    on_tick()
                except Exception:
                    pass
            time.sleep(0.25)
    finally:
        if p.poll() is None:
            _kill_tree(p)
    t.join(3)
    code = p.returncode if p.returncode is not None else -1
    if not quiet:
        log(f"  (exit code {code})")
    return code, "\n".join(out)


def ps(script: str, timeout: int = 120, log: Optional[Callable[[str], None]] = None, cancel: Optional[threading.Event] = None,
       label: Optional[str] = None, quiet_cmd: bool = False) -> tuple[int, str]:
    cmd = ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script]
    if log is None:
        return run(cmd, timeout)
    return run_logged(cmd, log, timeout, cancel=cancel, label=label or ("PowerShell: " + " ".join(script.split())[:110]), quiet=quiet_cmd)


def psq(path) -> str:
    """Escape a value for use inside a single-quoted PowerShell string (an ISO called "Bob's Windows.iso" used to break the command)."""
    return str(path).replace("'", "''")


def vkey(s: str) -> tuple:
    return tuple(int(n) for n in re.findall(r"\d+", s))


def _open(url: str, direct: bool, timeout: float = 25):
    opener = urllib.request.build_opener(*([urllib.request.ProxyHandler({})] if direct else []))
    req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept": "*/*"})
    return opener, req, timeout


def http_text(url: str, timeout: float = 25) -> str:
    last = None
    for direct in (True, False):
        try:
            opener, req, t = _open(url, direct, timeout)
            with opener.open(req, timeout=t) as r:
                return r.read().decode("utf-8", "replace")
        except Exception as exc:
            last = exc
    raise FlashError(f"could not read {url}: {last}")


def list_dir(url: str) -> list[str]:
    from urllib.parse import unquote
    html = http_text(url)
    seen, out = set(), []
    for h in re.findall(r'href="([^"?#]+)"', html):
        if h.startswith(("/", "http", "..", "mailto")):
            continue
        h = unquote(h)
        if h not in seen:
            seen.add(h)
            out.append(h)
    return out


# ── resolving the download ────────────────────────────────────────────────────

def parse_checksum(text: str, filename: str) -> Optional[str]:
    """Find the SHA-256 for `filename` in any common checksum-file format."""
    for line in text.splitlines():
        if filename in line:
            m = re.search(r"\b([A-Fa-f0-9]{64})\b", line)
            if m:
                return m.group(1).lower()
    if text.strip() and len(re.findall(r"\b[A-Fa-f0-9]{64}\b", text)) == 1 and len(text.strip().splitlines()) == 1:
        return re.search(r"\b([A-Fa-f0-9]{64})\b", text).group(1).lower()      # single-hash *.sha256 file
    return None


def _fido_url(ver: str, log) -> str:
    FIDO = CACHE.parent / "Fido.ps1"
    FIDO.parent.mkdir(parents=True, exist_ok=True)
    log("Downloading the Fido script (Microsoft ISO resolver)…")
    # utf-8-sig: Windows PowerShell 5.1 (the default on Windows 10) reads BOM-less UTF-8 as ANSI and can mis-parse Fido
    FIDO.write_text(http_text("https://raw.githubusercontent.com/pbatard/Fido/master/Fido.ps1", 30), encoding="utf-8-sig")
    log(f"Asking Microsoft for the latest Windows {ver} x64 ISO link (this can take up to a minute)…")
    code, out = ps(f"& '{FIDO}' -Win {ver} -Rel Latest -Arch x64 -Lang English -GetUrl", 240)
    urls = [l.strip() for l in out.splitlines() if l.strip().startswith("http")]
    if not urls:
        for line in [l for l in out.splitlines() if l.strip()][-8:]:
            log("  Fido: " + line.strip()[:200])
        page = "https://www.microsoft.com/software-download/windows" + ("11" if ver == "11" else "10ISO")
        raise FlashError(f"Microsoft did not hand out a download link (it sometimes blocks automated requests). "
                         f"Download the ISO yourself from {page} and pick it with 'Use my own ISO file'.")
    log("Got an official download link from Microsoft.")
    return urls[-1]


def resolve(entry: dict, log) -> dict:
    """-> {urls:[...], filename, sha256|None}"""
    src = entry["src"]
    if src == "fido":
        url = _fido_url(entry["win"], log)
        name = f"Windows{entry['win']}_x64.iso"
        return {"urls": [url], "filename": name, "sha256": None}
    if src == "fixed":
        urls = entry["urls"]
        name = entry.get("filename") or urls[0].rsplit("/", 1)[-1] or entry["id"] + ".iso"
        sha = None
        for cu in entry.get("checksum_urls", []):
            try:
                sha = parse_checksum(http_text(cu), name) or parse_checksum(http_text(cu), urls[0].rsplit("/", 1)[-1])
                if sha:
                    break
            except FlashError:
                continue
        return {"urls": urls, "filename": name, "sha256": sha}
    if src == "github":
        return _resolve_github(entry, log)
    # listing: try the main mirror, then alternates; inside one, walk version folders newest -> oldest
    # until one really contains the file (the newest folder is sometimes still being populated).
    last_err = "no mirror answered"
    for root in [entry["base"]] + list(entry.get("alt_bases", [])):
        try:
            return _resolve_listing(entry, root, log)
        except FlashError as exc:
            last_err = str(exc)
            log(f"  ! {root.split('//', 1)[-1][:60]}: {last_err[:110]}")
    raise FlashError(last_err)


def github_asset(repo: str, pattern: str, log=lambda m: None) -> tuple[str, str]:
    """Newest release asset of `repo` whose file name matches `pattern` -> (download url, file name).
    Uses the API first and falls back to the public release pages, because the API is limited to 60 requests/hour per IP
    (shared / busy networks hit that constantly)."""
    pat = re.compile(pattern)
    try:
        j = json.loads(http_text(f"https://api.github.com/repos/{repo}/releases/latest", 30))
        for a in j.get("assets", []):
            if pat.search(a["name"]):
                return a["browser_download_url"], a["name"]
    except Exception as exc:
        log(f"  ! GitHub API unavailable ({str(exc)[:70]}) - reading the release page instead")
    try:
        from urllib.parse import unquote
        opener, req, t = _open(f"https://github.com/{repo}/releases/latest", True, 30)
        with opener.open(req, timeout=t) as r:
            tag = r.geturl().rstrip("/").rsplit("/", 1)[-1]
        html = http_text(f"https://github.com/{repo}/releases/expanded_assets/{tag}", 30)
        for path, name in re.findall(r'href="(/[^"]+/releases/download/[^"]+/([^"/]+))"', html):
            name = unquote(name)
            if pat.search(name):
                return "https://github.com" + path, name
    except Exception as exc:
        raise FlashError(f"could not find the latest release of {repo}: {str(exc)[:120]}")
    raise FlashError("no matching release asset")


def _resolve_github(entry: dict, log) -> dict:
    url, name = github_asset(entry["repo"], entry["asset"], log)
    return {"urls": [url], "filename": name, "sha256": None}


def _resolve_listing(entry: dict, root: str, log) -> dict:
    bases = [root]
    if entry.get("subdir"):
        subs = sorted((d for d in list_dir(root) if re.search(entry["subdir"], d)), key=vkey, reverse=True)
        if not subs:
            raise FlashError(f"no version folders at {root}")
        bases = [root + d + entry.get("subpath", "") for d in subs[:6]]
    else:
        bases = [root + entry.get("subpath", "")]
    err = "no matching file"
    for base in bases:
        try:
            names = list_dir(base)
        except FlashError as exc:
            err = str(exc)
            continue
        files = [n for n in names if re.search(entry["file"], n)]
        if not files:
            err = f"no matching file at {base}"
            continue
        fname = max(files, key=vkey)
        sha = None
        cands = [base + c for c in entry.get("checksum_files", [])]
        if entry.get("checksum_re"):
            cands += [base + n for n in names if re.search(entry["checksum_re"], n)]
        for cu in cands:
            try:
                sha = parse_checksum(http_text(cu), fname)
                if sha:
                    break
            except FlashError:
                continue
        return {"urls": [base + fname], "filename": fname, "sha256": sha}
    raise FlashError(err)


# ── downloading (resumable, mirror fallback, progress) ────────────────────────

def download(urls: list[str], dest: Path, on_prog: Callable[[float, float, float], None], cancel: threading.Event,
             log: Callable[[str], None]) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name + ".part")
    errors = []
    for url in urls:
        for direct in (True, False):
            try:
                pos = part.stat().st_size if part.exists() else 0
                opener, req, _ = _open(url, direct)
                if pos:
                    req.add_header("Range", f"bytes={pos}-")
                log(f"Downloading {url.split('//', 1)[-1][:70]} ({'direct' if direct else 'via system proxy'})" + (f" - resuming at {pos / 1048576:.0f} MB" if pos else ""))
                with opener.open(req, timeout=30) as r:
                    if r.status == 200 and pos:
                        pos = 0
                    total = int(r.headers.get("Content-Length", 0)) + pos
                    log(f"  Connected (HTTP {r.status}) - " + (f"{total / 1e9:.2f} GB" if total else "size unknown") + (f", following redirect to {r.geturl().split('//', 1)[-1][:60]}" if r.geturl() != url else ""))
                    mode = "ab" if pos else "wb"
                    done, t0, last = pos, time.monotonic(), 0.0
                    with open(part, mode) as f:
                        while True:
                            if cancel.is_set():
                                raise Cancelled()
                            chunk = r.read(1 << 20)
                            if not chunk:
                                break
                            f.write(chunk)
                            done += len(chunk)
                            now = time.monotonic()
                            if now - last > 0.3:
                                last = now
                                sp = (done - pos) / max(now - t0, 0.001)
                                on_prog(done / total if total else 0.0, sp, ((total - done) / sp) if sp and total else 0.0)
                if total and part.stat().st_size < total:
                    raise FlashError("connection dropped before the end")
                if dest.exists():
                    dest.unlink()
                part.replace(dest)
                on_prog(1.0, 0.0, 0.0)
                return dest
            except Cancelled:
                raise
            except Exception as exc:
                errors.append(f"{url.split('//', 1)[-1][:50]}: {str(exc)[:80]}")
                log(f"  ! {errors[-1]}")
    raise FlashError("download failed - " + "; ".join(errors[-3:]))


def sha256_file(path: Path, on_prog, cancel: threading.Event) -> str:
    h, size, done = hashlib.sha256(), path.stat().st_size, 0
    with open(path, "rb") as f:
        while True:
            if cancel.is_set():
                raise Cancelled()
            b = f.read(CHUNK)
            if not b:
                break
            h.update(b)
            done += len(b)
            on_prog(done / max(size, 1))
    return h.hexdigest()


# ── USB drives ────────────────────────────────────────────────────────────────

_LIST_PS = r"""
$out = @()
foreach ($d in (Get-Disk | Where-Object { $_.BusType -eq 'USB' -and -not $_.IsSystem -and -not $_.IsBoot })) {
  $parts = @(Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue)
  $vols = @(); foreach ($p in $parts) { $v = Get-Volume -Partition $p -ErrorAction SilentlyContinue; if ($v) { $vols += $v } }
  $letters = ($vols | Where-Object { $_.DriveLetter } | ForEach-Object { "$($_.DriveLetter):" }) -join ' '
  $labels = ($vols | Where-Object { $_.FileSystemLabel } | ForEach-Object { $_.FileSystemLabel }) -join ', '
  $used = ($vols | ForEach-Object { $_.Size - $_.SizeRemaining } | Measure-Object -Sum).Sum
  $out += [pscustomobject]@{ number = $d.Number; name = $d.FriendlyName; size = [int64]$d.Size; serial = "$($d.SerialNumber)".Trim();
    style = "$($d.PartitionStyle)"; letters = $letters; labels = $labels; used = [int64]$used; offline = $d.IsOffline; readonly = $d.IsReadOnly }
}
ConvertTo-Json -InputObject @($out) -Compress
"""


def list_usb_drives(log: Optional[Callable[[str], None]] = None) -> list[dict]:
    code, out = ps(_LIST_PS, 60, log=log, label="PowerShell: Get-Disk (USB drives only, system/boot disks excluded)") if log else ps(_LIST_PS, 60)
    try:
        data = json.loads(out.strip().splitlines()[-1])
    except Exception:
        if log:
            log("  ! could not read the drive list" + (": " + out.strip()[-200:] if out.strip() else ""))
        return []
    data = data if isinstance(data, list) else [data]
    if log:
        log(f"Found {len(data)} USB drive(s)" + ("".join(f"\n   Disk {d.get('number')}: {d.get('name')} ({d.get('size', 0) / 1e9:.1f} GB) {d.get('letters') or ''}" for d in data)))
    return data


def revalidate(disk: dict, log: Optional[Callable[[str], None]] = None) -> None:
    """Called right before anything destructive."""
    code, out = ps(f"Get-Disk -Number {int(disk['number'])} | Select-Object Number,Size,BusType,IsSystem,IsBoot,SerialNumber | ConvertTo-Json -Compress", 30)
    try:
        d = json.loads(out.strip().splitlines()[-1])
    except Exception:
        raise FlashError("The selected drive is no longer available - was it unplugged?")
    if str(d.get("BusType")).upper() not in ("USB", "7") or d.get("IsSystem") or d.get("IsBoot"):
        raise FlashError("Refusing to continue: the selected disk is not a removable USB drive.")
    if int(d.get("Size", 0)) != int(disk["size"]) or ("%s" % d.get("SerialNumber", "")).strip() != (disk.get("serial") or ""):
        raise FlashError("The drive changed since you selected it (different size/serial). Please start again.")
    if log:
        log(f"Safety check passed: Disk {int(disk['number'])} is still the same removable USB drive.")


def diskpart(lines: list[str], timeout: int = 300, log: Optional[Callable[[str], None]] = None,
             cancel: Optional[threading.Event] = None, strict: bool = True) -> str:
    script = Path(os.environ.get("TEMP", ".")) / "dwut_diskpart.txt"
    script.write_text("\n".join(lines) + "\n", encoding="ascii", errors="replace")
    if log:
        log("diskpart script:  " + "  ->  ".join(lines))
        code, out = run_logged(["diskpart", "/s", str(script)], log, timeout, cancel=cancel)
    else:
        code, out = run(["diskpart", "/s", str(script)], timeout)
    try:
        script.unlink()
    except OSError:
        pass
    if strict and (code != 0 or "DiskPart has encountered an error" in out or "Access is denied" in out):
        raise FlashError("diskpart failed: " + out.strip()[-300:])
    return out


def wipe(disk: dict, log: Optional[Callable[[str], None]] = None) -> None:
    diskpart([f"select disk {int(disk['number'])}", "attributes disk clear readonly noerr", "online disk noerr", "clean", "convert mbr"], 300, log)
    time.sleep(2)


def free_letter(exclude: str = "") -> str:
    for l in "ZYXWVUTSRQPONMLKJIHGFED":
        if l not in exclude and not os.path.exists(f"{l}:\\"):
            return l
    raise FlashError("No free drive letters available.")


# ── raw writing / verification ────────────────────────────────────────────────

def raw_path(n: int) -> str:
    return rf"\\.\PhysicalDrive{int(n)}"


def write_image(image: Path, target: str, on_prog, cancel: threading.Event) -> int:
    size = image.stat().st_size
    done, t0, last = 0, time.monotonic(), 0.0
    with open(image, "rb") as src, open(target, "r+b", buffering=0) as dst:
        while True:
            if cancel.is_set():
                raise Cancelled()
            data = src.read(CHUNK)
            if not data:
                break
            if len(data) % 4096:
                data += b"\0" * (4096 - len(data) % 4096)          # sector-align the tail
            dst.write(data)
            done += min(len(data), size - done)
            now = time.monotonic()
            if now - last > 0.3:
                last = now
                sp = done / max(now - t0, 0.001)
                on_prog(done / size, sp, (size - done) / sp if sp else 0)
        try:
            dst.flush()
            os.fsync(dst.fileno())
        except OSError:
            pass
    on_prog(1.0, 0.0, 0.0)
    return size


def verify_image(image: Path, target: str, on_prog, cancel: threading.Event) -> None:
    size, done = image.stat().st_size, 0
    with open(image, "rb") as src, open(target, "rb", buffering=0) as dev:
        while done < size:
            if cancel.is_set():
                raise Cancelled()
            a = src.read(CHUNK)
            if not a:
                break
            n = len(a)
            n_al = n + (-n % 4096)
            b = dev.read(n_al)[:n]
            if a != b:
                raise FlashError(f"Verification FAILED at {done / 1048576:.0f} MB - the stick may be faulty or counterfeit. Try another USB stick.")
            done += n
            on_prog(done / size)


def is_hybrid(image: Path) -> bool:
    try:
        with open(image, "rb") as f:
            return f.read(512)[510:512] == b"\x55\xaa"
    except OSError:
        return False


# ── Windows-style ISO (FAT32 + split WIM + boot code) ─────────────────────────

def flash_winiso(iso: Path, disk: dict, prog, cancel, log) -> None:
    n = int(disk["number"])
    letter = free_letter()
    size_mb = int(disk["size"] / 1048576)
    part = "create partition primary size=32000" if size_mb > 32768 else "create partition primary"
    prog.stage("prepare", "Preparing the USB stick (MBR + FAT32)…")
    diskpart([f"select disk {n}", "attributes disk clear readonly noerr", "online disk noerr", "clean", "convert mbr", part,
              "select partition 1", "active", 'format fs=fat32 quick label="DWUT_USB"', f"assign letter={letter}"], 600, log, cancel)
    time.sleep(2)
    if not os.path.exists(f"{letter}:\\"):
        raise FlashError("The new USB volume did not appear.")
    log(f"USB volume ready as {letter}:")
    prog.stage("copy", "Mounting the ISO…")
    code, out = ps(f"$i = Mount-DiskImage -ImagePath '{psq(iso)}' -PassThru; Start-Sleep 2; ($i | Get-Volume).DriveLetter", 120, log, cancel, label=f"PowerShell: Mount-DiskImage '{iso.name}'")
    src = out.strip().splitlines()[-1].strip() if out.strip() else ""
    if not re.fullmatch(r"[A-Za-z]", src):
        raise FlashError("Could not mount the ISO: " + out.strip()[-200:])
    log(f"ISO mounted as {src}:")
    S, U = f"{src}:\\", f"{letter}:\\"
    try:
        wim = Path(S) / "sources" / "install.wim"
        big_wim = wim.exists() and wim.stat().st_size > 4_000_000_000
        total = sum(f.stat().st_size for f in Path(S).rglob("*") if f.is_file() and not (big_wim and f == wim))
        log(f"Copying {total / 1048576:.0f} MB of installer files" + (" (install.wim is over 4 GB: it is split afterwards for FAT32)" if big_wim else "") + "…")
        t0 = time.monotonic()

        def tick() -> None:
            try:
                used = shutil.disk_usage(U).used
            except OSError:
                used = 0
            prog.frac(min(used / max(total, 1), 0.99), speed=used / max(time.monotonic() - t0, 1))

        # robocopy prints one line per file: we log them (thinned to the most useful ones) instead of throwing them away
        cmd = ["robocopy", S, U, "/E", "/R:2", "/W:2", "/NDL", "/NJH", "/NP", "/MT:4", "/BYTES"] + (["/XF", "install.wim"] if big_wim else [])
        code, out = run_logged(cmd, lambda m: log(m) if (len(m) < 160 and ("\\" in m or "ERROR" in m.upper() or "Total" in m or "Files" in m or "Bytes" in m or "exit code" in m)) else None,
                               7200, cancel=cancel, label=" ".join(cmd), on_tick=tick)
        if code >= 8:
            raise FlashError(f"File copy failed (robocopy code {code}). Last output: {out.strip()[-200:]}")
        log("File copy finished.")
        if big_wim:
            prog.stage("split", "Splitting install.wim for FAT32 (a few minutes - Windows prints progress below)…", indeterminate=True)
            code, out = run_logged(["dism", "/Split-Image", f"/ImageFile:{wim}", f"/SWMFile:{U}sources\\install.swm", "/FileSize:3800"], log, 3600, cancel=cancel)
            if code != 0:
                raise FlashError("DISM could not split install.wim: " + out.strip()[-200:])
        prog.stage("boot", "Writing boot code…")
        bs = Path(S) / "boot" / "bootsect.exe"
        if bs.exists():
            code, out = run_logged([str(bs), "/nt60", f"{letter}:", "/force", "/mbr"], log, 120, cancel=cancel)
            if code != 0:
                log("  ! bootsect failed (UEFI boot still works)")
        else:
            log("  ! this ISO has no bootsect.exe - the stick will boot on UEFI PCs only")
    finally:
        ps(f"Dismount-DiskImage -ImagePath '{psq(iso)}'", 60, log, label="PowerShell: Dismount-DiskImage")


# ── Ventoy ────────────────────────────────────────────────────────────────────

def ventoy_exe(prog, cancel, log) -> Path:
    cat = catalog.get("ventoy")
    root = CACHE.parent / "ventoy"
    found = next(iter(root.rglob("Ventoy2Disk.exe")), None) if root.exists() else None
    if found:
        log(f"Using the Ventoy installer already on this PC ({found.parent.name}).")
        return found
    prog.stage("download", "Getting the latest Ventoy…", True)
    r = resolve(cat, log)
    z = CACHE / r["filename"]
    if z.exists() and zipfile.is_zipfile(z):
        log(f"Ventoy {r['filename']} is already downloaded - reusing it.")
    else:
        z = download(r["urls"], z, prog.dl, cancel, log)
    log("Unpacking Ventoy…")
    shutil.rmtree(root, ignore_errors=True)
    try:
        with zipfile.ZipFile(z) as zf:
            zf.extractall(root)
    except zipfile.BadZipFile:
        z.unlink(missing_ok=True)
        raise FlashError("The Ventoy download was damaged - it was deleted. Please try again.")
    found = next(iter(root.rglob("Ventoy2Disk.exe")), None)
    if not found:
        raise FlashError("Ventoy2Disk.exe not found in the download.")
    log(f"Ventoy ready: {found}")
    return found


_VT_PS = ("Update-Disk -Number {n} -ErrorAction SilentlyContinue; "
          "Get-Partition -DiskNumber {n} -ErrorAction SilentlyContinue | ForEach-Object {{ "
          "$v = $_ | Get-Volume -ErrorAction SilentlyContinue; "
          "$dl = if ($_.DriveLetter -and [int][char]$_.DriveLetter -ne 0) {{ [string]$_.DriveLetter }} else {{ '' }}; "
          "\"$($_.PartitionNumber)|$($v.FileSystemLabel)|$dl|$($_.Size)|$($v.FileSystem)\" }}")

_VENTOY_EFI_BYTES = 32 * 1024 * 1024               # Ventoy's second partition (VTOYEFI) is exactly 32 MiB
_GOOD_FS = ("exfat", "ntfs", "fat32", "fat")


def _ventoy_parts(n: int, timeout: int = 25) -> list[dict]:
    """Partitions of disk n as WINDOWS sees them -> [{num, label, letter, size, fs}].  Only a fallback: the storage cmdlets can hang
    for a long time on a half-formatted partition, so the main path reads the partition table straight off the disk (_read_mbr)."""
    code, out = ps(_VT_PS.format(n=n), timeout)
    parts = []
    for line in out.splitlines():
        f = line.strip().split("|")
        if len(f) < 5 or not f[0].isdigit():
            continue
        try:
            size = int(f[3])
        except ValueError:
            size = 0
        parts.append({"num": int(f[0]), "label": f[1].strip(), "letter": f[2].strip().upper() if re.fullmatch(r"[A-Za-z]", f[2].strip() or "") else "",
                      "size": size, "fs": f[4].strip()})
    return sorted(parts, key=lambda x: x["num"])


def _is_ventoy_layout(parts: list[dict]) -> bool:
    """Windows' view: a big data partition 1 plus the 32 MiB boot partition (judged by size as well as by label)."""
    if len(parts) < 2 or parts[0]["num"] != 1:
        return False
    return any(p["label"].lower() == "vtoyefi" or abs(p["size"] - _VENTOY_EFI_BYTES) <= 2 * 1024 * 1024 for p in parts[1:])


def _read_mbr(n: int) -> Optional[list[dict]]:
    """The MBR partition table read STRAIGHT FROM THE DISK (needs admin, which the flasher already requires).  Needs no PowerShell,
    no volume manager and cannot hang.  -> [{slot,type,start,sectors}] sorted by position, or None when it cannot be read."""
    try:
        with open(raw_path(n), "rb", buffering=0) as f:
            sec = f.read(4096)
    except OSError:
        return None
    if len(sec) < 512 or sec[510:512] != b"\x55\xaa":
        return None
    out = []
    for i in range(4):
        e = sec[446 + 16 * i: 462 + 16 * i]
        ptype, lba, cnt = e[4], int.from_bytes(e[8:12], "little"), int.from_bytes(e[12:16], "little")
        if ptype and cnt:
            out.append({"slot": i + 1, "type": ptype, "start": lba, "sectors": cnt})
    return sorted(out, key=lambda p: p["start"])


def _mbr_is_ventoy(parts: Optional[list[dict]]) -> bool:
    """Ventoy (MBR style) = a big data partition followed by a 32 MiB type-0xEF partition (VTOYEFI) at the very end."""
    if not parts or len(parts) < 2 or parts[0]["type"] == 0xEE:
        return False
    a, b = parts[0], parts[1]
    return b["type"] == 0xEF and b["sectors"] in (65536, 8192) and b["start"] >= a["start"] + a["sectors"] and a["sectors"] > 65536


def _fs_signature(n: int, start_lba: int) -> tuple[str, bool]:
    """-> (file system found at the start of a partition, partition looks completely blank).  Read raw, no Windows involved."""
    try:
        with open(raw_path(n), "rb", buffering=0) as f:
            f.seek(start_lba * 512)
            b = f.read(4096)
    except OSError:
        return "", False
    if len(b) < 512:
        return "", False
    if b[3:11] == b"EXFAT   ":
        return "exfat", False
    if b[3:7] == b"NTFS":
        return "ntfs", False
    if b[82:90] == b"FAT32   ":
        return "fat32", False
    if b[54:57] == b"FAT":
        return "fat", False
    return "", not b.strip(b"\0")


def _probe_writable(letter: str, log) -> bool:
    p = Path(f"{letter}:\\.dwut_probe.tmp")
    try:
        p.write_bytes(b"dwut-probe")
        ok = p.read_bytes() == b"dwut-probe"
        p.unlink()
        return ok
    except OSError as exc:
        log(f"  ! {letter}: is visible but not writable yet ({str(exc)[:80]})")
        return False


def _format_data_partition(n: int, log, cancel) -> None:
    """Format partition 1 as exFAT 'Ventoy' - exactly what Ventoy itself does - trying diskpart first, then PowerShell."""
    log("  Formatting the Ventoy data partition as exFAT (label 'Ventoy')…")
    try:
        diskpart([f"select disk {n}", "select partition 1", 'format fs=exfat quick label="Ventoy" override'], 900, log, cancel)
        return
    except FlashError as exc:
        log(f"  ! diskpart could not format it ({str(exc)[:120]}) - trying PowerShell")
    code, out = ps(f"$p = Get-Partition -DiskNumber {n} -PartitionNumber 1; "
                   "Format-Volume -Partition $p -FileSystem exFAT -NewFileSystemLabel Ventoy -Confirm:$false -Force | Out-Null; 'FORMATTED'",
                   600, log, cancel, label=f"PowerShell: Format-Volume (Disk {n}, partition 1, exFAT, label Ventoy)")
    if "FORMATTED" not in out:
        raise FlashError("The Ventoy data partition could not be formatted (diskpart and PowerShell both failed). "
                         "Close any Explorer windows showing this stick, unplug and re-plug it, then try again.")


def _ventoy_data_letter(n: int, data: dict, log, cancel, fresh: bool, force_format: bool = False) -> str:
    """Make Ventoy's data partition usable and return its drive letter.

    fresh=True  - Ventoy was JUST installed on a stick we wiped: the partition is ours, so if it has no usable file system (or Ventoy's
                  own log said its format step failed) it is formatted exFAT 'Ventoy'.
    fresh=False - an existing Ventoy stick the user may have files on: it is only ever formatted when it is completely blank; a file
                  system we cannot write to (ext4 / XFS ...) stops the job instead of being erased."""
    fs, blank = _fs_signature(n, data["start"])
    log(f"  Ventoy data partition: {data['sectors'] * 512 / 1e9:.1f} GB at sector {data['start']}, file system: {fs or ('blank' if blank else 'unknown')}")
    need_format = False
    if fresh:
        need_format = force_format or not fs
    elif not fs:
        if blank:
            need_format = True
        else:
            raise FlashError("This Ventoy stick uses a file system Windows cannot write to (such as ext4 or XFS). "
                             "Nothing was changed. Use 'Restore USB' on it first (that erases it), or use another stick.")
    if need_format:
        _format_data_partition(n, log, cancel)
        time.sleep(1)
    letter = free_letter()
    log(f"  Giving the data partition drive letter {letter}:…")
    # 'remove all' first so there is exactly ONE known letter (Windows may already have auto-mounted it under another one)
    diskpart(["rescan", f"select disk {n}", "attributes disk clear readonly noerr", "online disk noerr", "select partition 1", "remove all noerr",
              f"assign letter={letter}"], 120, log, cancel, strict=False)
    for i in range(30):
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        if os.path.exists(f"{letter}:\\") and _probe_writable(letter, log):
            log(f"  Ventoy data partition is ready as {letter}: and writable.")
            return letter
        if i and i % 5 == 0:
            log(f"  …waiting for Windows to mount {letter}: ({i}/30)")
        time.sleep(1)
    raise FlashError(f"Windows did not mount the Ventoy data partition as {letter}:. Unplug the stick, plug it in again, and flash once more.")


def _ventoy_letter(n: int, tries: int, log=None, cancel=None, fresh: bool = False, force_format: bool = False) -> str:
    """Wait until the stick has Ventoy's layout and a USABLE data partition; repair/format it when Ventoy left it unusable.
    -> drive letter, or '' when this disk does not have Ventoy.  Every decision is logged: this step must never be silent."""
    log = log or (lambda m: None)
    seen = None
    for i in range(tries):
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        mbr = _read_mbr(n)
        desc = ("cannot read the partition table yet" if mbr is None else
                "partition table: " + ", ".join(f"#{p['slot']} type 0x{p['type']:02X} {p['sectors'] * 512 / 1e9:.2f} GB" for p in mbr))
        if desc != seen:
            log(f"  {desc}")
            seen = desc
        if _mbr_is_ventoy(mbr):
            log("  Ventoy's partition layout is on the stick (data partition + 32 MiB VTOYEFI).")
            return _ventoy_data_letter(n, mbr[0], log, cancel, fresh, force_format)
        if mbr is None or i >= 2:                                   # unreadable table -> ask Windows (slow, so only as a fallback)
            parts = _ventoy_parts(n, 20)
            if _is_ventoy_layout(parts):
                d = parts[0]
                log(f"  Windows sees Ventoy's layout (partition 1: {d['fs'] or 'unformatted'}, {d['letter'] or 'no letter'}).")
                if d["fs"].lower() in _GOOD_FS and d["letter"] and os.path.exists(f"{d['letter']}:\\"):
                    return d["letter"]
                if mbr is not None:
                    return _ventoy_data_letter(n, mbr[0], log, cancel, fresh, force_format)
                _ventoy_repair_data(n, parts, log)
                time.sleep(2)
                again = _ventoy_parts(n, 20)
                if again and again[0]["letter"] and os.path.exists(f"{again[0]['letter']}:\\"):
                    return again[0]["letter"]
        if i and i % 5 == 0:
            log(f"  …waiting for the Ventoy partitions to show up ({i}/{tries})")
        time.sleep(1)
    return ""


def _ventoy_repair_data(n: int, parts: list[dict], log) -> None:
    """Fallback used only when the partition table could not be read directly: format partition 1 and give it a letter."""
    d = parts[0]
    if d["fs"].lower() not in _GOOD_FS:
        log("  Formatting the data partition as exFAT 'Ventoy'…")
        try:
            diskpart([f"select disk {n}", "select partition 1", 'format fs=exfat quick label="Ventoy" override'], 900, log)
        except FlashError as exc:
            log(f"  ! {str(exc)[:140]}")
    if not d["letter"]:
        diskpart([f"select disk {n}", "select partition 1", "assign noerr"], 60, log, strict=False)


def _tail_file(path: Path, log, n: int = 14, title: str = "") -> None:
    try:
        if path.exists():
            lines = [l.rstrip() for l in path.read_text(errors="replace").splitlines() if l.strip()][-n:]
            if lines:
                log(f"  --- {title or path.name} ---")
                for l in lines:
                    log("  " + l[:200])
    except OSError:
        pass


def install_ventoy(disk: dict, prog, cancel, log, need_user, reinstall: bool = False) -> str:
    """Returns the drive letter of the Ventoy data partition.

    * A stick that ALREADY has Ventoy on it (both Ventoy partitions present) is reused as-is - nothing is erased.
    * Otherwise: wipe, then Ventoy's command-line installer (normally first, then with /NoUSBCheck for external SSDs that
      report a non-USB bus), and finally Ventoy's own window as a last resort.  Everything Ventoy prints and its own log
      files are shown in the Activity log.
    * Ventoy's CLI says SUCCESS even when it could not format its data partition ("Failed to find ventoy volume" / "Can not
      reformat D:\\ to exFAT").  So its result is never taken on trust: the partition table is read back from the disk, the data
      partition is formatted when needed, mounted under a known drive letter and a test file is written to it."""
    exe = ventoy_exe(prog, cancel, log)
    n = int(disk["number"])
    log(f"Checking whether Disk {n} already has Ventoy…")
    if not reinstall:
        if _mbr_is_ventoy(_read_mbr(n)):
            log("The stick has Ventoy's partition layout - checking that its data partition is usable…")
            existing = _ventoy_letter(n, 20, log, cancel, fresh=False)
            if existing:
                log(f"Ventoy is already installed on this stick (drive {existing}:) - keeping everything on it and just adding the ISO.")
                return existing
        log("No usable Ventoy found on the stick - installing it (the stick is erased first).")
    prog.stage("install", "Installing Ventoy on the stick…", True)
    wipe(disk, log)
    letter = ""
    attempts = [[], ["/NoUSBCheck"]]
    for k, extra in enumerate(attempts):
        if cancel.is_set():
            raise Cancelled()
        for stale in ("cli_log.txt", "log.txt"):
            try:
                (exe.parent / stale).unlink()
            except OSError:
                pass
        log(f"Ventoy install attempt {k + 1} of {len(attempts)}" + (" (allowing non-USB bus drives)" if extra else ""))
        code, out = run_logged([str(exe), "VTOYCLI", "/I", f"/PhyDrive:{n}", *extra], log, 420, cwd=exe.parent, cancel=cancel)
        _tail_file(exe.parent / "cli_log.txt", log, 12, "Ventoy status (cli_log.txt)")
        try:
            cli_txt = (exe.parent / "cli_log.txt").read_text(errors="replace").lower()
        except OSError:
            cli_txt = ""
        vt_format_failed = "can not reformat" in cli_txt or "failed to find ventoy volume" in cli_txt
        if code == 0 and vt_format_failed:
            log("  Ventoy wrote its partitions but could not format the data partition itself (common on Windows 11) - DWUT finishes that part.")
        prog.stage("install", "Preparing the Ventoy data partition…", True)
        letter = _ventoy_letter(n, 45 if code == 0 else 4, log, cancel, fresh=True, force_format=vt_format_failed)
        if letter:
            log(f"Ventoy installed - data partition is {letter}:")
            break
        log(f"  ! Ventoy attempt {k + 1} did not produce a Ventoy stick (exit code {code}).")
        _tail_file(exe.parent / "log.txt", log, 14, "Ventoy log (log.txt)")
        if k + 1 < len(attempts):
            log("  Cleaning the stick again before retrying…")
            wipe(disk, log)
    if not letter:
        log("  ! Ventoy's command-line mode failed - opening its window for you.")
        subprocess.Popen([str(exe)], cwd=str(exe.parent))
        need_user(f"Ventoy opened. Pick the device that is Disk {n} ({disk['name']}), click Install, then press Continue here.")
        letter = _ventoy_letter(n, 25, log, cancel, fresh=True)
    if not letter:
        raise FlashError("Ventoy was not installed on the stick. See the log above for Ventoy's own messages.")
    return letter


def copy_file(src: Path, dst: Path, on_prog, cancel, log: Optional[Callable[[str], None]] = None) -> None:
    size, done, t0, last = src.stat().st_size, 0, time.monotonic(), 0.0
    log = log or (lambda m: None)
    try:
        free = shutil.disk_usage(dst.parent).free
        if dst.exists():
            free += dst.stat().st_size
        log(f"Free space on {dst.parent}: {free / 1e9:.1f} GB (ISO needs {size / 1e9:.2f} GB)")
        if free < size + 1024 * 1024:
            raise FlashError(f"Not enough space on the stick: the ISO is {size / 1e9:.2f} GB but only {free / 1e9:.2f} GB is free.")
    except OSError:
        pass
    log(f"Copying {src.name} ({size / 1e9:.2f} GB) -> {dst}")
    try:
        with open(src, "rb") as a, open(dst, "wb") as b:
            while True:
                if cancel.is_set():
                    raise Cancelled()
                c = a.read(CHUNK)
                if not c:
                    break
                b.write(c)
                done += len(c)
                now = time.monotonic()
                if now - last > 0.3:
                    last = now
                    sp = done / max(now - t0, 0.001)
                    on_prog(done / size, sp, (size - done) / sp if sp else 0)
            b.flush()
            try:
                os.fsync(b.fileno())
            except OSError:
                pass
    except OSError as exc:
        raise FlashError(f"Writing to the stick failed: {exc}. Is it full, write-protected or unplugged?")
    on_prog(1.0, 0, 0)
    el = max(time.monotonic() - t0, 0.001)
    log(f"Copy finished: {size / 1048576:.0f} MB in {el:.0f} s ({size / 1048576 / el:.1f} MB/s)")
    ps(f"Write-VolumeCache -DriveLetter {str(dst)[0]} -ErrorAction SilentlyContinue", 120, log, label="PowerShell: flush the stick's write cache")
    got = dst.stat().st_size if dst.exists() else -1
    if got != size:
        raise FlashError(f"The copy on the stick is {got} bytes but the ISO is {size} bytes - the stick may be failing. Try another one.")
    log(f"Verified: {dst.name} on the stick is exactly {size} bytes.")
