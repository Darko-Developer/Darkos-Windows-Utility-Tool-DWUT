r"""
modules/system/gpu_prefs.py - "Settings > System > Display > Graphics": give EVERY app the High-performance GPU.

Windows stores the per-app choice in HKCU\Software\Microsoft\DirectX\UserGpuPreferences:
    value name = full path of the .exe (desktop apps)  or  the AppUserModelID (Microsoft Store apps, "Family!App")
    value data = "GpuPreference=2;"      (0 = let Windows decide, 1 = power saving, 2 = high performance)
Other tokens in the same string (AutoHDR, SwapEffectUpgradeEnable ...) are kept.  Every value we change is first saved to
%LOCALAPPDATA%\DWUT\gpu_prefs_backup.json so restore_all() can put each app back exactly as it was.
On a PC with a single GPU this changes nothing visible; on a hybrid laptop it sends every app to the discrete GPU (more battery use).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path
from typing import Callable, Optional

try:
    import winreg
except ImportError:
    winreg = None                                     # type: ignore[assignment]

from core.logger import get_logger

_log = get_logger(__name__)
KEY = r"Software\Microsoft\DirectX\UserGpuPreferences"
MAX_APPS = 3000
_SKIP_NAME = re.compile(r"(unins|uninstall|vcredist|vc_redist|dotnet|crashpad|crashreport|bugreport|setup|installer|updater)", re.I)
_BACKUP = Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT" / "gpu_prefs_backup.json"


def merge_pref(current: Optional[str], level: int = 2) -> str:
    """'AutoHDREnable=2097;GpuPreference=1;' -> 'AutoHDREnable=2097;GpuPreference=2;'  (other tokens are kept)."""
    toks = [t for t in (current or "").split(";") if t.strip() and not t.strip().lower().startswith("gpupreference=")]
    return ";".join(toks + [f"GpuPreference={level}"]) + ";"


def keep_exe(path: str) -> bool:
    """Desktop programs only: real .exe files outside the Windows folder, and not installers / uninstallers / crash helpers."""
    p = path.strip().strip('"')
    if not p.lower().endswith(".exe") or len(p) < 6:
        return False
    low = p.lower()
    if low.startswith(os.environ.get("SystemRoot", r"c:\windows").lower() + "\\"):
        return False
    return not _SKIP_NAME.search(os.path.basename(p))


_ENUM_PS = r"""
$ErrorActionPreference = 'SilentlyContinue'
$out = New-Object System.Collections.Generic.List[string]
$sh = New-Object -ComObject WScript.Shell
$dirs = @("$env:ProgramData\Microsoft\Windows\Start Menu\Programs", "$env:APPDATA\Microsoft\Windows\Start Menu\Programs", "$env:PUBLIC\Desktop", [Environment]::GetFolderPath('Desktop'))
foreach ($d in $dirs) { if (Test-Path $d) { Get-ChildItem $d -Recurse -Filter *.lnk -File | ForEach-Object { $t = $sh.CreateShortcut($_.FullName).TargetPath; if ($t -and $t.ToLower().EndsWith('.exe')) { $out.Add('E|' + $t) } } } }
foreach ($h in 'HKLM:','HKCU:') { foreach ($p in 'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths','SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths') {
  Get-ChildItem "$h\$p" | ForEach-Object { $v = (Get-ItemProperty $_.PSPath).'(default)'; if ($v) { $out.Add('E|' + $v.Trim('"')) } } } }
foreach ($h in 'HKLM:','HKCU:') { foreach ($p in 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall','SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall') {
  Get-ChildItem "$h\$p" | ForEach-Object { $loc = (Get-ItemProperty $_.PSPath).InstallLocation; if ($loc -and (Test-Path $loc)) {
    Get-ChildItem $loc -Filter *.exe -File -Depth 1 | Select-Object -First 25 | ForEach-Object { $out.Add('E|' + $_.FullName) } } } } }
Get-StartApps | Where-Object { $_.AppID -match '^[^\\/:]+_[a-z0-9]{13}!' } | ForEach-Object { $out.Add('S|' + $_.AppID) }
$out | Sort-Object -Unique
"""


def enumerate_apps(log: Callable[[str], None] = lambda m: None) -> list[str]:
    """-> value names: full .exe paths (that exist) and Store-app AppUserModelIDs, de-duplicated."""
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _ENUM_PS],
                           capture_output=True, text=True, timeout=240, errors="replace", stdin=subprocess.DEVNULL,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        lines = (r.stdout or "").splitlines()
    except Exception as exc:
        log(f"  ! could not list installed apps: {exc}")
        return []
    return parse_enumeration(lines)


def parse_enumeration(lines: list[str], exists: Callable[[str], bool] = os.path.exists) -> list[str]:
    seen, out = set(), []
    for ln in lines:
        kind, _, val = ln.strip().partition("|")
        val = val.strip().strip('"')
        if not val:
            continue
        if kind == "E":
            if not keep_exe(val) or not exists(val):
                continue
        elif kind != "S":
            continue
        k = val.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(val)
        if len(out) >= MAX_APPS:
            break
    return out


def set_all_high_performance(log: Callable[[str], None] = lambda m: None, apps: Optional[list[str]] = None, reg=None) -> dict:
    """Set GpuPreference=2 for every app.  -> {"total", "changed", "already", "failed"}"""
    reg = reg or winreg
    apps = apps if apps is not None else enumerate_apps(log)
    changed = already = failed = 0
    backup: dict[str, Optional[str]] = {}
    try:
        backup = json.loads(_BACKUP.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    key = reg.CreateKeyEx(reg.HKEY_CURRENT_USER, KEY, 0, reg.KEY_SET_VALUE | reg.KEY_QUERY_VALUE)
    try:
        for name in apps:
            try:
                try:
                    cur, _t = reg.QueryValueEx(key, name)
                except OSError:
                    cur = None
                new = merge_pref(cur)
                if cur == new:
                    already += 1
                    continue
                backup.setdefault(name, cur)                                  # keep the ORIGINAL value, even across repeated runs
                reg.SetValueEx(key, name, 0, reg.REG_SZ, new)
                changed += 1
            except OSError as exc:
                failed += 1
                log(f"  ! {name}: {exc}")
    finally:
        reg.CloseKey(key)
    try:
        _BACKUP.parent.mkdir(parents=True, exist_ok=True)
        _BACKUP.write_text(json.dumps(backup), encoding="utf-8")
    except OSError as exc:
        log(f"  ! could not save the undo list: {exc}")
    return {"total": len(apps), "changed": changed, "already": already, "failed": failed}


def restore_all(reg=None) -> dict:
    """Put every app DWUT changed back to what it was before (apps that had no entry lose it again)."""
    reg = reg or winreg
    try:
        backup = json.loads(_BACKUP.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"restored": 0, "message": "Nothing to restore - DWUT has not changed any app's graphics preference."}
    n = 0
    key = reg.CreateKeyEx(reg.HKEY_CURRENT_USER, KEY, 0, reg.KEY_SET_VALUE)
    try:
        for name, old in backup.items():
            try:
                if old is None:
                    reg.DeleteValue(key, name)
                else:
                    reg.SetValueEx(key, name, 0, reg.REG_SZ, old)
                n += 1
            except OSError:
                pass
    finally:
        reg.CloseKey(key)
    try:
        _BACKUP.unlink()
    except OSError:
        pass
    return {"restored": n, "message": f"Restored {n} app graphics preference(s)."}
