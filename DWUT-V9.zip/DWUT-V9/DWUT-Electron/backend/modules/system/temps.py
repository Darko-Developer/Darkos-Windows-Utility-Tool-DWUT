"""
modules/system/temps.py - ONE background sampler for CPU and GPU temperature, shared by the Dashboard, Task Manager and
Game Booster so they always show the same number and no page ever waits on a slow WMI call.

Windows has no built-in "CPU die temperature" counter, so several sources are tried, best first, and the first plausible
reading wins (the winning source is reported so the UI can show where the number came from):

  CPU   1. LibreHardwareMonitor / OpenHardwareMonitor WMI  (CPU Package / Core Max)  - exact, needs that app running
        2. Thermal-zone performance counter  (\\Thermal Zone Information(*)\\Temperature, Kelvin)  - no extra software
        3. ACPI thermal zone WMI  (root\\wmi MSAcpi_ThermalZoneTemperature)  - many laptops / some desktops, needs admin
  GPU   1. NVML (NVIDIA)           - exact
        2. LibreHardwareMonitor / OpenHardwareMonitor WMI  (any vendor)

If nothing is available the value is None and the cards honestly show N/A (same as the GPU card always did).
"""
from __future__ import annotations

import threading
import time
from typing import Optional

from core.logger import get_logger

_log = get_logger(__name__)

_PLAUSIBLE = (15.0, 115.0)          # anything outside this is a bogus sensor value (e.g. 0 K, 27315)


def _ok(v) -> Optional[float]:
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    return round(v, 1) if _PLAUSIBLE[0] <= v <= _PLAUSIBLE[1] else None


class TempSampler:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._data = {"cpu": None, "cpu_src": "", "gpu": None, "gpu_src": "", "ts": 0.0}
        self._started = False
        self._wmi = None
        self._pythoncom = None
        self._hw_ns: Optional[str] = None            # which hardware-monitor WMI namespace answers
        self._hw_checked = 0.0

    # ------------------------------------------------------------------ public
    def start(self) -> None:
        with self._lock:
            if self._started:
                return
            self._started = True
        threading.Thread(target=self._run, daemon=True, name="temp-sampler").start()

    def read(self) -> dict:
        """Latest values (never blocks).  Starts the sampler on first use."""
        if not self._started:
            self.start()
        with self._lock:
            return dict(self._data)

    def cpu(self) -> Optional[float]:
        return self.read()["cpu"]

    def gpu(self) -> Optional[float]:
        return self.read()["gpu"]

    # ------------------------------------------------------------------ worker
    def _run(self) -> None:
        try:
            import pythoncom
            import wmi
            self._wmi, self._pythoncom = wmi, pythoncom
            pythoncom.CoInitialize()
        except Exception:
            self._wmi = self._pythoncom = None
        while True:
            t0 = time.time()
            cpu, csrc, gpu, gsrc = None, "", None, ""
            try:
                hw = self._hw_sensors()
                cpu, csrc = self._cpu(hw)
                gpu, gsrc = self._gpu(hw)
            except Exception as exc:
                _log.debug("temp sample: %s", exc)
            with self._lock:
                self._data = {"cpu": cpu, "cpu_src": csrc, "gpu": gpu, "gpu_src": gsrc, "ts": time.time()}
            time.sleep(max(0.5, 2.0 - (time.time() - t0)))

    # ------------------------------------------------------------------ sources
    def _hw_sensors(self) -> list:
        """Temperature sensors from LibreHardwareMonitor / OpenHardwareMonitor, if either is running."""
        if self._wmi is None:
            return []
        now = time.time()
        if self._hw_ns is None and now - self._hw_checked < 30:       # don't hammer WMI looking for an app that is not running
            return []
        spaces = [self._hw_ns] if self._hw_ns else [r"root\LibreHardwareMonitor", r"root\OpenHardwareMonitor"]
        for ns in spaces:
            try:
                c = self._wmi.WMI(namespace=ns)
                out = [(s.Name or "", s.Identifier or "", float(s.Value)) for s in c.Sensor() if s.SensorType == "Temperature" and s.Value is not None]
                self._hw_ns = ns
                return out
            except Exception:
                continue
        self._hw_ns = None
        self._hw_checked = now
        return []

    def _cpu(self, hw: list) -> tuple:
        # 1. hardware monitor
        pref = ("package", "core max", "cpu total", "tctl", "tdie", "cpu die", "cores (average)")
        cpu_s = [(n.lower(), i.lower(), v) for n, i, v in hw if "/cpu" in i.lower() or "cpu" in n.lower() or "core" in n.lower()]
        for key in pref:
            for n, i, v in cpu_s:
                if key in n and _ok(v):
                    return _ok(v), "LibreHW" if (self._hw_ns or "").endswith("LibreHardwareMonitor") else "OHM"
        vals = [_ok(v) for n, i, v in cpu_s if _ok(v)]
        if vals:
            return max(vals), "LibreHW" if (self._hw_ns or "").endswith("LibreHardwareMonitor") else "OHM"
        # 2. thermal-zone performance counter (Kelvin) - works without extra software on many PCs
        if self._wmi is not None:
            try:
                c = self._wmi.WMI()
                temps = []
                for z in c.Win32_PerfFormattedData_Counters_ThermalZoneInformation():
                    k = float(getattr(z, "Temperature", 0) or 0)
                    temps.append(_ok(k - 273.15))
                temps = [t for t in temps if t]
                if temps:
                    return max(temps), "Thermal zone"
            except Exception:
                pass
            # 3. ACPI thermal zone (tenths of Kelvin)
            try:
                c = self._wmi.WMI(namespace=r"root\wmi")
                temps = [_ok(float(z.CurrentTemperature) / 10.0 - 273.15) for z in c.MSAcpi_ThermalZoneTemperature()]
                temps = [t for t in temps if t]
                if temps:
                    return max(temps), "ACPI"
            except Exception:
                pass
        return None, ""

    def _gpu(self, hw: list) -> tuple:
        try:                                              # NVML first: exact and cheap
            from modules.system import info as _info
            if _info._NVML_OK and _info._NVML_HANDLE is not None:
                v = _ok(_info._nvml.nvmlDeviceGetTemperature(_info._NVML_HANDLE, _info._nvml.NVML_TEMPERATURE_GPU))
                if v:
                    return v, "NVML"
        except Exception:
            pass
        gp = [(n.lower(), v) for n, i, v in hw if "/gpu" in i.lower() or "gpu" in n.lower()]
        for key in ("gpu core", "gpu"):
            for n, v in gp:
                if key in n and _ok(v):
                    return _ok(v), "LibreHW" if (self._hw_ns or "").endswith("LibreHardwareMonitor") else "OHM"
        return None, ""


temps = TempSampler()
