"""
modules/system/termpty.py - a real pseudo-terminal running the REAL cmd.exe / powershell.exe.

The custom DWUT terminal windows are only a skin: the shell inside is the genuine Windows one, attached to a ConPTY
(pywinpty), so colours, line editing, history, tab-completion, Ctrl+C, full-screen programs (vim, htop-like tools, winget
progress bars ...) behave exactly like they do in the normal console.

(On non-Windows machines a plain `pty` + bash is used - that exists only so the pipeline can be tested during development.)
"""
from __future__ import annotations

import os
import threading
from typing import Callable, Optional

KINDS = {"cmd": "Command Prompt", "powershell": "Windows PowerShell"}


def _is_admin() -> bool:
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _ensure_winpty() -> bool:
    """pywinpty is needed for ConPTY.  Install it once, quietly, if it is missing."""
    try:
        import winpty  # noqa: F401
        return True
    except Exception:
        pass
    try:
        import importlib
        import subprocess
        import sys
        subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-q", "--prefer-binary", "pywinpty"],
                       capture_output=True, timeout=240, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        importlib.invalidate_caches()
        import winpty  # noqa: F401,F811
        return True
    except Exception:
        return False


def shell_argv(kind: str) -> list[str]:
    root = os.environ.get("SystemRoot", r"C:\Windows")
    if kind == "powershell":
        p = os.path.join(root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
        return [p if os.path.exists(p) else "powershell.exe", "-NoLogo"]
    p = os.path.join(root, "System32", "cmd.exe")
    return [p if os.path.exists(p) else "cmd.exe"]


def start_dir(admin: bool) -> str:
    """Same default folder the real tools open in: your profile folder, or System32 when elevated."""
    if admin:
        return os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32")
    return os.environ.get("USERPROFILE") or os.path.expanduser("~")


class LocalPty:
    """One shell attached to a pseudo-terminal.  Output is pushed to on_data(str); on_exit(code) fires once at the end."""

    def __init__(self, kind: str, cols: int, rows: int, admin: bool,
                 on_data: Callable[[str], None], on_exit: Callable[[int], None]) -> None:
        self.kind, self.on_data, self.on_exit = kind, on_data, on_exit
        self._proc = None
        self._fd = None
        self._closed = False
        cols, rows = max(20, int(cols or 80)), max(5, int(rows or 24))
        cwd = start_dir(admin)
        if os.name == "nt":
            if not _ensure_winpty():
                raise RuntimeError("The terminal needs the 'pywinpty' package and it could not be installed automatically "
                                   "(no internet?). Run:  python -m pip install pywinpty")
            from winpty import PtyProcess
            env = dict(os.environ)
            env.setdefault("TERM", "xterm-256color")
            self._proc = PtyProcess.spawn(shell_argv(kind), cwd=cwd, env=env, dimensions=(rows, cols))
            target = self._read_win
        else:                                                    # development fallback only
            import fcntl
            import pty
            import struct
            import termios
            pid, fd = pty.fork()
            if pid == 0:
                os.chdir(cwd if os.path.isdir(cwd) else "/")
                os.execvp("bash", ["bash", "--norc", "-i"])
            self._pid, self._fd = pid, fd
            fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
            target = self._read_posix
        threading.Thread(target=target, daemon=True, name=f"pty-{kind}").start()

    # ---- readers
    def _read_win(self) -> None:
        code = 0
        try:
            while True:
                data = self._proc.read(4096)
                if data:
                    self.on_data(data)
                elif not self._proc.isalive():
                    break
        except EOFError:
            pass
        except Exception:
            pass
        try:
            code = int(self._proc.exitstatus or 0)
        except Exception:
            code = 0
        self._finish(code)

    def _read_posix(self) -> None:
        code = 0
        try:
            while True:
                try:
                    data = os.read(self._fd, 4096)
                except OSError:
                    break
                if not data:
                    break
                self.on_data(data.decode("utf-8", "replace"))
            _, st = os.waitpid(self._pid, 0)
            code = os.waitstatus_to_exitcode(st)
        except Exception:
            pass
        self._finish(code)

    def _finish(self, code: int) -> None:
        if not self._closed:
            self._closed = True
            try:
                self.on_exit(code)
            except Exception:
                pass

    # ---- control
    def write(self, data: str) -> None:
        try:
            if self._proc is not None:
                self._proc.write(data)
            elif self._fd is not None:
                os.write(self._fd, data.encode("utf-8"))
        except Exception:
            pass

    def resize(self, cols: int, rows: int) -> None:
        cols, rows = max(20, int(cols)), max(5, int(rows))
        try:
            if self._proc is not None:
                self._proc.setwinsize(rows, cols)
            elif self._fd is not None:
                import fcntl
                import struct
                import termios
                fcntl.ioctl(self._fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        except Exception:
            pass

    def close(self) -> None:
        self._closed = True
        try:
            if self._proc is not None:
                self._proc.terminate(force=True)
            elif self._fd is not None:
                os.kill(self._pid, 9)
        except Exception:
            pass
