"""
modules/system/info.py

GPU detection uses a multi-source approach, from best to most universal:

  1. pynvml  (NVIDIA Management Library) — most reliable for NVIDIA cards,
              gives usage%, temp, VRAM used/total directly.
              NOT bundled with the driver — pip install pynvml.
  2. OHM WMI — only used if pynvml fails AND OpenHardwareMonitor is running.
  3. Win32_PerfFormattedData_Counters_GPUEngine — Windows' own "GPU Engine"
              perf counters (what Task Manager's GPU graph reads). Works
              for ANY vendor (NVIDIA/AMD/Intel) with no extra software.
  4. Win32_VideoController (WMI) — name/VRAM-total only, no live usage.
  5. None    — if all else fails, cards show N/A (honest)

Sources 3 and 4 both need the `wmi` package — see requirements.txt.
"""

from __future__ import annotations

import os
import platform
import socket
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional

import psutil

from core.logger import get_logger

_log = get_logger(__name__)

# ── pynvml (via the nvidia-ml-py package — see requirements.txt) ────────────
try:
    import warnings as _warnings
    with _warnings.catch_warnings():
        # Defensive: if someone already has the OLD deprecated standalone
        # "pynvml" package installed instead of nvidia-ml-py, it prints a
        # FutureWarning on import that has nothing actionable for this
        # app's users to do about — silence just that one category here.
        _warnings.filterwarnings("ignore", category=FutureWarning)
        import pynvml as _nvml
    _nvml.nvmlInit()
    _NVML_HANDLE = _nvml.nvmlDeviceGetHandleByIndex(0)
    _NVML_OK = True
except Exception:
    _NVML_OK = False
    _NVML_HANDLE = None

# ── WMI — for GPU name / fallback ────────────────────────────────────────────
try:
    import wmi as _wmi
    import pythoncom as _pythoncom
    _WMI_AVAILABLE = True
except ImportError:
    _WMI_AVAILABLE = False

# ── OHM — last resort, only if running ───────────────────────────────────────
_OHM_CHECKED   = False
_OHM_AVAILABLE = False

# Prime CPU counter
try:
    psutil.cpu_percent(interval=None)
except Exception:
    pass

# Cache slow values
_cpu_name_cache: Optional[str] = None
_gpu_name_cache: Optional[str] = None


def gpu_packages_missing() -> bool:
    """True if the install button should be offered — i.e. wmi/pynvml
    aren't installed (as opposed to being installed but still not finding
    a working GPU data source, which the button can't fix)."""
    return not _NVML_OK or not _WMI_AVAILABLE


def gpu_detection_status() -> str:
    """
    One-line, actionable explanation for WHY GPU stats might be missing —
    almost always because the optional `wmi`/`pynvml` packages (added to
    requirements.txt so GPU detection works on any vendor) simply aren't
    installed in whatever environment is actually running the app. CPU/RAM/
    Disk only ever needed psutil, so if those work but GPU doesn't, this is
    the first thing to check — not a bug in the detection logic itself.
    """
    missing = []
    if not _NVML_OK:
        missing.append("nvidia-ml-py")
    if not _WMI_AVAILABLE:
        missing.append("wmi")
    if missing:
        return f"Missing package(s): {', '.join(missing)} — run: pip install {' '.join(missing)}"
    return "Packages present but no GPU data source responded — see logs"


def install_gpu_packages() -> tuple[bool, str]:
    """
    Installs the missing wmi/pynvml packages into the SAME Python
    interpreter running this app (sys.executable -m pip ...), so it
    reliably targets the right environment regardless of how the app
    itself was launched.

    Note: this module already imported (or failed to import) wmi/pynvml
    at process startup, and _NVML_OK/_WMI_AVAILABLE were decided then —
    installing the packages now does NOT retroactively fix an already-
    running process. The app needs a restart afterward for GPU detection
    to actually pick them up.
    """
    import subprocess
    import sys

    missing = []
    if not _NVML_OK:
        missing.append("nvidia-ml-py")
    if not _WMI_AVAILABLE:
        missing.append("wmi")
    if not missing:
        return True, "GPU packages are already installed."

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", *missing],
            capture_output=True, text=True, timeout=120,
        )
        out = (result.stdout or "") + (result.stderr or "")
        if result.returncode == 0:
            return True, f"Installed {', '.join(missing)}. Restart DWUT for GPU stats to appear."
        return False, out[-800:] if out else "pip install failed (no output captured)."
    except Exception as exc:
        return False, str(exc)


# ── Data types ────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class GpuStats:
    name: str
    usage_pct: Optional[float]
    temp_c: Optional[float]
    vram_used_mb: Optional[float]
    vram_total_mb: Optional[float]
    source: str = ""     # "nvml" | "ohm" | "wmi"


@dataclass(frozen=True)
class NetworkIO:
    bytes_sent: int
    bytes_recv: int
    send_rate_kbps: Optional[float]
    recv_rate_kbps: Optional[float]
    send_mbps: Optional[float] = None      # same numbers as the Task Manager (megabits / s)
    recv_mbps: Optional[float] = None


@dataclass(frozen=True)
class DashboardSnapshot:
    cpu_pct: float
    cpu_freq_mhz: Optional[float]
    cpu_core_count: int
    cpu_name: str
    ram_pct: float
    ram_used_gb: float
    ram_total_gb: float
    disk_pct: float
    disk_free_gb: float
    disk_total_gb: float
    gpu: Optional[GpuStats]
    net: NetworkIO
    uptime: timedelta
    is_admin: bool
    windows_version: str
    hostname: str
    pending_reboot: bool
    captured_at: datetime = field(default_factory=datetime.now)
    cpu_temp_c: Optional[float] = None
    cpu_temp_src: str = ""
    ram_avail_gb: float = 0.0
    disk_active_pct: float = 0.0           # Task Manager's Disk "active time"
    disk_read_mb_s: float = 0.0
    disk_write_mb_s: float = 0.0


@dataclass(frozen=True)
class SystemHealthScore:
    total: int
    cpu: int
    ram: int
    disk: int
    uptime: int
    label: str


# ── Internal state ────────────────────────────────────────────────────────────

_last_net_io: Optional[object] = None
_last_net_time: Optional[float] = None


# ── CPU ───────────────────────────────────────────────────────────────────────

def _get_cpu_name() -> str:
    global _cpu_name_cache
    if _cpu_name_cache:
        return _cpu_name_cache
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"HARDWARE\DESCRIPTION\System\CentralProcessor\0",
        )
        name, _ = winreg.QueryValueEx(key, "ProcessorNameString")
        winreg.CloseKey(key)
        _cpu_name_cache = name.strip()
    except Exception:
        _cpu_name_cache = platform.processor() or "Unknown CPU"
    return _cpu_name_cache


# ── GPU — three-source approach ───────────────────────────────────────────────

def _gpu_via_nvml() -> Optional[GpuStats]:
    """
    NVIDIA Management Library — works on any NVIDIA GPU (GTX/RTX) without OHM.
    pynvml is bundled with the NVIDIA driver or installable via: pip install pynvml
    """
    if not _NVML_OK or _NVML_HANDLE is None:
        return None
    try:
        import pynvml as _nvml
        name_bytes = _nvml.nvmlDeviceGetName(_NVML_HANDLE)
        name = name_bytes.decode() if isinstance(name_bytes, bytes) else name_bytes

        util  = _nvml.nvmlDeviceGetUtilizationRates(_NVML_HANDLE)
        usage = float(util.gpu)

        try:
            temp = float(_nvml.nvmlDeviceGetTemperature(
                _NVML_HANDLE, _nvml.NVML_TEMPERATURE_GPU
            ))
        except Exception:
            temp = None

        try:
            mem = _nvml.nvmlDeviceGetMemoryInfo(_NVML_HANDLE)
            vram_used  = mem.used  / (1024 * 1024)
            vram_total = mem.total / (1024 * 1024)
        except Exception:
            vram_used = vram_total = None

        return GpuStats(
            name=name, usage_pct=usage, temp_c=temp,
            vram_used_mb=vram_used, vram_total_mb=vram_total,
            source="nvml",
        )
    except Exception:
        return None


def _gpu_via_wmi_name() -> str:
    """Get GPU name from Win32_VideoController — works for any GPU."""
    global _gpu_name_cache
    if _gpu_name_cache:
        return _gpu_name_cache
    if not _WMI_AVAILABLE:
        return "GPU"
    try:
        _pythoncom.CoInitialize()
        c = _wmi.WMI()
        for card in c.Win32_VideoController():
            n = getattr(card, "Name", "") or ""
            if n and "Microsoft" not in n and "Remote" not in n:
                _gpu_name_cache = n
                return n
    except Exception:
        pass
    finally:
        try:
            _pythoncom.CoUninitialize()
        except Exception:
            pass
    _gpu_name_cache = "GPU"
    return "GPU"


def _check_ohm() -> bool:
    global _OHM_CHECKED, _OHM_AVAILABLE
    if _OHM_CHECKED:
        return _OHM_AVAILABLE
    _OHM_CHECKED = True
    if not _WMI_AVAILABLE:
        return False
    try:
        _pythoncom.CoInitialize()
        c = _wmi.WMI(namespace=r"root\OpenHardwareMonitor")
        list(c.Sensor())[:1]
        _OHM_AVAILABLE = True
    except Exception:
        _OHM_AVAILABLE = False
    finally:
        try:
            _pythoncom.CoUninitialize()
        except Exception:
            pass
    return _OHM_AVAILABLE


def _gpu_via_ohm() -> Optional[GpuStats]:
    if not _check_ohm():
        return None
    try:
        _pythoncom.CoInitialize()
        c = _wmi.WMI(namespace=r"root\OpenHardwareMonitor")
        usage = temp = vram_used = vram_total = None
        name = "GPU"
        for s in c.Sensor():
            sn = s.Name.upper()
            st = s.SensorType
            if st == "Load"        and "GPU" in sn and "CORE" in sn: usage      = float(s.Value)
            elif st == "Temperature" and "GPU" in sn:                  temp       = float(s.Value)
            elif st == "SmallData"  and "GPU" in sn:
                if   "USED"  in sn: vram_used  = float(s.Value)
                elif "TOTAL" in sn: vram_total = float(s.Value)
        if usage is None:
            return None
        return GpuStats(name=name, usage_pct=usage, temp_c=temp,
                        vram_used_mb=vram_used, vram_total_mb=vram_total, source="ohm")
    except Exception:
        return None
    finally:
        try:
            _pythoncom.CoUninitialize()
        except Exception:
            pass


def _gpu_via_perfcounters() -> Optional[GpuStats]:
    """
    Windows' native "GPU Engine" performance counters — the same data
    source Task Manager's GPU graph reads from. Works for ANY vendor
    (NVIDIA/AMD/Intel) with zero extra drivers or background apps,
    unlike NVML (NVIDIA-only) and OHM (needs a separate app running).
    Only needs the `wmi` package, which is already used for the GPU name.
    """
    if not _WMI_AVAILABLE:
        return None
    try:
        _pythoncom.CoInitialize()
        c = _wmi.WMI()
        rows = c.Win32_PerfFormattedData_Counters_GPUEngine()

        # Each physical GPU exposes several "engines" (3D, Copy, VideoDecode,
        # etc.) as separate counter instances. Task Manager reports the busiest
        # engine per adapter as "GPU usage" — mirror that instead of summing,
        # which would double-count and can read >100%.
        best_by_adapter: dict[str, float] = {}
        for row in rows:
            name = getattr(row, "Name", "") or ""
            util = getattr(row, "UtilizationPercentage", None)
            if util is None:
                continue
            adapter_key = name.split("engtype_")[0]
            util = float(util)
            if util > best_by_adapter.get(adapter_key, -1.0):
                best_by_adapter[adapter_key] = util

        if not best_by_adapter:
            return None

        usage = max(best_by_adapter.values())
        return GpuStats(
            name=_gpu_via_wmi_name(), usage_pct=usage, temp_c=None,
            vram_used_mb=None, vram_total_mb=None, source="perfcounter",
        )
    except Exception as exc:
        # This used to swallow the exception with a bare `return None`,
        # which made an Intel iGPU (or anything else that hits this path)
        # fail completely silently — there was no way to tell whether it
        # genuinely had no data, threw, or something else. Now it's at
        # least visible in the log for real debugging.
        _log.debug("GPU perf-counter read failed: %s", exc)
        return None
    finally:
        try:
            _pythoncom.CoUninitialize()
        except Exception:
            pass


def _get_gpu_stats() -> Optional[GpuStats]:
    """Same numbers as the Task Manager: utilisation = the shared sampler's busiest GPU engine (any vendor);
    NVML / OHM only add name, temperature and VRAM."""
    from dataclasses import replace as _replace
    stats = _get_gpu_stats_raw()
    try:
        from modules.system.perfsample import system_totals
        st = system_totals()
        if stats is not None:
            kw = {"usage_pct": float(st.get("gpu_pct") or 0.0)}
            if st.get("gpu_vram_mb") and not stats.vram_used_mb:
                kw["vram_used_mb"] = float(st["gpu_vram_mb"])
            if stats.source in ("wmi_name", "ohm"):
                kw["source"] = "perfcounter"
            stats = _replace(stats, **kw)          # GpuStats is frozen - assigning to it used to raise and be swallowed
    except Exception as exc:
        _log.debug("GPU usage override failed: %s", exc)
    return stats


def _get_gpu_stats_raw() -> Optional[GpuStats]:
    """FAST sources only - this runs on every dashboard refresh and must never block.

    1. NVML (NVIDIA)                 - microseconds
    2. the shared PDH sampler        - the SAME numbers Task Manager shows, any vendor, already sampled in the background
    3. registry name / VRAM          - no WMI
    OpenHardwareMonitor is only used if it was already detected.  The old code fell through to WMI queries on every refresh
    (any machine without an NVIDIA GPU): on a weak CPU those take many seconds, the refresh lock stayed held and the
    dashboard never loaded any stats at all."""
    stats = _gpu_via_nvml()
    if stats:
        return stats
    try:
        from modules.system.perfsample import gpu_name, perf, vram_total_mb
        g = perf.gpu()
        name = gpu_name() or _gpu_name_cache or "GPU"
        if g:
            return GpuStats(name=name, usage_pct=float(g.get("total") or 0.0), temp_c=None,
                            vram_used_mb=float(g.get("vram_mb") or 0.0) or None,
                            vram_total_mb=vram_total_mb() or None, source="perfcounter")
        if name and name != "GPU":
            return GpuStats(name=name, usage_pct=None, temp_c=None, vram_used_mb=None,
                            vram_total_mb=vram_total_mb() or None, source="wmi_name")
    except Exception as exc:
        _log.debug("fast GPU read failed: %s", exc)
    if _OHM_CHECKED and _OHM_AVAILABLE:
        stats = _gpu_via_ohm()
        if stats:
            return stats
    return None


# ── Network ───────────────────────────────────────────────────────────────────

def _get_net_io() -> NetworkIO:
    global _last_net_io, _last_net_time
    now = time.monotonic()
    current = psutil.net_io_counters()
    send_rate = recv_rate = None
    if _last_net_io is not None and _last_net_time is not None:
        elapsed = now - _last_net_time
        if elapsed > 0:
            send_rate = (current.bytes_sent - _last_net_io.bytes_sent) / elapsed / 1024
            recv_rate = (current.bytes_recv - _last_net_io.bytes_recv) / elapsed / 1024
    _last_net_io   = current
    _last_net_time = now
    return NetworkIO(current.bytes_sent, current.bytes_recv, send_rate, recv_rate)


def _net_io_shared(st: dict) -> NetworkIO:
    """Totals from psutil, RATES from the shared sampler (Mbps, send / receive) = the Task Manager's network numbers."""
    cur = psutil.net_io_counters()
    sm, rm = st.get("net_send_mbps"), st.get("net_recv_mbps")
    return NetworkIO(cur.bytes_sent, cur.bytes_recv,
                     sm * 1000 / 8 if sm is not None else None, rm * 1000 / 8 if rm is not None else None, sm, rm)


# ── Pending reboot ────────────────────────────────────────────────────────────

def _pending_reboot() -> bool:
    try:
        import winreg
        for hive, path in [
            (winreg.HKEY_LOCAL_MACHINE,
             r"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"),
            (winreg.HKEY_LOCAL_MACHINE,
             r"SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"),
        ]:
            try:
                k = winreg.OpenKey(hive, path); winreg.CloseKey(k); return True
            except Exception:
                pass
    except Exception:
        pass
    return False


# ── Main snapshot ─────────────────────────────────────────────────────────────

def _safe_uptime():
    try:
        return datetime.now() - datetime.fromtimestamp(psutil.boot_time())
    except Exception:
        return timedelta(0)


def get_dashboard_snapshot() -> DashboardSnapshot:
    from app.permissions import is_admin
    cpu_pct = None
    try:
        freq = psutil.cpu_freq()
    except Exception:
        freq = None                                   # some Windows 10 builds / VMs raise here - never let that kill the whole snapshot
    try:                                   # the shared sampler (Task Manager's own number) - psutil's global baseline is disturbed by other callers
        from modules.system.perfsample import perf
        c = perf.cpu()
        if c.get("total") is not None:
            cpu_pct = c["total"]
        elif c.get("per"):
            cpu_pct = round(sum(c["per"]) / len(c["per"]), 1)
        if c.get("freq_mhz"):
            freq = type("F", (), {"current": float(c["freq_mhz"])})()
    except Exception:
        pass
    if cpu_pct is None:
        cpu_pct = psutil.cpu_percent(interval=None)
    mem     = psutil.virtual_memory()
    from modules.system.perfsample import system_totals
    st = system_totals()                                  # SAME numbers as the Task Manager and the Game Booster
    cpu_pct = st["cpu_pct"]
    try:
        disk = psutil.disk_usage(os.environ.get("SystemDrive", "C:") + "\\")
        disk_pct, disk_free, disk_total = disk.percent, disk.free/(1024**3), disk.total/(1024**3)
    except Exception:
        disk_pct = disk_free = disk_total = 0.0

    gpu = _get_gpu_stats()
    t = {}
    try:                                                   # shared background sampler: never blocks this call
        from modules.system.temps import temps
        t = temps.read()
        if gpu is not None and gpu.temp_c is None and t.get("gpu") is not None:
            from dataclasses import replace as _replace
            gpu = _replace(gpu, temp_c=t["gpu"])
    except Exception:
        pass

    return DashboardSnapshot(
        cpu_temp_c=t.get("cpu"), cpu_temp_src=t.get("cpu_src") or "",
        cpu_pct=cpu_pct,
        cpu_freq_mhz=freq.current if freq else None,
        cpu_core_count=psutil.cpu_count(logical=True) or 0,
        cpu_name=_get_cpu_name(),
        ram_pct=st["mem_pct"] if st.get("mem_pct") is not None else mem.percent,
        ram_used_gb=st.get("mem_used_gb", round(mem.used / 1e9, 2)),
        ram_total_gb=st.get("mem_total_gb", round(mem.total / 1e9, 2)),
        ram_avail_gb=st.get("mem_avail_gb", round(mem.available / 1e9, 2)),
        disk_active_pct=st.get("disk_active_pct", 0.0),
        disk_read_mb_s=st.get("disk_read_mb_s", 0.0),
        disk_write_mb_s=st.get("disk_write_mb_s", 0.0),
        disk_pct=disk_pct,
        disk_free_gb=disk_free,
        disk_total_gb=disk_total,
        gpu=gpu,
        net=_net_io_shared(st),
        uptime=_safe_uptime(),
        is_admin=is_admin(),
        windows_version=platform.version(),
        hostname=socket.gethostname(),
        pending_reboot=_pending_reboot(),
    )


def compute_health_score(snap: DashboardSnapshot) -> SystemHealthScore:
    cpu_s  = int(max(0, (100 - snap.cpu_pct)  / 100 * 30))
    ram_s  = int(max(0, (100 - snap.ram_pct)  / 100 * 30))
    disk_s = int(min(25, (snap.disk_free_gb / max(snap.disk_total_gb, 1)) * 100 / 2)) if snap.disk_total_gb else 0
    days   = snap.uptime.days
    up_s   = 15 if days < 7 else 12 if days < 14 else 8 if days < 30 else 4 if days < 60 else 0
    total  = min(100, cpu_s + ram_s + disk_s + up_s)
    if snap.pending_reboot:
        total = max(0, total - 10)
    label = "Excellent" if total >= 85 else "Good" if total >= 70 else "Fair" if total >= 50 else "Poor"
    return SystemHealthScore(total=total, cpu=cpu_s, ram=ram_s, disk=disk_s, uptime=up_s, label=label)
