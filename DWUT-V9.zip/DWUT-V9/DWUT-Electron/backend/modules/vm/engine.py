"""
modules/vm/engine.py — build a ready-to-install virtual machine.

VirtualBox (recommended) is fully automatic: download + silent install, create the VM with the chosen specs, and for ISOs VirtualBox
can install unattended (Windows 10/11, Ubuntu, Debian, Fedora, ...) the OS installs itself.  VMware Workstation cannot be downloaded
without a Broadcom login, so for it DWUT downloads the ISO and gives an exact click-by-click guide with the chosen specs.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Callable, Optional

import psutil

from core.logger import get_logger
from modules.usb import catalog
from modules.usb import engine as ue
from modules.usb.engine import CACHE, Cancelled, FlashError, ps, run, run_logged

_log = get_logger(__name__)
VM_TOOLS = CACHE.parent / "vm"

# id -> (VirtualBox ostype, cpus, ram_gb, disk_gb, vram_mb, efi, tpm)
VBOX = {
    "win11": ("Windows11_64", 4, 8, 80, 128, True, True), "win10": ("Windows10_64", 2, 4, 60, 128, False, False),
    "ubuntu": ("Ubuntu_64", 2, 4, 40, 128, False, False), "mint": ("Ubuntu_64", 2, 4, 40, 128, False, False), "mint_xfce": ("Ubuntu_64", 2, 4, 40, 128, False, False),
    "fedora": ("Fedora_64", 2, 4, 40, 128, False, False), "debian": ("Debian_64", 2, 4, 40, 128, False, False),
    "arch": ("ArchLinux_64", 2, 4, 30, 64, False, False), "opensuse": ("openSUSE_64", 2, 4, 40, 128, False, False), "alpine": ("Linux26_64", 1, 1, 10, 16, False, False),
    "kali": ("Debian_64", 2, 4, 50, 128, False, False), "kali_purple": ("Debian_64", 2, 4, 60, 128, False, False),
    "parrot_sec": ("Debian_64", 2, 4, 50, 128, False, False), "parrot_home": ("Debian_64", 2, 4, 40, 128, False, False),
    "blackarch": ("ArchLinux_64", 2, 4, 60, 64, False, False), "qubes": ("Linux26_64", 4, 16, 100, 64, False, False),
    "tails": ("Debian_64", 2, 4, 8, 64, False, False), "templeos": ("Other_64", 1, 1, 4, 16, False, False), "hbcd": ("Windows10_64", 2, 4, 20, 64, False, False),
}
_FEDORA = ("Fedora_64", 4, 8, 60, 128, False, False)         # gaming spins want a bit more RAM / disk
_UBU = ("Ubuntu_64", 2, 4, 40, 128, False, False)
_DEB = ("Debian_64", 2, 4, 40, 128, False, False)
_ARCH = ("ArchLinux_64", 2, 4, 40, 128, False, False)
_RHEL = ("RedHat_64", 2, 4, 30, 64, False, False)
VBOX.update({
    "bazzite": _FEDORA, "bazzite_nvidia": _FEDORA, "bazzite_deck": _FEDORA, "bazzite_gnome": _FEDORA, "nobara": _FEDORA,
    "cachyos": _ARCH, "garuda_gaming": _ARCH, "endeavouros": _ARCH, "manjaro_kde": _ARCH,
    "kubuntu": _UBU, "xubuntu": _UBU, "lubuntu": ("Ubuntu_64", 2, 3, 30, 64, False, False), "ubuntu_mate": _UBU,
    "ubuntu_server": ("Ubuntu_64", 2, 4, 30, 16, False, False), "debian_netinst": _DEB,
    "nixos": ("Linux26_64", 2, 4, 40, 128, False, False), "void": ("Linux26_64", 2, 2, 20, 64, False, False),
    "gentoo": ("Gentoo_64", 2, 4, 60, 64, False, False),
    "rocky": _RHEL, "alma": _RHEL, "centos_stream": _RHEL, "proxmox": ("Debian_64", 4, 8, 60, 16, False, False),
    "freebsd": ("FreeBSD_64", 2, 4, 30, 64, False, False), "rescuezilla": ("Ubuntu_64", 2, 2, 8, 64, False, False),
})
OSTYPE_CHOICES = {"Windows 11": "Windows11_64", "Windows 10": "Windows10_64", "Linux (64-bit)": "Linux26_64", "Other (64-bit)": "Other_64"}


def host_info() -> dict:
    code, out = ps("$p=Get-CimInstance Win32_Processor | Select-Object -First 1; $c=Get-CimInstance Win32_ComputerSystem; "
                   "ConvertTo-Json -Compress @{virt=[bool]$p.VirtualizationFirmwareEnabled; hyperv=[bool]$c.HypervisorPresent}", 30)
    d = {}
    try:
        d = json.loads(out.strip().splitlines()[-1])
    except Exception:
        pass
    hyperv = bool(d.get("hyperv", False))
    # When Hyper-V / WSL2 / Memory Integrity owns the CPU, Windows reports VirtualizationFirmwareEnabled = False even though virtualisation
    # IS on in the BIOS.  Only warn when the hypervisor is NOT present and the firmware flag is off.
    virt = bool(d.get("virt", True)) or hyperv
    return {"cores": psutil.cpu_count(logical=True) or 2, "ram_gb": round(psutil.virtual_memory().total / 1024 ** 3, 1),
            "virt_enabled": virt, "hyperv": hyperv}


def list_drives() -> list[dict]:
    code, out = ps("$v=@(Get-Volume | Where-Object { $_.DriveType -eq 'Fixed' -and $_.DriveLetter -and $_.Size -gt 0 } | ForEach-Object { "
                   "[pscustomobject]@{letter=\"$($_.DriveLetter)\"; label=$_.FileSystemLabel; fs=$_.FileSystem; size=[int64]$_.Size; free=[int64]$_.SizeRemaining} }); "
                   "ConvertTo-Json -InputObject @($v) -Compress", 40)
    try:
        d = json.loads(out.strip().splitlines()[-1])
        return d if isinstance(d, list) else [d]
    except Exception:
        return []


def defaults(os_id: str) -> dict:
    t = VBOX.get(os_id, ("Other_64", 2, 4, 30, 64, False, False))
    h = host_info()
    cpus = min(t[1], max(1, h["cores"] // 2 or 1))
    ram = min(t[2], max(1, int(h["ram_gb"] // 2)))
    return {"ostype": t[0], "cpus": cpus, "ram_gb": ram, "disk_gb": t[3], "vram_mb": t[4], "efi": t[5], "tpm": t[6], "host": h}


# ── VirtualBox ────────────────────────────────────────────────────────────────

def vbox_exe() -> Optional[Path]:
    for root in (os.environ.get("ProgramFiles", r"C:\Program Files"), os.environ.get("ProgramW6432", r"C:\Program Files")):
        p = Path(root) / "Oracle" / "VirtualBox" / "VBoxManage.exe"
        if p.exists():
            return p
    return None


def ensure_virtualbox(log, on_dl, cancel: threading.Event) -> Path:
    exe = vbox_exe()
    if exe:
        code, out = run_logged([str(exe), "--version"], log, 30, cancel=cancel)
        log(f"VirtualBox is already installed (version {out.strip().splitlines()[-1] if out.strip() else '?'}).")
        return exe
    log("VirtualBox is not installed - looking up the latest stable version…")
    ver = ue.http_text("https://download.virtualbox.org/virtualbox/LATEST-STABLE.TXT", 30).strip().splitlines()[0].strip()
    log(f"Latest stable VirtualBox: {ver}")
    base = f"https://download.virtualbox.org/virtualbox/{ver}/"
    names = [n for n in ue.list_dir(base) if re.fullmatch(rf"VirtualBox-{re.escape(ver)}-\d+-Win\.exe", n)]
    if not names:
        raise FlashError(f"VirtualBox {ver} installer not found on download.virtualbox.org")
    name = names[0]
    VM_TOOLS.mkdir(parents=True, exist_ok=True)
    dest = VM_TOOLS / name
    sha = None
    try:
        sha = ue.parse_checksum(ue.http_text(base + "SHA256SUMS", 30), name)
    except FlashError:
        log("  (no checksum file published - relying on the digital signature check)")
    if dest.exists() and dest.stat().st_size > 50_000_000:
        log(f"Installer already downloaded: {dest}")
    else:
        log(f"Downloading VirtualBox {ver}…")
        ue.download([base + name], dest, on_dl, cancel, log)
    if sha:
        log("Checking SHA-256…")
        if ue.sha256_file(dest, lambda f: None, cancel) != sha:
            dest.unlink(missing_ok=True)
            raise FlashError("VirtualBox download failed its checksum - it was deleted, please try again.")
        log("  checksum OK")
    code, out = ps(f"$s=Get-AuthenticodeSignature -LiteralPath '{dest}'; \"SIG|$($s.Status)|$($s.SignerCertificate.Subject)\"", 60, log,
                   cancel, label="PowerShell: check the installer's digital signature")
    sig = next((l for l in out.splitlines() if l.strip().startswith("SIG|")), "")
    if not (sig.startswith("SIG|Valid") and "oracle" in sig.lower()):
        dest.unlink(missing_ok=True)
        raise FlashError(f"VirtualBox installer signature check failed ({sig or 'no result'}). The file was deleted.")
    log("  signature is valid and signed by Oracle.")
    log("Installing VirtualBox silently (about a minute; your network connection may blink once)…")
    code, out = run_logged([str(dest), "--silent", "--ignore-reboot"], log, 1200, cancel=cancel)
    exe = vbox_exe()
    if not exe:
        raise FlashError(f"VirtualBox installation failed (code {code}). Try running the installer manually: {dest}")
    log("VirtualBox installed.")
    return exe


def _vb(exe: Path, args: list[str], timeout: int = 600, strict: bool = True, log=None, cancel=None, mask: tuple = ()) -> str:
    if log:
        code, out = run_logged([str(exe), *args], log, timeout, cancel=cancel, mask=mask,
                               label="VBoxManage " + " ".join(('"%s"' % a if " " in a else a) for a in args))
    else:
        code, out = run([str(exe), *args], timeout)
    if code != 0 and strict:
        raise FlashError(f"VBoxManage {' '.join(args[:2])} failed (exit {code}): {out.strip()[-300:]}{_hint(out)}")
    return out


def _hint(out: str) -> str:
    """Plain-English next step for the VirtualBox errors that cover 90% of 'the VM won't start' reports."""
    o = out or ""
    if re.search(r"VERR_VMX_NO_VMX|VERR_SVM_NO_SVM|VT-x is not available|AMD-V is not available|VERR_VMX_MSR_VMX_DISABLED", o):
        return "\n-> Hardware virtualisation (Intel VT-x / AMD-V / SVM) is off. Turn it on in your BIOS/UEFI settings, then try again."
    if re.search(r"VERR_NEM_|WHV|Hyper-V|VERR_VMX_IN_VMX_ROOT_MODE|VERR_SVM_IN_USE", o):
        return ("\n-> Windows' own hypervisor (Hyper-V / WSL2 / Memory Integrity / Windows Sandbox) is using the CPU. "
                "Turn those off (Settings > Windows Security > Device security > Core isolation, and 'Turn Windows features on or off'), reboot, and try again.")
    if re.search(r"E_ACCESSDENIED|NS_ERROR_|Failed to (acquire|create) the VirtualBox COM object|RPC_E_", o):
        return "\n-> VirtualBox's background service is not reachable. Close any open VirtualBox windows, wait 10 seconds, and try again."
    if re.search(r"VERR_DISK_FULL|There is not enough space|ERROR_DISK_FULL", o):
        return "\n-> The drive for the virtual disk is full. Pick another drive or a smaller disk size."
    return ""


def _unique_name(exe: Path, name: str) -> str:
    out = _vb(exe, ["list", "vms"], 60, strict=False)
    taken = set(re.findall(r'^"(.*?)"', out, re.M))
    n, cand = 1, name
    while cand in taken:
        n += 1
        cand = f"{name} ({n})"
    return cand


def _sanitize_spec(spec: dict, log) -> dict:
    """Clamp the chosen hardware to what this PC can really give (a VM asking for more RAM than the host has never starts)."""
    out = dict(spec)
    try:
        host_ram = psutil.virtual_memory().total / 1024 ** 3
        host_cpu = psutil.cpu_count(logical=True) or 2
    except Exception:
        host_ram, host_cpu = 16.0, 4
    ram = float(out.get("ram_gb") or 2)
    cap = max(1.0, round(host_ram * 0.75, 1))
    if ram > cap:
        log(f"  ! {ram:g} GB RAM is more than this PC can spare ({host_ram:.1f} GB installed) - using {cap:g} GB instead.")
        ram = cap
    out["ram_gb"] = max(0.5, ram)
    cpus = int(out.get("cpus") or 1)
    if cpus > host_cpu:
        log(f"  ! {cpus} CPU cores requested but this PC has {host_cpu} - using {host_cpu}.")
        cpus = host_cpu
    out["cpus"] = max(1, cpus)
    out["disk_gb"] = max(2, int(out.get("disk_gb") or 20))
    out["vram_mb"] = min(256, max(4, int(out.get("vram_mb") or 64)))
    if "windows" not in str(out.get("ostype", "")).lower():            # VMSVGA (Linux guests) accepts at most 128 MB
        out["vram_mb"] = min(128, out["vram_mb"])
    return out


def _ostype_ok(exe: Path, ostype: str, log) -> str:
    """Older VirtualBox builds do not know newer OS types (Windows11_64 appeared in 6.1.x); fall back to a generic one."""
    out = _vb(exe, ["list", "ostypes"], 60, strict=False)
    known = set(re.findall(r"^ID:\s+(\S+)", out, re.M))
    if not known or ostype in known:
        return ostype
    fb = "Windows10_64" if ostype.startswith("Windows") else ("Linux26_64" if ostype.endswith("_64") and "Other" not in ostype else "Other_64")
    fb = fb if fb in known else ("Other_64" if "Other_64" in known else ostype)
    log(f"  ! this VirtualBox does not know OS type '{ostype}' - using '{fb}' (update VirtualBox for the exact type).")
    return fb


def build_vbox(exe: Path, spec: dict, iso: Path, drive: str, log, cancel: Optional[threading.Event] = None) -> dict:
    pw = str(spec.get("password") or "changeme")
    spec = _sanitize_spec(spec, log)

    def vb(args, timeout=600, strict=True):
        return _vb(exe, args, timeout, strict, log, cancel, (pw,))

    root = f"{drive}:\\"
    try:
        free = shutil.disk_usage(root).free
        if free < 6 * 1024 ** 3:
            raise FlashError(f"Drive {drive}: has only {free / 1e9:.1f} GB free - a VM needs at least 6 GB. Pick another drive.")
        if free < spec["disk_gb"] * 1024 ** 3:
            log(f"  Note: {drive}: has {free / 1e9:.0f} GB free, less than the {spec['disk_gb']} GB virtual disk - it grows on demand, so the VM works until the drive fills up.")
    except FileNotFoundError:
        raise FlashError(f"Drive {drive}: is not available.")
    except OSError:
        pass
    name = _unique_name(exe, re.sub(r'[\\/:*?"<>|]', "", spec["name"]).strip() or "DWUT VM")
    base = Path(f"{drive}:\\DWUT-VMs")
    base.mkdir(parents=True, exist_ok=True)
    ostype = _ostype_ok(exe, spec["ostype"], log)
    unattended = False
    if spec.get("unattended"):
        out = vb(["unattended", "detect", f"--iso={iso}", "--machine-readable"], 120, strict=False)
        unattended = re.search(r'UnattendedInstallationSupported="?true', out, re.I) is not None
        log("Unattended install " + ("supported by this ISO - the OS will install itself." if unattended else "not supported by this ISO - you will run its installer."))
    log(f"Creating VM '{name}' on {drive}: (files go to {base})…")
    created = False
    try:
        vb(["createvm", "--name", name, "--ostype", ostype, "--register", "--basefolder", str(base)])
        created = True
        mod = ["modifyvm", name, "--memory", str(int(spec["ram_gb"] * 1024)), "--cpus", str(spec["cpus"]), "--vram", str(spec["vram_mb"]),
               "--graphicscontroller", "vboxsvga" if "Windows" in ostype else "vmsvga", "--nic1", "nat", "--boot1", "dvd", "--boot2", "disk", "--boot3", "none", "--ioapic", "on"]
        if spec.get("efi"):
            mod += ["--firmware", "efi"]
        vb(mod)
        if spec.get("tpm"):
            vb(["modifyvm", name, "--tpm-type", "2.0"], 60, strict=False)
        if spec.get("accel3d"):
            vb(["modifyvm", name, "--accelerate-3d", "on"], 60, strict=False)
        for opt in (["--audio-enabled", "on", "--audio-driver", "default", "--audio-controller", "hda"], ["--clipboard-mode", "bidirectional"], ["--drag-and-drop", "bidirectional"]):
            vb(["modifyvm", name, *opt], 60, strict=False)          # optional niceties: older VirtualBox may not know them
        vdi = base / name / f"{name}.vdi"
        vb(["createmedium", "disk", "--filename", str(vdi), "--size", str(int(spec["disk_gb"] * 1024)), "--format", "VDI"], 900)
        vb(["storagectl", name, "--name", "SATA", "--add", "sata", "--controller", "IntelAhci", "--portcount", "2"])
        vb(["storageattach", name, "--storagectl", "SATA", "--port", "0", "--device", "0", "--type", "hdd", "--medium", str(vdi)])
        vb(["storageattach", name, "--storagectl", "SATA", "--port", "1", "--device", "0", "--type", "dvddrive", "--medium", "emptydrive" if unattended else str(iso)])
        started = False
        if unattended:
            user = re.sub(r"[^A-Za-z0-9_.-]", "", spec.get("user") or "user") or "user"
            adds = exe.parent / "VBoxGuestAdditions.iso"
            ua = ["unattended", "install", name, f"--iso={iso}", f"--user={user}", f"--password={pw}",
                  f"--full-user-name={user}", "--locale=en_US", "--start-vm=gui"]
            if adds.exists():
                ua.insert(-2, "--install-additions")
                ua.insert(-2, f"--additions-iso={adds}")
            else:
                log("  (VirtualBox's Guest Additions disc was not found - the OS installs itself, you add the Additions later from the VM's Devices menu.)")
            try:
                vb(ua, 300)
                started = True
            except FlashError as exc:
                # An unattended install that VirtualBox refuses must not throw the whole VM away: fall back to a normal manual install.
                log(f"  ! VirtualBox could not set up the unattended install ({str(exc)[:200]})")
                log("  Falling back to a normal install: the ISO is inserted and you click through the installer yourself.")
                unattended = False
                vb(["storageattach", name, "--storagectl", "SATA", "--port", "1", "--device", "0", "--type", "dvddrive", "--medium", str(iso)])
        if not started:
            vb(["startvm", name, "--type", "gui"], 120)
    except BaseException:
        if created:                                                  # never leave a half-built VM registered (the next try would become "name (2)")
            log(f"Build failed - removing the unfinished VM '{name}' so nothing is left behind…")
            try:
                _vb(exe, ["unregistervm", name, "--delete"], 180, strict=False, log=log)
            except Exception:
                pass
            shutil.rmtree(base / name, ignore_errors=True)
        raise
    log("VM created" + (" and the unattended install has started - the OS installs itself (this takes a while)." if unattended else " and started - follow the OS installer in the VM window."))
    return {"name": name, "unattended": unattended, "folder": str(base / name), "user": spec.get("user"), "password": spec.get("password")}


# ── guides ────────────────────────────────────────────────────────────────────

def specs_lines(spec: dict, drive: str) -> list[str]:
    return [f"Name: {spec['name']}", f"CPU cores: {spec['cpus']}", f"Memory: {spec['ram_gb']} GB ({int(spec['ram_gb'] * 1024)} MB)", f"Disk: {spec['disk_gb']} GB (stored on {drive}:)",
            f"Video memory: {spec['vram_mb']} MB", f"Firmware: {'UEFI (EFI)' if spec.get('efi') else 'BIOS'}", f"TPM 2.0: {'yes' if spec.get('tpm') else 'no'}"]


def guide_virtualbox(res: dict, spec: dict) -> dict:
    if res["unattended"]:
        steps = [f"The VM '{res['name']}' is running and is installing the operating system BY ITSELF - you do not need to click through setup.",
                 "Leave the VM window open. The install takes roughly 15-40 minutes and the VM restarts a few times.",
                 f"When it reaches the desktop, sign in with  user: {res['user'] or 'user'}  /  password: {res['password'] or 'changeme'}  (change this password afterwards).",
                 "Guest Additions (better resolution, shared clipboard, drag-and-drop) are installed automatically.",
                 "Tip: to leave the VM, press the Right Ctrl key. Close the window and choose 'Save the machine state' to pause it."]
    else:
        steps = [f"The VM '{res['name']}' was created and started, with the ISO already inserted - this ISO cannot be installed unattended, so run its installer yourself.",
                 "Click inside the VM window and press Enter (or pick 'Install') at the boot menu. If the screen stays black for a minute, give it a moment.",
                 "When the installer asks where to install, choose the virtual disk (it is empty and shows the size you chose).",
                 "After the install finishes the VM restarts - if it boots the installer again, use the VM's Devices > Optical Drives > 'Remove disk from virtual drive'.",
                 "Then in the VM menu choose Devices > Insert Guest Additions CD image and run it for proper resolution and shared clipboard.",
                 "Tip: press the Right Ctrl key to release your mouse from the VM."]
    return {"title": "Your virtual machine", "steps": steps, "specs": specs_lines(spec, "?"), "software": "VirtualBox", "folder": res["folder"]}


def guide_vmware(iso: Path, spec: dict, drive: str, os_name: str) -> dict:
    steps = ["VMware Workstation Pro is free for personal use now, but Broadcom only offers it after you create a free account, so DWUT cannot download it for you. Click 'Open VMware download page' below, sign in/register, and install it (accept the defaults).",
             f"Your operating system image is already downloaded: {iso}",
             "Open VMware Workstation and choose File > New Virtual Machine… > Typical > Next.",
             f"Choose 'Installer disc image file (iso)' and browse to the file above. Next.",
             f"Pick the guest OS ({os_name}); Name: {spec['name']}; Location: {drive}:\\DWUT-VMs\\{spec['name']}",
             f"Maximum disk size: {spec['disk_gb']} GB. Choose 'Store virtual disk as a single file'. Next.",
             f"Click 'Customize Hardware…' and set Memory = {int(spec['ram_gb'] * 1024)} MB and Processors = {spec['cpus']} cores. Close, then Finish."]
    if spec.get("efi"):
        steps.append("This OS needs UEFI: select the VM > VM > Settings > Options > Advanced > Firmware type: UEFI (tick 'Enable secure boot' for Windows 11).")
    if spec.get("tpm"):
        steps.append("Windows 11 also needs a TPM: VM > Settings > Options > Access Control > Encrypt (set a password) > then Hardware > Add > Trusted Platform Module.")
    steps += ["Power on the VM and follow the OS installer.", "After installing, choose VM > Install VMware Tools for better resolution and shared clipboard."]
    return {"title": "Set up your VMware VM", "steps": steps, "specs": specs_lines(spec, drive), "software": "VMware", "folder": str(iso.parent),
            "url": "https://www.vmware.com/products/desktop-hypervisor/workstation-and-fusion"}
