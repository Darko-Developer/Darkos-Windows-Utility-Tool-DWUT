"""api/visualfx_api.py - DWUT's Performance Options (Visual Effects) dialog: read and apply the same settings Windows does."""
from __future__ import annotations

from core.logger import get_logger
from server import rpc

_log = get_logger("api.visualfx")


@rpc("visualfx.get")
def visualfx_get():
    """Live state: {"mode": "windows"|"appearance"|"performance"|"dwut"|"custom"|None, "fx": {key: bool}, "effects": [[key, label], ...]}"""
    from modules.system import visual_effects as vfx
    st = vfx.read_state()
    fx = {k: bool(v) if v is not None else True for k, v in st["fx"].items()}
    raw = st["mode"]
    mode = {0: "windows", 1: "appearance", 2: "performance"}.get(raw)
    if raw == 3 or mode is None:
        # Windows only knows "custom" - but if the boxes match DWUT's recommended set exactly, show that radio button
        mode = "dwut" if fx == vfx.preset("dwut") else "custom"
    return {"mode": mode, "fx": fx, "effects": [list(e) for e in vfx.EFFECTS]}


@rpc("visualfx.apply")
def visualfx_apply(mode: str, fx: dict):
    from modules.system import visual_effects as vfx
    try:
        return vfx.apply(str(mode), dict(fx or {}))
    except Exception as exc:                                                    # never let the dialog hang on a backend error
        _log.exception("visual effects apply failed")
        return {"ok": False, "applied": 0, "failed": [], "message": f"Unexpected error: {exc}"}
