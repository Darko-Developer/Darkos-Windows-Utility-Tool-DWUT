"""api/system_api.py — generic module-call bridge + Optimizer/Tools data."""
from __future__ import annotations

import importlib
import re

from core.events import Events, bus
from core.logger import get_logger
from core.worker import worker
from server import rpc

_log = get_logger("api.system")


def _resolve(module: str, fn: str):
    if not module.startswith("modules."):
        raise PermissionError(f"module not allowed: {module}")
    if fn.startswith("_") and not module.endswith("popups"):
        raise PermissionError(f"function not allowed: {fn}")
    return getattr(importlib.import_module(module), fn)


@rpc("call")
def call(module: str, fn: str, args: list | None = None, kwargs: dict | None = None, bg: bool = False):
    """Call any modules.* function with the ORIGINAL signature.
    bg=True mirrors `worker.submit(fn, ...)`: return immediately, results arrive via events."""
    func = _resolve(module, fn)
    args, kwargs = args or [], kwargs or {}
    if bg:
        worker.submit(func, *args, on_error=lambda e: (_log.error("%s failed: %s", fn, e),
                      bus.publish(Events.APP_ERROR, f"{fn} failed: {e}")), **kwargs)
        return True
    return func(*args, **kwargs)


@rpc("system.os_info")
def system_os_info():
    """Detailed OS facts (family, edition, version, build, arch, feature availability) for the UI."""
    from modules.system.platform_info import get_os_info
    return get_os_info()


@rpc("optimizer.static")
def optimizer_static():
    from modules.debloat.operations import FEATURES, feature_applies
    from modules.system.platform_info import get_os_info, is_windows_11
    from modules.system.windows_features import WINDOWS_FEATURES
    from modules.system.winutil import get_available_tools, get_dns_presets
    return {
        "features": [dict(key=f.key, name=f.name, desc=f.desc, recommended=f.recommended, severity=f.severity,
                          category=f.category, windows11_only=f.windows11_only, windows10_only=f.windows10_only)
                     for f in FEATURES if feature_applies(f)],
        # Hyper-V and Windows Sandbox exist only on Pro / Enterprise / Education - never offer them on Home.
        "win_features": [dict(key=w.key, name=w.name, desc=w.desc) for w in WINDOWS_FEATURES
                         if not (get_os_info()["is_home"] and w.key in ("hyperv", "sandbox"))],
        "dns_presets": get_dns_presets(),
        "tools": get_available_tools(),
        "is_win11": is_windows_11(),
    }


@rpc("optimizer.power_state")
def power_state():
    from modules.system.power_modes import is_extreme_performance_active, is_ultimate_performance_active
    return [is_ultimate_performance_active(), is_extreme_performance_active()]


@rpc("optimizer.apply_features")
def apply_features_bg(keys: list):
    from modules.debloat.operations import apply_features
    worker.submit(apply_features, keys, on_error=lambda e: bus.publish(Events.APP_ERROR, f"Tweak apply failed: {e}"))
    return True


@rpc("optimizer.install_win_features")
def install_win_features(keys: list):
    from modules.system.windows_features import enable_features_batch
    worker.submit(enable_features_batch, keys, on_error=lambda e: bus.publish(Events.APP_ERROR, f"Feature install failed: {e}"))
    return True


# ═════════════════════════════ Tools page ════════════════════════════════════
_reg_issues: list = []
_startup: list = []


@rpc("tools.reg_scan")
def reg_scan():
    from modules.system.registry_cleaner import scan_registry
    global _reg_issues
    r = scan_registry()
    _reg_issues = list(r.issues)
    return {
        "issues": [dict(i=n, description=x.description, detail=x.detail, priority=x.priority) for n, x in enumerate(r.issues)],
        "duration": r.scan_duration_s, "high": r.high_count, "medium": r.medium_count, "low": r.low_count,
    }


@rpc("tools.reg_backup")
def reg_backup():
    from modules.system.registry_cleaner import export_registry_backup
    return export_registry_backup() or "Backup failed"


@rpc("tools.reg_clean")
def reg_clean(indices: list):
    from modules.system.registry_cleaner import clean_issues
    sel = [_reg_issues[i] for i in indices if 0 <= i < len(_reg_issues)]
    r = clean_issues(sel, create_backup=True)
    return {"deleted": r.deleted, "failed": r.failed, "backup_path": r.backup_path, "duration_s": r.duration_s}


@rpc("tools.startup_list")
def startup_list():
    from modules.system.startup import get_startup_entries
    global _startup
    _startup = list(get_startup_entries())
    return [dict(i=n, name=e.name, location=e.location, command=e.command, enabled=e.enabled, impact=e.impact_from_path())
            for n, e in enumerate(_startup)]


@rpc("tools.startup_set")
def startup_set(indices: list, enable: bool):
    from modules.system.startup import disable_startup_entry, enable_startup_entry
    fn = enable_startup_entry if enable else disable_startup_entry
    return sum(1 for i in indices if 0 <= i < len(_startup) and fn(_startup[i]))


@rpc("tools.startup_open")
def startup_open(index: int):
    from modules.system.startup import open_file_location
    if 0 <= index < len(_startup):
        worker.submit(open_file_location, _startup[index])
    return True


def _cat(c):
    return dict(key=c.key, name=c.name, description=c.description, aggressive=c.aggressive, estimated_mb=c.estimated_mb)


@rpc("tools.disk_categories")
def disk_categories():
    from modules.system.disk_cleanup import _make_categories
    return [_cat(c) for c in _make_categories()]


@rpc("tools.disk_scan")
def disk_scan():
    from modules.system.disk_cleanup import scan_disk_categories
    r = scan_disk_categories()
    return {"categories": [_cat(c) for c in r.categories], "total_bytes": r.total_bytes}


@rpc("tools.disk_clean")
def disk_clean(keys: list):
    from modules.system.disk_cleanup import clean_categories
    r = clean_categories(keys)
    return {"mb_freed": r.total_bytes_freed / (1024 * 1024), "files_deleted": r.files_deleted, "errors": r.errors}


@rpc("tools.drives")
def drives():
    import os
    import string
    from modules.system.disk_cleanup import get_drive_info
    return [get_drive_info(f"{d}:\\") for d in string.ascii_uppercase if os.path.exists(f"{d}:\\")]


# ═════════════ winget: apps whose installed version can't be determined ═════════════
def _parse_winget_table(text: str) -> list:
    """Rows of `winget upgrade` as dicts, using the header's column positions."""
    lines = [l.rstrip() for l in text.replace("\r", "").split("\n")]
    hdr = next((i for i, l in enumerate(lines) if "Name" in l and "Id" in l and "Version" in l), None)
    if hdr is None:
        return []
    h = lines[hdr]
    cols = [("name", h.index("Name")), ("id", h.index("Id")), ("version", h.index("Version"))]
    cols.append(("available", h.index("Available")) if "Available" in h else ("available", len(h)))
    if "Source" in h:
        cols.append(("source", h.index("Source")))
    rows = []
    for l in lines[hdr + 2:]:
        if not l.strip() or l.startswith(("---", " ")) and not l[:1].isalnum():
            continue
        if re.match(r"^\d+ (upgrade|package)", l.strip()):
            break
        r = {}
        for i, (k, st) in enumerate(cols):
            en = cols[i + 1][1] if i + 1 < len(cols) else len(l)
            r[k] = l[st:en].strip()
        r.setdefault("source", "")
        if r["id"]:
            rows.append(r)
    return rows


@rpc("tools.open")
def tools_open(name: str):
    from modules.system.winutil import launch_tool_ex
    return launch_tool_ex(str(name))


@rpc("updates.winget_scan")
def winget_scan():
    """Find out what winget can update and which apps it can't read a version for."""
    from modules.system.winutil import _find_winget
    import subprocess
    w = _find_winget()
    def run_(args):
        r = subprocess.run([w, *args], capture_output=True, text=True, timeout=300, errors="replace",
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), stdin=subprocess.DEVNULL)
        return r.stdout + r.stderr
    normal = run_(["upgrade", "--accept-source-agreements"])
    m = re.search(r"(\d+) package\(s\) have version numbers that cannot be determined", normal)
    n_unknown = int(m.group(1)) if m else 0
    unknown = []
    if n_unknown:
        full = run_(["upgrade", "--include-unknown", "--accept-source-agreements"])
        unknown = [r for r in _parse_winget_table(full) if r["version"].lower().startswith("unknown")]
    return {"unknown_count": n_unknown, "unknown": unknown, "known": _parse_winget_table(normal)}


# ═════════════════════════ Quick Optimize (tray menu) ════════════════════════

@rpc("system.quick_optimize")
def quick_optimize():
    """One-click optimise: temp cleanup, disk cleanup, Windows Update cache clear,
    DNS flush, Winsock reset, and network-stack reset.  Returns a summary dict."""
    import subprocess
    import shutil
    import os
    import tempfile
    import threading
    from pathlib import Path

    _NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    results: list[str] = []
    errors: list[str] = []

    def _run(cmd, timeout=60):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                               creationflags=_NO_WINDOW, stdin=subprocess.DEVNULL)
            return r.returncode == 0
        except Exception:
            return False

    # 1. Flush DNS cache
    if _run(["ipconfig", "/flushdns"]):
        results.append("DNS cache flushed")
    else:
        errors.append("DNS flush failed (non-fatal)")

    # 2. Winsock reset
    if _run(["netsh", "winsock", "reset"]):
        results.append("Winsock reset queued")
    else:
        errors.append("Winsock reset failed")

    # 3. TCP/IP (network stack) reset
    if _run(["netsh", "int", "ip", "reset"]):
        results.append("Network stack (TCP/IP) reset queued")
    else:
        errors.append("Network stack reset failed")

    # 4. Clear Windows Update cache
    wu_path = Path(r"C:\Windows\SoftwareDistribution\Download")
    try:
        _run(["net", "stop", "wuauserv"], 20)
        cleared = 0
        for item in wu_path.iterdir() if wu_path.exists() else []:
            try:
                if item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                else:
                    item.unlink(missing_ok=True)
                cleared += 1
            except Exception:
                pass
        _run(["net", "start", "wuauserv"], 20)
        results.append(f"Windows Update cache cleared ({cleared} items)")
    except Exception as e:
        errors.append(f"Windows Update cache: {e}")

    # 5. Clean temp files (user + system)
    temp_dirs = [
        Path(tempfile.gettempdir()),
        Path(os.environ.get("SystemRoot", r"C:\Windows")) / "Temp",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Temp",
    ]
    total_freed_mb = 0.0
    for td in temp_dirs:
        if not td.exists():
            continue
        try:
            for item in list(td.iterdir()):
                try:
                    size = item.stat().st_size if item.is_file() else 0
                    if item.is_dir():
                        shutil.rmtree(item, ignore_errors=True)
                    else:
                        item.unlink(missing_ok=True)
                    total_freed_mb += size / (1024 * 1024)
                except Exception:
                    pass
        except Exception:
            pass
    results.append(f"Temp files cleaned (~{total_freed_mb:.1f} MB freed)")

    # 6. Disk cleanup via cleanmgr in background (quiet mode)
    try:
        subprocess.Popen(["cleanmgr", "/sagerun:1"], creationflags=_NO_WINDOW)
        results.append("Disk Cleanup started (runs in background)")
    except Exception:
        errors.append("Disk Cleanup could not be started")

    from server import emit as _emit
    _emit("system.quick_optimize_done", {"results": results, "errors": errors})
    return {"ok": True, "results": results, "errors": errors}
