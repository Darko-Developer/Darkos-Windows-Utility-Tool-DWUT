"""api/proxy_api.py — Proxy Center bridge. Proxy lists/results stay in Python; the UI gets compact rows."""
from __future__ import annotations

import json
import re
import threading
import time

from core.events import Events, bus
from core.worker import worker
from server import emit, rpc

_raw: list = []
_results: list = []
_live: list = []
_stop: threading.Event | None = None
_lock = threading.Lock()


def _row(r) -> dict:
    yt, dc = bool(getattr(r, "youtube_ok", False)), bool(getattr(r, "discord_ok", False))
    https = ("YT+DC" if (yt and dc) else "YT" if yt else "OK" if r.browse_ok else "NO")
    p = r.proxy
    tp = getattr(r, "throughput_mbps", None)
    jt = getattr(r, "jitter_ms", None)
    return {
        "address":    p.address(), "ip": p.ip, "port": p.port, "protocol": p.protocol,
        "https":      https,
        "country":    r.country or "Unknown",
        "latency":    f"{r.tcp_latency_ms:.0f}ms" if r.tcp_latency_ms else "n/a",
        "throughput": f"{tp:.1f}MB/s" if tp is not None else "n/a",
        "jitter":     f"{jt:.0f}ms" if jt is not None else "n/a",
        "anonymity":  r.anonymity or "unknown",
        "score":      r.score,
        "tier":       r.tier,
        "yt":         yt,
        "dc":         dc,
        "elite":      r.anonymity == "elite",
        "secure":     bool(getattr(r, "secure", False)),
    }


# ── bus -> compact events ─────────────────────────────────────────────────────

def _on_fetch_done(proxies):
    global _raw
    _raw = list(proxies)
    from modules.proxy.sources import LAST_FETCH
    emit("proxy.fetch_done", {"count": len(_raw), "preview": [f"{p.protocol}://{p.ip}:{p.port}" for p in _raw[:3000]],
                              "sources_ok": LAST_FETCH.get("ok", 0), "sources_failed": LAST_FETCH.get("failed", 0),
                              "sources_total": LAST_FETCH.get("total", 0), "source_errors": LAST_FETCH.get("errors", {})})


def _on_check_done(results):
    global _results, _stop
    from modules.proxy.checker import STATS
    was_stopped = bool(getattr(_stop, "_by_user", False))
    _results = list(results)
    _stop = None
    t = lambda *names: sum(1 for r in _results if r.tier in names)  # noqa: E731
    gaming, excellent, good, fair = t("gaming"), t("excellent"), t("good"), t("fair")
    working = gaming + excellent + good + fair
    pings = sorted(r.tcp_latency_ms for r in _results if r.tcp_latency_ms)
    emit("proxy.check_done", {
        "total":        len(_results),
        "gaming":       gaming,
        "excellent":    excellent,
        "good":         good,
        "fair":         fair,
        "rejected":     0,
        "youtube":      sum(1 for r in _results if getattr(r, "youtube_ok", False)),
        "elite":        sum(1 for r in _results if r.anonymity == "elite"),
        "working":      working,
        "stopped":      was_stopped,
        "remaining":    0,
        "scanned":      STATS.get("scanned", 0),
        "fast_hosts":   STATS.get("fast", 0),
        "verified":     STATS.get("verified", 0),
        "limit":        STATS.get("limit"),
        "fallback_ping": STATS.get("fallback_ping"),
        "best_rtt":     STATS.get("best_rtt"),
        "best_ping":    pings[0]               if pings else None,
        "median_ping":  pings[len(pings) // 2] if pings else None,
        "elapsed":      STATS.get("elapsed"),
        "reasons":      STATS.get("reasons") or {},
        "min_speed":    STATS.get("min_speed"),
        "skipped_ports": STATS.get("skipped_ports", 0),
        "discord":      sum(1 for r in _results if getattr(r, "discord_ok", False)),
        "relaxed":      STATS.get("relaxed", 0),
        "my_ip_known":  STATS.get("my_ip_known", True),
    })


def _on_batch(batch):
    if not batch:
        return
    with _lock:
        _live.extend(batch)
    emit("proxy.batch", [_row(r) for r in batch])


bus.subscribe(Events.PROXY_FETCH_DONE, _on_fetch_done)
bus.subscribe(Events.PROXY_CHECK_DONE, _on_check_done)
bus.subscribe(Events.PROXY_RESULT_BATCH, _on_batch)


# ── calls ─────────────────────────────────────────────────────────────────────

@rpc("proxy.fetch")
def proxy_fetch():
    from modules.proxy.sources import fetch_all_sources
    worker.submit(fetch_all_sources, on_error=lambda e: bus.publish(Events.APP_ERROR, f"Fetch failed: {e}"))
    return True


@rpc("proxy.check")
def proxy_check(workers: int = 300, region: str = "Any", protocol: str = "any", min_anonymity: str = "any",
                max_latency_ms: float | None = 90, target: int = 200, min_speed: float = 1.0, require_youtube: bool = True, **_ignored):
    """Business-grade proxy check — latency + throughput + jitter pipeline."""
    global _stop
    from modules.proxy.checker import check_all
    if not _raw:
        return False
    with _lock:
        _live.clear()
    _stop = threading.Event()
    worker.submit(check_all, list(_raw), max_workers=max(60, min(int(workers), 600)), stop_event=_stop,
                  region_filter=region, protocol_filter=protocol, min_anonymity=min_anonymity,
                  max_latency_ms=max_latency_ms, target=max(1, int(target or 200)),
                  min_speed_mbps=max(0.0, float(min_speed if min_speed is not None else 1.0)), require_youtube=bool(require_youtube),
                  on_error=lambda e: bus.publish(Events.APP_ERROR, f"Check failed: {e}"))
    return True


@rpc("proxy.stop")
def proxy_stop():
    if _stop:
        _stop._by_user = True            # type: ignore[attr-defined]
        _stop.set()
    return True


@rpc("proxy.counts")
def proxy_counts():
    return {"raw": len(_raw), "results": len(_results)}


def _best():
    """Return the best result: Gaming > Excellent > Good > Fair, sorted by score then latency."""
    for tier in ("gaming", "excellent", "good", "fair"):
        c = [r for r in _results if r.tier == tier]
        if c:
            c.sort(key=lambda r: (-(r.score or 0), r.tcp_latency_ms or 9999))
            return c[0]
    return None


# ── system-proxy connection (via local failover relay) ───────────────────────
import os
from pathlib import Path

_PORT_FILE = Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT" / "relay_port.txt"


def _progress(msg: str) -> None:
    emit("proxy.connect_progress", msg)


def _ranked() -> list:
    """Working results, best first (tier, then score, then ping)."""
    order = {"gaming": 0, "excellent": 1, "good": 2, "fair": 3}
    good = [r for r in (_results or []) if r.tier in order]
    if not good:                                           # a stopped / still-running check: use what the table already shows
        good = [r for r in _live if r.tier in order]
    good.sort(key=lambda r: (order.get(r.tier, 9), -(r.score or 0), r.tcp_latency_ms or 9999))
    return good


def _verify(port: int) -> tuple[bool, str]:
    """Real end-to-end test THROUGH the relay exactly like a browser would use it."""
    import requests
    px = {"http": f"http://127.0.0.1:{port}", "https": f"http://127.0.0.1:{port}"}
    s = requests.Session()
    s.trust_env = False
    why = ""
    for url, ok_msg in (("https://www.youtube.com/generate_204", "YouTube reachable"), ("https://www.google.com/generate_204", "browsing OK (YouTube blocked by this proxy)")):
        try:
            r = s.get(url, proxies=px, timeout=14, allow_redirects=False)
            if r.status_code == 204:
                return True, ok_msg
            why = f"{url.split('/')[2]} returned HTTP {r.status_code}"
        except Exception as exc:
            why = str(exc).split("(Caused by")[0].strip()[:90] or exc.__class__.__name__
    return False, why


def _fail_summary(bad: dict) -> str:
    if not bad:
        return ""
    counts: dict = {}
    for why in bad.values():
        counts[why] = counts.get(why, 0) + 1
    return "; ".join(f"{n}x {w}" for w, n in sorted(counts.items(), key=lambda kv: -kv[1])[:3])


def _finalize(pool: list, label_hint: str = "") -> dict:
    """Start the relay on `pool` (best first), point Windows at it, prove it end-to-end, or roll everything back."""
    from modules.proxy.connect import disable_proxy, enable_proxy
    from modules.proxy.relay import relay
    port = relay.start(pool)
    relay.on_switch = lambda lab: _progress(f"Switched to {lab}")
    try:
        _PORT_FILE.parent.mkdir(parents=True, exist_ok=True)
        _PORT_FILE.write_text(str(port))
    except OSError:
        pass
    enable_proxy("127.0.0.1", port, "http")
    why = ""
    for attempt in (1, 2):
        _progress(f"Final end-to-end test through {relay.current_label()}...")
        ok, why = _verify(port)
        if ok:
            carried = relay.last_ok or relay.current_label()
            return {"ok": True, "message": f"Connected via {carried} - {why}. Auto-failover is on ({len(pool)} proxies in the pool)."}
    relay.stop()
    disable_proxy()
    try:
        _PORT_FILE.unlink()
    except OSError:
        pass
    return {"ok": False, "message": f"The proxy answered the quick test but real traffic through it failed ({why}). "
                                    "System proxy left OFF so your connection keeps working. Try again or pick another."}


def _live_filter(cands: list, want: int = 6, budget: float = 22.0) -> tuple[list, dict]:
    """Re-test candidates RIGHT NOW (in parallel).  -> ([(result, ping)] sorted by ping, {address: reason for failures})."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from modules.proxy.checker import live_check
    good, bad = [], {}
    t0 = time.monotonic()
    ex = ThreadPoolExecutor(max_workers=12, thread_name_prefix="px-live")
    futs = {ex.submit(live_check, r.proxy.ip, r.proxy.port, r.proxy.protocol, 6.0): r for r in cands}
    done_n = 0
    try:
        for f in as_completed(futs, timeout=budget):
            r = futs[f]
            done_n += 1
            try:
                res = f.result()
            except Exception as exc:
                res = {"ok": False, "why": str(exc)[:60]}
            if res["ok"]:
                good.append((r, res["ping"] or 9999))
            else:
                bad[r.proxy.address()] = res["why"]
            _progress(f"Re-testing the best proxies right now... {done_n}/{len(cands)} checked, {len(good)} alive")
            if len(good) >= want or time.monotonic() - t0 > budget:
                break
    except Exception:                                      # as_completed timeout: use what we have
        pass
    finally:
        ex.shutdown(wait=False, cancel_futures=True)
    good.sort(key=lambda x: x[1])
    return good, bad


def _upstream(r):
    from modules.proxy.relay import Upstream
    return Upstream(r.proxy.ip, r.proxy.port, r.proxy.protocol)


@rpc("proxy.connect_best")
def proxy_connect_best():
    ranked = _ranked()
    if not ranked:
        return {"ok": False, "message": "No working proxies yet - run Check All and wait for some results first."}
    _progress(f"Re-testing the best of {len(ranked)} proxies right now (free proxies die fast)...")
    good, bad = _live_filter(ranked[:40])
    if not good:
        return {"ok": False, "message": f"All {min(40, len(ranked))} best proxies stopped answering since the check ({_fail_summary(bad) or 'no response'}). "
                                        "Free proxies go offline within minutes - run Check All again and connect right away."}
    # best quality first among the proven-alive ones, failover pool = the other alive ones, then a few untested spares
    order = {"gaming": 0, "excellent": 1, "good": 2, "fair": 3}
    good.sort(key=lambda x: (order.get(x[0].tier, 9), x[1]))
    pool = [_upstream(r) for r, _ in good]
    alive = {(u.ip, u.port) for u in pool}
    pool += [_upstream(r) for r in ranked[:40] if (r.proxy.ip, r.proxy.port) not in alive and r.proxy.address() not in bad][: max(0, 8 - len(pool))]
    _progress(f"{len(good)} alive - connecting to {good[0][0].proxy.address()} ({good[0][1]:.0f} ms)...")
    return _finalize(pool[:8])


@rpc("proxy.enable")
def proxy_enable(ip: str, port: int, protocol: str = "http"):
    from modules.proxy.checker import live_check
    from modules.proxy.relay import Upstream
    port = int(port)
    proto = protocol
    for r in (_live or []) + (_results or []):
        if r.proxy.ip == ip and r.proxy.port == port:
            proto = r.proxy.protocol
            break
    _progress(f"Testing {ip}:{port} ({proto.upper()}) right now...")
    res = live_check(ip, port, proto, 7.0)
    if not res["ok"]:
        res = live_check(ip, port, proto, 9.0)             # free proxies are flaky - one retry before giving up
    if not res["ok"]:
        return {"ok": False, "message": f"{ip}:{port} is not usable right now ({res['why']}). Free proxies drop quickly - "
                                        "pick another one in the list or use Connect to Best."}
    first = Upstream(ip, port, proto)
    others = [_upstream(r) for r in _ranked() if (r.proxy.ip, r.proxy.port) != (ip, port)][:7]
    return _finalize([first] + others)


@rpc("proxy.disconnect")
def proxy_disconnect():
    return shutdown_proxy(manual=True)


def shutdown_proxy(manual: bool = False) -> dict:
    """Stop the relay and clear the Windows proxy.  Also called when DWUT exits."""
    from modules.proxy.connect import disable_proxy, get_active_proxy
    from modules.proxy.relay import relay
    was = relay.running
    relay.stop()
    cur = get_active_proxy()
    ok, msg = True, "System proxy disabled"
    if was or manual or (cur and "127.0.0.1:" in cur and _PORT_FILE.exists()):
        ok, msg = disable_proxy()
    try:
        _PORT_FILE.unlink()
    except OSError:
        pass
    return {"ok": ok, "message": msg}


@rpc("proxy.active")
def proxy_active():
    from modules.proxy.connect import get_active_proxy
    from modules.proxy.relay import relay
    cur = get_active_proxy()
    if cur and relay.running and "127.0.0.1:" in cur:
        return f"{relay.current_label()} via local relay"
    return cur


def _recover_stale_proxy() -> None:
    """If DWUT crashed last time the system proxy may still point at our dead relay - undo that."""
    try:
        from modules.proxy.connect import disable_proxy, get_active_proxy
        if _PORT_FILE.exists():
            port = _PORT_FILE.read_text().strip()
            cur = get_active_proxy()
            if cur and f"127.0.0.1:{port}" in cur:
                disable_proxy()
            _PORT_FILE.unlink()
    except Exception:
        pass


_recover_stale_proxy()


_RE_SCHEME = re.compile(r"^(?P<proto>https?|socks[45])://(?:(?P<creds>[^@]+)@)?(?P<host>[^:/]+):(?P<port>\d+)", re.IGNORECASE)
_RE_BARE = re.compile(r"^(?P<host>[^:/\s]+):(?P<port>\d+)(?::(?P<proto>https?|socks[45]))?$", re.IGNORECASE)


@rpc("proxy.import")
def proxy_import(text: str, default_protocol: str = "http"):
    global _raw
    from modules.proxy.sources import ProxyRecord
    from modules.proxy.ports import is_blocked_port
    parsed, skipped = [], 0
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = _RE_SCHEME.match(line)
        if m:
            parsed.append(ProxyRecord(ip=m.group("host"), port=int(m.group("port")),
                                      protocol=m.group("proto").lower().replace("https", "http"), credentials=m.group("creds")))
            continue
        m = _RE_BARE.match(line)
        if m:
            rp = (m.group("proto") or "").lower().replace("https", "http")
            parsed.append(ProxyRecord(ip=m.group("host"), port=int(m.group("port")),
                                      protocol=rp if rp in ("http", "socks4", "socks5") else default_protocol))
            continue
        skipped += 1
    blocked = len(parsed)
    parsed = [p for p in parsed if not is_blocked_port(p.port)]
    blocked -= len(parsed)
    skipped += blocked                                   # RAT / miner / Tor / service ports are dropped
    if not parsed:
        return {"ok": False, "skipped": skipped, "new": 0, "dupes": 0, "total": len(_raw)}
    seen = {(p.ip, p.port, p.protocol) for p in _raw}
    new = []
    for p in parsed:
        k = (p.ip, p.port, p.protocol)
        if k not in seen:
            seen.add(k)
            new.append(p)
    _raw = _raw + new
    return {"ok": True, "new": len(new), "dupes": len(parsed) - len(new), "skipped": skipped, "total": len(_raw)}


@rpc("proxy.export")
def proxy_export(fmt: str):
    working = [r for r in _results if r.tier in ("gaming", "excellent", "good", "fair")]
    if not working:
        return {"count": 0, "text": ""}
    P = [r.proxy for r in working]
    if fmt == "ip:port":
        lines = [f"{p.ip}:{p.port}" for p in P]
    elif fmt == "ip:port:protocol":
        lines = [f"{p.ip}:{p.port}:{p.protocol}" for p in P]
    elif fmt == "Proxifier (*.ppx)":
        tp = {"http": "HTTPS", "socks4": "SOCKS4", "socks5": "SOCKS5"}
        body = "".join(f'    <Proxy id="{100 + i}" type="{tp.get(p.protocol, "HTTPS")}">\n      <Address>{p.ip}</Address>\n      <Port>{p.port}</Port>\n      <Options>48</Options>\n    </Proxy>\n' for i, p in enumerate(P))
        lines = ['<?xml version="1.0" encoding="utf-8"?>', '<ProxifierProfile version="101" platform="Windows" product_id="0" product_minver="310">', "  <ProxyList>", body.rstrip("\n"), "  </ProxyList>", "</ProxifierProfile>"]
    elif fmt == "ProxyCap":
        lines = [f"{p.protocol.upper()} {p.ip} {p.port}" for p in P]
    elif fmt == "Shadowsocks JSON":
        lines = [json.dumps({"servers": [{"server": p.ip, "server_port": p.port, "protocol": p.protocol} for p in P]}, indent=2)]
    elif fmt == "Windows system proxy command":
        lines = [f'netsh winhttp set proxy proxy-server="{p.ip}:{p.port}"' for p in P]
    else:
        lines = [f"{p.protocol}://{p.ip}:{p.port}" for p in P]
    return {"count": len(P), "text": "\n".join(lines)}


@rpc("proxy.chain_info")
def proxy_chain_info(addrs: list):
    out = []
    for a in addrs:
        proto, lat = "?", ""
        for r in _results:
            if r.proxy.address() == a:
                proto = r.proxy.protocol.upper()
                if r.tcp_latency_ms:
                    lat = f"{r.tcp_latency_ms:.0f}ms"
                break
        out.append({"proto": proto, "latency": lat})
    return out


@rpc("proxy.chain_candidates")
def proxy_chain_candidates(used: list, limit: int = 1):
    good = sorted([r for r in _results if r.tier in ("gaming", "excellent", "good")], key=lambda r: -(r.score or 0))
    if not good:
        return {"none": True, "addrs": []}
    used = set(used)
    addrs = [r.proxy.address() for r in good if r.proxy.address() not in used][:limit]
    return {"none": False, "addrs": addrs}


@rpc("proxy.chain_test")
def proxy_chain_test(nodes: list):
    import socket
    import time
    import requests
    hops = []
    for addr in nodes:
        try:
            host, port = addr.rsplit(":", 1)
            t0 = time.monotonic()
            socket.create_connection((host, int(port)), timeout=5).close()
            hops.append([addr, True, f"{(time.monotonic() - t0) * 1000:.0f}ms"])
        except Exception as exc:
            hops.append([addr, False, str(exc)])
    last = nodes[-1]
    protocol = next((r.proxy.protocol for r in _results if r.proxy.address() == last), "http")
    url = f"{protocol}://{last}"
    res = {"hops": hops}
    try:
        t0 = time.monotonic()
        resp = requests.get("http://api.ipify.org?format=json", proxies={"http": url, "https": url}, timeout=8)
        res.update(exit_ip=resp.json().get("ip", "?"), exit_ms=f"{(time.monotonic() - t0) * 1000:.0f}ms", success=True)
    except Exception as exc:
        err = str(exc)
        if "SOCKS" in err and "connect" in err.lower():
            err = "SOCKS proxy unreachable (TCP connect failed)"
        elif "PySocks" in err or ("socks" in err.lower() and "install" in err.lower()):
            err = "Install PySocks: pip install requests[socks]"
        res.update(exit_ip="failed", exit_ms="—", success=False, error=err)
    return res


@rpc("proxy.defaults")
def proxy_defaults():
    from app.config import config
    return {"workers": config.proxy_max_workers, "timeout": config.proxy_timeout_s,
            "anonymity": config.proxy_default_anonymity, "protocol": config.proxy_default_protocol}


def _ensure_pysocks() -> None:
    """SOCKS proxy checking needs PySocks.  Install it in the background if it's missing."""
    try:
        import socks  # noqa: F401
        return
    except ImportError:
        pass

    def _install():
        import subprocess
        import sys
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-q", "PySocks"],
                           capture_output=True, timeout=180, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception:
            pass
    threading.Thread(target=_install, daemon=True).start()


_ensure_pysocks()
