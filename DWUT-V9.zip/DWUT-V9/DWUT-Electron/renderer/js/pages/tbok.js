'use strict';
/* TBOK (CORPORATE AND BUSINESS) - runs The Beard of Knowledge's TBOK Windows Performance Optimizer (bundled unmodified, see backend/vendor/tbok).
   Lives on the Dashboard under the DWUT 1 CLICK BUTTON.  The hover panel is a short bullet summary of the tool's README (the full README ships in backend/vendor/tbok). */
window.Tbok = { build() {
  const status = h('span', { class: 'f11 ts' });
  let busy = false, clearT = 0;
  const say = (t, ms) => { status.textContent = t || ''; clearTimeout(clearT); if (ms) clearT = setTimeout(() => { status.textContent = ''; }, ms); };

  // ── hover panel: a short bullet list of what the tool does (condensed from the README's own sections) ──
  const INTRO = 'Business-approved 1-click Windows 11 optimizer. Also works on Windows 10 / LTSC.';
  const POINTS = [
    ['Safe', 'restore point made first'],
    ['All users', 'every account + new users'],
    ['Startup', 'Fast Startup off (desktops), F8 menu, virtual memory'],
    ['Services', 'trimmed and tuned to your hardware'],
    ['System', 'no network throttling, faster UI + shutdown'],
    ['Privacy', 'telemetry, Edge background, Recall off'],
    ['Bloat', 'Copilot, Bing search, Widgets, junk tasks'],
    ['Per-user', 'no background apps, End Task, full right-click menu'],
    ['No ads', 'Start, lock screen, Settings, Explorer'],
    ['Office', 'telemetry + feedback off'],
    ['Gaming', 'GPU scheduling, frame timing, Ultimate plan'],
    ['Extras', 'WinGet app updater, disk cleanup (soon)'],
  ];
  let box = null;
  function richTip(target) {
    if (!document.getElementById('tbok-tip-css')) {
      const st = document.createElement('style'); st.id = 'tbok-tip-css';
      st.textContent = '#tbok-tip{position:fixed;left:0;top:0;z-index:10001;width:300px;max-width:calc(100vw - 16px);background:var(--bg_card);border:1px solid var(--accent);color:var(--text_primary);padding:9px 11px;border-radius:8px;' +
        'box-shadow:0 8px 28px rgba(0,0,0,.55);pointer-events:none;display:none;font-size:max(8px,calc(10px*var(--fs)));line-height:1.3}' +
        '#tbok-tip .tt-head{font-weight:700;color:var(--accent);font-size:1.12em;margin-bottom:3px}' +
        '#tbok-tip .tt-intro{color:var(--text_secondary);margin-bottom:6px}' +
        '#tbok-tip .tt-li{display:flex;gap:6px;margin:2px 0}#tbok-tip .tt-li i{font-style:normal;color:var(--accent);flex:none}' +
        '#tbok-tip .tt-li b{color:var(--text_primary)}#tbok-tip .tt-li span{color:var(--text_secondary)}' +
        '#tbok-tip .tt-foot{margin-top:7px;padding-top:5px;border-top:1px solid var(--border);color:var(--text_secondary)}';
      document.head.appendChild(st);
    }
    const place = (e) => {
      const w = box.offsetWidth, hh = box.offsetHeight;
      let x = e.clientX + 14, y = e.clientY + 16;
      if (x + w > innerWidth - 8) x = e.clientX - w - 10;
      if (y + hh > innerHeight - 8) y = innerHeight - hh - 8;
      box.style.left = Math.max(8, x) + 'px'; box.style.top = Math.max(8, y) + 'px';
    };
    target.addEventListener('mouseenter', (e) => {
      if (!box) {
        box = document.createElement('div'); box.id = 'tbok-tip'; document.body.appendChild(box);
        box.append(h('div', { class: 'tt-head', text: 'TBOK - by The Beard of Knowledge' }), h('div', { class: 'tt-intro', text: INTRO }),
          ...POINTS.map(([t, d]) => h('div', { class: 'tt-li' }, h('i', { text: '•' }), h('div', null, h('b', { text: t + ': ' }), h('span', { text: d })))),
          h('div', { class: 'tt-foot', text: 'Click to run it in its own window.' }));
      }
      box.style.display = 'block'; place(e);
    });
    target.addEventListener('mousemove', (e) => { if (box && box.style.display === 'block') place(e); });
    const hide = () => { if (box) box.style.display = 'none'; };
    target.addEventListener('mouseleave', hide); target.addEventListener('mousedown', hide);
  }

  // ── credits: Windows notification + in-app popup (with a clickable repo link) shown whenever the tool is launched ──
  const CREDIT_TITLE = 'Credits to TheBeardOfKnowledge';
  const CREDIT_LINE = 'For Making This Tool';
  const REPO = 'https://github.com/TheBeardofKnowledge/TBOK-Win11Optimizer';
  function showCredits() {
    try { dwut.notify(CREDIT_TITLE, CREDIT_LINE + '\n' + REPO, REPO); } catch { /* notification is best-effort */ }
    Modal.custom((close) => h('div', { class: 'modal' },
      h('h3', { text: CREDIT_TITLE, class: 'b' }),
      h('div', { class: 'body f12', style: 'white-space:normal' },
        h('div', { text: CREDIT_LINE }),
        h('a', { href: REPO, text: REPO, style: 'display:inline-block;margin-top:6px;color:var(--accent);text-decoration:underline;cursor:pointer;word-break:break-all',
          onclick: (e) => { e.preventDefault(); try { dwut.openExternal(REPO); } catch { /* ignore */ } } })),
      h('div', { class: 'foot' }, Btn('OK', { w: 90, onclick: () => close(true) }))));
  }

  async function run() {
    if (busy) return; busy = true; say('Opening TBOK…');
    try {
      const r = await rpc('tbok.run');
      if (!r || !r.ok) { say(''); fail('Could not start TBOK', (r && r.error) || 'Unknown error'); }
      else { say('TBOK is running in its own window.', 10000); showCredits(); }
    } catch (e) { say(''); fail('Could not start TBOK', e.message); }
    busy = false;
  }

  // ── shared entry point (dashboard button AND tray entry): warn who this is for, and only run TBOK if they confirm ──
  async function start() {
    if (busy) return;
    const ok = await Modal.confirm('TBOK (CORPORATE AND BUSINESS)',
      'THIS IS RECOMMENDED FOR BUSINESSES AND CORPORATES\n\n' +
      'IF YOU PREFER TO GAME AND ARE USING YOUR PERSONAL SYSTEM IT IS RECOMMENDED YOU RUN THE DWUT 1 CLICK\n\n' +
      'THIS WILL DISABLE XBOX AND SERVICES YOU MAY WANT TO REMAIN ENABLED (USE DWUT FOR MORE CUSTOMIZABILITY)',
      { yes: 'Continue', no: 'Cancel' });
    if (ok) run();
  }

  const btn = Btn('TBOK (CORPORATE AND BUSINESS)', { h: 56, cls: 'fill', bold: true, f: 16, onclick: start });   // same path as the tray entry: warning popup -> run -> credits notification + popup
  richTip(btn);
  const el = Card([
    h('div', { class: 'row', style: 'padding:10px 12px 4px' }, h('span', { class: 'f13 b', text: 'TBOK WINDOWS OPTIMIZER' }), h('div', { class: 'grow' }), status),
    h('div', { class: 'f11 ts', style: 'padding:0 12px 8px;white-space:normal', text: "The Beard of Knowledge's business-approved 1-click Windows optimizer - safe for IT teams, MSPs, system builders and technicians. Hover the button for what it does." }),
    h('div', { class: 'row', style: 'gap:8px;padding:4px 12px 12px' }, btn)], 'col', { minWidth: 0 });
  return { el, run, start };
} };
