'use strict';
Pages.register('usb', () => {
  const gb = (b) => (b / 1e9 >= 100 ? (b / 1e9).toFixed(0) : (b / 1e9).toFixed(1)) + ' GB';
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (t) => { status.textContent = t || ''; };
  // Never fail silently: any unexpected error inside a wizard is shown to the user (and the status line is cleared).
  const safe = (title, fn) => async (...a) => { try { return await fn(...a); } catch (e) { console.error(title, e); setStatus(''); Modal.close(); return fail(title, String((e && e.message) || e)); } };
  const logBox = Textbox({ f: 10, max: 400, h: 150 });
  const lg = (t) => logBox.line(t);
  on('usb.log', lg);
  let CAT = null;

  // ───────────── step 1: pick the drive ─────────────
  function pickDrive(title, sub) {
    return Modal.custom((close) => {
      let sel = null;
      const list = h('div', { class: 'scroll', style: 'max-height:280px;margin:10px 0;min-width:520px' });
      const next = Btn('Next', { w: 100, onclick: () => close(sel) }); next.disabled = true;
      const refresh = async () => {
        list.textContent = ''; sel = null; next.disabled = true;
        list.append(h('div', { class: 'f11 ts', text: 'Looking for USB drives…', style: 'padding:14px' }));
        let drives = [];
        try { drives = await rpc('usb.drives'); } catch (e) { list.textContent = ''; return list.append(h('div', { class: 'f11 c-err', text: 'Could not list drives: ' + e.message, style: 'padding:14px' })); }
        list.textContent = '';
        if (!drives.length) return list.append(h('div', { class: 'f12 ts', text: 'No USB drives found.\nPlug a stick in, wait a few seconds, then press Refresh.\n(Internal and system disks are never shown.)', style: 'padding:16px;white-space:pre-wrap' }));
        drives.forEach((d) => {
          const big = d.size > 256e9;
          const row = h('div', { class: 'row', style: 'padding:9px 10px;border-radius:6px;cursor:pointer;margin:2px 0;border:2px solid transparent;gap:10px' },
            h('div', { class: 'f18 b c-acc', text: 'USB', style: 'width:46px;font-size:12px;text-align:center;background:var(--bg_input);border-radius:4px;padding:6px 0' }),
            h('div', { class: 'col grow', style: 'align-items:flex-start;min-width:0' },
              h('span', { class: 'f12 b tp ell', text: `${d.name || 'USB drive'}  -  ${gb(d.size)}`, style: 'max-width:100%' }),
              h('span', { class: 'f10 ts', text: `Disk ${d.number}${d.letters ? '  |  ' + d.letters : ''}${d.labels ? '  |  ' + d.labels : ''}${d.used ? '  |  ' + gb(d.used) + ' used' : ''}` }),
              big ? h('span', { class: 'f10 c-warn', text: 'Large drive - is this really a USB stick and not an external hard disk?' }) : null,
              d.used > 1e9 ? h('span', { class: 'f10 c-warn', text: 'Contains data that will be erased.' }) : null));
          row.onclick = () => { sel = d; next.disabled = false; $$('.row', list).forEach((r) => { r.style.borderColor = 'transparent'; r.style.background = ''; }); row.style.borderColor = 'var(--accent)'; row.style.background = 'var(--sidebar_active)'; };
          list.append(row);
        });
      };
      setTimeout(refresh, 30);
      return h('div', { class: 'modal', style: 'min-width:560px' }, h('h3', { text: title }), h('div', { class: 'f11 ts', text: sub, style: 'white-space:normal' }), list,
        h('div', { class: 'foot' }, Btn('Refresh', { variant: 'ghost', w: 90, onclick: refresh }), h('div', { class: 'grow' }), Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }), next));
    });
  }

  // ───────────── step 2: pick the OS ─────────────
  const pickOS = (disk, only) => wzPickOS(CAT, only, { subtitle: `Target: ${disk.name || 'USB drive'} (${gb(disk.size)}, Disk ${disk.number}).  Everything needed is downloaded automatically.` });

  // ───────────── confirm erase ─────────────
  function adminPrompt() {
    return Modal.custom((close) => {
        return h('div', { class: 'modal' },
          h('h3', { text: 'Administrator Privileges Required', style: 'color:var(--warning)' }),
          h('div', { class: 'body f12', text: 'Writing directly to physical USB storage drives and formatting partitions requires Administrator privileges.\n\nRestart DWUT as Administrator now?' }),
          h('div', { class: 'foot' },
            Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(false) }),
            Btn('Restart as Admin', { variant: 'primary', w: 150, onclick: () => { window.dwut?.relaunchAdmin?.(); close(false); } })
          )
        );
    });
  }
  function confirmErase(disk, what) {
    if (!Nav.isAdmin) return adminPrompt();
    return Modal.custom((close) => {
      const hint = h('div', { class: 'f11 c-warn', style: 'display:none;margin-top:6px;font-weight:600', text: '⚠ Please check the confirmation box below to continue.' });
      const ok = Check(`I understand everything on Disk ${disk.number} will be permanently erased`, {
        themed: true, f: 12,
        onchange: (v) => { if (v) hint.style.display = 'none'; }
      });
      const onConfirm = () => {
        if (!ok.checked) {
          hint.style.display = '';
          ok.style.outline = '2px solid var(--warning)';
          ok.style.borderRadius = '4px';
          setTimeout(() => { ok.style.outline = 'none'; }, 2000);
          return;
        }
        close(true);
      };
      const go = Btn('Erase and continue', { variant: 'danger', w: 170, onclick: onConfirm });
      return h('div', { class: 'modal' }, h('h3', { text: 'Erase this drive?', style: 'color:var(--error)' }),
        h('div', { class: 'body f12', text: `${disk.name || 'USB drive'}  -  ${gb(disk.size)}\nDisk ${disk.number}${disk.letters ? '  (' + disk.letters + ')' : ''}${disk.labels ? '\nLabel: ' + disk.labels : ''}\n\n${what}\n\nAll files on this stick will be lost. This cannot be undone.` }),
        h('div', { style: 'margin-top:12px' }, ok), hint,
        h('div', { class: 'foot' }, Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(false) }), go));
    });
  }

  // ───────────── progress window (cannot be dismissed while running) ─────────────
  const runJob = (title, start) => wzRunJob(title, start, 'usb');

  // ───────────── wizards ─────────────
  async function flashWizard(only) {
    if (!CAT) CAT = await rpc('usb.catalog');
    let disk = null, choice = null;
    for (;;) {
      disk = await pickDrive('Step 1 of 3 - Pick the USB stick', 'Only removable USB drives are listed. The drive you pick will be ERASED.');
      if (!disk) return;
      choice = await pickOS(disk, only);
      if (choice === 'back') continue;
      break;
    }
    if (!choice) return;
    const what = choice.iso_path ? `It will be overwritten with: ${choice.name}` : `It will be overwritten with: ${choice.name} (downloaded automatically).`;
    if (!(await confirmErase(disk, what))) return;
    setStatus(`Flashing ${choice.name}…`);
    await runJob(`Creating ${choice.name} USB`, () => rpc('usb.start', { disk, os_id: choice.os_id, iso_path: choice.iso_path, verify: choice.verify, delete_iso: choice.delete_iso }));
    setStatus('');
  }
  // ───────────── Ventoy: pick several operating systems to download onto the stick ─────────────
  function pickMulti(disk) {
    return Modal.custom((close) => {
      const checks = {};
      const items = CAT.os.filter((o) => o.id !== 'ventoy');
      const search = Entry({ placeholder: 'Search operating systems…', fill: true, h: 28, f: 12, onchange: () => paint() }); search.style.width = 'auto';
      const list = h('div', { class: 'scroll', style: 'max-height:320px;margin:8px 0' });
      const del = Check('Delete the downloads from this PC afterwards', { checked: false, themed: true, sm: true, f: 11 });
      const sum = h('span', { class: 'f11 ts' });
      const next = Btn('Download', { w: 110, onclick: () => close({ ids: items.filter((o) => checks[o.id].checked).map((o) => o.id), delete_iso: del.checked }) });
      const upd = () => {
        const sel = items.filter((o) => checks[o.id].checked), tot = sel.reduce((a, o) => a + (o.size_gb || 0), 0);
        const room = disk.size / 1e9;
        sum.textContent = sel.length ? `${sel.length} selected  |  about ${tot.toFixed(1)} GB  |  stick: ${wzGb(disk.size)}` : 'Nothing selected yet';
        sum.style.color = tot > room * 0.97 ? 'var(--warning)' : '';
        if (tot > room * 0.97) sum.textContent += '  -  may not all fit';
        next.disabled = !sel.length;
      };
      items.forEach((o) => { checks[o.id] = Check('', { checked: false, themed: true, onchange: upd }); });
      function paint() {
        list.textContent = '';
        const q = search.value.trim().toLowerCase();
        for (const g of CAT.groups) {
          const rows = items.filter((o) => o.group === g && (!q || (o.name + ' ' + o.desc).toLowerCase().includes(q)));
          if (!rows.length) continue;
          list.append(h('div', { class: 'f11 b c-acc', text: g, style: 'margin:8px 4px 3px' }));
          rows.forEach((o) => {
            const cb = checks[o.id];
            const row = h('div', { class: 'row', style: 'padding:5px 8px;border-radius:6px;cursor:pointer;margin:2px 0;gap:8px;align-items:flex-start',
                onclick: (ev) => { if (!ev.target.closest('.cb')) { cb.toggle(); upd(); } } },
              h('div', { style: 'padding-top:2px' }, cb),
              h('div', { class: 'col grow', style: 'align-items:flex-start;min-width:0' },
                h('div', { class: 'row', style: 'width:100%' }, h('span', { class: 'f12 b tp grow', text: o.name }), h('span', { class: 'f10 ts', text: o.size_gb >= 0.1 ? `~${o.size_gb} GB` : 'tiny' })),
                h('div', { class: 'f10 ts', text: o.desc, style: 'white-space:normal' }), o.warn ? h('div', { class: 'f10 c-warn', text: o.warn, style: 'white-space:normal' }) : null));
            row.onmouseenter = () => { row.style.background = 'var(--bg_hover)'; }; row.onmouseleave = () => { row.style.background = ''; };
            list.append(row);
          });
        }
      }
      paint(); upd();
      return h('div', { class: 'modal', style: 'width:660px;max-width:92%' },
        h('h3', { text: 'Step 2 of 3 - Choose what to put on the Ventoy stick' }),
        h('div', { class: 'f11 ts', text: `Tick as many as fit on ${disk.name || 'the stick'} (${wzGb(disk.size)}). DWUT downloads the latest official version of each, checks it, and copies it onto the stick.`, style: 'white-space:normal;margin-bottom:6px' }),
        search, list, h('div', { class: 'row', style: 'gap:18px;margin-top:6px' }, del, h('div', { class: 'grow' }), sum),
        h('div', { class: 'foot' }, Btn('Back', { variant: 'ghost', w: 90, onclick: () => close('back') }), h('div', { class: 'grow' }), Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }), next));
    });
  }
  async function ventoyIsoWizard() {
    if (!CAT) CAT = await rpc('usb.catalog');
    let disk = null, pick = null;
    for (;;) {
      disk = await pickDrive('Step 1 of 3 - Pick the Ventoy stick', 'Pick a stick that already has Ventoy to keep everything on it. Any other stick is erased and set up with Ventoy first.');
      if (!disk) return;
      pick = await pickMulti(disk);
      if (pick === 'back') continue;
      break;
    }
    if (!pick || !pick.ids.length) return;
    if (!Nav.isAdmin) { await adminPrompt(); return; }
    setStatus('Checking the stick…');
    let hasVentoy = null;
    try { hasVentoy = await rpc('usb.ventoy_check', { disk }); } catch { /* unknown -> treated as "will be erased" */ }
    setStatus('');
    const names = CAT.os.filter((o) => pick.ids.includes(o.id)).map((o) => o.name);
    const list = names.length > 8 ? names.slice(0, 8).join(', ') + ` and ${names.length - 8} more` : names.join(', ');
    if (hasVentoy === true) {
      if (!(await Modal.confirm('Add these to your Ventoy stick?', `${disk.name || 'USB drive'} - ${gb(disk.size)} (Disk ${disk.number}) already has Ventoy.\n\nNothing on it is erased. DWUT will download and copy:\n${list}`, { yes: 'Start', no: 'Cancel' }))) return;
    } else if (!(await confirmErase(disk, hasVentoy === false ? `This stick does not have Ventoy yet, so DWUT will install it first, then add:\n${list}` : `DWUT could not tell whether this stick already has Ventoy. If it does not, it is erased and Ventoy is installed first. Then DWUT adds:\n${list}`))) return;
    setStatus('Putting ISOs on the Ventoy stick…');
    await runJob('Download ISOs onto the Ventoy stick', () => rpc('usb.ventoy_isos', { disk, os_ids: pick.ids, delete_iso: pick.delete_iso }));
    setStatus('');
  }
  async function restoreWizard() {
    const disk = await pickDrive('Restore a USB stick to normal', 'Erases the stick and turns it back into one ordinary drive (use after flashing Linux/Windows media).');
    if (!disk) return;
    const fs = { v: 'exFAT' }, label = Entry({ value: 'USB', w: 140, h: 28 });
    const ok = await Modal.custom((close) => {
      const o = Option(['exFAT', 'NTFS', 'FAT32'], { w: 140, onchange: (v) => { fs.v = v; } }); o.classList.add('bordered');
      return h('div', { class: 'modal' }, h('h3', { text: 'Format options' }), h('div', { class: 'row', style: 'gap:10px;margin:6px 0' }, h('span', { class: 'f12 ts', text: 'File system', style: 'width:90px' }), o),
        h('div', { class: 'row', style: 'gap:10px;margin:6px 0' }, h('span', { class: 'f12 ts', text: 'Name', style: 'width:90px' }), label), h('div', { class: 'f10 ts', text: 'exFAT works on Windows, Mac and most TVs. FAT32 is limited to 32 GB here (bigger sticks use exFAT automatically).', style: 'white-space:normal;max-width:380px;margin-top:6px' }),
        h('div', { class: 'foot' }, Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(false) }), Btn('Next', { w: 90, onclick: () => close(true) })));
    });
    if (!ok || !(await confirmErase(disk, `It will be formatted as ${fs.v} named "${label.value}".`))) return;
    await runJob('Restoring USB stick', () => rpc('usb.restore', { disk, fs: fs.v.toLowerCase(), label: label.value }));
  }
  async function backupWizard() {
    const disk = await pickDrive('Back up a USB stick', 'Saves an exact image of the whole stick to a file (nothing on the stick is changed).');
    if (!disk) return;
    const path = await dwut.dialog.save({ defaultPath: `usb_backup_${disk.number}.img`, filters: [{ name: 'Disk image', extensions: ['img'] }] });
    if (!path) return;
    await runJob('Backing up USB stick', () => rpc('usb.backup', { disk, path }));
  }
  async function libraryDialog() {
    const render = async (box) => {
      const lib = await rpc('usb.library'); box.textContent = '';
      if (!lib.files.length) box.append(h('div', { class: 'f12 ts', text: 'No downloaded images yet. They appear here after you flash something.', style: 'padding:14px' }));
      lib.files.forEach((f) => box.append(h('div', { class: 'row', style: 'padding:6px 4px;gap:10px' }, h('span', { class: 'f12 tp grow ell', text: f.name + (f.partial ? '  (unfinished download - resumes automatically)' : '') }), h('span', { class: 'f11 ts', text: gb(f.size) }),
        Btn('Delete', { variant: 'ghost', w: 70, h: 24, f: 10, onclick: async () => { await rpc('usb.delete_iso', { name: f.name }); render(box); } }))));
      return lib;
    };
    await Modal.custom((close) => {
      const box = h('div', { class: 'scroll', style: 'max-height:300px;min-width:520px;margin:8px 0' });
      render(box).then((lib) => { openBtn.onclick = () => rpc('os.open_path', { path: lib.path }); });
      const openBtn = Btn('Open folder', { variant: 'ghost', w: 120 });
      return h('div', { class: 'modal' }, h('h3', { text: 'ISO library' }), h('div', { class: 'f11 ts', text: 'Downloaded images are kept so re-flashing is instant.' }), box, h('div', { class: 'foot' }, openBtn, h('div', { class: 'grow' }), Btn('Close', { w: 90, onclick: () => close(true) })));
    });
  }

  // ───────────── page ─────────────
  const tile = (title, desc, btnText, onclick, primary) => Card([h('div', { class: 'f14 b tp', text: title, style: 'padding:14px 16px 4px' }), h('div', { class: 'f11 ts', text: desc, style: 'padding:0 16px 12px;white-space:normal;flex:1' }),
    h('div', { style: 'padding:0 16px 16px' }, Btn(btnText, { variant: primary ? 'primary' : 'ghost', h: 34, w: 170, onclick }))], 'col', { minWidth: 0 });
  const el = h('div', { class: 'col scroll', style: 'flex:1;padding:0 20px 16px' },
    h('div', { class: 'title-row', style: 'padding:0' }, h('h1', { text: 'USB Flasher' }), h('div', { class: 'grow' }), status),
    h('div', { class: 'f11 ts', text: 'Turn any USB stick into installation media. Windows 10/11, Fedora, Linux Mint, Arch, Kali, Parrot, BlackArch, Qubes, Tails, TempleOS and more - downloaded and written automatically.', style: 'margin:2px 0 12px;white-space:normal' }),
    h('div', { style: 'display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:12px' },
      tile('Flash a USB stick', 'Pick a stick, pick an operating system - DWUT downloads the latest official version, checks it, and writes a bootable stick. Works on UEFI and BIOS PCs.', 'Create', safe('USB Flasher', () => flashWizard()), true),
      tile('Multi-boot stick (Ventoy)', 'Install Ventoy once, then drag-and-drop as many ISO files as you like onto the stick and choose one at boot.', 'Create', safe('USB Flasher', () => flashWizard(['ventoy']))),
      tile('Restore a stick to normal', 'After flashing Linux or Windows media the stick looks tiny or unreadable. This wipes it and makes it a normal, full-size drive again.', 'Restore', safe('Restore USB', restoreWizard)),
      tile('Download ISOs onto Ventoy', 'Tick as many operating systems as you like - DWUT downloads each one and puts it on your Ventoy stick (installing Ventoy first only if the stick does not have it).', 'Choose ISOs', safe('Ventoy ISOs', ventoyIsoWizard)),
      tile('Back up a stick to a file', 'Saves an exact image of a USB stick (.img) so you can clone it later.', 'Back up', safe('Back up USB', backupWizard)),
      tile('ISO library', 'See, reuse and delete the operating-system images DWUT has downloaded.', 'Open library', safe('ISO library', libraryDialog))),
    Card([h('div', { class: 'row', style: 'padding:10px 14px 4px' }, h('span', { class: 'f12 b ts', text: 'Activity' }), h('div', { class: 'grow' }), Btn('Clear', { variant: 'plain', h: 22, w: 44, f: 10, style: { minWidth: '44px', color: 'var(--text_disabled)' }, onclick: () => logBox.clear() })),
      (() => { logBox.style.margin = '0 10px 10px'; return logBox; })()], 'col', { flex: 'none' }));
  rpc('usb.catalog').then((c) => { CAT = c; }).catch(() => {});
  return { el };
});
