'use strict';
/* DWUT 1 CLICK BUTTON - lives on the Dashboard (OneClick.build() returns its card). One button that runs every safe maintenance job.
   The only questions it asks are the things you must decide yourself: which apps to remove, which tweaks to apply, which TBOK-equivalent system
   optimizations to apply (everything The Beard of Knowledge's TBOK optimizer does, each one a switch), which power mode (if any) and which visual effects.
   Everything else is automatic. */
window.OneClick = { build() {
  const WIDE = 'max-width:min(900px,95vw);width:min(900px,95vw);height:min(660px,88%)';
  const STATE = { wait: ['○', 'var(--text_disabled)'], run: ['▶', 'var(--accent)'], ok: ['✓', 'var(--success)'], warn: ['!', 'var(--warning)'], skip: ['–', 'var(--text_disabled)'], fail: ['✗', 'var(--error)'] };
  let running = false, rows = {}, total = 0;

  const status = h('span', { class: 'f11 ts' });
  const pbar = Progress({ height: 6 });
  const plabel = h('div', { class: 'f11 ts', style: 'padding:4px 2px;min-height:16px' });
  const stepList = h('div', { class: 'col', style: 'gap:3px' });
  const out = Textbox({ f: 10, max: 600, h: 150 });
  const stopBtn = Btn('Stop after current step', { variant: 'ghost', h: 30, cls: 'auto', onclick: () => { rpc('oneclick.cancel'); plabel.textContent = 'Stopping after the current step…'; } });
  stopBtn.style.display = 'none';

  const what = [
    ['Debloat Windows', 'Removes the apps you tick in a popup (Photos, Groove Music, Power Automate and the Xbox apps are NOT ticked by default).'],
    ['Clean + optimize every drive', 'Safe cleanup categories on all drives, then TRIM (SSD) / defrag (hard disk).'],
    ['Free + optimize RAM, CPU and GPU', 'Trims working sets and the standby list, un-parks cores, lowers busy background programs (nothing is closed), clears shader caches, GPU scheduling.'],
    ['Tweaks', 'Applies the recommended tweaks you confirm in a popup (never the Xbox ones).'],
    ['System optimizations (TBOK-equivalent)', 'Everything the TBOK optimizer does, each as a switch you can turn off: hibernation by PC type, F8 menu, page file, services tuning, network/system registry, telemetry, Edge, bloat removal (Copilot, Bing, Widgets), wasteful scheduled tasks, ads and per-user settings for EVERY user and new accounts, gaming (MMCS, windowed games, power throttling), optional WinGet app updates.'],
    ['Disable Windows Recall', 'Windows 11 only.'],
    ['Repair', 'DISM, then SFC, then the High CPU Power Config Repair.'],
    ['Network stack reset', 'Last, because DISM needs the internet. A restart finishes it.'],
    ['Every app on the high-performance GPU', 'Windows Graphics settings: every installed program and Store app is set to High performance (undo any time in Settings > System > Display > Graphics).'],
    ['Visual effects (your choice)', 'Opens a copy of the Windows Performance Options dialog with an extra "DWUT recommended" choice (best performance, then Peek, fading menus, thumbnails and a few more switched back on).'],
    ['Power mode (your choice)', 'Offers Ultimate or Extreme Performance in a popup - or keeps your current plan. Applied after the repairs.'],
    ['Extra safe cleanups', 'Windows Update cache, Recycle Bin, superseded update files, clock sync.'],
  ];

  // ── popups (look and behave like the real pages) ───────────────────────────
  function bloatPopup(D) {
    return Modal.custom((close) => {
      const checks = {};
      const pc = { High: 'var(--success)', Medium: 'var(--warning)', Low: 'var(--text_disabled)' };
      const list = h('div', { class: 'scroll', style: 'flex:1;background:var(--bg_card);border-radius:6px;padding:2px;min-height:0' });
      D.bloat.forEach((e, i) => {
        const cb = Check('', { checked: e.default, themed: true }); checks[e.pkg] = cb;
        const badge = e.installed === true ? h('span', { class: 'f9', text: 'INSTALLED', style: 'background:var(--warning);color:#000;font-weight:700;border-radius:4px;padding:0 6px;margin-left:6px' })
          : e.installed === false ? h('span', { class: 'f9', text: 'not found', style: 'color:var(--text_disabled);margin-left:6px' }) : null;
        const kept = e.protected ? h('span', { class: 'f9 b', text: 'kept by default', style: 'color:var(--accent);margin-left:6px' }) : null;
        list.append(h('div', { class: 'row', style: `background:var(${i % 2 === 0 ? '--bg_input' : '--bg_card'});border-radius:4px;margin:1px 2px;cursor:pointer`,
            onclick: (ev) => { if (!ev.target.closest('.cb')) cb.toggle(); } },
          h('div', { style: 'padding:8px 10px' }, cb),
          h('div', { class: 'grow col', style: 'padding:6px 0;align-items:flex-start' }, h('div', { class: 'row' }, h('span', { class: 'f12 b tp', text: e.name }), badge, kept), h('span', { class: 'f10 ts', text: e.desc })),
          h('span', { class: 'f9 b', text: e.priority, style: `width:55px;text-align:center;margin-right:10px;color:${pc[e.priority] || 'var(--text_secondary)'}` })));
      });
      const count = h('span', { class: 'f11 ts' });
      const upd = () => { count.textContent = `${Object.values(checks).filter((c) => c.checked).length} selected`; };
      list.addEventListener('click', () => setTimeout(upd, 0)); upd();
      const setAll = (fn) => { D.bloat.forEach((e) => checks[e.pkg].set(fn(e), true)); upd(); };
      const sel = () => D.bloat.filter((e) => checks[e.pkg].checked).map(({ name, pkg, desc, priority }) => ({ name, pkg, desc, priority }));
      return h('div', { class: 'modal', style: WIDE },
        h('h3', { class: 'b', text: 'DWUT 1 Click - Step 1 of 5: Debloat' }),
        h('div', { class: 'f11 ts', style: 'margin:-4px 0 8px', text: 'Tick the apps to remove. Installed apps are ticked for you - except Microsoft Photos, Groove Music, Power Automate and the Xbox apps. A restore point is made first.' }),
        h('div', { class: 'row', style: 'gap:6px;margin-bottom:8px' }, Btn('Recommended', { h: 28, onclick: () => setAll((e) => e.default) }),
          Btn('Select All', { variant: 'ghost', h: 28, onclick: () => setAll(() => true) }), Btn('Deselect All', { variant: 'ghost', h: 28, onclick: () => setAll(() => false) }), h('div', { class: 'grow' }), count),
        list,
        h('div', { class: 'foot' }, Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }),
          Btn('Skip debloat', { variant: 'ghost', w: 120, onclick: () => close([]) }), Btn('Next', { w: 110, onclick: () => close(sel()) })));
    });
  }

  function tweakPopup(D) {
    return Modal.custom((close) => {
      const sev = { Critical: 'var(--error)', High: 'var(--warning)', Medium: 'var(--accent)', Low: 'var(--text_disabled)' };
      const sw = {};
      const box = h('div', { class: 'scroll', style: 'flex:1;min-height:0;padding-right:4px' });
      const section = (title, sub, items) => {
        if (!items.length) return;
        box.append(h('div', { class: 'f13 b c-acc', text: title, style: 'padding:8px 4px 2px' }));
        if (sub) box.append(h('div', { class: 'f10 ts', text: sub, style: 'padding:0 4px 6px' }));
        const g = h('div', { style: 'display:grid;grid-template-columns:repeat(2,1fr);padding:0 2px 4px;gap:4px' });
        items.forEach((ft, i) => {
          const s = Switch({ checked: ft.default }); s.style.setProperty('--sw-knob', 'var(--text_primary)'); sw[ft.key] = s;
          const c = h('div', { class: 'row', style: `background:var(${i % 2 === 0 ? '--bg_input' : '--bg_card'});border-radius:6px;padding:6px 10px;min-width:0;height:36px;align-items:center;gap:8px;cursor:pointer;border:1px solid ${ft.recommended ? 'var(--success)' : 'var(--border)'}`,
              onclick: (ev) => { if (!ev.target.closest('.sw')) s.set(!s.checked); upd(); } },
            s, h('span', { class: 'f11 b tp grow ell', text: ft.name }),
            ft.recommended ? h('span', { class: 'f9 b c-ok', text: 'REC', style: 'background:#132b1d;border-radius:3px;padding:1px 4px;flex:none' }) : null,
            ft.severity && ft.severity !== 'Low' ? h('span', { class: 'f9 b', text: ft.severity, style: `color:${sev[ft.severity] || 'var(--text_secondary)'};flex:none` }) : null);
          tip(c, `${ft.name}\n\n${ft.desc}${ft.severity ? '\n\nSeverity: ' + ft.severity : ''}`);
          g.append(c);
        });
        box.append(g);
      };
      section('Essential Tweaks', '', D.tweaks.filter((x) => x.category === 'essential'));
      section('Advanced Tweaks — CAUTION', 'These go further than the essentials - read each description before enabling.', D.tweaks.filter((x) => x.category === 'advanced'));
      section('Customize Preferences', 'Cosmetic / UX toggles - taskbar, logon screen, Start Menu, accessibility.', D.tweaks.filter((x) => x.category === 'preference'));
      const count = h('span', { class: 'f11 ts' });
      function upd() { setTimeout(() => { count.textContent = `${Object.values(sw).filter((s) => s.checked).length} selected`; }, 0); }
      upd();
      const setAll = (fn) => { D.tweaks.forEach((t) => sw[t.key] && sw[t.key].set(fn(t), true)); upd(); };
      const sel = () => D.tweaks.filter((t) => sw[t.key] && sw[t.key].checked).map((t) => t.key);
      return h('div', { class: 'modal', style: WIDE },
        h('h3', { class: 'b', text: 'DWUT 1 Click - Step 2 of 5: Tweaks' }),
        h('div', { class: 'f11 ts', style: 'margin:-4px 0 8px', text: 'The recommended tweaks are switched on for you (no Xbox ones). Change anything you like. Windows Recall is turned off automatically on Windows 11.' }),
        h('div', { class: 'row', style: 'gap:6px;margin-bottom:6px' }, Btn('Recommended', { h: 28, onclick: () => setAll((t) => t.recommended) }),
          Btn('Select All', { variant: 'ghost', h: 28, onclick: () => setAll(() => true) }), Btn('Deselect All', { variant: 'ghost', h: 28, onclick: () => setAll(() => false) }), h('div', { class: 'grow' }), count),
        box,
        h('div', { class: 'foot' }, Btn('Back', { variant: 'ghost', w: 90, onclick: () => close('back') }), Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }),
          Btn('Skip tweaks', { variant: 'ghost', w: 120, onclick: () => close([]) }), Btn('Next', { w: 110, onclick: () => close(sel()) })));
    });
  }

  function sysoptPopup(D) {
    return Modal.custom((close) => {
      const sw = {};
      const items = D.sysopt || [];
      const box = h('div', { class: 'scroll', style: 'flex:1;min-height:0;padding-right:4px' });
      const groups = [];
      items.forEach((it) => { if (!groups.includes(it.group)) groups.push(it.group); });
      groups.forEach((g) => {
        const list = items.filter((it) => it.group === g);
        box.append(h('div', { class: 'f13 b c-acc', text: list[0].group_title, style: 'padding:8px 4px 6px' }));
        const grid = h('div', { style: 'display:grid;grid-template-columns:repeat(2,1fr);padding:0 2px 4px;gap:4px' });
        list.forEach((it, i) => {
          const s = Switch({ checked: it.default }); s.style.setProperty('--sw-knob', 'var(--text_primary)'); sw[it.key] = s;
          const c = h('div', { class: 'row', style: `background:var(${i % 2 === 0 ? '--bg_input' : '--bg_card'});border-radius:6px;padding:6px 10px;min-width:0;height:36px;align-items:center;gap:8px;cursor:pointer;border:1px solid transparent`,
              onclick: (ev) => { if (!ev.target.closest('.sw')) s.set(!s.checked); upd(); } },
            s, h('span', { class: 'f11 b tp grow ell', text: it.name }),
            it.desktop ? h('span', { class: 'f9 b', text: 'DESKTOP', style: 'color:var(--accent);flex:none' }) : null);
          tip(c, `${it.name}\n\n${it.desc}`);
          grid.append(c);
        });
        box.append(grid);
      });
      const count = h('span', { class: 'f11 ts' });
      function upd() { setTimeout(() => { count.textContent = `${Object.values(sw).filter((x) => x.checked).length} of ${items.length} selected`; }, 0); }
      upd();
      const setAll = (fn) => { items.forEach((it) => sw[it.key] && sw[it.key].set(fn(it), true)); upd(); };
      const sel = () => items.filter((it) => sw[it.key] && sw[it.key].checked).map((it) => it.key);
      const kind = D.chassis === 'Laptop' ? 'a laptop / tablet - desktop-only items are skipped and hibernation stays on' : D.chassis === 'Desktop' ? 'a desktop - hibernation / Fast Startup are turned off' : 'of an unknown type - hibernation and desktop-only items are left alone';
      return h('div', { class: 'modal', style: WIDE },
        h('h3', { class: 'b', text: 'DWUT 1 Click - Step 3 of 5: System optimizations' }),
        h('div', { class: 'f11 ts', style: 'margin:-4px 0 4px;white-space:normal', text: 'Everything The Beard of Knowledge\'s TBOK optimizer does, as switches - all on by default except app updates. Settings are applied to every user account and to new accounts, never touch Xbox, and can be undone from the restore point.' }),
        h('div', { class: 'f11 b', style: 'margin:0 0 8px;color:var(--accent)', text: `This PC looks like ${kind}.` }),
        h('div', { class: 'row', style: 'gap:6px;margin-bottom:6px' }, Btn('TBOK recommended', { h: 28, onclick: () => setAll((it) => it.default) }),
          Btn('Select All', { variant: 'ghost', h: 28, onclick: () => setAll(() => true) }), Btn('Deselect All', { variant: 'ghost', h: 28, onclick: () => setAll(() => false) }), h('div', { class: 'grow' }), count),
        box,
        h('div', { class: 'foot' }, Btn('Back', { variant: 'ghost', w: 90, onclick: () => close('back') }), Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }),
          Btn('Skip', { variant: 'ghost', w: 90, onclick: () => close([]) }), Btn('Next', { w: 110, onclick: () => close(sel()) })));
    });
  }

  function powerPopup(D) {
    return Modal.custom((close) => {
      const opts = [
        ['ultimate', 'Ultimate Performance', 'Windows\' own top plan: no core parking or idle throttling, so the PC reacts instantly. Uses a bit more power than Balanced.', null],
        ['extreme', 'Extreme Performance (DWUT)', 'Everything in Ultimate, plus the CPU is pinned at 100% and USB / PCIe power saving is off. More heat, fan noise and power draw.', 'NOT FOR LAPTOPS ON BATTERY.'],
        ['none', 'Keep my current power plan', 'Do not change the power plan.', null],
      ];
      let sel = D.power_active ? 'none' : (D.has_battery ? 'none' : 'ultimate');
      const rows = {};
      const paintAll = () => Object.entries(rows).forEach(([k, r]) => { r.style.borderColor = k === sel ? 'var(--accent)' : 'transparent'; r.style.background = k === sel ? 'var(--sidebar_active)' : 'var(--bg_input)'; });
      const list = h('div', { class: 'col', style: 'gap:6px;margin:8px 0' });
      opts.forEach(([k, name, desc, warnTxt]) => {
        const active = D.power_active === k;
        const r = h('div', { style: 'padding:10px 12px;border-radius:6px;cursor:pointer;border:2px solid transparent', onclick: () => { sel = k; paintAll(); } },
          h('div', { class: 'row' }, h('span', { class: 'f13 b tp', text: name }), active ? h('span', { class: 'f9 b c-ok', text: 'ACTIVE NOW', style: 'margin-left:8px' }) : null),
          h('div', { class: 'f11 ts', text: desc, style: 'white-space:normal;margin-top:2px' }),
          warnTxt ? h('div', { class: 'f11 b', text: warnTxt + (D.has_battery ? '  This PC has a battery.' : ''), style: 'color:var(--error);margin-top:2px' }) : null);
        rows[k] = r; list.append(r);
      });
      paintAll();
      return h('div', { class: 'modal', style: 'max-width:min(640px,92vw);width:min(640px,92vw)' },
        h('h3', { class: 'b', text: 'DWUT 1 Click - Step 4 of 5: Power mode' }),
        h('div', { class: 'f11 ts', style: 'white-space:normal', text: 'Want a performance power plan? It is switched on near the end of the run, after the repairs. You can undo it any time from Optimizer > Performance Plans.' }),
        list,
        h('div', { class: 'foot' }, Btn('Back', { variant: 'ghost', w: 90, onclick: () => close('back') }), Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }),
          Btn('Next', { w: 110, onclick: () => close(sel) })));
    });
  }

  function visualPopup() {
    return Modal.custom((close) => {
      const dlg = PerfOpts.build({
        embedded: true, state: { mode: 'dwut', fx: PerfOpts.preset('dwut') },
        onOk: (sel) => close(sel), onCancel: () => close(null), onBack: () => close('back'), onSkip: () => close('skip'),
      });
      return h('div', { class: 'modal', style: 'max-width:min(560px,94vw);width:min(560px,94vw)' },
        h('h3', { class: 'b', text: 'DWUT 1 Click - Step 5 of 5: Visual effects' }),
        h('div', { class: 'f11 ts', style: 'white-space:normal;margin-bottom:8px', text: 'The same settings as Windows\' Performance Options. "DWUT recommended" is picked for you. Applied after the tweaks; change it any time from Optimizer > Config Tools > Performance Options.' }),
        dlg.el);
    });
  }

  async function start() {
    Nav.go('dashboard');
    try { el.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch { /* not attached yet */ }
    if (running) return;
    if (!Nav.isAdmin) return fail('Administrator needed', 'The 1 Click Button changes system settings, so DWUT must run as Administrator.\nRestart DWUT as administrator and try again.');
    setStatus('Preparing…');
    let D;
    try { D = await rpc('oneclick.static'); } catch (e) { setStatus(''); return fail('Could not prepare', e.message); }
    setStatus('');
    if (D.running) return notify('Already running', 'A 1 Click run is already in progress.');
    let bloat = null, tweaks = null, sysopt = [], power = 'none', visual = null, stepNo = 1;
    for (;;) {
      if (stepNo === 1) { bloat = await bloatPopup(D); if (bloat === null) return; stepNo = 2; }
      else if (stepNo === 2) { const t = await tweakPopup(D); if (t === null) return; if (t === 'back') { stepNo = 1; continue; } tweaks = t; stepNo = 3; }
      else if (stepNo === 3) {
        if (!(D.sysopt && D.sysopt.length)) { stepNo = 4; continue; }
        const so = await sysoptPopup(D); if (so === null) return; if (so === 'back') { stepNo = 2; continue; } sysopt = so; stepNo = 4;
      }
      else if (stepNo === 4) { const p = await powerPopup(D); if (p === null) return; if (p === 'back') { stepNo = (D.sysopt && D.sysopt.length) ? 3 : 2; continue; } power = p; stepNo = 5; }
      else { const v = await visualPopup(); if (v === null) return; if (v === 'back') { stepNo = 4; continue; } visual = v === 'skip' ? null : v; break; }
    }
    const VN = { windows: 'Let Windows choose', appearance: 'Best appearance', performance: 'Best performance', dwut: 'DWUT recommended', custom: 'Custom' };
    const lines = ['Create a restore point', `Remove ${bloat.length} app(s)`, 'Clean + optimize all drives', 'Free + optimize RAM, CPU and GPU', 'Set every app to the high-performance GPU',
      `Apply ${tweaks.length} tweak(s)`, sysopt.length ? `Apply ${sysopt.length} TBOK-equivalent system optimization(s) - startup, services, system registry, bloat + tasks, settings for every user and new accounts, gaming${sysopt.includes('winget_update') ? ', app updates' : ''}` : null, visual ? `Visual effects: ${VN[visual.mode] || visual.mode} (${Object.values(visual.fx).filter(Boolean).length} of ${Object.keys(visual.fx).length} on)` : null,
      D.is_win11 ? 'Disable Windows Recall' : null, 'Extra safe cleanups', 'DISM, then SFC, then High CPU power repair',
      power !== 'none' ? `Enable ${power === 'extreme' ? 'Extreme' : 'Ultimate'} Performance power mode (and check that it really took effect)` : null,
      'Reset the network stack (internet blips once)'].filter(Boolean);
    const msg = `DWUT will now, in this order:\n\n` + lines.map((l, k) => `${k + 1}. ${l}`).join('\n') + `\n\n` +
      `It can take 20 - 60 minutes, mostly DISM and SFC. Keep the PC on and plugged in. You can keep using it, and you can stop it between steps.`;
    if (!(await Modal.confirm('Run the DWUT 1 Click Button?', msg, { yes: 'Start', no: 'Cancel' }))) return;
    out.clear(); buildSteps(null);
    let r;
    try { r = await rpc('oneclick.start', { bloat, tweaks, power, visual, sysopt }); } catch (e) { return fail('Could not start', e.message); }
    if (!r || !r.ok) return fail('Could not start', (r && r.error) || 'Unknown error');
    buildSteps(r.steps); setRunning(true);
  }

  function setStatus(m) { status.textContent = m; }
  function setRunning(on) {
    if (on) showDetail();
    running = on; stopBtn.style.display = on ? '' : 'none'; runBtn.disabled = on; runBtn.style.opacity = on ? .5 : 1;
    setStatus(on ? 'Running…' : '');
  }
  function paint(id, state, note) {
    const r = rows[id]; if (!r) return;
    const [ic, col] = STATE[state] || STATE.wait;
    r.ic.textContent = ic; r.ic.style.color = col; r.note.textContent = note || ''; r.note.style.color = state === 'fail' ? 'var(--error)' : state === 'warn' ? 'var(--warning)' : 'var(--text_secondary)';
    r.row.style.opacity = state === 'wait' ? .6 : 1;
  }
  function buildSteps(steps) {
    stepList.textContent = ''; rows = {}; total = steps ? steps.length : 0; pbar.set(0); plabel.textContent = '';
    (steps || []).forEach((s) => {
      const ic = h('span', { class: 'f13 b', style: 'width:22px;text-align:center;flex:none' }), note = h('span', { class: 'f10 ts ell', style: 'max-width:55%' });
      const row = h('div', { class: 'row', style: 'background:var(--bg_input);border-radius:5px;padding:6px 10px;gap:8px;align-items:center' }, ic, h('span', { class: 'f12 b tp grow ell', text: s.label }), note);
      rows[s.id] = { row, ic, note }; stepList.append(row); paint(s.id, s.state || 'wait', s.note);
    });
  }

  on('oneclick.log', (m) => out.line(String(m)));
  on('oneclick.step', (d) => {
    paint(d.id, d.state, d.note);
    pbar.set(d.state === 'run' ? d.idx / d.total : (d.idx + 1) / d.total);
    plabel.textContent = d.state === 'run' ? `Step ${d.idx + 1} of ${d.total}: ${d.label}` : plabel.textContent;
  });
  on('oneclick.done', (d) => {
    setRunning(false); pbar.set(1);
    const res = (d && d.results) || [], bad = res.filter((x) => x.state === 'fail' || x.state === 'warn');
    plabel.textContent = d && d.cancelled ? 'Stopped before finishing.' : `Finished - ${d.ok || 0} of ${d.total || res.length} steps fully succeeded.`;
    const body = (d && d.cancelled ? 'The run was stopped. Steps already done stay done.\n\n' : '') +
      `${d.ok || 0} of ${d.total || res.length} steps fully succeeded.` +
      (bad.length ? '\n\nNeeds a look:\n' + bad.slice(0, 8).map((x) => `• ${x.label}: ${x.note}`).join('\n') : '') +
      (d && d.restart_needed ? '\n\nRestart your PC to finish the tweaks, network reset and GPU settings.' : '');
    (bad.length ? warn : notify)('DWUT 1 Click finished', body);
  });

  const TIP_POINTS = [
    ['Debloat', 'removes the apps you pick'],
    ['Drives', 'safe cleanup, then TRIM / defrag'],
    ['RAM, CPU, GPU', 'free memory, un-park cores, shader caches'],
    ['Tweaks', 'the ones you confirm (never Xbox)'],
    ['System', 'TBOK-style switches, each one optional'],
    ['Recall', 'off on Windows 11'],
    ['Repair', 'DISM, SFC, High CPU power config'],
    ['Network', 'stack reset, done last'],
    ['GPU', 'every app on high performance'],
    ['Visuals', 'your choice of effects preset'],
    ['Power', 'Ultimate / Extreme, or keep yours'],
    ['Extras', 'update cache, Recycle Bin, clock sync'],
  ];
  const runBtn = Btn('RUN  DWUT 1 CLICK', { h: 34, cls: 'auto', style: { padding: '0 22px' }, bold: true, f: 13, onclick: () => start() });
  window.RichTip(runBtn, { head: 'DWUT 1 CLICK - the whole tune-up in one run', intro: 'You choose a few things in popups, DWUT does the rest in a safe order.', points: TIP_POINTS,
    foot: 'Restore point first. About 20 - 60 min. Needs Administrator. Click to start.' });
  const detail = h('div', { style: 'display:none;padding:0 12px 12px' }, pbar, plabel, stepList, h('div', { style: 'height:8px' }), out);
  const showDetail = () => { detail.style.display = ''; try { el.parentElement.style.gridTemplateColumns = '1fr'; } catch { /* not attached */ } };
  const el = Card([
    h('div', { class: 'row', style: 'padding:10px 12px 4px' }, h('span', { class: 'f13 b', text: 'DWUT 1 CLICK BUTTON' }), h('div', { class: 'grow' }), status),
    h('div', { class: 'f11 ts', style: 'padding:0 12px 8px;white-space:normal', text: 'Everything in one click, with more customizability than TBOK: you choose which apps to remove, which tweaks and system optimizations to apply, the power mode and visual effects - DWUT does the rest in a safe order.' }),
    h('div', { class: 'row', style: 'gap:8px;padding:4px 12px 12px' }, runBtn, stopBtn),
    detail], 'col', { minWidth: 0 });

  // when the page is opened while a run is going (tray start, page switch) show where it is
  async function resync() {
    try {
      const s = await rpc('oneclick.state');
      if (s.running) { buildSteps(s.steps); setRunning(true); out.clear(); s.log.forEach((l) => out.line(l)); }
    } catch { /* backend not ready */ }
  }
  return { el, start, onShow: resync };
} };
