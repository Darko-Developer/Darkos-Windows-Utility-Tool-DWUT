'use strict';
/* PerfOpts - DWUT's copy of Windows' "Performance Options" dialog (Visual Effects tab), plus one extra choice: "DWUT recommended".
   Shared by (1) the standalone window renderer/perfopts.html (opened from Optimizer > Config Tools > Performance Options) and
   (2) the 4th popup of the DWUT 1 CLICK BUTTON.  Plain DOM only, so it needs no other DWUT script.  Colours come from the CSS theme
   variables of whichever window it sits in, so it always matches the user's theme.

   PerfOpts.build({ effects:[[key,label],...], state:{mode,fx}, embedded, ...callbacks }) -> { el, getSel, setState, setBusy, setMessage }
     callbacks: onOk(sel)  onCancel()  onApply(sel)->Promise  onBack()  onSkip()  onOpenWindows()
   sel = { mode: 'windows'|'appearance'|'performance'|'dwut'|'custom', fx:{key:bool} } */
(function () {
  const DWUT_ON = ['peek', 'fade_menus', 'save_thumbnails', 'thumbnails', 'translucent_selection', 'window_contents_drag'];
  const EFFECTS = [
    ['animate_controls', 'Animate controls and elements inside windows'], ['animate_windows', 'Animate windows when minimizing and maximizing'],
    ['taskbar_animations', 'Animations in the taskbar'], ['peek', 'Enable Peek'], ['fade_menus', 'Fade or slide menus into view'],
    ['fade_tooltips', 'Fade or slide ToolTips into view'], ['fade_menu_items', 'Fade out menu items after clicking'],
    ['save_thumbnails', 'Save taskbar thumbnail previews'], ['cursor_shadow', 'Show shadows under mouse pointer'],
    ['window_shadows', 'Show shadows under windows'], ['thumbnails', 'Show thumbnails instead of icons'],
    ['translucent_selection', 'Show translucent selection rectangle'], ['window_contents_drag', 'Show window contents while dragging'],
    ['combo_slide', 'Slide open combo boxes'], ['font_smoothing', 'Smooth edges of screen fonts'], ['smooth_scroll', 'Smooth-scroll list boxes'],
    ['icon_label_shadows', 'Use drop shadows for icon labels on the desktop'],
  ];
  const RADIOS = [
    ['windows', "Let Windows choose what's best for my computer", 'Windows picks the effects for this PC (sets "Let Windows choose" and the default effects).'],
    ['appearance', 'Adjust for best appearance', 'Every visual effect on.'],
    ['performance', 'Adjust for best performance', 'Every visual effect off - the fastest, plainest look.'],
    ['dwut', 'DWUT recommended', 'Best performance, then the six effects that cost almost nothing and keep Windows pleasant to use are switched back on: Peek, fading menus, saved taskbar thumbnails, thumbnails instead of icons, the translucent selection rectangle and window contents while dragging.'],
    ['custom', 'Custom:', 'Tick exactly the effects you want.'],
  ];
  const preset = (name) => {
    const o = {};
    for (const [k] of EFFECTS) o[k] = name === 'performance' ? false : name === 'dwut' ? DWUT_ON.includes(k) : true;
    return o;
  };

  const CSS = `
.po{font:calc(12px*var(--fs,1)) var(--font,'Segoe UI',system-ui,sans-serif);color:var(--text_primary);display:flex;flex-direction:column;min-height:0;user-select:none}
.po *{box-sizing:border-box}
.po-tabs{display:flex;gap:2px;margin-bottom:-1px;position:relative;z-index:1}
.po-tab{padding:5px 11px;border:1px solid transparent;border-bottom:none;border-radius:6px 6px 0 0;background:none;color:var(--text_secondary);font:inherit;cursor:pointer}
.po-tab:hover{color:var(--text_primary);background:color-mix(in srgb,var(--bg_hover) 60%,transparent)}
.po-tab.on{background:color-mix(in srgb,var(--bg_card) 92%,transparent);border-color:var(--border);color:var(--text_primary);cursor:default}
.po-panel{border:1px solid var(--border);background:color-mix(in srgb,var(--bg_card) 92%,transparent);border-radius:0 8px 8px 8px;padding:14px;display:flex;flex-direction:column;min-height:0;flex:1}
.po-page{display:none;flex-direction:column;min-height:0;flex:1}.po-page.on{display:flex}
.po-desc{margin:0 0 12px;line-height:1.45;color:var(--text_primary)}
.po-radios{display:flex;flex-direction:column;gap:8px;margin-bottom:12px;flex:none}
.po-radio{display:flex;align-items:center;gap:9px;cursor:pointer;line-height:1.3}
.po-dot{width:16px;height:16px;border-radius:50%;border:1.6px solid var(--text_secondary);display:grid;place-items:center;flex:none;transition:border-color .12s}
.po-radio:hover .po-dot{border-color:var(--accent)}
.po-radio.on .po-dot{border-color:var(--accent)}.po-radio.on .po-dot::after{content:'';width:8px;height:8px;border-radius:50%;background:var(--accent)}
.po-new{font-size:.75em;font-weight:700;letter-spacing:.04em;color:var(--accent);background:var(--accent_subtle);border:1px solid color-mix(in srgb,var(--accent) 45%,transparent);border-radius:4px;padding:0 6px;margin-left:8px}
.po-radio.hl .po-lbl{font-weight:600}
.po-list{flex:1;min-height:150px;overflow-y:auto;background:color-mix(in srgb,var(--bg_input) 70%,transparent);border:1px solid var(--border);border-radius:5px;padding:5px 3px}
.po-item{display:flex;align-items:center;gap:9px;padding:4px 8px;border-radius:4px;cursor:pointer;line-height:1.25}
.po-item:hover{background:var(--bg_hover)}
.po-box{width:15px;height:15px;border:1.6px solid var(--text_secondary);border-radius:3px;display:grid;place-items:center;flex:none}
.po-item.on .po-box{background:var(--accent);border-color:var(--accent)}
.po-item.on .po-box::after{content:'';width:4px;height:8px;border:solid var(--text_on_accent,#fff);border-width:0 2px 2px 0;transform:rotate(45deg) translate(-1px,-1px)}
.po-foot{display:flex;gap:8px;align-items:center;justify-content:flex-end;padding-top:14px;flex:none}
.po-msg{flex:1;min-width:0;font-size:.92em;color:var(--text_secondary);white-space:normal;line-height:1.3}
.po-msg.err{color:var(--error)}.po-msg.ok{color:var(--success,var(--accent))}
.po-btn{min-width:82px;height:30px;padding:0 14px;border-radius:6px;border:1px solid var(--border);background:color-mix(in srgb,var(--bg_input) 60%,transparent);color:var(--text_primary);font:inherit;font-weight:600;cursor:pointer}
.po-btn:hover:not(:disabled){border-color:var(--accent)}.po-btn:disabled{opacity:.4;cursor:default}
.po-btn.pri{background:var(--accent);border-color:var(--accent);color:var(--text_on_accent,#fff)}
.po-note{line-height:1.5;color:var(--text_secondary);margin:4px 0 14px}
`;
  function injectCss() {
    if (document.getElementById('po-css')) return;
    const s = document.createElement('style'); s.id = 'po-css'; s.textContent = CSS; document.head.appendChild(s);
  }
  function el(tag, props, ...kids) {
    const n = document.createElement(tag);
    if (props) for (const [k, v] of Object.entries(props)) { if (k === 'class') n.className = v; else if (k === 'text') n.textContent = v; else if (k.startsWith('on')) n.addEventListener(k.slice(2), v); else n.setAttribute(k, v); }
    for (const c of kids) if (c) n.append(c);
    return n;
  }

  function build(o) {
    injectCss();
    const effects = o.effects && o.effects.length ? o.effects : EFFECTS;
    let mode = (o.state && o.state.mode) || 'dwut';
    let fx = Object.assign({}, preset('windows'), (o.state && o.state.fx) || preset('dwut'));
    let dirty = false, busy = false;
    const radios = {}, items = {};

    // ── Visual Effects page ──
    const rWrap = el('div', { class: 'po-radios' });
    RADIOS.forEach(([id, label, tip]) => {
      const r = el('div', { class: 'po-radio' + (id === 'dwut' ? ' hl' : ''), title: tip, onclick: () => choose(id) },
        el('span', { class: 'po-dot' }), el('span', { class: 'po-lbl', text: label }), id === 'dwut' ? el('span', { class: 'po-new', text: 'NEW' }) : null);
      radios[id] = r; rWrap.append(r);
    });
    const list = el('div', { class: 'po-list' });
    effects.forEach(([k, label]) => {
      const it = el('div', { class: 'po-item', onclick: () => { fx[k] = !fx[k]; mode = 'custom'; changed(); } }, el('span', { class: 'po-box' }), el('span', { text: label }));
      items[k] = it; list.append(it);
    });
    const vePage = el('div', { class: 'po-page on' },
      el('p', { class: 'po-desc', text: 'Select the settings you want to use for the appearance and performance of Windows on this computer.' }), rWrap, list);

    // ── the two other Windows tabs: unchanged Windows settings, so they hand over to the real dialog ──
    const other = (title) => el('div', { class: 'po-page' },
      el('p', { class: 'po-note', text: `${title} is not changed by DWUT - it is the same Windows setting, so it stays in Windows' own Performance Options window.` }),
      el('div', null, el('button', { class: 'po-btn', style: 'min-width:220px', text: "Open Windows' Performance Options", onclick: () => o.onOpenWindows && o.onOpenWindows() })));
    const pages = { ve: vePage, adv: other('Processor scheduling and virtual memory'), dep: other('Data Execution Prevention') };
    const tabs = {};
    const tabBar = el('div', { class: 'po-tabs' });
    [['ve', 'Visual Effects'], ['adv', 'Advanced'], ['dep', 'Data Execution Prevention']].forEach(([id, label]) => {
      if (o.embedded && id !== 've') return;
      const t = el('button', { class: 'po-tab' + (id === 've' ? ' on' : ''), text: label, onclick: () => showTab(id) });
      tabs[id] = t; tabBar.append(t);
    });
    function showTab(id) { for (const k of Object.keys(pages)) { pages[k].classList.toggle('on', k === id); if (tabs[k]) tabs[k].classList.toggle('on', k === id); } }

    // ── footer ──
    const msg = el('div', { class: 'po-msg' });
    const mk = (text, cls, fn) => el('button', { class: 'po-btn' + (cls ? ' ' + cls : ''), text, onclick: fn });
    const bOk = mk('OK', 'pri', () => { if (!busy) o.onOk && o.onOk(getSel()); });
    const bCancel = mk('Cancel', '', () => o.onCancel && o.onCancel());
    const bApply = mk('Apply', '', async () => {
      if (busy || !o.onApply) return;
      setBusy(true); setMessage('Applying…');
      try { await o.onApply(getSel()); dirty = false; } catch (e) { setMessage(String((e && e.message) || e), 'err'); }
      setBusy(false); sync();
    });
    const foot = el('div', { class: 'po-foot' });
    if (o.embedded) {
      foot.append(mk('Back', '', () => o.onBack && o.onBack()), mk('Skip this step', '', () => o.onSkip && o.onSkip()), msg, bOk, bCancel);
    } else foot.append(msg, bOk, bCancel, bApply);

    const root = el('div', { class: 'po' }, tabBar, el('div', { class: 'po-panel' }, vePage, pages.adv, pages.dep), foot);

    function choose(id) { mode = id; if (id !== 'custom') fx = Object.assign({}, fx, preset(id)); changed(); }
    function changed() { dirty = true; sync(); }
    function sync() {
      for (const [id, r] of Object.entries(radios)) r.classList.toggle('on', id === mode);
      for (const [k, it] of Object.entries(items)) it.classList.toggle('on', !!fx[k]);
      bApply.disabled = busy || !dirty;
    }
    function getSel() { return { mode, fx: Object.assign({}, fx) }; }
    function setState(st) { mode = st.mode || 'custom'; fx = Object.assign({}, fx, st.fx || {}); dirty = false; sync(); }
    function setBusy(b) { busy = b; for (const x of [bOk, bCancel]) x.disabled = b; sync(); }
    function setMessage(t, cls) { msg.textContent = t || ''; msg.className = 'po-msg' + (cls ? ' ' + cls : ''); }
    if (o.state && o.state.fx) fx = Object.assign({}, fx, o.state.fx);
    sync();
    return { el: root, getSel, setState, setBusy, setMessage, markClean() { dirty = false; sync(); } };
  }

  window.PerfOpts = { EFFECTS, DWUT_ON, preset, build, injectCss };
})();
