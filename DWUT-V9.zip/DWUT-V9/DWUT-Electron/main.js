'use strict';
/**
 * DWUT — Electron main process v9.0
 *  - supervises the Python backend (untouched modules/) over stdin/stdout JSON lines
 *  - offers to relaunch as Administrator (same wording as the original app)
 *  - frameless window: custom title bar lives in the renderer
 *  - system tray: closing the window hides it (Discord-style); tray icon with context menu
 *  - creates a startup shortcut on first run so DWUT launches with Windows
 */
const { app, BrowserWindow, ipcMain, dialog, shell, screen, Tray, Menu, nativeImage, globalShortcut, webContents, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const cp = require('child_process');
const readline = require('readline');
const os = require('os');

const MIN_W = 900, MIN_H = 630, DEF_W = 960, DEF_H = 700;
const localBackend = path.join(__dirname, 'backend');
const bundledBackend = path.join(process.resourcesPath || '', 'backend');
const runFromFolder = fs.existsSync(path.join(localBackend, 'server.py'));
const backendDir = runFromFolder ? localBackend : bundledBackend;

let win = null;
let tmWin = null;   // Task Manager window
const termWins = new Set();   // custom Command Prompt / PowerShell windows
let runWin = null;  // Run window (Win+R)
let perfWin = null; // DWUT's own Performance Options window
let tray = null;
let backend = null;
let backendReady = false;
let nextId = 1;
const pending = new Map();
let shuttingDown = false;
let backendLog = null;
const START_ARG = '--startup';                        // passed by the Windows-startup entry: start quietly in the tray
const startedAtLogin = process.argv.includes(START_ARG);
const TASK_NAME = 'DWUT Startup';
const SHOW_FLAG = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'DWUT', 'show.signal');
let isQuitting = false;   // set to true only when the user picks "Exit" from tray
let _vpnConnected = false;

// -- resilience: logging, crash recovery, GPU safe-mode, low-end detection -------------------------------------
const DWUT_DATA = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'DWUT');
const GPU_FLAG = path.join(DWUT_DATA, 'disable_gpu.flag');
function elog(...a) {
  try {
    fs.mkdirSync(path.join(DWUT_DATA, 'logs'), { recursive: true });
    const f = path.join(DWUT_DATA, 'logs', 'electron.log');
    try { if (fs.statSync(f).size > 1024 * 1024) fs.renameSync(f, f + '.old'); } catch { /* no log yet */ }
    fs.appendFileSync(f, `${new Date().toISOString()} ${a.map((x) => (x && x.stack) || (typeof x === 'string' ? x : JSON.stringify(x))).join(' ')}\n`);
  } catch { /* logging must never throw */ }
}
function lowEndInfo() {
  const cpus = os.cpus() || [], model = ((cpus[0] && cpus[0].model) || '').toLowerCase();
  const memGB = os.totalmem() / 1024 ** 3;
  const weakModel = /pentium|celeron|atom|\bn[0-9]{3,4}\b|\bj[0-9]{4}\b|\bn[0-9]{4}\b/.test(model);
  return { lowEnd: cpus.length <= 2 || memGB <= 4.5 || weakModel, cores: cpus.length, memGB: Math.round(memGB * 10) / 10, model: (cpus[0] && cpus[0].model) || '' };
}
// If the GPU process has crashed repeatedly on this machine (old Intel iGPUs / bad drivers), run without it from now on.
if (fs.existsSync(GPU_FLAG)) { try { app.disableHardwareAcceleration(); elog('GPU safe-mode ON (flag present)'); } catch { /* ignore */ } }
process.on('uncaughtException', (e) => { elog('uncaughtException', e); });      // a stray error must not take the whole app down
process.on('unhandledRejection', (e) => { elog('unhandledRejection', e); });
let _gpuCrashes = 0;
const _reloads = [];
app.on('child-process-gone', (_e, d) => {
  elog('child-process-gone', d);
  if (d.type === 'GPU' && d.reason !== 'clean-exit' && ++_gpuCrashes >= 2) {
    try { fs.mkdirSync(DWUT_DATA, { recursive: true }); fs.writeFileSync(GPU_FLAG, new Date().toISOString()); elog('GPU safe-mode armed for next start'); } catch { /* ignore */ }
  }
});
app.on('render-process-gone', (_e, wc, d) => {
  elog('render-process-gone', d);
  if (d.reason === 'clean-exit' || d.reason === 'killed' && isQuitting) return;
  const now = Date.now();
  while (_reloads.length && now - _reloads[0] > 60000) _reloads.shift();
  if (_reloads.length >= 3) return;                                              // don't loop forever
  _reloads.push(now);
  setTimeout(() => { try { if (!wc.isDestroyed()) wc.reload(); } catch (e) { elog('reload failed', e); } }, 400);
});


// ── helpers ──────────────────────────────────────────────────────────────────
function isAdmin() {
  if (process.platform !== 'win32') return true;
  try { cp.execFileSync('fltmc', [], { stdio: 'ignore', windowsHide: true }); return true; }
  catch { return false; }
}

function readConfig() {
  const appdata = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const candidates = [path.join(backendDir, 'settings', 'config.json'), path.join(appdata, 'DWUT', 'settings', 'config.json')];
  for (const f of candidates) {
    try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { /* next */ }
  }
  return {};
}

function findPython() {
  const local = process.env.LOCALAPPDATA || '';
  const list = [];
  if (process.env.DWUT_PYTHON) list.push([process.env.DWUT_PYTHON, []]);
  try {
    const recorded = fs.readFileSync(path.join(local, 'DWUT', 'python_path.txt'), 'utf8').trim();
    if (recorded) list.push([recorded, []]);
  } catch { /* none */ }
  list.push([path.join(local, 'DWUT', 'python', 'python.exe'), []]);
  list.push(['py', ['-3']]);
  list.push(['python', []]);
  list.push(['python3', []]);
  for (const [exe, pre] of list) {
    try {
      if (path.isAbsolute(exe) && !fs.existsSync(exe)) continue;
      const r = cp.spawnSync(exe, [...pre, '-c', 'import sys;print(sys.version_info[:2]>=(3,10))'],
        { encoding: 'utf8', windowsHide: true, timeout: 15000 });
      if (r.status === 0 && /True/.test(r.stdout)) return [exe, pre];
    } catch { /* next */ }
  }
  return null;
}

// ── start with Windows ───────────────────────────────────────────────────────
// Preferred: a Scheduled Task that runs at sign-in with the highest privileges - DWUT then starts ELEVATED without a
// UAC prompt every boot (the VPN auto-connect and most tools need admin).  Creating that needs admin, so when DWUT is
// not elevated we fall back to a normal Startup-folder shortcut.  Both start DWUT hidden in the tray (--startup).
const _startupDir = () => path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
const _startupLnk = () => path.join(_startupDir(), 'DWUT.lnk');
const _APPROVED = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\StartupFolder';
const _xml = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const _sch = (args, timeout = 15000) => cp.spawnSync('schtasks', args, { encoding: 'utf8', windowsHide: true, timeout });

function createStartupTask() {
  const d = shortcutDetails(true);
  const user = `${process.env.USERDOMAIN || process.env.COMPUTERNAME || ''}\\${process.env.USERNAME || ''}`;
  const xml = `<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>Starts DWUT when you sign in</Description></RegistrationInfo>
  <Triggers><LogonTrigger><Enabled>true</Enabled><UserId>${_xml(user)}</UserId><Delay>PT8S</Delay></LogonTrigger></Triggers>
  <Principals><Principal id="Author"><UserId>${_xml(user)}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Enabled>true</Enabled>
  </Settings>
  <Actions Context="Author"><Exec><Command>${_xml(d.target)}</Command><Arguments>${_xml(d.args)}</Arguments><WorkingDirectory>${_xml(d.cwd)}</WorkingDirectory></Exec></Actions>
</Task>`;
  const tmp = path.join(os.tmpdir(), `dwut_task_${process.pid}.xml`);
  try {
    fs.writeFileSync(tmp, Buffer.concat([Buffer.from([0xFF, 0xFE]), Buffer.from(xml, 'utf16le')]));
    const r = _sch(['/Create', '/TN', TASK_NAME, '/XML', tmp, '/F']);
    return r.status === 0;
  } catch (e) { console.error('startup task failed:', e.message); return false; }
  finally { try { fs.unlinkSync(tmp); } catch { /* ignore */ } }
}

function createStartupShortcut() {
  try {
    fs.mkdirSync(_startupDir(), { recursive: true });
    const lnk = _startupLnk();
    shell.writeShortcutLink(lnk, fs.existsSync(lnk) ? 'replace' : 'create', shortcutDetails(true));
    return fs.existsSync(lnk);
  } catch (e) { console.error('startup shortcut failed:', e.message); return false; }
}

function removeStartupShortcut() { try { fs.unlinkSync(_startupLnk()); } catch { /* not there */ } }
function clearStartupDisabledFlag() { try { cp.spawnSync('reg', ['delete', _APPROVED, '/v', 'DWUT.lnk', '/f'], { windowsHide: true, timeout: 8000 }); } catch { /* ignore */ } }

// Is DWUT set to start with Windows - and is that entry actually switched ON (Task Manager > Startup can disable it)?
function startupState() {
  const out = { registered: false, enabled: false, via: '' };
  if (process.platform !== 'win32') return out;
  try {
    const t = _sch(['/Query', '/TN', TASK_NAME, '/XML'], 8000);
    if (t.status === 0 && /<Task/i.test(t.stdout || '')) {
      out.registered = true; out.via = 'task';
      out.enabled = !/<Settings>[\s\S]*?<Enabled>\s*false\s*<\/Enabled>/i.test(t.stdout);
      if (out.enabled) return out;
    }
  } catch { /* fall through to the shortcut */ }
  try {
    if (fs.existsSync(_startupLnk())) {
      let enabled = true;
      const r = cp.spawnSync('reg', ['query', _APPROVED, '/v', 'DWUT.lnk'], { encoding: 'utf8', windowsHide: true, timeout: 8000 });
      const m = r.status === 0 && /REG_BINARY\s+([0-9A-Fa-f]{2})/.exec(r.stdout || '');
      if (m) enabled = (parseInt(m[1], 16) & 1) === 0;          // 02/06 = on, 03/07 = switched off in Task Manager
      if (!out.registered) { out.registered = true; out.via = 'shortcut'; out.enabled = enabled; }
      else out.enabled = out.enabled || enabled;
    }
  } catch { /* ignore */ }
  return out;
}

function enableStartup() {
  if (process.platform !== 'win32') return false;
  let ok = false;
  if (isAdmin()) { ok = createStartupTask(); if (ok) removeStartupShortcut(); }
  if (!ok) ok = createStartupShortcut();
  if (ok) clearStartupDisabledFlag();
  return ok && startupState().enabled;
}

function disableStartup() {
  try { _sch(['/Delete', '/TN', TASK_NAME, '/F']); } catch { /* none */ }
  removeStartupShortcut();
  return !startupState().registered;
}
const ensureStartupShortcut = () => enableStartup();      // old name, still used by the first-run prompt

// What a DWUT shortcut must look like: the runtime + the app folder as ONE quoted argument.
function shortcutDetails(startup) {
  const target = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
  const unpackaged = !process.env.PORTABLE_EXECUTABLE_FILE && !app.isPackaged;
  const ico = path.join(__dirname, 'renderer', 'icon.ico');
  return {
    target,
    args: [unpackaged ? `"${app.getAppPath()}"` : '', startup ? START_ARG : ''].filter(Boolean).join(' '),
    cwd: unpackaged ? app.getAppPath() : path.dirname(target),
    description: "Darko's Windows Utility Tool",
    appUserModelId: 'tool.darko.dwut',
    icon: fs.existsSync(ico) ? ico : target, iconIndex: 0,
  };
}

// Older versions wrote shortcuts whose arguments were lost (-> Electron's default window opened instead of DWUT).
// Fix every DWUT shortcut we can find, every start.
function repairShortcuts() {
  if (process.platform !== 'win32') return;
  try {
    const want = shortcutDetails();
    const places = [
      path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'DWUT.lnk'),
      path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'DWUT.lnk'),
      path.join(app.getPath('desktop'), 'DWUT.lnk'),
      path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'Desktop', 'DWUT.lnk'),
    ];
    for (const lnk of places) {
      if (!fs.existsSync(lnk)) continue;
      let cur;
      try { cur = shell.readShortcutLink(lnk); } catch { continue; }
      const isStartupLnk = /\\Startup\\DWUT\.lnk$/i.test(lnk);
      const wantHere = isStartupLnk ? shortcutDetails(true) : want;
      const sameTarget = (cur.target || '').toLowerCase() === want.target.toLowerCase();
      const looksOurs = sameTarget || /dwut|electron/i.test(cur.target || '');
      if (!looksOurs) continue;
      if (!sameTarget || (cur.args || '').trim() !== wantHere.args.trim() || (cur.cwd || '') === '') {
        try { shell.writeShortcutLink(lnk, 'update', { ...wantHere, icon: cur.icon || want.icon, iconIndex: cur.iconIndex || 0 }); }
        catch (e) { console.error('shortcut repair failed:', lnk, e.message); }
      }
    }
  } catch (e) { console.error('repairShortcuts:', e.message); }
}

// on DWUT's taskbar button pins THIS shortcut (with the right target) instead of a bare electron.exe.
function ensureStartMenuShortcut() {
  if (process.platform !== 'win32') return;
  try {
    const dir = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs');
    const lnk = path.join(dir, 'DWUT.lnk');
    const marker = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'DWUT', 'startmenu_shortcut_created.txt');
    const target = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;   // the portable build unpacks to a temp dir
    const args = app.isPackaged ? '' : `"${app.getAppPath()}"`;
    const ico = path.join(__dirname, 'renderer', 'icon.ico');
    const details = {
      target, args, cwd: path.dirname(target),
      description: "Darko's Windows Utility Tool",
      appUserModelId: 'tool.darko.dwut',
      icon: (!app.isPackaged && fs.existsSync(ico)) ? ico : target, iconIndex: 0,
    };
    const exists = fs.existsSync(lnk);
    if (!exists && fs.existsSync(marker)) return;            // created before; the user deleted it on purpose
    let needsWrite = !exists;
    if (exists) {                                            // repair it if DWUT was moved / updated
      try {
        const cur = shell.readShortcutLink(lnk);
        needsWrite = cur.target.toLowerCase() !== target.toLowerCase() || (cur.args || '') !== args || cur.appUserModelId !== details.appUserModelId;
      } catch { needsWrite = true; }
    }
    if (needsWrite) {
      fs.mkdirSync(dir, { recursive: true });
      shell.writeShortcutLink(lnk, exists ? 'replace' : 'create', details);
    }
    fs.mkdirSync(path.dirname(marker), { recursive: true });
    fs.writeFileSync(marker, new Date().toISOString());
  } catch (e) {
    console.error('Failed to create Start Menu shortcut:', e.message);
  }
}

// The installer may have put the Desktop shortcut on a different account's desktop (UAC with another admin) or it was
// deleted/never made: DWUT keeps one for the user who is actually running it.  Made once; deleting it later sticks.
function ensureDesktopShortcut() {
  if (process.platform !== 'win32') return;
  try {
    const lnk = path.join(app.getPath('desktop'), 'DWUT.lnk');
    const marker = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'DWUT', 'desktop_shortcut_created.txt');
    if (fs.existsSync(lnk) || fs.existsSync(marker)) return;
    shell.writeShortcutLink(lnk, 'create', shortcutDetails());
    fs.mkdirSync(path.dirname(marker), { recursive: true });
    fs.writeFileSync(marker, new Date().toISOString());
  } catch (e) { console.error('desktop shortcut:', e.message); }
}

function startupShortcutPath() {
  return path.join(os.homedir(), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'DWUT.lnk');
}

// ── backend ──────────────────────────────────────────────────────────────────
function startBackend() {
  const py = findPython();
  if (!py) {
    dialog.showErrorBox('Python not found',
      'DWUT needs Python 3.10 or newer.\n\nRun the DWUT bootstrap (bootstrap.ps1) or install Python from python.org, then start DWUT again.');
    app.quit();
    return false;
  }
  if (!fs.existsSync(path.join(backendDir, 'server.py'))) {
    dialog.showErrorBox('DWUT backend missing', `Could not find backend\\server.py in:\n${backendDir}\n\nRe-run bootstrap.ps1 to reinstall.`);
    app.quit();
    return false;
  }
  const [exe, pre] = py;
  const logDir = path.join(process.env.APPDATA || '.', 'DWUT', 'logs');
  try { fs.mkdirSync(logDir, { recursive: true }); backendLog = fs.createWriteStream(path.join(logDir, 'electron-backend.log'), { flags: 'a' }); } catch { /* ignore */ }

  backend = cp.spawn(exe, [...pre, '-u', path.join(backendDir, 'server.py')], {
    cwd: backendDir,
    windowsHide: true,
    stdio: ['pipe', 'pipe', 'pipe'],
    env: { ...process.env, PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1', PYTHONDONTWRITEBYTECODE: '1' },
  });

  backend.on('error', (err) => {
    dialog.showErrorBox('DWUT could not start its Python backend',
      `${err.message}\n\nPython: ${exe}\nBackend: ${backendDir}\n\nRe-run bootstrap.ps1 to repair the install.`);
    app.exit(1);
  });
  const rl = readline.createInterface({ input: backend.stdout, crlfDelay: Infinity });
  rl.on('line', (line) => {
    let msg;
    try { msg = JSON.parse(line); } catch { return; }
    if (msg.event) {
      if (msg.event === 'backend.ready') {
        backendReady = true;
        refreshVpnLive(false).then(() => { if (tray) rebuildTrayMenu(); });
        // Auto-connect VPN on startup if configured
        callBackend('vpn.autostart_get', {}).then((enabled) => {
          if (enabled) {
            setTimeout(() => {
              callBackend('vpn.connect', { opts: {} }).catch(() => {});
            }, 2000);
          }
        }).catch(() => {});
      }
      // Ctrl+Shift+Esc (low-level hook in the backend) -> our Task Manager
      if (msg.event === 'app.open_taskmgr') { openTaskManager(); return; }
      // Win+R (low-level hook in the backend) -> our Run window
      if (msg.event === 'app.open_run') { openRunWindow(); return; }
      // terminal output goes ONLY to the window that owns the session (never broadcast to the main window)
      if (msg.event === 'term.data' || msg.event === 'term.exit') {
        try {
          const wc = msg.data && webContents.fromId(msg.data.wid);
          if (wc && !wc.isDestroyed()) wc.send(msg.event === 'term.data' ? 'term:data' : 'term:exit', msg.data.sid, msg.event === 'term.data' ? msg.data.data : msg.data.code);
        } catch { /* window closed */ }
        return;
      }
      if (msg.event === 'oneclick.done') {
        const d = msg.data || {};
        trayNotify('DWUT 1 Click', d.cancelled ? 'Stopped before finishing.' : `Finished - ${d.ok || 0} of ${d.total || 0} steps fully succeeded.` + (d.restart_needed ? ' Restart your PC to finish.' : ''));
      }
      if (msg.event === 'cleaner.done' && _quickRun) {
        trayNotify(_quickRun === 'repair' ? 'Quick SFC / DISM' : 'Quick Clean', msg.data && msg.data.completed ? 'Finished.' : 'Stopped before finishing.');
        _quickRun = null;
      }
      // Update tray menu when VPN state changes
      if (msg.event === 'vpn.state' && msg.data) {
        updateTrayVpnState(msg.data);
      }

      if (win && !win.isDestroyed()) win.webContents.send('backend:event', msg.event, msg.data);
      if (msg.event === 'cosmetics.audio') {                       // music-reactive backgrounds also in the Task Manager + Run window
        for (const w2 of [tmWin, runWin, perfWin, ...termWins]) { try { if (w2 && !w2.isDestroyed() && w2.isVisible()) w2.webContents.send('cosmetics:audio', (msg.data && msg.data.level) || 0, !!(msg.data && msg.data.beat), (msg.data && msg.data.s) || 1, (msg.data && msg.data.t) || 0); } catch { /* window closing */ } }
      }
    } else if (msg.id != null) {
      const p = pending.get(msg.id);
      if (p) {
        pending.delete(msg.id);
        if (msg.error) p.reject(new Error(msg.error)); else p.resolve(msg.result);
      }
    }
  });
  backend.stderr.on('data', (d) => { if (backendLog) backendLog.write(d); });
  backend.on('exit', (code) => {
    backendReady = false;
    for (const [, p] of pending) p.reject(new Error('Backend stopped'));
    pending.clear();
    if (!shuttingDown && win && !win.isDestroyed()) {
      win.webContents.send('backend:event', 'backend.crashed', { code });
      setTimeout(() => { if (!shuttingDown) startBackend(); }, 800);
    }
  });
  return true;
}

function callBackend(method, params) {
  return new Promise((resolve, reject) => {
    if (!backend || !backend.stdin.writable) return reject(new Error('Backend not running'));
    const id = nextId++;
    pending.set(id, { resolve, reject });
    backend.stdin.write(JSON.stringify({ id, method, params: params || {} }) + '\n');
  });
}

async function stopBackend() {
  shuttingDown = true;
  if (!backend) return;
  try { backend.stdin.write(JSON.stringify({ method: 'backend.shutdown' }) + '\n'); backend.stdin.end(); } catch { /* ignore */ }
  await new Promise((r) => {
    const t = setTimeout(() => { try { backend.kill(); } catch { /* ignore */ } r(); }, 2500);
    backend.once('exit', () => { clearTimeout(t); r(); });
  });
}

// ── tray ─────────────────────────────────────────────────────────────────────

// -- VPN state for the tray.  The tray never trusts a cached flag: every time the menu is opened it asks the backend for the REAL
//    state (tunnel service running + traffic really leaving through it).  Events and a slow poll only keep the tooltip fresh.
let _vpnLive = { on: false, status: 'off', busy: false, server: '', latency: null, can_switch: false };
let _trayMenu = null;
let _quickRun = null;      // 'clean' | 'repair' while a tray-started run is going (to notify when it ends)

function updateTrayVpnState(s) {                       // from the 'vpn.state' event
  _vpnLive = { on: !!s.on, status: s.status || (s.on ? 'connected' : 'off'), busy: !!s.busy, server: s.server_name || '', latency: s.latency == null ? null : s.latency,
               can_switch: !!s.on && !s.busy };
  _vpnConnected = _vpnLive.on;
  updateTrayTooltip();
  vpnTrayDone(s);
  if (tray) rebuildTrayMenu();
}

// A tray-started VPN action (connect / disconnect / reconnect / switch) tells you how it ended - the menu closes, so nothing else would.
let _vpnPending = null;                                  // { what, seenBusy }
function vpnTrayStart(what, ok) {
  if (ok) _vpnPending = { what, seenBusy: false };
  else trayNotify('VPN', 'The VPN is busy with another step - try again in a few seconds.');
}
function vpnTrayDone(s) {
  if (!_vpnPending) return;
  if (s.busy) { _vpnPending.seenBusy = true; return; }
  if (!_vpnPending.seenBusy) return;
  const what = _vpnPending.what; _vpnPending = null;
  const note = (s.notes || []).filter(Boolean)[0];
  let msg;
  if (what === 'disconnect') msg = s.on ? 'The VPN is still on.' : 'VPN disconnected.';
  else if (what === 'switch') msg = note || (s.on ? 'Switched server.' : 'The VPN was turned off so your internet keeps working.');
  else msg = s.on ? `VPN connected${s.server_name ? ' - ' + s.server_name : ''}.` : (note || 'The VPN could not connect.');
  trayNotify('VPN', msg);
}

async function refreshVpnLive(deep = true, timeoutMs = 2500) {
  try {
    const r = await Promise.race([callBackend('vpn.live', { deep }), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), timeoutMs))]);
    if (r && typeof r === 'object') { _vpnLive = r; _vpnConnected = !!r.on; }
  } catch { /* keep the last known state */ }
  updateTrayTooltip();
  return _vpnLive;
}

function updateTrayTooltip() {
  if (!tray) return;
  try { tray.setToolTip(`Darko's Windows Utility Tool - VPN ${_vpnLive.on ? 'ON' : 'OFF'}`); } catch { /* tray gone */ }
}

function trayNotify(title, content) {
  try { if (tray && tray.displayBalloon) tray.displayBalloon({ title, content, iconType: 'info' }); } catch { /* not supported */ }
}

function vpnTrayItems() {
  const v = _vpnLive;
  const words = { connecting: 'connecting...', switching: 'finding a better server...', reconnecting: 'reconnecting...', degraded: 'connection lost', not_protecting: 'tunnel is up but NOT protecting you', working: 'working...' };
  let label;
  if (v.busy) label = `VPN: ${words[v.status] || 'working...'}`;
  else if (v.on) label = `VPN: ON${v.server ? ' - ' + v.server : ''}${v.latency != null ? ` (${v.latency} ms)` : ''}`;
  else label = `VPN: ${words[v.status] || 'OFF'}`;
  const needsReconnect = !v.on && ['not_protecting', 'degraded', 'reconnecting'].includes(v.status);
  const toggleLabel = v.on ? 'Disconnect VPN' : needsReconnect ? 'Reconnect VPN' : 'Connect VPN';
  const items = [
    { label, enabled: false },
    {
      label: toggleLabel, enabled: !v.busy,
      click: async () => {
        const f = await refreshVpnLive(false, 1500);       // act on the REAL state at click time, not on what the menu showed when it was built
        if (f.busy) return trayNotify('VPN', 'The VPN is busy with another step - try again in a few seconds.');
        const reconnect = !f.on && ['not_protecting', 'degraded', 'reconnecting'].includes(f.status);
        let ok;
        if (f.on) { ok = await callBackend('vpn.disconnect', {}).catch(() => false); vpnTrayStart('disconnect', ok); }
        else if (reconnect) { ok = await callBackend('vpn.reconnect', {}).catch(() => false); vpnTrayStart('reconnect', ok); }
        else { ok = await callBackend('vpn.connect', { opts: {} }).catch(() => false); vpnTrayStart('connect', ok); }
        setTimeout(() => refreshVpnLive(false).then(() => { if (tray) rebuildTrayMenu(); }), 1500);
      },
    },
    {
      label: 'Switch server', enabled: !!v.can_switch && !v.busy,
      click: async () => {
        const f = await refreshVpnLive(false, 1500);
        if (!f.on) return trayNotify('VPN', 'Connect to the VPN first, then you can switch servers.');
        if (f.busy) return trayNotify('VPN', 'The VPN is busy with another step - try again in a few seconds.');
        const ok = await callBackend('vpn.change_server', {}).catch(() => false);
        vpnTrayStart('switch', ok);
        if (ok) trayNotify('VPN', 'Finding a faster server - this takes a few seconds...');
      },
    },
  ];
  if (!v.on && !v.busy && ['not_protecting', 'degraded', 'reconnecting'].includes(v.status)) {
    items.push({
      label: 'Restore internet (turn VPN off)',
      click: async () => {
        await callBackend('vpn.panic', {}).catch(() => {});
        await refreshVpnLive(false);
        if (tray) rebuildTrayMenu();
        trayNotify('VPN', 'All VPN rules removed - your normal internet is back.');
      },
    });
  }
  return items;
}

function rebuildTrayMenu() {
  if (!tray) return;
  const menu = Menu.buildFromTemplate([
    {
      label: 'Open DWUT',
      click: () => showWindow(),
    },
    {
      label: 'Task Manager',
      click: () => openTaskManager(),
    },
    { label: 'Command Prompt', click: () => openTerminal('cmd') },
    { label: 'PowerShell', click: () => openTerminal('powershell') },
    { type: 'separator' },
    ...vpnTrayItems(),
    { type: 'separator' },
    {
      label: 'DWUT 1 CLICK BUTTON',
      click: () => {
        // Opens the Dashboard and its three popups (apps to remove, tweaks to apply, power mode). Nothing runs until you confirm.
        showWindow();
        if (!win || win.isDestroyed()) return;
        const go = () => win.webContents.executeJavaScript(
          "(function(){try{Nav.go('dashboard');var p=Nav.pages&&Nav.pages.dashboard&&Nav.pages.dashboard.oneclick;if(p&&p.start){p.start();return true;}}catch(e){}return false;})()"
        ).catch(() => false);
        go().then((ok) => { if (!ok) setTimeout(go, 600); });
      },
    },
    {
      label: 'TBOK (CORPORATE AND BUSINESS)',
      click: () => {
        // Opens the Dashboard and shows the "who is this for" warning popup first. TBOK only runs if they press Continue.
        showWindow();
        if (!win || win.isDestroyed()) return;
        const go = () => win.webContents.executeJavaScript(
          "(function(){try{Nav.go('dashboard');var p=Nav.pages&&Nav.pages.dashboard&&Nav.pages.dashboard.tbok;if(p&&p.start){p.start();return true;}}catch(e){}return false;})()"
        ).catch(() => false);
        go().then((ok) => { if (!ok) setTimeout(go, 600); });
      },
    },
    {
      label: 'Quick Optimize',
      click: async () => {
        try {
          await callBackend('system.quick_optimize', {});
        } catch (e) {
          console.error('Quick optimize failed:', e.message);
        }
      },
    },
    {
      label: 'Quick Clean',
      click: async () => {
        _quickRun = 'clean';
        const r = await callBackend('cleaner.quick', { kind: 'clean' }).catch(() => null);
        if (r && r.ok) trayNotify('Quick Clean', 'Started - it runs in the background and will tell you when it is done.');
        else { _quickRun = null; trayNotify('Quick Clean', 'A clean is already running.'); }
      },
    },
    {
      label: 'Quick SFC / DISM',
      click: async () => {
        _quickRun = 'repair';
        const r = await callBackend('cleaner.quick', { kind: 'repair' }).catch(() => null);
        if (r && r.ok) trayNotify('Quick SFC / DISM', 'Started in the background.');
        else { _quickRun = null; trayNotify('Quick SFC / DISM', 'A clean is already running.'); }
      },
    },
    {
      label: 'Quick Game Boost',
      click: () => {
        // Opens the SAME "choose what to close" popup as the Boost button in the Gaming page, so apps like Discord or
        // browsers are never closed without the user ticking them.  Nothing is applied until they press Apply Boost.
        showWindow();
        if (!win || win.isDestroyed()) return;
        const go = () => win.webContents.executeJavaScript(
          "(function(){try{Nav.go('gaming');var p=Nav.pages&&Nav.pages.gaming;if(p&&p.openBoost){p.openBoost();return true;}}catch(e){}return false;})()"
        ).catch(() => false);
        // the renderer may still be loading if the app started hidden in the tray - retry briefly
        go().then((ok) => { if (!ok) setTimeout(go, 600); });
      },
    },
    {
      label: 'Network Monitor',
      click: () => { showWindow(); if (win) win.webContents.executeJavaScript('Nav.go("network")').catch(()=>{}); },
    },
    { type: 'separator' },
    {
      label: 'Exit',
      click: () => {
        isQuitting = true;
        gracefulClose();
      },
    },
  ]);
  _trayMenu = menu;
}

function showWindow() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function createTray() {
  const iconPath = path.join(__dirname, 'renderer', 'icon.png');
  let icon;
  try {
    icon = nativeImage.createFromPath(iconPath);
    if (icon.isEmpty()) {
      // create a simple 16x16 icon from scratch if file not found
      icon = nativeImage.createEmpty();
    }
  } catch {
    icon = nativeImage.createEmpty();
  }

  tray = new Tray(icon);
  tray.setToolTip("Darko's Windows Utility Tool");
  rebuildTrayMenu();

  tray.on('double-click', () => showWindow());
  tray.on('click', () => showWindow());
  tray.on('right-click', async () => {
    // Ask the backend for the REAL VPN state first (fast, non-deep, max 0.7 s) so the menu that opens is correct -
    // the old code opened the last-known menu and rebuilt it behind the open popup, so you could click a stale item.
    await refreshVpnLive(false, 700).catch(() => {});
    rebuildTrayMenu();
    if (_trayMenu && tray) tray.popUpContextMenu(_trayMenu);
  });

  // Keep VPN state fresh: lightweight poll every 20 s
  setInterval(() => { refreshVpnLive(false, 1500).then(() => { if (tray) rebuildTrayMenu(); }).catch(() => {}); }, 20000);
}

// ── window ───────────────────────────────────────────────────────────────────
function createWindow() {
  const cfg = readConfig();
  const wa = screen.getPrimaryDisplay().size;
  let w = Math.max(parseInt(cfg.window_width || DEF_W, 10), MIN_W);
  let h = Math.max(parseInt(cfg.window_height || DEF_H, 10), MIN_H);
  w = Math.min(w, Math.max(wa.width - 40, MIN_W));
  h = Math.min(h, Math.max(wa.height - 40, MIN_H));
  const x = Math.max(Math.floor((wa.width - w) / 2), 0);
  const y = Math.max(Math.floor((wa.height - h) / 2), 0);

  win = new BrowserWindow({
    x, y, width: w, height: h, minWidth: MIN_W, minHeight: MIN_H,
    frame: false, show: false, backgroundColor: '#0D0F12',
    title: "Darko's Windows Utility Tool",
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: false,
      spellcheck: false, backgroundThrottling: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.on('unresponsive', () => { elog('main window unresponsive'); setTimeout(() => { try { if (win && !win.isDestroyed() && !win.webContents.isLoading()) win.webContents.reload(); } catch { /* ignore */ } }, 20000); });
  win.webContents.on('did-fail-load', (_e, code, desc, url) => { elog('did-fail-load', code, desc, url); if (code !== -3) setTimeout(() => { try { win.loadFile(path.join(__dirname, 'renderer', 'index.html')); } catch { /* ignore */ } }, 1500); });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => { if (!startedAtLogin) win.show(); });   // started by Windows at sign-in: stay in the tray
  if (process.env.DWUT_SHOT_DIR) require('./devtools/shots.js')(win, process.env.DWUT_SHOT_DIR, app);
  win.on('maximize', () => win.webContents.send('win:state', { maximized: true }));
  win.on('unmaximize', () => win.webContents.send('win:state', { maximized: false }));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); } });

  // Intercept close: hide to tray instead of closing
  win.on('close', (e) => {
    if (!isQuitting) {
      e.preventDefault();
      win.hide();
      // Show a balloon notification on first hide (Windows only)
      try {
        if (tray && process.platform === 'win32') {
          tray.displayBalloon({
            iconType: 'info',
            title: 'DWUT is still running',
            content: 'DWUT is minimized to the system tray. Right-click the icon to access options or exit.',
          });
        }
      } catch { /* ignore, older Electron or non-Windows */ }
    }
  });

  win.on('closed', () => { win = null; });
}

async function gracefulClose() {
  isQuitting = true;
  if (!win) return app.quit();
  try {
    const page = await win.webContents.executeJavaScript('window.__currentPage || ""');
    const b = win.isMaximized() ? win.getNormalBounds() : win.getBounds();
    await Promise.race([
      callBackend('config.set', { values: { window_width: b.width, window_height: b.height, ...(page ? { start_page: page } : {}) } }),
      new Promise((r) => setTimeout(r, 800)),
    ]);
  } catch { /* ignore */ }
  await stopBackend();
  if (tray) { tray.destroy(); tray = null; }
  app.exit(0);
}

// ── elevation ─────────────────────────────────────────────────────────────────
function relaunchElevated() {
  const exe = process.execPath;
  // Start-Process -ArgumentList does NOT quote array items, so a path with a space ("C:\\Users\\John Smith\\...") used to
  // reach Electron as two arguments and it opened its built-in welcome window instead of DWUT.  Pass ONE pre-quoted string.
  const argString = runFromFolder ? `"${app.getAppPath()}"` : '';
  const psq = (t) => `'${String(t).replace(/'/g, "''")}'`;
  const ps = `Start-Process -FilePath ${psq(exe)} ${argString ? `-ArgumentList ${psq(argString)} ` : ''}-WorkingDirectory ${psq(path.dirname(exe))} -Verb RunAs`;
  app.releaseSingleInstanceLock();
  const r = cp.spawnSync('powershell', ['-NoProfile', '-WindowStyle', 'Hidden', '-Command', ps], { windowsHide: true });
  if (r.status === 0) { app.exit(0); return true; }
  app.requestSingleInstanceLock();
  return false;
}

function checkAndPromptAdmin() {
  if (process.env.DWUT_SKIP_ADMIN || startedAtLogin || isAdmin()) return;
  const btn = dialog.showMessageBoxSync({
    type: 'question', buttons: ['Yes', 'No'], defaultId: 0, cancelId: 1,
    title: 'Administrator Privileges Recommended',
    message: "DWUT isn't running as Administrator.\n\nMost of its features — registry tweaks, service changes, the Startup Manager, repairs, and Windows features — need admin rights to work at all.\n\nRestart as Administrator now?",
  });
  if (btn === 0) relaunchElevated();
}

// ── IPC ───────────────────────────────────────────────────────────────────────
ipcMain.handle('backend:call', (_e, method, params) => callBackend(method, params));
ipcMain.handle('backend:ready', () => backendReady);
ipcMain.handle('app:perf', () => ({ ...lowEndInfo(), gpuSafeMode: fs.existsSync(GPU_FLAG) }));
// DWUT acting on itself (Task Manager: End Task / Kill / Restart on DWUT's own processes)
ipcMain.handle('app:self', async (_e, action) => {
  if (action === 'restart') {
    isQuitting = true; shuttingDown = true;
    try { app.releaseSingleInstanceLock(); } catch { /* ignore */ }
    app.relaunch({ execPath: process.execPath, args: runFromFolder ? [app.getAppPath()] : [] });
    try { await stopBackend(); } catch { /* ignore */ }
    app.exit(0);
    return true;
  }
  if (action === 'quit' || action === 'kill') {
    isQuitting = true; shuttingDown = true;
    if (action === 'kill') { try { await stopBackend(); } catch { /* ignore */ } app.exit(0); return true; }
    gracefulClose();
    return true;
  }
  return false;
});
// Task manager uses nodeIntegration — route via ipcMain.on
ipcMain.on('backend:call', (event, id, method, params) => {
  params = params || {};
  if (typeof method === 'string' && method.startsWith('term.')) params = { ...params, wid: event.sender.id };   // lets the backend route terminal output to this window
  callBackend(method, params)
    .then(r => { try { event.sender.send('backend:result', id, r); } catch {} })
    .catch(e => { try { event.sender.send('backend:error', id, String(e.message || e)); } catch {} });
});
ipcMain.on('win:minimize', () => win && win.minimize());
ipcMain.on('win:maximize', () => { if (!win) return; if (win.isMaximized()) win.unmaximize(); else win.maximize(); });
ipcMain.on('win:close', () => {
  // X button: hide to tray (same as clicking the window X)
  if (!isQuitting && win) { win.hide(); }
});
ipcMain.on('win:resize', (_e, dw, dh, ow, oh) => { if (win && !win.isMaximized()) win.setSize(Math.max(MIN_W, Math.round(ow + dw)), Math.max(MIN_H, Math.round(oh + dh))); });
ipcMain.handle('win:size', () => (win ? win.getSize() : [DEF_W, DEF_H]));
ipcMain.handle('dialog:save', async (_e, opts) => {
  const r = await dialog.showSaveDialog(win, opts || {});
  return r.canceled ? null : r.filePath;
});
ipcMain.handle('dialog:open', async (_e, opts) => {
  const r = await dialog.showOpenDialog(win, opts || {});
  return r.canceled ? null : r.filePaths;
});
ipcMain.handle('shell:open', (_e, url) => shell.openExternal(url));
// Native Windows toast (falls back to the tray balloon). Clicking it opens `url` when given (http/https only).
ipcMain.handle('app:notify', (_e, title, body, url) => {
  const link = typeof url === 'string' && /^https?:\/\//i.test(url) ? url : null;
  try {
    if (Notification.isSupported()) {
      const n = new Notification({ title: String(title || 'DWUT'), body: String(body || ''), icon: path.join(__dirname, 'renderer', 'icon.png') });
      if (link) n.on('click', () => { try { shell.openExternal(link); } catch { /* ignore */ } });
      n.show();
      return true;
    }
  } catch { /* fall through to the tray balloon */ }
  trayNotify(String(title || 'DWUT'), String(body || ''));
  return false;
});
ipcMain.handle('app:update-now', async () => {
  const url = 'https://raw.githubusercontent.com/supportpantheon-sys/Darkos-Windows-Utility-Tool-DWUT/main/bootstrap.ps1';
  const ps = `Start-Sleep -Seconds 3; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; irm '${url}' | iex`;
  const child = cp.spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { detached: true, stdio: 'ignore', windowsHide: false });
  child.unref();
  setTimeout(() => { isQuitting = true; gracefulClose(); }, 400);
  return true;
});
ipcMain.handle('app:relaunch-admin', () => relaunchElevated());
ipcMain.handle('app:has-startup', () => { try { const st = startupState(); return st.registered && st.enabled; } catch { return false; } });
ipcMain.handle('app:startup-state', () => { try { return startupState(); } catch { return { registered: false, enabled: false, via: '' }; } });
ipcMain.handle('app:add-startup', () => { try { return !!enableStartup(); } catch { return false; } });
ipcMain.handle('app:remove-startup', () => { try { return !!disableStartup(); } catch { return false; } });

// ── Task Manager window ───────────────────────────────────────────────────────
function openTaskManager(page) {
  // `page` (optional): 'processes' | 'performance' | 'network' | 'startup' | 'services' | 'users' - open straight on that section
  if (tmWin && !tmWin.isDestroyed()) {
    if (tmWin.isMinimized()) tmWin.restore();
    tmWin.show(); tmWin.focus();
    if (page) tmWin.webContents.send('tm:goto', page);
    return;
  }
  const { width: sw, height: sh } = screen.getPrimaryDisplay().size;
  tmWin = new BrowserWindow({
    width: Math.min(1280, sw - 40), height: Math.min(880, sh - 40),
    minWidth: 1100, minHeight: 720,
    resizable: true,
    title: 'DWUT Task Manager',
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    frame: false,
    backgroundColor: '#0d0d0f',
    show: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      sandbox: false,
      backgroundThrottling: false,
    },
  });
  tmWin.setMenuBarVisibility(false);
  tmWin.loadFile(path.join(__dirname, 'renderer', 'taskmanager.html'), page ? { query: { page: String(page) } } : undefined);
  tmWin.once('ready-to-show', () => tmWin.show());
  tmWin.on('maximize', () => { if (tmWin && !tmWin.isDestroyed()) tmWin.webContents.send('tm:max-state', true); });
  tmWin.on('unmaximize', () => { if (tmWin && !tmWin.isDestroyed()) tmWin.webContents.send('tm:max-state', false); });
  tmWin.on('closed', () => { tmWin = null; });
  // Forward backend calls from task manager window
  tmWin.webContents.on('ipc-message', () => {});
}

// ── Run window (Win+R) ───────────────────────────────────────────────────────
const RUN_W = 480;
// Copy the exact look of the main window (every CSS variable it has set: theme colours, font, size, text colour) into the Run window.
async function syncRunTheme() {
  try {
    if (!win || win.isDestroyed() || !runWin || runWin.isDestroyed()) return;
    const d = await win.webContents.executeJavaScript(`(() => {
      const st = document.documentElement.style, tokens = {};
      for (let i = 0; i < st.length; i++) { const k = st[i]; if (k.startsWith('--')) tokens[k.slice(2)] = st.getPropertyValue(k).trim(); }
      return { name: localStorage.getItem('dwut_theme') || 'dark', tokens };
    })()`, true);
    if (d && d.tokens && Object.keys(d.tokens).length && runWin && !runWin.isDestroyed()) runWin.webContents.send('tm:theme', d);
  } catch { /* main window not ready - the pushed theme (if any) still applies */ }
}
function openRunWindow() {
  if (runWin && !runWin.isDestroyed()) {
    if (runWin.isMinimized()) runWin.restore();
    runWin.setContentSize(RUN_W, 318);
    syncRunTheme();
    runWin.center(); runWin.show(); runWin.focus();
    runWin.webContents.send('run:show');
    return;
  }
  runWin = new BrowserWindow({
    width: RUN_W, height: 318, useContentSize: true,
    resizable: false, minimizable: false, maximizable: false, fullscreenable: false,
    frame: false, alwaysOnTop: true, skipTaskbar: false,
    title: 'Run',
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    backgroundColor: '#13161a',
    show: false,
    webPreferences: { nodeIntegration: true, contextIsolation: false, sandbox: false, backgroundThrottling: false },
  });
  runWin.setMenuBarVisibility(false);
  runWin.loadFile(path.join(__dirname, 'renderer', 'run.html'));
  runWin.webContents.once('did-finish-load', () => {
    if (!runWin || runWin.isDestroyed()) return;
    syncRunTheme();
    runWin.center(); runWin.show(); runWin.focus();
    runWin.webContents.send('run:show');
  });
  // The window is kept alive and hidden on close so the next Win+R is instant.
  runWin.on('close', (e) => { if (!isQuitting && runWin && !runWin.isDestroyed()) { e.preventDefault(); runWin.hide(); } });
  runWin.on('closed', () => { runWin = null; });
}
// ── Performance Options (DWUT's themed copy of the Windows dialog + the "DWUT recommended" choice) ──
function openPerfOptions() {
  if (perfWin && !perfWin.isDestroyed()) {
    if (perfWin.isMinimized()) perfWin.restore();
    syncThemeTo(perfWin); perfWin.show(); perfWin.focus();
    return;
  }
  perfWin = new BrowserWindow({
    width: 500, height: Math.max(560, Math.min(780, screen.getPrimaryDisplay().workAreaSize.height - 40)), useContentSize: true,
    resizable: false, maximizable: false, fullscreenable: false,
    frame: false, show: false,
    title: 'Performance Options',
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    backgroundColor: '#13161a',
    webPreferences: { nodeIntegration: true, contextIsolation: false, sandbox: false, backgroundThrottling: false },
  });
  perfWin.setMenuBarVisibility(false);
  perfWin.loadFile(path.join(__dirname, 'renderer', 'perfopts.html'));
  perfWin.webContents.once('did-finish-load', () => {
    if (!perfWin || perfWin.isDestroyed()) return;
    syncThemeTo(perfWin);
    perfWin.center(); perfWin.show(); perfWin.focus();
  });
  perfWin.on('closed', () => { perfWin = null; });
}
ipcMain.on('perf:open', () => openPerfOptions());
ipcMain.on('perf:close', () => { if (perfWin && !perfWin.isDestroyed()) perfWin.close(); });

// ── Custom terminals (reskinned Command Prompt / PowerShell) ─────────────────
async function syncThemeTo(target) {
  try {
    if (_lastThemeData && target && !target.isDestroyed()) target.webContents.send('tm:theme', _lastThemeData);
    if (!win || win.isDestroyed() || !target || target.isDestroyed()) return;
    const d = await win.webContents.executeJavaScript(`(() => {
      const st = document.documentElement.style, tokens = {};
      for (let i = 0; i < st.length; i++) { const k = st[i]; if (k.startsWith('--')) tokens[k.slice(2)] = st.getPropertyValue(k).trim(); }
      return { name: localStorage.getItem('dwut_theme') || 'dark', tokens };
    })()`, true);
    if (d && d.tokens && Object.keys(d.tokens).length && !target.isDestroyed()) target.webContents.send('tm:theme', d);
  } catch { /* main window not ready - the pushed theme (if any) still applies */ }
}
// kind: 'cmd' | 'powershell'.  admin: true / false, or undefined = the window asks "open as administrator?" first.
function openTerminal(kind, admin) {
  const k = kind === 'powershell' ? 'powershell' : 'cmd';
  const { width: sw, height: sh } = screen.getPrimaryDisplay().workAreaSize;
  const tw = new BrowserWindow({
    width: Math.min(1000, sw - 80), height: Math.min(620, sh - 80), minWidth: 520, minHeight: 320,
    frame: false, show: false,
    title: k === 'powershell' ? 'Windows PowerShell' : 'Command Prompt',
    icon: path.join(__dirname, 'renderer', 'icon.png'),
    backgroundColor: '#13161a',
    webPreferences: { nodeIntegration: true, contextIsolation: false, sandbox: false, backgroundThrottling: false },
  });
  const wcId = tw.webContents.id;
  termWins.add(tw);
  tw.setMenuBarVisibility(false);
  const query = { kind: k };
  if (typeof admin === 'boolean') query.admin = admin ? '1' : '0';
  tw.loadFile(path.join(__dirname, 'renderer', 'terminal.html'), { query });
  tw.webContents.once('did-finish-load', () => { if (tw.isDestroyed()) return; syncThemeTo(tw); tw.show(); tw.focus(); });
  tw.on('maximize', () => { try { tw.webContents.send('term:max-state', true); } catch { /* closing */ } });
  tw.on('unmaximize', () => { try { tw.webContents.send('term:max-state', false); } catch { /* closing */ } });
  tw.on('closed', () => { termWins.delete(tw); callBackend('term.close_window', { wid: wcId }).catch(() => {}); });
  return tw;
}
ipcMain.on('term:open', (_e, kind, admin) => openTerminal(kind, typeof admin === 'boolean' ? admin : undefined));
ipcMain.on('term:win', (e, action) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (!w || w.isDestroyed()) return;
  if (action === 'close') w.close();
  else if (action === 'minimize') w.minimize();
  else if (action === 'maximize') { if (w.isMaximized()) w.unmaximize(); else w.maximize(); }
  else if (action === 'theme') syncThemeTo(w);
});
ipcMain.handle('term:theme-get', () => _lastThemeData || null);

ipcMain.on('run:open', () => openRunWindow());
ipcMain.on('run:close', () => { if (runWin && !runWin.isDestroyed()) runWin.hide(); });
ipcMain.on('run:height', (_e, h) => { if (runWin && !runWin.isDestroyed()) runWin.setContentSize(RUN_W, Math.max(318, Math.min(700, Math.round(h)))); });
ipcMain.handle('run:browse', async () => {
  const r = await dialog.showOpenDialog(runWin && !runWin.isDestroyed() ? runWin : undefined, {
    title: 'Browse', properties: ['openFile'],
    filters: [{ name: 'Programs', extensions: ['exe', 'bat', 'cmd', 'com', 'msc', 'lnk', 'ps1', 'vbs'] }, { name: 'All files', extensions: ['*'] }],
  });
  return r.canceled || !r.filePaths.length ? '' : r.filePaths[0];
});

ipcMain.on('tm:open', (_e, page) => openTaskManager(typeof page === 'string' ? page : undefined));
ipcMain.handle('tm:browse', async () => {
  const r = await dialog.showOpenDialog(tmWin && !tmWin.isDestroyed() ? tmWin : undefined, {
    title: 'Browse', properties: ['openFile'],
    filters: [{ name: 'Programs', extensions: ['exe', 'bat', 'cmd', 'com', 'msc', 'lnk', 'ps1', 'vbs'] }, { name: 'All files', extensions: ['*'] }],
  });
  return r.canceled || !r.filePaths.length ? '' : r.filePaths[0];
});
ipcMain.on('tm:shell-open', (_e, folderPath) => { try { shell.openPath(folderPath); } catch {} });
ipcMain.on('tm:close',    () => { if (tmWin && !tmWin.isDestroyed()) tmWin.close(); });
ipcMain.on('tm:minimize', () => { if (tmWin && !tmWin.isDestroyed()) tmWin.minimize(); });
ipcMain.on('tm:maximize', () => { if (tmWin && !tmWin.isDestroyed()) { if (tmWin.isMaximized()) tmWin.unmaximize(); else tmWin.maximize(); } });
ipcMain.handle('tm:get-bounds', () => {
  if (tmWin && !tmWin.isDestroyed()) return tmWin.getBounds();
  return null;
});
ipcMain.on('tm:set-bounds', (_e, bounds) => {
  if (tmWin && !tmWin.isDestroyed() && !tmWin.isMaximized()) {
    const cur = tmWin.getBounds();
    const b = { ...cur, ...bounds };
    b.width = Math.max(700, Math.round(b.width));
    b.height = Math.max(460, Math.round(b.height));
    tmWin.setBounds(b);
  }
});

// Theme sync — main window pushes theme name + CSS vars whenever theme changes
ipcMain.on('tm:theme-push', (_e, themeData) => {
  _lastThemeData = themeData;
  try {
    const bg = themeData && themeData.tokens && themeData.tokens.bg_shell;
    if (bg && /^#[0-9a-f]{6}$/i.test(bg)) {
      if (tmWin && !tmWin.isDestroyed()) tmWin.setBackgroundColor(bg);
      if (runWin && !runWin.isDestroyed()) runWin.setBackgroundColor(bg);
      if (perfWin && !perfWin.isDestroyed()) perfWin.setBackgroundColor(bg);
    }
  } catch { /* cosmetic only */ }
  if (tmWin && !tmWin.isDestroyed()) {
    tmWin.webContents.send('tm:theme', themeData);
  }
  if (runWin && !runWin.isDestroyed()) {
    runWin.webContents.send('tm:theme', themeData);
  }
  if (perfWin && !perfWin.isDestroyed()) perfWin.webContents.send('tm:theme', themeData);
  for (const tw of termWins) { try { if (!tw.isDestroyed()) { tw.webContents.send('tm:theme', themeData); } } catch { /* closing */ } }
});
// TM window requests current theme on startup
ipcMain.handle('tm:theme-get', () => _lastThemeData || null);

let _lastThemeData = null;

// Native Windows File Icon extraction (100% authentic shell icons for processes)
const _fileIconCache = new Map();

async function _fetchNativeIcon(filePath) {
  if (!filePath || typeof filePath !== 'string') return '';
  if (_fileIconCache.has(filePath)) return _fileIconCache.get(filePath);

  const sysRoot = process.env.SystemRoot || 'C:\\Windows';
  const base = path.basename(filePath);
  const exeBase = base.toLowerCase().endsWith('.exe') ? base : (base + '.exe');
  const candidates = [
    filePath,
    path.join(sysRoot, 'System32', base),
    path.join(sysRoot, 'System32', exeBase),
    path.join(sysRoot, base),
    path.join(sysRoot, exeBase),
    path.join(sysRoot, 'SysWOW64', base),
    path.join(sysRoot, 'SysWOW64', exeBase),
    path.join(sysRoot, 'explorer.exe'),
    path.join(sysRoot, 'System32', 'imageres.dll')
  ];

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      try {
        const icon = await app.getFileIcon(candidate, { size: 'small' });
        const dataUrl = icon.toDataURL();
        if (dataUrl && dataUrl.length > 50) {
          _fileIconCache.set(filePath, dataUrl);
          return dataUrl;
        }
      } catch {}
    }
  }

  // Final fallback attempt with getFileIcon directly on filePath or base
  try {
    const icon = await app.getFileIcon(filePath, { size: 'small' });
    const dataUrl = icon.toDataURL();
    _fileIconCache.set(filePath, dataUrl);
    return dataUrl;
  } catch {
    _fileIconCache.set(filePath, '');
    return '';
  }
}

ipcMain.handle('tm:get-file-icon', async (_e, filePath) => {
  return _fetchNativeIcon(filePath);
});

ipcMain.handle('tm:get-file-icons-batch', async (_e, paths) => {
  if (!Array.isArray(paths)) return {};
  const results = {};
  for (const p of paths) {
    if (!p) continue;
    results[p] = await _fetchNativeIcon(p);
  }
  return results;
});

// ── first-run startup prompt ──────────────────────────────────────────────────
function promptStartupOnFirstRun() {
  const local = process.env.LOCALAPPDATA || os.tmpdir();
  const markerPath = path.join(local, 'DWUT', 'first_run_done.txt');
  if (fs.existsSync(markerPath) || startedAtLogin) return;   // already ran once / started silently by Windows
  // Wait for window to be visible
  const doPrompt = () => {
    const btn = dialog.showMessageBoxSync(win, {
      type: 'question',
      buttons: ['Yes — Start with Windows', 'No thanks'],
      defaultId: 0,
      cancelId: 1,
      title: 'Launch DWUT with Windows?',
      message: "Welcome to DWUT 9!\n\nWould you like DWUT to start automatically when Windows boots?\n\nThis creates a startup shortcut so the app is always ready in the system tray.\nYou can change this anytime in Settings.",
      icon: path.join(__dirname, 'renderer', 'icon.png'),
    });
    try {
      fs.mkdirSync(path.dirname(markerPath), { recursive: true });
      fs.writeFileSync(markerPath, new Date().toISOString());
    } catch { /* ignore */ }
    if (btn === 0) {
      if (!enableStartup()) dialog.showMessageBox(win, { type: 'warning', message: 'Could not set DWUT to start with Windows.', detail: 'Try again from the VPN page (Connect when DWUT starts) or run DWUT as administrator.' }).catch(() => {});
    } else {
      // User said no — delete any shortcut that may have been created earlier
      try { disableStartup(); } catch { /* ignore */ }
    }
  };
  if (win && win.isVisible()) {
    setTimeout(doPrompt, 800);
  } else {
    win && win.once('show', () => setTimeout(doPrompt, 800));
  }
}

// ── lifecycle ─────────────────────────────────────────────────────────────────
if (!app.requestSingleInstanceLock()) {
  // An elevated DWUT cannot be reached by Electron's own message from a normal one (and vice versa) - so a shortcut click
  // used to do nothing.  Leave a note in the user's own folder instead; the running DWUT picks it up and shows itself.
  if (!startedAtLogin) { try { fs.mkdirSync(path.dirname(SHOW_FLAG), { recursive: true }); fs.writeFileSync(SHOW_FLAG, String(Date.now())); } catch { /* ignore */ } }
  app.quit();
}
else {
  try { fs.unlinkSync(SHOW_FLAG); } catch { /* none */ }
  setInterval(() => { try { if (fs.existsSync(SHOW_FLAG)) { fs.unlinkSync(SHOW_FLAG); showWindow(); } } catch { /* ignore */ } }, 700);
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
  app.setAppUserModelId('tool.darko.dwut');
  ensureStartMenuShortcut();
  // Fallback only: Windows normally keeps Ctrl+Shift+Esc for itself, so the real handling is the backend's
  // keyboard hook. If this registration does succeed, it simply opens the same window.
  try { globalShortcut.register('CommandOrControl+Shift+Escape', () => openTaskManager()); } catch { /* reserved by Windows */ }
  app.whenReady().then(() => {
    checkAndPromptAdmin();
    if (!startBackend()) return;
    createTray();
    createWindow();
    ensureDesktopShortcut();
    setTimeout(repairShortcuts, 4000);          // fix shortcuts written by older versions (they opened Electron's welcome window)
    // First-run: ask about startup after window is shown
    promptStartupOnFirstRun();
  });
  // Prevent default quit on all-windows-closed; tray keeps the app alive
  app.on('window-all-closed', () => {
    // Only quit if user explicitly chose Exit from tray
    if (isQuitting) gracefulClose();
    // Never auto-quit — task manager or other sub-windows closing must not kill the app
  });
  app.on('before-quit', () => { isQuitting = true; shuttingDown = true; });
  app.on('activate', () => { if (win) showWindow(); });
}
