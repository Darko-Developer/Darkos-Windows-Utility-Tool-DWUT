@echo off
rem ====================================================================================================================
rem  DWUT 9 launcher.  Double-click this file - it installs / repairs EVERYTHING DWUT needs and then starts the app:
rem    * Python 3.10+            (winget, or python.org with a checksum, if it is missing)
rem    * every Python package    (psutil, pywin32, requests, PySocks, wmi, nvidia-ml-py, pycaw ...)
rem    * the Electron runtime    (prebuilt - it already contains its own Node.js, so Node.js does NOT need to be installed)
rem    * a desktop shortcut that always opens the app
rem  Works the same on Windows 10 (1809+) and 11, 64-bit, 32-bit and ARM64.  Run it again at any time to repair an install.
rem ====================================================================================================================
setlocal
set "HERE=%~dp0"
title DWUT setup

where powershell >nul 2>&1
if errorlevel 1 (
  echo [DWUT] Windows PowerShell was not found. It ships with Windows 10/11 - please repair Windows and try again.
  pause
  exit /b 1
)

rem bootstrap.ps1 elevates itself (UAC), installs what is missing, copies the app and launches it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%bootstrap.ps1" %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo [DWUT] Setup did not finish ^(code %RC%^). Read the messages above - most problems are a missing internet connection.
  pause
)
exit /b %RC%
