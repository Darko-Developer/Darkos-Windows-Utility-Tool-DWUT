## DWUT 1 CLICK BUTTON now covers everything TBOK does (and stays customizable)

New popup "Step 3 of 5: System optimizations" - 55 switches ported one-to-one from The Beard of Knowledge's TBOK v1.6.2 (`backend/modules/oneclick/sysopt.py`):
hibernation / Fast Startup by PC type, F8 boot menu, page-file sizing, svchost grouping, SysMain by drive type + RAM, ~140 services to Manual (service lists verified identical to TBOK, minus Xbox),
essential services to Auto, delayed-start services, every machine-wide registry value, telemetry, OOBE, WPBT, Edge, Copilot / Bing / Widgets removal (installed + provisioned), wasteful scheduled tasks,
per-user settings applied to EVERY loaded user, every offline profile (NTUSER.DAT) and the Default profile, gaming (HPET reset, windowed games, MMCS, power throttling on desktops) and optional WinGet app updates.
Differences on purpose: Xbox is never touched; visual effects stay in DWUT's own Visual effects popup (TBOK's lighter-animations preset is skipped if you choose your own); HAGS / Ultimate power plan / Recall are
the existing automatic steps.  The restore-point step now does what TBOK does (enable System Restore + VSS, lift the 24-hour limit, back up profile registry files if Windows still refuses).
Service start modes are saved to %LOCALAPPDATA%\DWUT\Backups before they are changed.

# DWUT changes in this build

## Music sync (rewritten)
- Real beat detection: captures what your speakers play (Windows loopback), analyses it live in 3 bands
  (bass / mid / high) so kicks, snares and hats are all caught - even under a loud mix.
- Offline test: `python devtools/test_beatdetect.py` (~98-100% of hits caught, ~8 ms analysis delay, no false triggers on music).
- Personalization -> "Visual delay" (default none) lines visuals up with slow speakers / Bluetooth.
- Falls back to the old peak meter automatically if the loopback packages cannot be installed.
- New optional packages: numpy, PyAudioWPatch (auto-installed on first use).

## Proxy Center
- New checker: one complete test per proxy (ping median of 8, jitter, YouTube, Discord, real speed). Rows only appear fully filled in.
- Defaults: ping <= 90 ms, speed >= 1.0 MB/s (new "Min Speed" box). RAT / miner / Tor / service ports are never checked.
- Connect-to-Best / Enable: re-test the candidates live, parallel, use only alive ones, honest error messages.
- Fixed: Gaming-tier rows had no "Enable" item.

## USB flasher / Ventoy / VM builder
- Every external program (diskpart, Ventoy, robocopy, DISM, bootsect, VBoxManage, VirtualBox installer) streams its output live into the log.
- Fixed: any stick whose first partition had a drive letter was treated as "Ventoy already installed".
- Fixed: false "virtualization disabled" warning when Hyper-V is active.

## Other
- Tray "Quick Game Boost" opens the same confirmation popup as the Gaming page.
- CPU + GPU temperature on Dashboard, Task Manager (Performance) and Game Booster (shared sampler: LibreHardwareMonitor/OHM, Windows thermal zones, NVML).
- Personalization -> "Mouse particle push".

## Round 2
- Config Tools: **Command Prompt** and **PowerShell** open a DWUT-skinned window (theme, particles, mouse push) around the REAL shell
  (ConPTY via `pywinpty`, auto-installed). Asks "open as administrator?" first. Copy/paste like Windows Terminal, Ctrl+C only copies
  when text is selected, Ctrl +/- zoom, Enter restarts after `exit`. Also in the tray menu. Admin <-> normal is done by a small helper
  process (`backend/term_host.py`): UAC prompt for admin, a normal token when DWUT itself is elevated.
- **Group Policy** / **Local Security** previously did nothing silently on Windows Home (the files don't exist there). Now the button says
  why and offers to enable Windows' own Group Policy packages (DISM output streamed to the log).
- **Startup Apps** opens the DWUT Task Manager on its Startup section.
- **Update Apps (WinGet)**: scans, then a list where you tick exactly which apps to update ("Include selected (N)"). Unknown-version apps are off by default.
- Weed leaves: stems are now proportional to the leaf, the leaf shape is cached (much cheaper to draw), and the auto-thinning no longer
  respawns every particle (that caused the disappearing / glitching).

## Round 3
- **One set of numbers everywhere.** Dashboard, Game Booster and Task Manager (Processes status bar + Performance) now read the SAME shared sampler
  (`perfsample.system_totals()`): CPU % (Processor Utility), RAM %, GPU % (busiest engine), Disk **active time** %, Network Mbps (send / receive),
  CPU / GPU temperature. Only the graphs differ per page.
  - Dashboard: DISK card = active time (was C: capacity), network rates in Mbps, memory in the Task Manager's units, percents with one decimal.
  - Booster: Disk graph = active time % (read / write MB/s underneath), Network graph is now really Mbps (it was MB/s labelled Mbps).
  - Task Manager: Disk was a throughput guess on Windows - now the real `% Idle Time` counter.
  - Fixed: the Dashboard's GPU override raised on a frozen dataclass and was silently skipped, so it showed NVML's number instead of the Task Manager's.
- **VPN switching.** Busy state is now claimed atomically before the worker starts (double clicks / page + tray / startup auto-connect used to start
  overlapping connect or switch threads). "Change server" button stays disabled until the switch really finishes. Only one tunnel monitor runs.
- **VPN tray menu.** Menu is built from the real state before it opens, actions re-check the real state at click time, every action reports how
  it ended (balloon), and a "Restore internet" item appears when the tunnel is up but not protecting you.
- Version bumped 8 -> 9.

## Round 4
- **CPU number fixed (Dashboard, Booster, Task Manager).** Two causes: (1) a variable clash in the CPU sampler (`base` = base clock, overwritten by a
  process name) made every CPU sample crash whenever the per-process counter existed, so the pages silently fell back to flaky readings;
  (2) the headline used "% Processor Utility", which is frequency-scaled and can read several times higher than real busy time.
  The headline is now real busy time ("% Processor Time", same maths as GetSystemTimes / Resource Monitor), per-core uses the same counter, and the
  Task Manager's per-process CPU is rescaled so the rows add up to that same total.
- Dashboard: new **STORAGE** card (how full C: is, %). Dashboard only.

## Round 5 - USB flasher + VM builder fixes
- **USB Flasher: "Erase and continue" did nothing.** The page called `setStatus()` right after you confirmed, but it was never defined, so the click
  threw and the job never started (Flash a stick, Multi-boot / Ventoy, own ISO). It is defined now. All wizards also show an error dialog if anything
  unexpected goes wrong, instead of failing silently.
- **VM Builder: could never create a VM.** The VBoxManage helper inside `build_vbox` called itself instead of `_vb`, recursing until Python gave up on
  the first VirtualBox command. Fixed.
- Verified with a scripted UI run (every USB mode + VM wizard) and a backend run of every job with simulated Windows tools.

## Round 5
- **DWUT 1 CLICK BUTTON** (sidebar, right under Dashboard, and in the tray menu). One run: restore point -> debloat -> clean all drives -> optimize all drives
  -> free + optimize RAM / CPU / GPU -> tweaks -> disable Recall (Win 11) -> extra safe cleanups -> DISM -> SFC -> High CPU Power Config Repair -> network stack reset.
  Two small popups that look like the real pages: **Debloat** (installed apps ticked, Photos / Groove / Xbox apps NOT ticked) and **Tweaks** (recommended ticked, never the Xbox ones).
  Live step list + log, "Stop after current step", tray notification when finished. DISM runs before SFC, and the network reset is last because DISM needs the internet.
  Files: `backend/modules/oneclick/runner.py`, `backend/api/oneclick_api.py`, `renderer/js/pages/oneclick.js`.
- **Ventoy: the step after "Ventoy CLI SUCCESS" is no longer silent or fragile.** Ventoy's CLI reports success even when it could not format its data partition
  ("Failed to find ventoy volume" / "Can not reformat D:\ to exFAT"). DWUT used to wait on Windows' storage cmdlets (which can hang on such a partition, each call up to 40 s, no log).
  Now: the partition table is read straight from the disk, the data partition is formatted exFAT "Ventoy" with diskpart when needed (PowerShell as fallback), given a known
  drive letter, and a test file is written before the ISO is copied. Every decision is logged. An existing Ventoy stick is only ever formatted if it is completely blank.
- ISO copy to the Ventoy stick: free-space check first, flush, and the copied size is verified.
- VM builder: if VirtualBox refuses the unattended install, the VM is kept and falls back to a normal manual install (ISO inserted) instead of being deleted;
  Guest Additions are only requested when their disc exists; video memory is clamped to 128 MB for Linux guests.
