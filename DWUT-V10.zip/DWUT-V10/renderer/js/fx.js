// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* DWUT animation engine.  Adds motion only: it never changes what a page does.
   1. Page open: HUD scan line, header / divider / tabs slide in, cards rise in one after another, and the slime hops from the dock to the page title.
   2. Stage: the game-style loading screen for long actions (Game Booster, Debloat, Privacy, VPN ...).  The slime hops from task to task and number chips
      pop up around it.  It is driven by the SAME progress events the pages already receive, so every step shown is a real step the backend reported.
      It can always be hidden (button / Esc) and the action carries on.
   3. Interaction: cards follow the pointer with a light + small cards tilt, buttons flash where you press them, the mascot watches your mouse.
   Everything follows the selected theme AND your Personalization (gradient / image / video backgrounds, particles, click effects stay in charge:
   overlays here are see-through, and "Button click animation: None" turns the extra press effects off).  Honors the Windows "reduce motion" setting. */
(function () {
  const reduced = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const clickAnimOn = () => (document.documentElement.dataset.clickAnim || 'glitch') !== 'none';

  // ── 1. page open ──────────────────────────────────────────────────────────────────────────────────────────
  const CARD_SEL = '.card, .frame-card, .nm-tile, .vp-opt';
  function enter(page) {
    if (!page || reduced()) return;
    const vh = window.innerHeight || 800;
    const cards = [...page.querySelectorAll(CARD_SEL)].filter((c) => !c.classList.contains('fx-in') && !c.classList.contains('fx-in-done') && c.getClientRects().length && !c.parentElement.closest('.card') && !c.closest('.fxs') && !c.closest('.hl-ov') && !c.closest('#modal-host'));
    let i = 0;
    cards.forEach((c) => {
      const r = c.getBoundingClientRect();
      if (r.top > vh * 1.1 || i > 22) return;
      const cx = (r.left + r.width / 2) / (window.innerWidth || 1200) - 0.5;
      // Smooth glide-up from below, slight lateral drift for cards at the edges
      const dx = cx < -0.12 ? -60 : cx > 0.12 ? 60 : 0;
      const dy = 50;
      const rot = cx < -0.15 ? -2 : cx > 0.15 ? 2 : 0;
      c.style.setProperty('--fx-dx', dx + 'px');
      c.style.setProperty('--fx-dy', dy + 'px');
      c.style.setProperty('--fx-rot', rot + 'deg');
      c.style.animationDelay = Math.min(i * 45, 600) + 'ms';
      c.classList.add('fx-in'); i++;
      c.addEventListener('animationend', function done(e) {
        if (e.target !== c) return;
        c.classList.remove('fx-in'); c.classList.add('fx-in-done');
        c.style.animationDelay = '';
        c.style.removeProperty('--fx-dx'); c.style.removeProperty('--fx-dy'); c.style.removeProperty('--fx-rot');
        c.removeEventListener('animationend', done);
        // Clear fx-in-done after a bit so the card can animate again on next page switch
        setTimeout(() => c.classList.remove('fx-in-done'), 1200);
      });
    });
  }

  function open(page, force) {
    if (!page) return;
    if (!force && document.getElementById('splash')) return;                    // the splash is up: Shell calls open(page, true) once it is gone
    enter(page);
    if (reduced()) return;
    page.classList.remove('fx-open'); void page.offsetWidth; page.classList.add('fx-open');
    setTimeout(() => page.classList.remove('fx-open'), 1100);
    const content = document.getElementById('content');
    if (content) {
      content.querySelectorAll('.fx-scan').forEach((n) => n.remove());
      const sc = el('div', 'fx-scan'); content.append(sc); setTimeout(() => sc.remove(), 900);
    }
    if (window.Mascot) Mascot.onNav();
  }

  function boot() {
    const content = document.getElementById('content');
    if (!content) return;
    new MutationObserver((muts) => {
      for (const m of muts) { const t = m.target; if (t.classList && t.classList.contains('page') && t.classList.contains('active') && m.oldValue !== null && !/\bactive\b/.test(m.oldValue)) open(t); }
    }).observe(content, { subtree: true, attributes: true, attributeFilter: ['class'], attributeOldValue: true });
    document.addEventListener('click', (e) => {
      if (!e.target.closest || !e.target.closest('.tab')) return;
      const page = e.target.closest('.page'); setTimeout(() => enter(page), 60);
    }, true);
    pointerFx();
    // ambient life: every few seconds one visible card gets a light sweep, like a console idling
    setInterval(() => {
      if (reduced() || document.visibilityState !== 'visible' || document.documentElement.classList.contains('idle') || stage.cur) return;
      const cs = [...document.querySelectorAll('.page.active .card')].filter((c) => { const r = c.getBoundingClientRect(); return r.width > 80 && r.top < innerHeight && r.bottom > 80; });
      if (!cs.length) return; const c = cs[Math.floor(Math.random() * cs.length)];
      c.classList.remove('fx-ping'); void c.offsetWidth; c.classList.add('fx-ping'); setTimeout(() => c.classList.remove('fx-ping'), 1300);
    }, 3600);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();

  // ── 2. pointer / press effects ───────────────────────────────────────────────────────────────────────────
  function pointerFx() {
    let hov = null, raf = 0, ev = null;
    const reset = (c) => { c.classList.remove('fx-tilt'); c.style.removeProperty('--rx'); c.style.removeProperty('--ry'); c.style.removeProperty('--mx'); c.style.removeProperty('--my'); };
    // a card that holds buttons / inputs never tilts: tilting moves the controls under the pointer, which made them flicker at their edges
    const ctlCache = new WeakMap();
    const hasCtl = (c) => { let v = ctlCache.get(c); if (v === undefined) { v = !!c.querySelector('button,.btn,input,select,textarea,a,[role="button"],.sw,.cb'); ctlCache.set(c, v); } return v; };
    function frame() {
      raf = 0; if (!ev) return;
      const t = ev.target, c = t && t.closest ? t.closest('.card') : null;
      if (hov && hov !== c) { reset(hov); hov = null; }
      if (c && !c.closest('.fxs') && !c.closest('#modal-host')) {
        const r = c.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top;
        c.style.setProperty('--mx', x + 'px'); c.style.setProperty('--my', y + 'px');
        if (!reduced() && r.width <= 400 && r.height <= 260 && r.width > 60 && !hasCtl(c)) {
          c.classList.add('fx-tilt');
          c.style.setProperty('--ry', (((x / r.width) - 0.5) * 9).toFixed(2) + 'deg'); c.style.setProperty('--rx', ((0.5 - (y / r.height)) * 7).toFixed(2) + 'deg');
        }
        hov = c;
      }
    }
    document.addEventListener('pointermove', (e) => { ev = e; if (!raf) raf = requestAnimationFrame(frame); }, { passive: true });
    document.addEventListener('pointerleave', () => { if (hov) { reset(hov); hov = null; } }, true);
    document.addEventListener('pointerdown', (e) => {
      const b = e.target.closest && e.target.closest('.btn:not(:disabled)');
      if (!b || e.button > 0) return;
      if (clickAnimOn() && !reduced()) {
        const r = b.getBoundingClientRect(); b.style.setProperty('--bx', (e.clientX - r.left) + 'px'); b.style.setProperty('--by', (e.clientY - r.top) + 'px');
        b.classList.remove('fx-flash'); void b.offsetWidth; b.classList.add('fx-flash'); setTimeout(() => b.classList.remove('fx-flash'), 560);
        if (window.Mascot) Mascot.react('press');
      }
    }, true);
  }


  // ── category rail: a page's tab strip becomes a column of HUD tiles (same look as the Dashboard hub) ─────────
  function rail(bar, descs) {
    if (!bar) return bar;
    bar.className = 'rail'; bar.style.cssText = '';
    [...bar.querySelectorAll('.btn')].forEach((btn, i) => {
      const name = btn.textContent.trim(); btn.textContent = '';
      btn.classList.add('hub-tile'); btn.style.setProperty('--i', String(i));
      const n = el('i', 'ht-n', String(i + 1).padStart(2, '0')), t = el('span', 'ht-t'), b = el('b', null, name), sm = el('small', null, (descs && descs[name]) || '');
      t.append(b, sm); btn.append(n, t, el('i', 'ht-arrow'));
    });
    return bar;
  }

  // ── 4. stage ───────────────────────────────────────────────────────────────────────────────────────────────
  const stage = { cur: null };

  function begin(opts) {
    opts = opts || {};
    if (stage.cur) stage.cur.close(true);
    const host = (window.Nav && Nav.pages && Nav.pages[Nav.current] && Nav.pages[Nav.current].root) || document.getElementById('content');
    if (!host) return noop();
    const big = el('div', 'big', opts.title || 'Working'), now = el('div', 'now', opts.now || 'Starting…');
    const bar = el('div', 'pbar'), fill = el('i'); bar.append(fill);
    const num = el('span', 'pbnum', ''); const pb = el('div', 'pb'); pb.append(bar, num);
    const lane = el('div', 'lane'), list = el('div', 'list'), arena = el('div', 'arena'); arena.append(lane, list);
    const hide = el('button', 'btn btn-ghost auto', 'Hide'); hide.style.cssText = 'height:28px;width:auto;min-width:0;padding:0 18px';
    const foot = el('div', 'foot'); foot.append(hide);
    const ctr = el('div', 'ctr'); ctr.append(el('div', 'eyebrow', opts.eyebrow || 'DWUT'), big, arena, now, pb, foot);
    const ov = el('div', 'fxs'); ov.append(el('i', 'hud tl'), el('i', 'hud tr'), el('i', 'hud bl'), el('i', 'hud br'), ctr); host.append(ov);

    const S = { kind: opts.kind || '', t0: Date.now(), items: [], queue: [], timer: null, n: 0, running: null, finished: false, closed: false, f: null, lastText: '', lastEvt: Date.now() };
    const LANE = 115;
    const rider = window.Slime ? Slime.rider(arena, {
      size: 104, bounce: true,
      anchor: (r, hr) => ({ x: LANE, y: r.top - hr.top + r.height / 2 + 24, sc: 0.78 }),
      home: () => { const h = arena.getBoundingClientRect(); return { x: LANE, y: Math.max(90, h.height / 2 + 42), sc: S.finished ? 1.02 : 0.95 }; },
      onLand: (t) => { if (t && t.classList) { t.classList.add('land'); setTimeout(() => t.classList.remove('land'), 260); } },
    }) : null;
    const onKey = (e) => { if (e.key === 'Escape') S.close(false); };
    document.addEventListener('keydown', onKey);
    hide.onclick = () => S.close(false);
    const safety = setTimeout(() => S.close(false), 15 * 60 * 1000);
    const watch = setInterval(() => {                                   // a quiet backend is not a frozen app: say so, and make leaving obvious
      if (S.closed || S.finished) return;
      if (Date.now() - S.lastEvt > 20000) now.textContent = 'Still working… this one can take a while. Press Hide to keep using DWUT meanwhile.';
    }, 2000);

    const label = () => (S.f != null ? Math.round(S.f * 100) + '%' : (S.n ? '#' + S.n : ''));
    function show(text) {
      if (S.running) { S.running.classList.remove('run'); S.running.classList.add('ok'); S.running.lastChild.textContent = 'done'; }
      const it = el('div', 'it run'); it.append(el('span', 'dot'), el('span', 't', text), el('span', 's', 'working'));
      it.title = text; list.append(it); S.running = it; S.n++; now.textContent = text; num.textContent = label();
      while (list.children.length > 40) list.removeChild(list.firstChild);
      const over = list.scrollHeight > list.clientHeight + 2; list.classList.toggle('ovf', over);
      if (over) list.scrollTo({ top: list.scrollHeight, behavior: reduced() ? 'auto' : 'smooth' });
      if (rider) rider.hopTo(it, () => { if (!S.closed) rider.chip(label()); });
    }
    let pendingHop = false;  // true while the slime is mid-hop; next pump() call waits for landing
    function pump() {
      if (S.closed) return;
      if (S.queue.length) {
        const doShow = () => { show(S.queue.shift()); };
        // If slime is already hopping, wait until it lands before starting the next task
        if (rider && rider.hopping && rider.hopping() && !pendingHop) {
          pendingHop = true;
          // Poll until not hopping, then flush
          const wait = () => {
            if (S.closed) return;
            if (!rider.hopping()) { pendingHop = false; doShow(); S.timer = setTimeout(pump, reduced() ? 0 : 350); }
            else S.timer = setTimeout(wait, 40);
          };
          S.timer = setTimeout(wait, 60);
        } else {
          pendingHop = false;
          doShow();
          // Spacing: fast when many steps but NEVER faster than the hop animation (min 280ms)
          const gap = S.queue.length > 8 ? 180 : S.queue.length > 3 ? 300 : 420;
          S.timer = setTimeout(pump, reduced() ? 0 : gap);
        }
      } else { S.timer = null; if (S.finished) wrap(); }
    }
    function wrap() {
      if (S.closed) return;
      if (S.running) { S.running.classList.remove('run'); S.running.classList.add(S.failed ? 'bad' : 'ok'); S.running.lastChild.textContent = S.failed ? 'failed' : 'done'; }
      fill.style.width = '100%'; num.textContent = S.failed ? '!' : '100%';
      ov.classList.add('fin'); big.textContent = S.failed ? (opts.failTitle || 'Stopped') : (opts.doneTitle || 'Complete'); now.textContent = S.note || '';
      if (rider) { if (S.failed) { rider.shake(); rider.chip('!', 'bad'); } else rider.celebrate(() => rider.chip('100%')); }
      const wait = Math.max(0, 1500 - (Date.now() - S.t0)) + (S.failed ? 1800 : 1500);
      setTimeout(() => S.close(false), reduced() ? 50 : wait);
    }
    S.step = (text) => { text = String(text || '').trim(); if (!text || S.closed || S.finished) return; S.lastEvt = Date.now(); if (text === S.lastText) return; S.lastText = text; S.queue.push(text); if (!S.timer) pump(); };
    S.progress = (f) => {
      if (S.closed || typeof f !== 'number' || isNaN(f)) return; f = Math.max(0, Math.min(1, f)); S.f = f; S.lastEvt = Date.now();
      fill.style.width = (f * 100) + '%'; num.textContent = label();
    };
    S.finish = (note) => { if (S.closed || S.finished) return; S.finished = true; S.note = note || ''; if (!S.timer) pump(); };
    S.fail = (msg) => { if (S.closed || S.finished) return; S.finished = true; S.failed = true; S.note = msg || ''; if (!S.timer) pump(); };
    S.close = (now_) => {
      if (S.closed) return; S.closed = true; clearTimeout(S.timer); clearTimeout(safety); clearInterval(watch); document.removeEventListener('keydown', onKey);
      if (stage.cur === S) stage.cur = null;
      const done = () => { if (rider) rider.destroy(); ov.remove(); };
      if (now_ || reduced()) done(); else { ov.classList.add('out'); setTimeout(done, 600); }
    };
    stage.cur = S;
    if (opts.first) S.step(opts.first);
    return S;
  }
  const noop = () => ({ step() {}, progress() {}, finish() {}, fail() {}, close() {} });
  const live = (kind) => (stage.cur && stage.cur.kind === kind ? stage.cur : null);

  window.FX = {
    stage: { begin, step: (t) => stage.cur && stage.cur.step(t), progress: (f) => stage.cur && stage.cur.progress(f), finish: (n) => stage.cur && stage.cur.finish(n), fail: (m) => stage.cur && stage.cur.fail(m), close: () => stage.cur && stage.cur.close(true), active: () => !!stage.cur,
      finishKind: (k, n) => { const s = live(k); if (s) s.finish(n); }, failKind: (k, m) => { const s = live(k); if (s) s.fail(m); } },
    enter, open, rail,
  };

  // The same events the pages already listen to - the stage just shows them as a game-style sequence.
  const wire = () => {
    if (typeof on !== 'function' || !window.dwut) return setTimeout(wire, 100);
    on('gaming.boost_progress', (d) => { const s = live('boost'); if (s && d && d.step) s.step(d.step); });
    on('gaming.boost_changed', (r) => { const s = live('boost'); if (s) s.finish(r ? 'Boost is active - everything is restored when you deactivate it' : 'All settings restored'); });
    on('gaming.boost_error', (d) => { const s = live('boost'); if (s) s.fail((d && d.message) || 'Boost failed'); });
    on('debloat.progress', (d) => { const s = live('debloat'); if (s && d) { if (d.pct != null) s.progress(d.pct); if (d.step) s.step(d.step); } });
    on('debloat.done', (d) => { const s = live('debloat'); if (s) { const f = (d && d.failed) || []; s.finish(`${(d && d.applied) || 0} applied` + (f.length ? `, ${f.length} failed` : '')); } });
    on('vpn.progress', (d) => { const s = live('vpn'); if (s && d) { if (d.pct != null) s.progress(d.pct); if (d.msg) s.step(d.msg); } });
    on('app.error', (m) => { if (stage.cur && !stage.cur.finished) stage.cur.fail(typeof m === 'string' ? m : (m && m.message) || 'Something went wrong'); });
  };
  wire();
})();
