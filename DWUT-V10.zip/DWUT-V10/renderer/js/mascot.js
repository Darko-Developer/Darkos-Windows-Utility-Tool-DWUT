// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* The mascot: ONE slime that lives in the program.  It sits in the middle of the Dashboard core, hops up to the nav bar when you scroll the core away or open another
   page, escorts you to the page you opened, wanders over to sit on a hub tile now and then, looks at whatever you hover, falls asleep when you leave the mouse alone,
   and reacts when you poke it.  It hides while a loading stage is on screen (the stage has its own slime) and while Windows "reduce motion" is on it simply stays put. */
(function () {
  const reduced = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  const SIZE = 150;
  let R = null, layer = null, started = false, homeKey = '', until = 0, lookEl = null, lastMove = Date.now(), asleep = false, zN = 0;
  const q = (s) => document.querySelector(s);
  const lr = () => (layer ? layer.getBoundingClientRect() : { left: 0, top: 0 });

  function slotAnchor(el, sc) {
    const r = el.getBoundingClientRect(), l = lr();
    return { x: r.left - l.left + r.width / 2, y: r.bottom - l.top, sc: sc != null ? sc : Math.min(1, r.width / SIZE) };
  }
  function coreVisible() {
    const slot = q('.hub-core .core-slot'), c = q('#content'); if (!slot || !c || Nav.current !== 'dashboard') return null;
    const r = slot.getBoundingClientRect(), cr = c.getBoundingClientRect();
    const vis = Math.min(r.bottom, cr.bottom) - Math.max(r.top, cr.top);
    return vis > r.height * 0.6 ? slot : null;
  }
  function titleAnchor() {
    const p = Nav.pages[Nav.current], h1 = p && p.root && p.root.querySelector('.title-row h1'); if (!h1) return null;
    const r = h1.getBoundingClientRect(), l = lr(); if (!r.width) return null;
    let right = r.right;                                           // stay clear of badges that sit next to the title (before the row's spacer)
    for (const c of h1.parentElement.children) { if (c.classList.contains('grow')) break; const cr = c.getBoundingClientRect(); if (cr.width && cr.right > right) right = cr.right; }
    return { x: Math.min(innerWidth - 40, right - l.left + 40), y: r.bottom - l.top + 4, sc: 0.3 };
  }
  // where should the slime be right now?  returns [key, anchorFn]
  function desired() {
    const now = Date.now();
    if (until > now && R._spot) return [R._spotKey, R._spot];
    const core = coreVisible();
    if (core) return ['core', () => { const s = coreVisible() || q('.hub-core .core-slot'); return s ? slotAnchor(s, 0.85) : slotAnchor(q('#dock .dk-pet')); }];
    return ['dock', () => { const d = q('#dock .dk-pet'); return d ? slotAnchor(d) : { x: 60, y: 60, sc: 0.3 }; }];
  }
  function goto(key, fn, cb) { homeKey = key; R.hopTo(fn, cb); }
  function tickHome() {
    if (!R) return;
    const away = !!(window.FX && FX.stage.active()) || !!q('#modal-host.on');
    layer.classList.toggle('away', away);
    if (away) return;
    const [key, fn] = desired();
    if (key !== homeKey) goto(key, fn);
    // sleepy after 40 s without the mouse
    const idle = Date.now() - lastMove > 40000;
    if (idle && !asleep) { asleep = true; R.slime.sleep(true); }
    if (asleep && idle && Math.random() < 0.35) { R.chip('z' + 'z'.repeat(zN++ % 3)); }
  }
  function wake() { lastMove = Date.now(); if (asleep) { asleep = false; R.slime.sleep(false); R.slime.kick(3); R.chip('!'); } }

  // little things the slime does by itself
  const PHRASES = ['boop', 'hehe', 'hi!', 'poke!', 'yay', 'wheee'];
  function idleAct() {
    setTimeout(idleAct, 3200 + Math.random() * 4200);
    if (!R || reduced() || asleep || layer.classList.contains('away') || (R.hopping && R.hopping())) return;
    const s = R.slime, r = Math.random();
    if (r < 0.28) R.bounce();
    else if (r < 0.46) { s.look(Math.random() * 2 - 1, Math.random() * 2 - 1); setTimeout(() => { if (!lookEl) s.look(0, 0); }, 1300); }
    else if (r < 0.6) { s.kick(-2.6); setTimeout(() => s.kick(-2.6), 260); }
    else if (r < 0.72) s.kick(3.4);
    else if (r < 0.84 && Nav.current === 'dashboard' && homeKey === 'core') wander();
    else s.blink();
  }
  function spotOn(t) { return () => { const r = t.getBoundingClientRect(), l = lr(); return { x: r.left - l.left + r.width * 0.78, y: r.top - l.top + 4, sc: 0.3 }; }; }   // feet on the tile's top edge
  function wander() {                                  // hops out onto a tile, sometimes on to a second one, then the home logic brings it back
    const tiles = [...document.querySelectorAll('.hub-tile')]; if (!tiles.length) return;
    const t = tiles[Math.floor(Math.random() * tiles.length)];
    R._spotKey = 'tile'; R._spot = spotOn(t);
    until = Date.now() + 5200 + Math.random() * 1500;
    goto('tile', R._spot, () => {
      R.slime.kick(2.2);
      if (Math.random() < 0.65) setTimeout(() => {
        if (!R || Nav.current !== 'dashboard' || Date.now() > until) return;
        const t2 = tiles[Math.floor(Math.random() * tiles.length)]; if (t2 === t) return;
        R._spot = spotOn(t2); goto('tile', R._spot, () => R.slime.kick(2.2));
      }, 900);
    });
  }

  function escort() {                                 // after you open a page the slime hops over to its title, says hi, then goes back to the nav bar
    if (!R || reduced()) return;
    const a = Nav.current === 'dashboard' ? null : titleAnchor(); if (!a) { until = 0; return; }
    R._spotKey = 'title'; R._spot = () => titleAnchor() || a; until = Date.now() + 1500;
    goto('title', R._spot, () => { R.sparks(10, { up: true, r: 34 }); R.slime.kick(3); });
  }

  const api = {
    start() {
      if (started || !window.Slime) return; started = true;
      layer = document.getElementById('mascot'); if (!layer) return;
      R = Slime.rider(layer, { size: SIZE, bounce: false, chipGap: 16, anchor: () => ({ x: 0, y: 0, sc: 1 }), home: () => ({ x: 120, y: 120, sc: 1 }) });
      // drop in from above the screen onto the core
      const [key, fn] = desired();
      const a = fn(); R.place({ x: a.x, y: -140, sc: a.sc }); homeKey = key; R.hopTo(fn, () => { R.sparks(14, { up: true, r: 60 }); R.slime.kick(4); });
      setInterval(() => { if (!document.hidden && !document.documentElement.classList.contains('idle')) tickHome(); }, 220); setTimeout(idleAct, 5000);
      document.addEventListener('pointermove', (e) => {
        wake();
        const b = R.box(), l = lr(), cx = (b.l + b.r) / 2 + l.left, cy = (b.t + b.b) / 2 + l.top;
        if (lookEl) { const r = lookEl.getBoundingClientRect(); R.slime.look((r.left + r.width / 2 - cx) / 220, (r.top + r.height / 2 - cy) / 220); }
        else R.slime.look((e.clientX - cx) / 280, (e.clientY - cy) / 280);
        const x = e.clientX - l.left, y = e.clientY - l.top;
        if (x > b.l - 6 && x < b.r + 6 && y > b.t - 6 && y < b.b + 6 && (Nav.current === 'dashboard' || homeKey === 'core')) {
          layer.style.cursor = 'pointer';
        } else {
          layer.style.cursor = '';
        }
      }, { passive: true });
      document.addEventListener('keydown', wake, true);
      document.addEventListener('pointerdown', (e) => {                       // poke the slime
        if (layer.classList.contains('away')) return;
        const b = R.box(), l = lr(), x = e.clientX - l.left, y = e.clientY - l.top;
        if (x > b.l - 6 && x < b.r + 6 && y > b.t - 6 && y < b.b + 6) {
          R.bounce();
          R.slime.kick(-3.6);
          R.sparks(12, { up: true, r: 36 });
          if (Nav.current === 'dashboard' || homeKey === 'core') {
            R.chip('BOOST!');
            if (window.runGameBooster) window.runGameBooster();
          } else {
            R.chip(PHRASES[Math.floor(Math.random() * PHRASES.length)]);
          }
        }
      }, true);
    },
    onNav() { if (!R) return; wake(); escort(); },
    lookAtEl(el) { lookEl = el; if (!el && R) R.slime.look(0, 0); },
    react(kind) { if (!R) return; if (kind === 'press') R.slime.kick(-1.4); else if (kind === 'done') { R.slime.kick(4); R.sparks(12, { up: true }); } },
    get rider() { return R; },
  };
  window.Mascot = api;
})();
