// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* Font lists for Settings > Typography.  Windows fonts are only listed when this PC really has them; the bundled fonts (fonts/ folder) are always there. */
(function () {
  const WIN = ['Segoe UI Variable', 'Segoe UI', 'Segoe UI Semilight', 'Bahnschrift', 'Calibri', 'Candara', 'Corbel', 'Cambria', 'Constantia', 'Arial', 'Arial Narrow', 'Arial Rounded MT Bold', 'Tahoma', 'Verdana',
    'Trebuchet MS', 'Franklin Gothic Medium', 'Century Gothic', 'Gill Sans MT', 'Lucida Sans Unicode', 'Microsoft Sans Serif', 'Malgun Gothic', 'Nirmala UI', 'Yu Gothic UI', 'Leelawadee UI', 'Sitka Text',
    'Georgia', 'Palatino Linotype', 'Book Antiqua', 'Times New Roman', 'Garamond', 'Impact', 'Comic Sans MS', 'Ink Free', 'Segoe Print', 'Segoe Script', 'Consolas', 'Cascadia Code', 'Cascadia Mono', 'Courier New', 'Lucida Console'];
  const BUNDLED = ["Aldrich", "Anton", "Audiowide", "Barlow", "Bebas Neue", "Bruno Ace", "Chakra Petch", "DM Sans", "Electrolize", "Exo 2", "Fira Code", "Fira Sans", "Goldman", "IBM Plex Mono", "IBM Plex Sans", "Inter", "JetBrains Mono", "Josefin Sans", "Jura", "Kanit", "Lato", "Lexend", "Manrope", "Michroma", "Montserrat", "Nunito", "Open Sans", "Orbitron", "Oswald", "Outfit", "Oxanium", "Play", "Poppins", "Press Start 2P", "Quicksand", "Rajdhani", "Raleway", "Roboto", "Rubik", "Russo One", "Saira", "Share Tech Mono", "Sora", "Source Code Pro", "Source Sans 3", "Space Grotesk", "Space Mono", "Syncopate", "Teko", "Titillium Web", "Tomorrow", "Ubuntu", "VT323", "Work Sans"];
  const MONO_BUNDLED = ["Fira Code", "IBM Plex Mono", "JetBrains Mono", "Press Start 2P", "Share Tech Mono", "Source Code Pro", "Space Mono", "VT323"];
  let cv = null;
  function installed(name) {
    try {
      cv = cv || document.createElement('canvas').getContext('2d'); const t = 'mmmmmmmmmmlliWWWW 0123';
      const w = (f) => { cv.font = `40px ${f}`; return cv.measureText(t).width; };
      return w(`"${name}", monospace`) !== w('monospace') || w(`"${name}", serif`) !== w('serif') || w(`"${name}", sans-serif`) !== w('sans-serif');
    } catch { return true; }
  }
  const win = () => WIN.filter(installed);
  window.DW_FONTS = {
    main: () => [['Windows fonts on this PC', win().filter((n) => !/Consolas|Cascadia|Courier|Lucida Console/.test(n))], ['Bundled fonts', BUNDLED]],
    mono: () => [['Windows fonts on this PC', win().filter((n) => /Consolas|Cascadia|Courier|Lucida Console/.test(n))], ['Bundled code fonts', MONO_BUNDLED]],
    installed,
  };
})();
