// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* DWUT mascot: the slime.
   - Slime.create()  a living slime (breathes, blinks, eyes follow a look-target, squashes and stretches with a spring).
   - Slime.rider()   a slime that hops around inside a container (loading screens, mascot layer) with number chips that never touch it.
   - Slime.sprite    a flat SVG data-URI of the same slime, published as the CSS variable --slime-sprite (small spinners / progress bars / modals).
   The slime's body, rim and shine are mixed from the selected theme's accent (also custom accents), so it always matches your theme.
   There is no glow around it.  Honors Windows "reduce motion". */
(function () {
  const reduced = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  let uid = 0;

  // body outline in a 100 x 69 box: round dome, slightly flattened underside
  const BODY = 'M0 43C0 19 21 0 50 0C79 0 100 19 100 43C100 59 80 69 50 69C20 69 0 59 0 43Z';
  const mixv = (pct, other) => `color-mix(in srgb, var(--accent) ${pct}%, ${other})`;

  function svg(id) {
    return `<svg class="sl-svg" viewBox="0 0 100 69" xmlns="http://www.w3.org/2000/svg" overflow="visible">
<defs>
<linearGradient id="slb${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:${mixv(84, '#fff')}"/><stop offset=".5" style="stop-color:var(--accent)"/><stop offset="1" style="stop-color:${mixv(72, '#fff')}"/></linearGradient>
<radialGradient id="slr${id}" cx=".5" cy=".52" r=".62"><stop offset=".52" style="stop-color:${mixv(80, '#000')};stop-opacity:0"/><stop offset="1" style="stop-color:${mixv(42, '#fff')};stop-opacity:.6"/></radialGradient>
<radialGradient id="slg${id}" cx=".5" cy="1" r=".75"><stop offset="0" style="stop-color:${mixv(40, '#fff')};stop-opacity:.6"/><stop offset="1" style="stop-color:${mixv(40, '#fff')};stop-opacity:0"/></radialGradient>
<linearGradient id="slh${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset="1" style="stop-color:${mixv(30, '#fff')};stop-opacity:.6"/></linearGradient>
<clipPath id="slc${id}"><path d="${BODY}"/></clipPath>
</defs>
<path d="${BODY}" fill="url(#slb${id})"/>
<g clip-path="url(#slc${id})">
<rect x="-2" y="-2" width="104" height="73" fill="url(#slr${id})"/>
<ellipse cx="50" cy="73" rx="46" ry="22" fill="url(#slg${id})"/>
</g>
<path d="${BODY}" fill="none" style="stroke:${mixv(40, '#fff')}" stroke-opacity=".62" stroke-width="1"/>
<path d="M58 67.6C73 67.4 90 64 94.5 54" fill="none" style="stroke:${mixv(34, '#fff')}" stroke-opacity=".7" stroke-width="1.3" stroke-linecap="round"/>
<g class="sl-gloss"><ellipse cx="23" cy="14.6" rx="6.4" ry="3.4" transform="rotate(-34 23 14.6)" fill="url(#slh${id})"/><ellipse cx="14" cy="22" rx="1.1" ry="1.1" fill="#fff" opacity=".7"/></g>
<g class="sl-look" transform="translate(0 0)"><g class="sl-eyes" style="stroke:${mixv(8, '#04020a')}">
<line x1="30.4" y1="39" x2="42.5" y2="35.3" stroke-width="2.9" stroke-linecap="round"/>
<line x1="48.6" y1="35.1" x2="61.2" y2="39.2" stroke-width="2.9" stroke-linecap="round"/>
</g></g></svg>`;
  }

  // ── flat sprite for CSS backgrounds: re-coloured whenever the theme accent changes (CSS vars do not work inside data URIs) ──
  const probe = document.createElement('i');
  function rgbOf(c) {
    try { probe.style.color = ''; probe.style.color = c; document.documentElement.append(probe); const v = getComputedStyle(probe).color; probe.remove(); const m = v.match(/[\d.]+/g); if (m && m.length >= 3) return [+m[0], +m[1], +m[2]]; } catch { /* ignore */ }
    return [122, 92, 255];
  }
  const mixc = (a, b, t) => a.map((v, i) => Math.round(v * t + b[i] * (1 - t)));
  const hex = (c) => '#' + c.map((v) => Math.max(0, Math.min(255, v)).toString(16).padStart(2, '0')).join('');
  let lastAccent = '';
  function buildSprite(force) {
    let acc = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim();
    if (!acc) {
      try {
        const th = localStorage.getItem('dwut_theme') || 'dark';
        if (window.DW_THEMES) {
          const t = (window.DW_THEMES.themes && window.DW_THEMES.themes[th]) || {};
          acc = t.accent || (window.DW_THEMES.base && window.DW_THEMES.base.accent);
        }
      } catch {}
    }
    acc = acc || '#00F0FF';
    if (!force && acc === lastAccent) return;
    lastAccent = acc;
    const A = rgbOf(acc), W = [255, 255, 255], K = [4, 2, 10];
    const top = hex(mixc(A, W, .84)), mid = hex(A), bot = hex(mixc(A, W, .72)), rim = hex(mixc(A, W, .42)), eye = hex(mixc(A, K, .08));
    const s = `<svg xmlns="http://www.w3.org/2000/svg" width="108" height="77" viewBox="-4 -4 108 77"><defs><linearGradient id="a" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${top}"/><stop offset=".5" stop-color="${mid}"/><stop offset="1" stop-color="${bot}"/></linearGradient></defs>` +
      `<path d="${BODY}" fill="url(#a)" stroke="${rim}" stroke-opacity=".7" stroke-width="1.6"/><ellipse cx="23" cy="14.6" rx="6.4" ry="3.4" transform="rotate(-34 23 14.6)" fill="#fff" opacity=".85"/>` +
      `<line x1="30.4" y1="39" x2="42.5" y2="35.3" stroke="${eye}" stroke-width="3.2" stroke-linecap="round"/><line x1="48.6" y1="35.1" x2="61.2" y2="39.2" stroke="${eye}" stroke-width="3.2" stroke-linecap="round"/></svg>`;
    const uri = 'url("data:image/svg+xml,' + encodeURIComponent(s).replace(/"/g, '%22') + '")';
    api.sprite = uri;
    try { document.documentElement.style.setProperty('--slime-sprite', uri); } catch { /* ignore */ }
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const cv = document.createElement('canvas');
          cv.width = 256; cv.height = 256;
          const ctx = cv.getContext('2d');
          ctx.clearRect(0, 0, 256, 256);
          ctx.drawImage(img, 8, 32, 240, 171);
          const dataUrl = cv.toDataURL('image/png');
          if (window.dwut && window.dwut.setThemeIcon) {
            window.dwut.setThemeIcon(dataUrl);
          } else if (window.ipcRenderer) {
            window.ipcRenderer.send('app:set-theme-icon', dataUrl);
          } else if (window.require) {
            window.require('electron').ipcRenderer.send('app:set-theme-icon', dataUrl);
          }
        } catch (e) {
          console.error('Failed to render theme icon canvas:', e);
        }
      };
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s);
    } catch {}
  }
  let spriteT = 0;
  const queueSprite = () => { clearTimeout(spriteT); spriteT = setTimeout(() => buildSprite(false), 30); };

  // ── one shared animation loop; actors return true while they still need frames ──
  const actors = new Set(); let raf = 0, last = 0, suspended = false;
  function loop(now) {
    const dt = Math.min(0.033, (now - last) / 1000 || 0.016); last = now;
    for (const a of [...actors]) { let keep = false; try { keep = a(dt, now); } catch (e) { console.error('slime', e); } if (!keep) actors.delete(a); }
    raf = actors.size && !document.hidden && !suspended ? requestAnimationFrame(loop) : 0;
  }
  function wakeSlime() { if (!document.hidden && !suspended && actors.size && !raf) { last = performance.now(); raf = requestAnimationFrame(loop); } }
  function sleepSlime() { if (raf) { cancelAnimationFrame(raf); raf = 0; } }
  document.addEventListener('visibilitychange', () => { if (document.hidden) sleepSlime(); else wakeSlime(); });
  window.addEventListener('pagehide', () => { suspended = true; sleepSlime(); });
  window.addEventListener('pageshow', () => { suspended = false; wakeSlime(); });
  if (window.dwut && window.dwut.on) {
    try {
      window.dwut.on('app:suspend-render', () => { suspended = true; sleepSlime(); });
      window.dwut.on('app:resume-render', () => { suspended = false; wakeSlime(); });
    } catch {}
  }
  function run(fn) { actors.add(fn); if (!raf && !suspended) { last = performance.now(); raf = requestAnimationFrame(loop); } }

  // ── a living slime ──
  function create(o) {
    o = o || {};
    const id = ++uid;
    const el = document.createElement('div');
    el.className = 'slime' + (o.cls ? ' ' + o.cls : '');
    el.style.setProperty('--sz', (o.size || 96) + 'px');
    el.innerHTML = `<div class="sl-shadow"></div><div class="sl-breath"><div class="sl-squash">${svg(id)}</div></div>`;
    const sq = el.querySelector('.sl-squash'), look = el.querySelector('.sl-look');
    const S = { el, s: 0, v: 0, lx: 0, ly: 0, tx: 0, ty: 0, dead: false, hold: 0, timers: [] };
    const paint = () => { sq.style.transform = `scale(${(1 - S.s * 0.6).toFixed(4)},${(1 + S.s).toFixed(4)})`; look.setAttribute('transform', `translate(${S.lx.toFixed(2)} ${S.ly.toFixed(2)})`); };
    function step(dt) {
      S.v += (-115 * (S.s - S.hold) - 13 * S.v) * dt; S.s += S.v * dt;
      S.lx += (S.tx - S.lx) * Math.min(1, dt * 9); S.ly += (S.ty - S.ly) * Math.min(1, dt * 9);
      paint();
      const calm = Math.abs(S.s - S.hold) < 0.003 && Math.abs(S.v) < 0.025 && Math.abs(S.tx - S.lx) < 0.025 && Math.abs(S.ty - S.ly) < 0.025;
      if (calm) { S.s = S.hold; S.v = 0; paint(); S.running = false; return false; }
      return true;
    }
    function wake() { if (!S.running && !S.dead) { S.running = true; run((dt) => (S.dead ? false : step(dt))); } }
    S.kick = (amt) => { if (reduced()) return; S.v += amt; wake(); };            // negative = squash first, positive = stretch first
    S.set = (s) => { S.s = s; S.v = 0; paint(); wake(); };
    S.rest = (h) => { S.hold = h || 0; wake(); };                                // a held pose (e.g. asleep = slightly flattened)
    S.look = (dx, dy) => { S.tx = Math.max(-1, Math.min(1, dx)) * 3.2; S.ty = Math.max(-1, Math.min(1, dy)) * 1.6; wake(); };
    S.blink = () => { el.classList.add('blink'); S.timers.push(setTimeout(() => el.classList.remove('blink'), 130)); };
    S.sleep = (on) => { el.classList.toggle('asleep', !!on); S.rest(on ? -0.1 : 0); };
    S.jiggle = () => S.kick(-3.2);
    const blinkLoop = () => { if (S.dead) return; if (!el.classList.contains('asleep')) { S.blink(); if (Math.random() < 0.22) S.timers.push(setTimeout(() => S.blink(), 260)); } S.timers.push(setTimeout(blinkLoop, 2400 + Math.random() * 3600)); };
    S.timers.push(setTimeout(blinkLoop, 900 + Math.random() * 1500));
    S.destroy = () => { S.dead = true; S.timers.forEach(clearTimeout); el.remove(); };
    return S;
  }

  // ── sparks (celebration / landing dust) - mixed from the theme accent too ──
  function sparks(host, x, y, n, o) {
    if (reduced()) return; o = o || {};
    const cols = ['var(--accent)', 'color-mix(in srgb, var(--accent) 55%, #fff)', 'color-mix(in srgb, var(--accent) 80%, #fff)', '#fff', 'var(--info)'];
    for (let i = 0; i < n; i++) {
      const d = document.createElement('i'); d.className = 'sl-spark';
      const a = (o.up ? -Math.PI / 2 + (Math.random() - 0.5) * 2.2 : Math.random() * 6.283), r = (o.r || 46) * (0.5 + Math.random() * 0.8);
      d.style.cssText = `left:${x}px;top:${y}px;--dx:${Math.cos(a) * r}px;--dy:${Math.sin(a) * r}px;--c:${cols[i % cols.length]};--s:${3 + Math.random() * 4}px;animation-delay:${Math.random() * 60}ms`;
      host.append(d); setTimeout(() => d.remove(), 900);
    }
  }

  // ── a slime that hops around ──
  //  host   : positioned element the slime lives in (coordinates below are relative to it)
  //  o.size : slime width at scale 1
  //  o.anchor(elRect, hostRect) -> {x, y, sc}   where the FEET go when it stands on / next to an element
  //  o.home()                   -> {x, y, sc}   resting spot
  function rider(host, o) {
    o = Object.assign({ size: 104, bounce: true, chipGap: 14 }, o || {});
    const sl = create({ size: o.size });
    const W = o.size, H = o.size * 0.69 + 4;
    const w = document.createElement('div'); w.className = 'slime-rider'; w.style.width = W + 'px'; w.style.height = H + 'px'; w.append(sl.el); host.append(w);
    const st = { x: 0, y: 0, sc: 1, rot: 0, lift: 0 };
    let hop = null, target = null, dead = false, bt = -1, nextBounce = performance.now() + 900, running = false, onLand = null, chipN = 0;
    const chips = [];
    const hr = () => host.getBoundingClientRect();
    const place = () => { w.style.transform = `translate(${(st.x - W / 2).toFixed(1)}px,${(st.y - H + st.lift).toFixed(1)}px) rotate(${st.rot.toFixed(2)}deg) scale(${st.sc.toFixed(3)})`; };
    function resolve(t) {
      if (!t) return o.home ? o.home() : { x: st.x, y: st.y, sc: st.sc };
      if (typeof t === 'function') return t();
      if (t.nodeType === 1) { if (!t.isConnected) return { x: st.x, y: st.y, sc: st.sc }; return o.anchor(t.getBoundingClientRect(), hr()); }
      return t;
    }
    const ease = (u) => 0.5 - 0.5 * Math.cos(Math.PI * u);
    const box = () => { const bw = W * st.sc, bh = H * st.sc; return { l: st.x - bw / 2, r: st.x + bw / 2, t: st.y + st.lift - bh, b: st.y + st.lift, bw, bh }; };
    function chipGuard() {                       // a number chip never touches the slime: if the slime moves into it, the chip pops out of the way
      if (!chips.length) return; const b = box(), pad = 12;
      for (let i = chips.length - 1; i >= 0; i--) {
        const c = chips[i]; if (!c.el.isConnected) { chips.splice(i, 1); continue; }
        if (c.gone) continue;
        if (c.cx + c.cw / 2 + pad > b.l && c.cx - c.cw / 2 - pad < b.r && c.cy + c.ch / 2 + pad > b.t && c.cy - c.ch / 2 - pad < b.b) { c.gone = true; c.el.classList.add('gone'); }
      }
    }
    function tick(dt, now) {
      if (dead) return false;
      const a = resolve(target);
      if (hop) {
        const e = now - hop.t0;
        if (e < hop.crouch) { const c = e / hop.crouch; sl.set(-0.3 * ease(c)); st.y = hop.y0 + 2.5 * ease(c) * st.sc; st.x = hop.x0; st.sc = hop.sc0; }       // wind-up: sink into the ground
        else {
          if (!hop.go) { hop.go = true; sl.kick(3.4); hop.y0 = st.y; }                                                                                            // launch: spring up
          const u = Math.min(1, (e - hop.crouch) / hop.T), k = ease(u), kx = 0.82 * u + 0.18 * k;                                                                  // a real jump: x keeps its speed, only the scale eases
          st.x = hop.x0 + (a.x - hop.x0) * kx; st.y = hop.y0 + (a.y - hop.y0) * u - 4 * hop.H * u * (1 - u); st.sc = hop.sc0 + (a.sc - hop.sc0) * k;
          st.rot = Math.max(-12, Math.min(12, (a.x - hop.x0) * 0.045)) * Math.sin(Math.PI * u);
          sl.set(0.3 * (1 - 2 * u) * (u < 0.5 ? 1 : 0.55)); sl.look(Math.sign(a.x - hop.x0) * 0.9, u < 0.5 ? -0.6 : 0.5);
          if (u >= 1) { hop = null; st.x = a.x; st.y = a.y; st.sc = a.sc; st.rot = 0; sl.s = -0.34; sl.v = 0; sl.kick(0); sl.look(0.4, 0.3); const f = onLand; onLand = null; if (f) f(); if (o.onLand) o.onLand(target); nextBounce = now + 1200; }
        }
      } else {
        const f = Math.min(1, dt * 10); st.x += (a.x - st.x) * f; st.y += (a.y - st.y) * f; st.sc += (a.sc - st.sc) * f;
        if (o.bounce && target && now > nextBounce && bt < 0) { bt = 0; sl.kick(-1.8); nextBounce = now + 2200 + Math.random() * 1000; }
      }
      if (bt >= 0) { bt += dt / 0.46; if (bt >= 1) { bt = -1; st.lift = 0; sl.kick(-1.6); } else st.lift = -4 * 10 * bt * (1 - bt) * st.sc; }
      place(); chipGuard();
      return true;
    }
    function wake() { if (!running && !dead) { running = true; run((dt, n) => { const k = tick(dt, n); if (!k) running = false; return k; }); } }
    const api2 = {
      el: w, slime: sl,
      place(t) { target = t || null; const a = resolve(target); st.x = a.x; st.y = a.y; st.sc = a.sc; place(); wake(); },
      hopTo(t, cb) {
        target = t || null; onLand = cb || null;
        const a = resolve(target);
        if (reduced()) { st.x = a.x; st.y = a.y; st.sc = a.sc; place(); wake(); if (cb) setTimeout(cb, 0); return; }
        const dist = Math.hypot(a.x - st.x, a.y - st.y);
        hop = { t0: performance.now(), x0: st.x, y0: st.y, sc0: st.sc, crouch: 150, T: 440 + Math.min(520, dist * 0.85), H: 34 + Math.min(130, dist * 0.26), go: false };
        bt = -1; st.lift = 0; wake();
      },
      home(cb) { api2.hopTo(null, cb); },
      bounce() { if (bt < 0) { bt = 0; sl.kick(-2.4); } wake(); },
      /* a number / word that pops up at a different spot beside the slime each time - always OUTSIDE its body and its hop path */
      chip(text, tone) {
        if (dead) return;
        const c = document.createElement('div'); c.className = 'sl-chip' + (tone ? ' ' + tone : ''); c.textContent = text; c.style.visibility = 'hidden'; host.append(c);
        const cw = c.offsetWidth, ch = c.offsetHeight, b = box();
        const side = (chipN++ % 2) ? 1 : -1, up = [0.25, 0.72, 0.45, 0.9, 0.12][chipN % 5];
        let cx = st.x + side * (b.bw / 2 + cw / 2 + o.chipGap + Math.random() * 10), cy = b.b - b.bh * up;
        if (o.chipAbove) { cx = st.x + side * (cw / 2 + 8 + Math.random() * 24 + b.bw * 0.1); cy = b.t - ch / 2 - o.chipGap - Math.random() * 10; }
        c.style.left = cx + 'px'; c.style.top = cy + 'px'; c.style.visibility = '';
        c.style.setProperty('--rz', (Math.random() * 10 - 5).toFixed(1) + 'deg');
        chips.push({ el: c, cx, cy, cw, ch, gone: false }); setTimeout(() => c.remove(), 1500);
      },
      sparks(n, opt) { const b = box(); sparks(host, st.x, b.t + b.bh / 2, n || 14, opt); },
      celebrate(cb) { api2.hopTo(null, () => { api2.sparks(26, { up: true, r: 70 }); sl.kick(4); setTimeout(() => { if (!dead) { sl.kick(3); api2.sparks(10, { up: true }); } }, 380); if (cb) cb(); }); },
      shake() { sl.kick(-2); w.classList.remove('sl-shake'); void w.offsetWidth; w.classList.add('sl-shake'); },
      pos: () => ({ x: st.x, y: st.y, sc: st.sc }), box, hopping: () => !!hop,
      destroy() { dead = true; sl.destroy(); w.remove(); chips.forEach((c) => c.el.remove()); },
    };
    api2.place(null); wake();
    return api2;
  }

  const api = { create, rider, sparks, sprite: '', reduced, buildSprite };
  window.Slime = api;
  buildSprite();
  window.addEventListener('dwut-theme', queueSprite);
  window.addEventListener('DOMContentLoaded', queueSprite);
  window.addEventListener('load', queueSprite);
  if (window.ipcRenderer) {
    try { window.ipcRenderer.on('app:request-theme-icon', () => buildSprite(true)); } catch {}
  }
  try { new MutationObserver(queueSprite).observe(document.documentElement, { attributes: true, attributeFilter: ['style', 'data-theme'] }); } catch { /* ignore */ }
})();
