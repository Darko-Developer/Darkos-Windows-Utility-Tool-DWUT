// Copyright © 2026 Darko / Darko.Dev
'use strict';
// Idle saver: when the window is minimised / hidden / fully covered, freeze every CSS animation so the GPU and CPU rest.
// (The canvas background and the slime loops already stop themselves on visibilitychange.)  Nothing changes visually.
(function () {
  const de = document.documentElement;
  let isSuspended = false;
  const sync = () => de.classList.toggle('idle', isSuspended || document.visibilityState !== 'visible');
  document.addEventListener('visibilitychange', sync);
  window.addEventListener('pagehide', () => { isSuspended = true; sync(); });
  window.addEventListener('pageshow', () => { isSuspended = false; sync(); });
  if (window.dwut && window.dwut.on) {
    try {
      window.dwut.on('app:suspend-render', () => { isSuspended = true; sync(); });
      window.dwut.on('app:resume-render', () => { isSuspended = false; sync(); });
    } catch {}
  }
  sync();
})();
