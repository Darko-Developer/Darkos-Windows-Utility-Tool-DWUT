// Copyright © 2026 Darko / Darko.Dev
'use strict';
Pages.register('dashboard', () => {
  const P = 16;
  let visible = false, timer = null, speedStarted = false, busy = false, logCount = 0;

  // Helper for telemetry colors: normally matches user's theme (var(--accent)).
  // Only transitions to orange (var(--warning)) or red (var(--error-real)) when reaching unusual/unsafe thresholds.
  function alertCol(val, warnThresh, dangerThresh) {
    if (val == null || isNaN(val)) return 'var(--accent)';
    if (dangerThresh != null && val >= dangerThresh) return 'var(--error-real)';
    if (warnThresh != null && val >= warnThresh) return 'var(--warning)';
    return 'var(--accent)';
  }

  // ── stat card ──
  function StatCard(title, unit, tooltip) {
    const defaultColorVar = 'var(--accent)';
    const val = h('div', { class: 'f24 b', text: '—', style: { color: defaultColorVar, padding: '0 10px', textAlign: 'center' } });
    const bar = Progress({ height: 3, radius: 2, color: defaultColorVar });
    const el = Card([
      h('div', { class: 'row', style: { justifyContent: 'center', margin: '10px 10px 2px' } },
        h('span', { class: 'f11 ts', text: title }), tooltip ? h('span', { style: 'margin-left:3px' }, Info(tooltip)) : null),
      val, h('div', { style: 'margin:4px 12px 10px' }, bar)], '', { minWidth: 0 });
    el.update = (v, pct, alertColor) => {
      const c = alertColor || defaultColorVar;
      if (v == null) { val.textContent = 'N/A'; val.style.color = 'var(--text_disabled)'; bar.set(0); }
      else {
        val.textContent = `${v.toFixed(unit === '%' ? 1 : 0)}${unit}`;
        val.style.color = c;
        if (bar.setColor) bar.setColor(c);
        if (pct != null) bar.set(pct / 100);
      }
    };
    el.setText = (t, c) => { val.textContent = t; val.style.color = c || defaultColorVar; if (bar.setColor) bar.setColor(c || defaultColorVar); bar.set(0); };
    return el;
  }
  const cpu = StatCard('CPU', '%', 'CPU utilisation across all logical cores.');
  const ram = StatCard('RAM', '%', 'Physical memory in use as a percentage of total RAM.');
  const disk = StatCard('DISK', '%', "Disk active time across all drives - the same number as Task Manager's Disk column. Constantly high values slow Windows down.");
  const stor = StatCard('STORAGE', '%', 'How full your C: drive is (used space as a percentage of its size). Keep it below about 90% so Windows has room to work.');
  const gpu = StatCard('GPU', '%', "GPU core load, any vendor.\n\nUses NVML on NVIDIA, Windows' own GPU Engine counters otherwise (same source as Task Manager's GPU graph) — needs the 'wmi' package installed.");
  const ctemp = StatCard('CPU °C', '°', "CPU temperature in Celsius.\n\nWindows has no built-in CPU die-temperature counter, so DWUT reads (in order): LibreHardwareMonitor / OpenHardwareMonitor if running, then Windows' thermal-zone sensors (most laptops and many desktops).\nN/A means this PC exposes no sensor to Windows — run LibreHardwareMonitor in the background and it will appear.");
  const temp = StatCard('GPU °C', '°', 'GPU temperature in Celsius.\nAvailable via pynvml (NVIDIA) or OpenHardwareMonitor.\nN/A is normal if neither is running — Windows has no vendor-agnostic temperature counter.');

  const health = h('span', { class: 'f12 b ts', text: 'Health: —' });
  const gpuName = h('span', { class: 'f9 td', style: 'text-align:right' });
  const gpuBtn = Btn('Install GPU Support', { variant: 'dim', w: 140, h: 22, f: 9, style: { display: 'none', marginRight: '8px' },
    onclick: async () => {
      gpuBtn.disabled = true; gpuBtn.textContent = 'Installing…';
      try { const r = await rpc('dashboard.install_gpu'); (r.ok ? notify : fail)(r.ok ? 'GPU Support' : 'Install Failed', r.ok ? r.message : `Couldn't install GPU packages:\n\n${r.message}`); }
      catch (e) { fail('Install Failed', e.message); }
      gpuBtn.disabled = false; gpuBtn.textContent = 'Install GPU Support';
    } });

  // ── detail cards ──
  function Detail(title, tipText, rows, keyW) {
    const labels = {};
    const body = rows.map(([k, t]) => {
      const v = h('span', { class: 'f11 tp grow', text: '—', style: 'padding-left:6px;text-align:left' });
      labels[k] = v;
      return h('div', { class: 'row', style: 'padding:2px 12px' },
        h('div', { class: 'row' }, h('span', { class: 'f11 ts', text: k + ':', style: `width:${keyW}px` }), Info(t, '')), v);
    });
    const el = Card([h('div', { class: 'row', style: 'padding:10px 12px 4px' }, h('span', { class: 'f13 b', text: title }),
      tipText ? h('span', { style: 'margin-left:5px' }, Info(tipText)) : null), body, h('div', { style: 'height:6px' })], '', { minWidth: 0 });
    el.labels = labels; return el;
  }
  const sys = Detail('System', '', [['CPU', 'CPU model name'], ['OS', 'Windows build number'], ['Uptime', 'Time since last restart — long uptimes lower the health score'],
    ['Host', 'Machine hostname'], ['Admin', 'Administrator rights — most DWUT features require this'], ['Reboot', 'Whether Windows needs a restart to finish installing updates']], 54);
  const net = Detail('Network', 'Live network send/receive rates and totals since boot.', [['Send Rate', 'Current upload speed'], ['Recv Rate', 'Current download speed'],
    ['Total Sent', 'Total bytes sent since boot'], ['Total Recv', 'Total bytes received since boot']], 74);
  const mem = Detail('Memory', 'Physical RAM usage breakdown.', [['Used', 'RAM currently in use'], ['Free', 'RAM available for new processes'],
    ['Total', 'Total physical RAM installed'], ['Usage', 'Percentage of RAM in use']], 46);

  // ── quick actions ──
  const quick = [
    ['Optimize & Repair', 'optimizer', 'SFC, DISM, network reset, tool launchers'],
    ['Game Booster', 'gaming', 'Real process priority + power plan boost'],
    ['Debloat Windows', 'debloat', 'Remove bloatware, disable telemetry & Recall'],
    ['VPN', 'vpn', 'Secure tunnel, DNS leak protection, server routing & killswitch'],
    ...(window.SHOW_PROXY ? [['Proxy Center', 'proxy', 'Fetch, validate and export proxies']] : []),
    ['Health', 'tools', 'Scan your whole PC and fix & optimize every component', 'Health'],
    ['Tools', 'tools', 'Registry cleaner, disk cleanup, drive storage']
  ];
  const qa = Card([h('div', { class: 'row', style: 'padding:10px 12px 6px' }, h('span', { class: 'f13 b', text: 'Quick Actions' })),
    h('div', { style: `display:grid;grid-template-columns:repeat(${quick.length + 1},1fr);padding:0 12px 10px;gap:6px` },
      [...quick.map(([l, p, t, tab]) => Btn(l, { h: 32, cls: 'fill', style: { margin: '0' }, tip: t, onclick: () => { Nav.go(p); if (tab) Nav.pages[p] && Nav.pages[p].openTab && Nav.pages[p].openTab(tab); } })),
       Btn('Task Manager', { h: 32, cls: 'fill', style: { margin: '0' }, tip: 'Open the DWUT Task Manager — a supercharged process manager with live charts, inspector, startup manager, services, and more.', onclick: () => window.dwut?.openTaskManager?.() })])]);

  // ── DWUT 1 CLICK BUTTON (moved here from its own page) ──
  const oneclick = window.OneClick.build();
  const tbok = window.Tbok.build();           // TBOK (CORPORATE AND BUSINESS) sits right under it

  // ── speed test ──
  const sres = {};
  const box = (key, label, colorVar, t) => {
    const v = h('div', { class: 'f18 b', text: '—', style: { color: colorVar, padding: '0 12px 4px' } });
    sres[key] = v;
    return h('div', { class: 'col', style: 'background:var(--bg_input);border-radius:6px;padding:4px 8px;margin-right:8px;align-items:center' },
      h('div', { class: 'row', style: 'padding-top:4px' }, h('span', { class: 'f10 ts', text: label }), h('span', { style: 'margin-left:2px' }, Info(t))), v);
  };
  const sbar = Progress({ height: 3, radius: 0 });
  const sbarWrap = h('div', { style: 'display:none;margin:0 12px 6px' }, sbar);
  const sstatus = h('div', { class: 'f9 td', style: 'margin-top:4px;text-align:center;max-width:220px' });
  const sbtn = Btn('Run Speed Test', { h: 34, onclick: () => runSpeed() });
  const speed = Card([
    h('div', { class: 'row', style: 'padding:10px 12px 6px' }, h('span', { class: 'f13 b', text: 'Internet Speed Test' }),
      h('span', { style: 'margin-left:5px' }, Info("Measures real download and upload speed using Cloudflare's\nspeed.cloudflare.com endpoint — no third-party service.\n\nDownload: fetches a 10 MB payload, measures throughput.\nUpload: sends a 2 MB payload, measures throughput.\nLatency: raw TCP connect time to 1.1.1.1:443."))),
    h('div', { class: 'row', style: 'padding:0 12px 12px' },
      h('div', { class: 'row grow' }, box('download', 'Download', 'var(--success)', 'Download speed in Mbps (megabits per second).'),
        box('upload', 'Upload', 'var(--accent)', 'Upload speed in Mbps (megabits per second).'),
        box('latency', 'Latency', 'var(--warning)', 'Round-trip latency to Cloudflare 1.1.1.1:443 in milliseconds.')),
      h('div', { class: 'col', style: 'align-items:center;margin-left:8px' }, sbtn, sstatus)),
    sbarWrap]);
  async function runSpeed() {
    sbtn.disabled = true; sbtn.textContent = 'Running…'; sbar.set(0); sbarWrap.style.display = ''; sstatus.textContent = 'Measuring latency…';
    for (const k of ['download', 'upload', 'latency']) sres[k].textContent = '…';
    try {
      const r = await rpc('speedtest.run');
      sres.latency.textContent = r.latency != null ? `${Number(r.latency || 0).toFixed(0)} ms` : 'err';
      sres.download.textContent = r.download != null ? `${Number(r.download || 0).toFixed(0)} Mbps` : 'err';
      sres.upload.textContent = r.upload != null ? `${Number(r.upload || 0).toFixed(0)} Mbps` : 'err';
      setTimeout(() => { sbar.set(0); sbarWrap.style.display = 'none'; }, 2000);
    } catch (e) { sstatus.textContent = 'Error: ' + e.message; }
    sbtn.disabled = false; sbtn.textContent = 'Run Speed Test';
  }
  on('speedtest.progress', (d) => { sbar.set(d.value); sstatus.textContent = d.status; });

  // ── log ──
  const logBox = Textbox({ f: 10, max: 150 }); logBox.style.flex = '1'; logBox.style.margin = '0 10px 10px';
  const logCard = Card([h('div', { class: 'row', style: 'padding:10px 12px 4px' }, h('span', { class: 'f13 b', text: 'Recent Activity' }), h('div', { class: 'grow' }),
    Btn('Clear', { variant: 'plain', h: 22, w: 44, f: 10, style: { color: 'var(--text_disabled)', minWidth: '44px', borderRadius: '4px' }, onclick: () => logBox.clear() })), logBox], '', { flex: '1', display: 'flex', flexDirection: 'column', minHeight: '110px' });
  on('log.line', (rec) => {
    if (!visible) return;
    const d = new Date(rec.timestamp);
    const ts = [d.getHours(), d.getMinutes(), d.getSeconds()].map((n) => String(n).padStart(2, '0')).join(':');
    logBox.line(`[${ts}]  ${String(rec.level).padEnd(7)}  ${rec.message}`);
  });

  // ── assemble ──
  const hub = window.Hub ? Hub.build((k) => Nav.go(k)) : null;      // the hub (replaces the old sidebar menu)
  const cpuNote = h('span', { class: 'f9 td', style: 'margin-right:auto' });
  const gpuRow = h('div', { class: 'row', style: 'justify-content:flex-end;padding:0 4px 2px' }, cpuNote, gpuBtn, gpuName);
  const cards = h('div', { style: 'display:grid;grid-template-columns:repeat(7,1fr);gap:0' }, [cpu, ctemp, ram, disk, stor, gpu, temp].map((c) => { c.style.margin = '2px 4px'; return c; }));
  // The Dashboard never scrolls: the hub sits on top and everything else lives in a tabbed deck underneath that fills the rest of the window.
  const PANES = {
    Telemetry: h('div', { class: 'dash-pane col' }, h('div', { style: 'flex:none' }, cards, gpuRow),
      h('div', { style: 'display:grid;grid-template-columns:3fr 2fr 2fr;gap:6px;flex:none;margin-top:2px' }, sys, net, mem)),
    'One-Click': h('div', { class: 'dash-pane dash-pair', style: 'display:grid;grid-template-columns:1fr 1fr;gap:8px;align-items:start' }, oneclick.el, tbok.el),
    'Quick Actions': h('div', { class: 'dash-pane col', style: 'gap:8px' }, qa, speed),
    Activity: h('div', { class: 'dash-pane col' }, logCard),
  };
  const dtabs = {}, tabBar = h('div', { class: 'dash-tabs' });
  function showPane(name) {
    for (const [n, p] of Object.entries(PANES)) {
      const on = n === name; p.style.display = on ? '' : 'none'; dtabs[n].classList.toggle('active', on);
      if (on) { p.classList.remove('dp-in'); void p.offsetWidth; p.classList.add('dp-in'); }
    }
  }
  for (const n of Object.keys(PANES)) { dtabs[n] = Btn(n, { variant: 'plain', cls: 'tab f12', onclick: () => showPane(n) }); tabBar.append(dtabs[n]); }
  const deck = h('div', { class: 'dash-deck col' }, ...Object.values(PANES));
  const el = h('div', { class: 'col dash-root', style: `flex:1;min-height:0;padding:0 ${P}px ${P - 4}px` },
    hub ? h('div', { style: `margin-top:${P - 8}px;flex:none` }, hub.el) : null,
    h('div', { class: 'row title-row dash-head', style: `height:44px;margin-top:4px;flex:none;padding:0` }, h('h1', { text: 'System Overview' }), tabBar, h('div', { class: 'grow' }), health),
    deck);
  showPane('Telemetry');

  function upd(s) {
    const snap = s.snap;
    cpu.update(snap.cpu_pct, snap.cpu_pct, alertCol(snap.cpu_pct, 92, 98));
    ctemp.update(snap.cpu_temp_c != null ? snap.cpu_temp_c : null, snap.cpu_temp_c, alertCol(snap.cpu_temp_c, 80, 90));          // bar = degrees on a 0-100 °C scale
    cpuNote.textContent = snap.cpu_temp_c != null ? `CPU temp  [${snap.cpu_temp_src || 'sensor'}]` : 'CPU temp: no sensor exposed by this PC';
    ram.update(snap.ram_pct, snap.ram_pct, alertCol(snap.ram_pct, 90, 96));
    disk.update(snap.disk_active_pct, snap.disk_active_pct, alertCol(snap.disk_active_pct, 90, 96));
    stor.update(snap.disk_pct, snap.disk_pct, alertCol(snap.disk_pct, 90, 96));
    if (snap.gpu) {
      const src = { nvml: 'NVML', ohm: 'OHM', perfcounter: 'GPU Engine', wmi_name: 'WMI' }[snap.gpu.source] || '';
      gpuName.textContent = src ? `${snap.gpu.name}  [${src}]` : snap.gpu.name;
      snap.gpu.usage_pct != null ? gpu.update(snap.gpu.usage_pct, snap.gpu.usage_pct, alertCol(snap.gpu.usage_pct, 92, 98)) : gpu.setText('Detected', 'var(--accent)');
      temp.update(snap.gpu.temp_c != null ? snap.gpu.temp_c : null, snap.gpu.temp_c, alertCol(snap.gpu.temp_c, 80, 88));
      gpuBtn.style.display = 'none';
    } else {
      gpu.update(null); temp.update(null);
      gpuName.textContent = `GPU: not detected — ${s.gpu_status || ''}`;
      gpuBtn.style.display = s.gpu_missing ? '' : 'none';
    }
    const up = Math.floor(snap.uptime), d = Math.floor(up / 86400), hr = Math.floor((up % 86400) / 3600), m = Math.floor((up % 3600) / 60);
    sys.labels.CPU.textContent = snap.cpu_name; sys.labels.OS.textContent = snap.windows_version;
    sys.labels.Uptime.textContent = d ? `${d}d ${hr}h ${m}m` : `${hr}h ${m}m`; sys.labels.Host.textContent = snap.hostname;
    sys.labels.Admin.textContent = snap.is_admin ? 'Yes' : 'No — restart as admin'; sys.labels.Admin.style.color = snap.is_admin ? 'var(--success)' : 'var(--warning)';
    sys.labels.Reboot.textContent = snap.pending_reboot ? 'Restart pending' : 'None'; sys.labels.Reboot.style.color = snap.pending_reboot ? 'var(--warning)' : 'var(--success)';
    const rate = (v) => (v == null ? '—' : `${Number(v).toFixed(2)} Mbps`);
    const n = snap.net;
    net.labels['Send Rate'].textContent = rate(n.send_mbps); net.labels['Recv Rate'].textContent = rate(n.recv_mbps);
    net.labels['Total Sent'].textContent = fmt.bytes(n.bytes_sent); net.labels['Total Recv'].textContent = fmt.bytes(n.bytes_recv);
    mem.labels.Used.textContent = `${Number(snap.ram_used_gb || 0).toFixed(2)} GB`; mem.labels.Free.textContent = `${Number(snap.ram_avail_gb || 0).toFixed(2)} GB`;
    mem.labels.Total.textContent = `${Number(snap.ram_total_gb || 0).toFixed(2)} GB`; mem.labels.Usage.textContent = `${Number(snap.ram_pct || 0).toFixed(1)}%`;
    if (hub) hub.update(snap, s.health);
    const hc = { Excellent: 'var(--success)', Good: 'var(--accent)', Fair: 'var(--warning)', Poor: 'var(--error-real)' };
    health.textContent = `Health: ${s.health.total}%  —  ${s.health.label}`; health.style.color = hc[s.health.label] || 'var(--text_secondary)';
  }
  async function refresh() {
    if (!visible || busy || document.documentElement.classList.contains('idle')) return; busy = true;      // window minimised / in the tray: skip the backend call
    try { const s = await rpc('dashboard.snapshot'); if (s && s.snap && s.health && visible) upd(s); } catch (e) { console.warn(e); }
    busy = false;
  }
  return {
    el, oneclick, tbok,
    onShow() {
      visible = true; refresh(); oneclick.onShow();
      timer = setInterval(refresh, Math.max(500, Cfg.v.dashboard_refresh_ms || 2000));
      if (!speedStarted) { speedStarted = true; setTimeout(runSpeed, 800); }
    },
    onHide() { visible = false; clearInterval(timer); },
  };
});
