// Copyright © 2026 Darko / Darko.Dev
'use strict';
// Extra BIOS categories (same row format as bios_data.js): [name, recommended value, why, where, who a|i|*, risk s|c|x]
(function () {
  const add = (name, sub, rows) => window.BIOS_CATS.push([name, sub, rows]);
  // put the gamer-critical groups first
  const first = (name, sub, rows) => window.BIOS_CATS.unshift([name, sub, rows]);
  first('Boot & Performance', 'Startup & core switches', [
    ['BCLK 100MHz lock', 'On / Auto', 'Keeps the base clock at exactly 100 MHz so the CPU, PCIe and USB clocks stay in spec while you overclock via multipliers.', 'AI Tweaker > BCLK / PCIE Frequency', 'i', 'c'],
    ['Boot performance mode', 'Turbo Performance', 'Boots with the highest CPU ratio and power limits so the OS loads fast and benchmarks start at full speed.', 'Advanced > CPU Configuration > Boot Performance Mode', 'i', 's'],
    ['Fast Boot', 'Enabled', 'Skips device checks at power-on. Turn off if you cannot enter the BIOS with the key.', 'Boot > Fast Boot', '*', 's'],
    ['Ultra Fast Boot / Fast Boot USB', 'Enabled after setup is final', 'Skips USB and storage initialisation until Windows loads. Use a BIOS-entry button or Windows restart-to-UEFI afterwards.', 'Boot > Fast Boot > USB Support', '*', 'c'],
    ['Spread Spectrum (CPU / PCIe / FIVR)', 'Disabled', 'Dithers clocks to lower EMI. Disabling gives cleaner clocks and removes a source of jitter for overclocks.', 'AI Tweaker > Spread Spectrum / Advanced > FIVR', '*', 'c'],
    ['PCI delay optimisation', 'Enabled', 'Shortens the PCI bus delay at POST so the system starts quicker with many devices.', 'Advanced > PCI Subsystem Settings', '*', 's'],
    ['Quiet Boot / Full-screen logo', 'Disabled', 'Skips the logo and shows POST text; trims a second or two and helps troubleshooting.', 'Boot > Boot Logo Display', '*', 's'],
    ['Boot Num-Lock state', 'On', 'Keeps Num Lock on at start. Purely convenience.', 'Boot > Bootup NumLock State', '*', 's'],
    ['Wait for F1 on error', 'Disabled', 'Stops the PC freezing at "press F1" after a harmless warning such as no keyboard.', 'Boot > Wait for F1 If Error', '*', 's'],
    ['Option ROM messages', 'Disabled', 'Hides add-in card banners at POST and speeds startup.', 'Boot > Option ROM Messages', '*', 's'],
    ['CPU ratio sync (Sync all cores)', 'Auto', 'Manual all-core ratios disable per-core boosting; keep Auto unless doing a deliberate overclock.', 'AI Tweaker > CPU Core Ratio', 'i', 'x'],
    ['Game Boost / OC Genie / Performance preset', 'Off unless you trust it', 'One-button overclocks apply aggressive voltages. Prefer manual PBO, XMP/EXPO and curve tuning.', 'OC > Game Boost / OC Genie', '*', 'x'],
    ['Enhanced Turbo / Multi-Core Enhancement', 'Auto or Off', 'Board makers remove power limits by default; fine with strong cooling, hot and noisy without.', 'AI Tweaker > MCE / Enhanced Turbo', 'i', 'c'],
  ]);
  add('C-States', 'CPU sleep states', [
    ['C1E (Enhanced Halt)', 'Enabled for efficiency, Disabled for lowest latency', 'Drops idle cores to a lower voltage/clock. Disabling removes the wake-up delay in latency-sensitive games.', 'CPU Configuration > C1E', 'i', 'c'],
    ['C3 state support', 'Disabled', 'Rarely used deep state; disabling avoids occasional wake-up stutter with no real power cost.', 'CPU Configuration > C3 State', 'i', 's'],
    ['C6 / C7 state support', 'Enabled normally', 'Biggest idle power savings. Disable only when chasing the lowest possible wake latency.', 'CPU Configuration > C6 / C7', 'i', 'c'],
    ['Package C-State limit', 'C6 / Auto', 'How deep the whole CPU may sleep when idle. Auto is the right choice for nearly everyone.', 'CPU Configuration > Package C State Limit', 'i', 's'],
    ['Global C-State Control', 'Auto', 'AMD master switch for C-states. Disabling can cure rare audio crackle or USB drop-outs.', 'AMD CBS > CPU Common Options > Global C-state Control', 'a', 'c'],
    ['Core C6 (CC6) state', 'Enabled', 'Per-core deep sleep on Ryzen; keep on for best idle power and boost behaviour.', 'AMD CBS > Zen Common > Core Performance Boost', 'a', 's'],
    ['Package C6 (PC6) state', 'Enabled', 'Deep package sleep on Ryzen. Disable only for diagnosis.', 'AMD CBS > CPU Common Options', 'a', 's'],
    ['C-state auto-demotion / undemotion', 'Disabled for latency tuning', 'Stops the CPU quietly sliding to a shallower sleep state; fine-tunes wake-up time.', 'CPU Configuration > C-State Auto Demotion', 'i', 'x'],
    ['Enhanced Halt (C1E) on AMD', 'Auto', 'Older name for C1E on AM4/AM5. Leave on Auto.', 'AMD CBS > CPU Common Options', 'a', 's'],
    ['CPU C-states in legacy OS', 'Enabled', 'Allows Windows to request C-states through ACPI. Required for normal idle behaviour.', 'CPU Configuration > ACPI C-states', '*', 's'],
    ['Race to Halt (RTH)', 'Enabled', 'Finishes work quickly then sleeps. Helps efficiency without hurting latency on modern Intel.', 'CPU Configuration > Race To Halt', 'i', 's'],
    ['Deep Sleep / S3 / S0ix', 'S3 for desktops that must sleep', 'Controls how deep the PC sleeps. S3 is the classic, most compatible desktop sleep.', 'Advanced > ACPI Settings', '*', 'c'],
  ]);
  add('Energy Efficiency', 'Power management', [
    ['Enhanced Intel SpeedStep (EIST)', 'Enabled', 'Lets the CPU change speed with load. Needed for Turbo to work correctly.', 'CPU Configuration > EIST', 'i', 's'],
    ['Intel Speed Shift (HWP)', 'Enabled', 'The CPU picks its own clocks in microseconds. Smoother frame pacing than OS-driven P-states.', 'CPU Configuration > Intel Speed Shift Technology', 'i', 's'],
    ['AMD CPPC / CPPC Preferred Cores', 'Enabled', 'Lets Windows steer threads to the best cores on Ryzen; required for good game scheduling.', 'AMD CBS > SMU > CPPC / CPPC Preferred Cores', 'a', 's'],
    ['Cool\'n\'Quiet & P-states', 'Enabled', 'Normal AMD frequency scaling.', 'AMD CBS > CPU Common Options', 'a', 's'],
    ['Turbo power limits lock', 'Off', 'Lets you change PL1/PL2 and keep your settings; locked values reset to Intel defaults.', 'Advanced > CPU > Power Limit Lock', 'i', 'c'],
    ['Energy Efficient Turbo', 'Disabled', 'Reduces boost to save power when work looks light, which can cost FPS in games with bursty loads.', 'CPU Configuration > Energy Efficient Turbo', 'i', 's'],
    ['Intel Dynamic Tuning / Thermal Velocity Boost', 'Enabled', 'Higher boosts when the CPU is cool; worthwhile with a good cooler.', 'CPU Configuration > Thermal Velocity Boost', 'i', 's'],
    ['AMD ECO mode / TDP limit', 'Off (95/105 W stock)', 'Caps CPU power. Only enable for a quiet or cool build, not for gaming speed.', 'AMD Overclocking > Precision Boost > Eco Mode', 'a', 'c'],
    ['ErP Ready (EuP 2013)', 'Disabled', 'Cuts all standby power which also disables USB charging and Wake-on-LAN. Keep disabled for convenience.', 'Advanced > APM Configuration > ErP Ready', '*', 's'],
    ['PCH power gating / DMI ASPM', 'Disabled for stability', 'Lets the chipset idle deeply. A few boards stutter when it wakes; disable if you see micro-lag.', 'Advanced > PCH-FW / DMI Link ASPM', 'i', 'c'],
    ['Hardware P-state control', 'Native', 'Let Windows/HWP handle P-states. Do not force manual P-states on daily systems.', 'AMD CBS > SMU', 'a', 's'],
    ['Power-On by RTC / PME', 'Disabled', 'Stops scheduled or network wake-ups from turning the PC on unexpectedly.', 'Advanced > APM Configuration > Power On By RTC', '*', 's'],
    ['Restore AC power loss', 'Power Off', 'Prevents the PC from auto-starting after a power cut. Use Power On for servers.', 'Advanced > APM > Restore AC Power Loss', '*', 's'],
  ]);
  add('PCIe', 'Lanes & devices', [
    ['PCIe link speed (x16 slot)', 'Auto / Gen 4 / Gen 5', 'Forces the GPU slot to its top generation. Drop one Gen if you use a riser cable or see black screens.', 'Advanced > PCI Subsystem > PCIE x16 Link Speed', '*', 's'],
    ['PCIe NVMe link speed', 'Auto', 'Forces M.2 slots to Gen 4/5. Fix for drives falling back to Gen 3.', 'Advanced > PCI Subsystem > M.2 Link Mode', '*', 's'],
    ['PCIe ASPM', 'Disabled', 'Active State Power Management can add latency or device drop-outs on desktops.', 'Advanced > Onboard Devices > PCIe ASPM', '*', 's'],
    ['PCIe slot bifurcation', 'Auto (x4x4x4x4 for NVMe cards)', 'Splits a slot for multi-drive adapter cards. Not needed for normal use.', 'Advanced > PCI Subsystem > PCIEX16 Bifurcation', '*', 'c'],
    ['PCIe native power management', 'Disabled', 'Stops Windows from controlling PCIe sleep states; cures some wake and hot-plug bugs.', 'Advanced > PCI Express Native Power Management', '*', 'c'],
    ['PCIe Resizable BAR', 'Enabled', 'Lets the CPU address the whole GPU memory. Needs Above 4G Decoding and CSM off.', 'Advanced > PCI Subsystem > Re-Size BAR Support', '*', 's'],
    ['Above 4G Decoding', 'Enabled', 'Maps big PCIe devices above 4 GB. Required for ReBAR and some GPUs/accelerators.', 'Advanced > PCI Subsystem > Above 4G Decoding', '*', 's'],
    ['PCIe Gen5 / Gen4 compliance mode', 'Auto', 'Advanced signal-training modes. Only change if a Gen 5 device fails to link at full speed.', 'Advanced > PCI Subsystem', '*', 'x'],
    ['SR-IOV', 'Disabled unless hosting VMs', 'Splits devices across virtual machines. Safe to leave off on a gaming PC.', 'Advanced > PCI Subsystem > SR-IOV Support', '*', 's'],
    ['PCI latency timer', '32 (default)', 'Bus latency for legacy PCI devices. Leave at default on modern boards.', 'Advanced > PCI Subsystem > PCI Latency Timer', '*', 's'],
    ['Primary PCIe graphics', 'PEG / Auto', 'Picks which GPU the BIOS uses first. Set to the discrete card when you have an iGPU too.', 'Advanced > NB Configuration > Primary Graphics Adapter', '*', 's'],
    ['Hot-plug PCIe / Thunderbolt', 'Enabled only if used', 'Reserves resources for hot-plugged devices; disable to speed boot if you never hot-plug.', 'Advanced > PCI Express Hot Plug', '*', 's'],
  ]);
  add('Timers & Latency', 'Frame pacing & input', [
    ['HPET (High Precision Event Timer)', 'Enabled in BIOS, not forced in Windows', 'Windows picks the best timer by itself. Leave the BIOS option on and avoid forcing useplatformclock.', 'Advanced > PCH Configuration > HPET', '*', 's'],
    ['TSC / invariant TSC', 'Auto', 'Constant-rate timestamp counter; modern CPUs have it always. Nothing to change.', 'n/a', '*', 's'],
    ['Intel Turbo Boost Max 3.0', 'Enabled', 'Sends single-thread work to the fastest core; helps lightly threaded games.', 'CPU Configuration > Turbo Boost Max Technology 3.0', 'i', 's'],
    ['Active cores (E-cores / P-cores)', 'All cores', 'Disabling E-cores helps a few old games but hurts multitasking. Try only for a specific title.', 'CPU Configuration > Active Efficient-cores', 'i', 'c'],
    ['AMD CCD / Game Mode', 'Auto (Game Mode off on 3D V-Cache)', 'On dual-CCD X3D chips use the Windows Game Mode / chipset driver to park the non-cache CCD.', 'AMD CBS > Zen > CCD Control', 'a', 'c'],
    ['3D V-Cache optimiser', 'Driver + Game Mode on', 'Keeps games on the cache CCD. Install the AMD chipset driver for it to work.', 'Windows + chipset driver', 'a', 's'],
    ['Core Performance Boost', 'Enabled', 'Boost clocks on Ryzen. Never disable for gaming.', 'AMD CBS > CPU Common Options', 'a', 's'],
    ['USB polling / XHCI', 'Enabled', 'Normal USB 3 operation. The BIOS XHCI hand-off option avoids slow starts for devices.', 'Advanced > USB Configuration', '*', 's'],
    ['Audio controller (HD Audio)', 'Disabled if using a USB DAC', 'Frees an interrupt and a driver; fewer DPC spikes with some boards.', 'Advanced > Onboard Devices > HD Audio', '*', 's'],
    ['Serial / parallel / COM ports', 'Disabled', 'Legacy ports waste resources and boot time.', 'Advanced > Super IO Configuration', '*', 's'],
    ['Integrated Wi-Fi / Bluetooth', 'Disabled if unused', 'Fewer interrupts and drivers; a classic latency tidy-up when you use Ethernet.', 'Advanced > Onboard Devices', '*', 's'],
    ['Low-latency interrupt moderation (NIC)', 'Off', 'A Windows driver setting, not BIOS. Mentioned here because it is the usual follow-up to BIOS tuning.', 'Device Manager > NIC > Advanced', '*', 'c'],
  ]);
  add('Intel Overclocking', 'Core 12th-14th gen', [
    ['Intel Default Settings / Extreme profile', 'Intel Default', 'Use the official limits on 13th/14th gen chips to avoid the instability caused by over-spec motherboard power defaults.', 'Advanced > CPU > Intel Default Settings', 'i', 'c'],
    ['Intel Adaptive Voltage / Vcore', 'Auto or Adaptive', 'Adaptive voltage scales with clock. Fixed Vcore wastes power and heat.', 'AI Tweaker > CPU Core Voltage', 'i', 'x'],
    ['Core ratio per-core limit', 'Auto', 'Set individual boost multipliers. For tuners only.', 'AI Tweaker > Specific Core Ratio', 'i', 'x'],
    ['AVX offset / AVX2 / AVX-512', 'Auto', 'Negative offset lowers clocks under AVX load to stay cool.', 'AI Tweaker > AVX Related Controls', 'i', 'x'],
    ['Cache (ring) ratio', 'Auto / 2-4 below core', 'Raising ring speed improves game minimums but costs stability headroom.', 'AI Tweaker > Cache Ratio', 'i', 'x'],
    ['Load-line calibration (LLC)', 'Medium', 'Counters Vdroop. Too aggressive causes voltage overshoot at load release.', 'AI Tweaker > DIGI+ VRM > LLC', 'i', 'x'],
    ['Undervolt / V-F offset', '-50 mV to -100 mV', 'Free temperature and boost headroom if stable; test with a stress run.', 'AI Tweaker > Core Voltage Offset', 'i', 'x'],
    ['FIVR spread spectrum', 'Disabled', 'Reduces VRM clock dithering; slightly cleaner power at a tiny EMI cost.', 'Advanced > FIVR Control', 'i', 'c'],
    ['Intel Thread Director', 'Enabled', 'Lets Windows 11 place threads on P/E-cores correctly.', 'CPU Configuration > Thread Director', 'i', 's'],
    ['TVB voltage optimisations', 'Enabled', 'Trims voltage while in Thermal Velocity Boost. Safe and cooler.', 'AI Tweaker > TVB Voltage Optimizations', 'i', 's'],
    ['PL1 / PL2 power limits', '253 W / 4096 s on K chips, if cooled', 'Raising limits lets the CPU hold boost clocks. Needs strong cooling and VRMs.', 'AI Tweaker > Internal CPU Power Management', 'i', 'x'],
    ['Current limit (IccMax)', 'Auto / Intel spec', 'Caps peak current. Raising it can overheat VRMs.', 'AI Tweaker > IccMax', 'i', 'x'],
  ]);
  add('AMD Ryzen Tuning', 'AM4 / AM5', [
    ['Precision Boost Overdrive (PBO)', 'Enabled / Advanced', 'Lifts the boost power, current and thermal limits to your cooling headroom.', 'AMD Overclocking > PBO', 'a', 'c'],
    ['PBO limits (PPT / TDC / EDC)', 'Motherboard / 0 (auto)', 'Larger limits give longer all-core boost. Needs a decent board and cooler.', 'PBO > Advanced > Limits', 'a', 'x'],
    ['Curve Optimizer', 'All cores -10 to -30', 'Per-core undervolting that improves boost clocks. Test each step for stability.', 'PBO > Curve Optimizer', 'a', 'x'],
    ['Curve Shaper (AM5)', 'Per frequency band', 'Finer control than the Curve Optimizer on Zen 5.', 'PBO > Curve Shaper', 'a', 'x'],
    ['PBO scalar', 'Auto / 1x', 'Time spent at high voltage; higher scalar wears chips faster for tiny gains.', 'PBO > Precision Boost Overdrive Scalar', 'a', 'x'],
    ['Max CPU boost clock override', '+0 to +200 MHz', 'Raises the single-core ceiling when temperatures allow.', 'PBO > Max CPU Boost Clock Override', 'a', 'x'],
    ['Infinity Fabric (FCLK)', '2000 MHz with DDR5-6000', 'The sweet spot on AM5; 1:1 with memory gives the best latency.', 'AMD Overclocking > FCLK Frequency', 'a', 'c'],
    ['Memory context restore', 'Enabled after testing', 'Skips training on boot; disable while tuning RAM.', 'AMD CBS > UMC > Memory Context Restore', 'a', 's'],
    ['Power Supply Idle Control', 'Typical current idle', 'Fix for old Ryzen idle crashes on very low-load systems.', 'AMD CBS > CPU Common Options', 'a', 'c'],
    ['SVM Mode', 'Enabled', 'Needed for virtualisation and Windows security features.', 'AMD CBS > CPU Common Options > SVM Mode', 'a', 's'],
    ['Core Performance Boost', 'Enabled', 'Main Ryzen boost switch. Keep on.', 'AMD CBS > CPU Common Options', 'a', 's'],
    ['Zen Common: Opcache control', 'Auto', 'Op-cache tuning; rarely useful. Leave Auto.', 'AMD CBS > Zen Common Options', 'a', 'x'],
  ]);
})();
