// Copyright © 2026 Darko / Darko.Dev
'use strict';
Pages.register('gaming', () => {
  /* ── live graph ───────────────────────────────────────────────
     Scrolling line chart backed by a Float32Array ring buffer.
     Values are 0-1 (already normalised by caller).              */
  const GRAPH_H = 48, SAMPLES = 90;          // width follows the card, so 5 or 7 cards in a row all look the same

  function makeGraph(colorVar) {
    const buf = new Float32Array(SAMPLES);
    let   head = 0, lastVal = 0, GRAPH_W = 180;
    const cv = document.createElement('canvas');
    cv.width = GRAPH_W; cv.height = GRAPH_H;
    cv.style.cssText = `width:100%;height:${GRAPH_H}px;display:block;border-radius:5px`;
    const cx = cv.getContext('2d');

    function push(v) { buf[head++ % SAMPLES] = lastVal = Math.max(0, Math.min(1, v)); redraw(); }

    function redraw() {
      const cs   = getComputedStyle(document.documentElement);
      const col  = cs.getPropertyValue(colorVar).trim() || '#4a7cff';
      const bg   = cs.getPropertyValue('--bg_input').trim() || '#111';
      const grid = cs.getPropertyValue('--border').trim() || '#222';

      cx.clearRect(0, 0, GRAPH_W, GRAPH_H);
      cx.fillStyle = bg; cx.fillRect(0, 0, GRAPH_W, GRAPH_H);

      // grid lines
      cx.strokeStyle = grid; cx.lineWidth = 0.5; cx.setLineDash([2, 4]);
      [0.25, 0.5, 0.75].forEach(p => {
        cx.beginPath(); cx.moveTo(0, GRAPH_H * (1 - p)); cx.lineTo(GRAPH_W, GRAPH_H * (1 - p)); cx.stroke();
      });
      cx.setLineDash([]);

      const step = GRAPH_W / (SAMPLES - 1);

      // fill
      const grad = cx.createLinearGradient(0, 0, 0, GRAPH_H);
      grad.addColorStop(0,   col.replace(/rgb\(/, 'rgba(').replace(')', ',0.4)'));
      grad.addColorStop(1,   col.replace(/rgb\(/, 'rgba(').replace(')', ',0.02)'));
      cx.beginPath(); cx.moveTo(0, GRAPH_H);
      for (let i = 0; i < SAMPLES; i++) {
        const val = buf[(head - SAMPLES + i + SAMPLES * 10) % SAMPLES];
        const x = i * step, y = GRAPH_H - val * (GRAPH_H - 4) - 2;
        i === 0 ? cx.lineTo(x, y) : cx.lineTo(x, y);
      }
      cx.lineTo(GRAPH_W, GRAPH_H); cx.closePath();
      cx.fillStyle = grad; cx.fill();

      // line
      cx.beginPath(); cx.strokeStyle = col; cx.lineWidth = 1.5;
      for (let i = 0; i < SAMPLES; i++) {
        const val = buf[(head - SAMPLES + i + SAMPLES * 10) % SAMPLES];
        const x = i * step, y = GRAPH_H - val * (GRAPH_H - 4) - 2;
        i === 0 ? cx.moveTo(x, y) : cx.lineTo(x, y);
      }
      cx.stroke();
    }

    redraw();
    if (typeof ResizeObserver !== 'undefined') {        // keep the drawing 1:1 with the card width (crisp lines at any width)
      new ResizeObserver(() => {
        const w = Math.round(cv.clientWidth);
        if (w > 20 && w !== GRAPH_W) { GRAPH_W = w; cv.width = w; redraw(); }
      }).observe(cv);
    }
    return { cv, push, get last() { return lastVal; } };
  }

  /* ── metric card ─────────────────────────────────────────────── */
  const graphs = {}, valLabels = {}, subLabels = {};

  function metricCard(key, label, unit, colorVar) {
    const g   = makeGraph(colorVar); graphs[key] = g;
    const val = h('span', { style: `font-size:20px;font-weight:700;line-height:1;color:var(${colorVar})`, text: '--' });
    valLabels[key] = val;
    const sub = h('span', { class: 'f10 ts', text: '', style: 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-height:14px;display:block' }); subLabels[key] = sub;
    const unitLbl = h('span', { class: 'f10 ts', style: 'margin-left:2px;align-self:flex-end;padding-bottom:2px', text: unit });

    return h('div', {
      style: `backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);
              background:color-mix(in srgb,var(--bg_card) 12%,transparent);
              border:1px solid color-mix(in srgb,var(--border) 55%,transparent);
              border-top:1px solid color-mix(in srgb,#fff 10%,transparent);
              border-radius:10px;box-shadow:inset 0 1px 0 color-mix(in srgb,#fff 8%,transparent);
              padding:10px 12px 8px;display:flex;flex-direction:column;gap:3px;min-width:0;flex:1`
    },
      h('div', { class: 'f10 b ts', text: label, style: 'letter-spacing:.5px;text-transform:uppercase' }),
      h('div', { style: 'display:flex;align-items:baseline' }, val, unitLbl),
      sub,
      h('div', { style: 'margin-top:4px;border-radius:5px;overflow:hidden' }, g.cv));
  }

  function setMetric(key, raw, norm, sub) {
    valLabels[key].textContent = raw == null ? '--' : (typeof raw === 'number' ? (raw >= 100 ? Math.round(raw) : raw.toFixed(1)) : raw);
    if (sub != null) subLabels[key].textContent = sub;
    if (typeof norm === 'number') graphs[key].push(norm);
  }

  /* ── graph grid ─────────────────────────────────────────────── */
  const graphGrid = h('div', { style: 'display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:8px' },
    metricCard('cpu',  'CPU',     '%',    '--accent'),
    metricCard('ctemp', 'CPU Temp', '°C', '--accent'),
    metricCard('gpu',  'GPU',     '%',    '--error'),
    metricCard('gtemp', 'GPU Temp', '°C', '--error'),
    metricCard('ram',  'RAM',     '%',    '--success'),
    metricCard('disk', 'Disk',    '%',    '--warning'),
    metricCard('net',  'Network', 'Mbps', '--info'));

  /* ── live polling ────────────────────────────────────────────── */
  let _pollTimer = null, _gamePollTimer = null;
  async function sampleStats() {
    if (document.documentElement.classList.contains('idle')) return;
    try {
      const s = await rpc('gaming.system_stats');
      if (s) {
        setMetric('cpu',  s.cpu,  s.cpu  / 100, `${s.cpu.toFixed(1)}% used`);
        setMetric('gpu',  s.gpu,  s.gpu  / 100, `${s.gpu.toFixed(1)}% used`);
        const tNA = (v) => v == null;
        setMetric('ctemp', tNA(s.cpu_temp) ? 'N/A' : s.cpu_temp, tNA(s.cpu_temp) ? 0 : s.cpu_temp / 100, tNA(s.cpu_temp) ? 'no sensor' : (s.cpu_temp_src || 'sensor'));
        setMetric('gtemp', tNA(s.gpu_temp) ? 'N/A' : s.gpu_temp, tNA(s.gpu_temp) ? 0 : s.gpu_temp / 100, tNA(s.gpu_temp) ? 'no sensor' : (s.gpu_temp_src || 'sensor'));
        setMetric('ram',  s.ram,  s.ram  / 100, `${s.ram.toFixed(1)}% used`);
        setMetric('disk', s.disk, s.disk / 100, `R ${Number(s.disk_read || 0).toFixed(1)} / W ${Number(s.disk_write || 0).toFixed(1)} MB/s`);
        setMetric('net',  s.net,  Math.min(1, s.net * 2 / 100), `↑ ${Number(s.net_send || 0).toFixed(1)} / ↓ ${Number(s.net_recv || 0).toFixed(1)} Mbps`);
      }
    } catch { /* backend not ready yet */ }
  }

  async function checkDetectedGame() {
    if (document.documentElement.classList.contains('idle')) return;
    try {
      const g = await rpc('gaming.detected_game');
      if (g && g.name) {
        detectedLbl.textContent = `Detected running game: ${g.name} (PID ${g.pid})`;
        detectedLbl.style.color = 'var(--success)';
      } else {
        detectedLbl.textContent = 'No running game detected — system boost will apply globally to all games';
        detectedLbl.style.color = 'var(--text_secondary)';
      }
    } catch { /* ignore */ }
  }

  function startPoll() {
    if (_pollTimer) return;
    sampleStats();
    checkDetectedGame();
    setTimeout(sampleStats, 250);
    _pollTimer = setInterval(sampleStats, 1000);
    _gamePollTimer = setInterval(checkDetectedGame, 3000);
  }
  function stopPoll() {
    clearInterval(_pollTimer); _pollTimer = null;
    clearInterval(_gamePollTimer); _gamePollTimer = null;
  }

  /* ── badge ───────────────────────────────────────────────────── */
  const badge = h('div', {
    style: `padding:3px 10px;border-radius:20px;font-size:10px;font-weight:700;letter-spacing:.7px;
            border:1px solid transparent;transition:all .3s`,
    text: 'INACTIVE'
  });
  function setBadge(on) {
    badge.textContent = on ? 'ACTIVE' : 'INACTIVE';
    Object.assign(badge.style, {
      background: on ? 'color-mix(in srgb,var(--success) 15%,transparent)' : 'var(--bg_input)',
      color:      on ? 'var(--success)' : 'var(--text_secondary)',
      border:     on ? '1px solid color-mix(in srgb,var(--success) 35%,transparent)' : '1px solid transparent',
    });
  }

  /* ── what gets optimised ─────────────────────────────────────── */
  const OPTS = [
    ['Close background apps',          'Frees CPU and RAM instantly'],
    ['HIGH game process priority',      'Game gets CPU time before everything else'],
    ['DWUT Extreme Performance plan',   'Our custom power plan, always on after first boost'],
    ['Hardware GPU Scheduling (HAGS)', 'Reduces GPU latency on Win10 2004+'],
    ['Disable Xbox Game Bar / capture','Stops background capture overhead'],
    ['Stop disk-heavy services',        'WSearch, SysMain, DiagTrack paused'],
    ['Flush kernel standby RAM',        'Recovers cached pages back to the game'],
    ['Disable network throttling',      'Full bandwidth + low-latency TCP'],
    ['Auto-detect running game',        'Finds the game process automatically'],
    ['Fully restorable on deactivate',  'Every change reverts when you click Restore'],
  ];

  const optsList = h('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:1px 12px' },
    ...OPTS.map(([t, s]) =>
      h('div', { style: 'padding:3px 0;border-bottom:1px solid var(--border)' },
        h('div', { class: 'f11 tp b', text: t }),
        h('div', { class: 'f10 ts',  text: s }))));

  /* ── detail rows (post-boost) ────────────────────────────────── */
  const dets = {};
  const setDet = (k, t, c) => { if (dets[k]) { dets[k].textContent = t; dets[k].style.color = c || 'var(--text_primary)'; } };
  function detRow(key, label) {
    const v = h('span', { class: 'f11 tp', text: '--' }); dets[key] = v;
    return h('div', { class: 'row', style: 'padding:3px 0;gap:6px;border-bottom:1px solid var(--border)' },
      h('span', { class: 'f11 ts', style: 'width:130px;flex:none', text: label }), v);
  }
  const detPanel = h('div', { style: 'padding:2px 0' },
    detRow('game', 'Game'),
    detRow('ram',  'RAM Freed'),
    detRow('plan', 'Power Plan'),
    detRow('prio', 'Priority'),
    detRow('gpu',  'GPU Scheduling'),
    detRow('svc',  'Services Stopped'),
    detRow('net',  'Network'));

  const detectedLbl = h('div', { class: 'f11', style: 'min-height:16px;color:var(--accent)' });
  const progressLbl = h('div', { class: 'f11 ts', style: 'min-height:16px;font-style:italic' });

  /* ── buttons ─────────────────────────────────────────────────── */
  const boostBtn   = Btn('Boost', { h: 38, w: 110, bold: true, cls: 'fill', onclick: () => openDialog() });
  const restoreBtn = Btn('Restore', { variant: 'ghost', h: 38, w: 100, onclick: () => doRestore() });
  restoreBtn.disabled = true;

  /* ── card layout (no scroll — everything fits) ───────────────── */
  const card = Card([
    // header
    h('div', { class: 'row', style: 'padding:10px 14px 4px;gap:8px' },
      h('div', { class: 'col', style: 'gap:2px' },
        h('div', { class: 'f14 b tp', text: 'Game Booster' }),
        h('div', { class: 'f10 ts', text: 'CPU / RAM / GPU / Disk / Network — one click' })),
      h('div', { class: 'grow' }), badge),

    h('div', { style: 'padding:0 14px 4px' }, detectedLbl),

    // live graphs — always visible
    h('div', { class: 'f10 b ts', style: 'padding:4px 14px 5px;letter-spacing:.6px;text-transform:uppercase' }, 'Live System Stats'),
    h('div', { style: 'padding:0 14px 8px' }, graphGrid),

    // what gets optimised
    h('div', { class: 'f10 b ts', style: 'padding:4px 14px 5px;letter-spacing:.6px;text-transform:uppercase' }, 'What Boost Does'),
    h('div', { style: 'padding:0 14px 8px' }, optsList),

    // post-boost details
    h('div', { class: 'f10 b ts', style: 'padding:4px 14px 5px;letter-spacing:.6px;text-transform:uppercase' }, 'Boost Results'),
    h('div', { style: 'padding:0 14px 6px' }, detPanel),

    // progress
    h('div', { style: 'padding:0 14px 2px' }, progressLbl),

    h('div', { class: 'grow' }),

    // button row
    h('div', { class: 'row', style: 'padding:8px 14px;gap:8px;border-top:1px solid var(--border)' },
      boostBtn, restoreBtn,
      h('span', { class: 'f10 ts', style: 'margin-left:4px' }, 'All changes restored on deactivate. Requires admin.')),
  ], 'col', { flex: '1', minWidth: 0, display: 'flex', flexDirection: 'column' });

  /* ── event listeners ─────────────────────────────────────────── */
  on('gaming.boost_progress', (d) => { progressLbl.textContent = d && d.step ? d.step : ''; });
  on('gaming.boost_error',    (d) => { progressLbl.textContent = ''; boostBtn.disabled = false; fail('Boost failed', d.message); });

  on('gaming.boost_changed', (r) => {
    progressLbl.textContent = '';
    if (!r) {
      setBadge(false); boostBtn.disabled = false; restoreBtn.disabled = true;
      Object.values(dets).forEach(v => { v.textContent = '--'; v.style.color = ''; });
      detectedLbl.textContent = '';
    } else {
      setBadge(true); boostBtn.disabled = true; restoreBtn.disabled = false;
      setDet('game', r.game_pid ? (r.game_name + (r.auto_detected ? ' (auto)' : '')) : r.game_name + ' (waiting...)', r.game_pid ? 'var(--success)' : null);
      setDet('ram',  `${r.ram_freed_mb || 0} MB freed`, r.ram_freed_mb > 100 ? 'var(--success)' : null);
      setDet('plan', r.power_plan_applied || 'None available', r.power_plan_applied ? 'var(--success)' : 'var(--error)');
      setDet('prio', r.priority_applied ? 'HIGH (game) + IDLE (background)' : 'Could not set', r.priority_applied ? 'var(--success)' : 'var(--warning)');
      setDet('gpu',  r.gpu_scheduling_enabled ? 'HAGS enabled' : 'Not changed', r.gpu_scheduling_enabled ? 'var(--success)' : 'var(--text_secondary)');
      const svcs = r.services_stopped || (r.notes||[]).filter(n=>n.startsWith('Stopped')).map(n=>n.replace(/^Stopped\s*(disk-heavy services:)?\s*/i, ''));
      const svcArr = Array.isArray(svcs) ? svcs : (typeof svcs === 'string' && svcs ? svcs.split(', ') : []);
      if (svcArr.length > 0) {
        setDet('svc', `${svcArr.length} stopped (${svcArr.join(', ')})`, 'var(--success)');
      } else {
        setDet('svc', '0 stopped (already inactive)', 'var(--text_secondary)');
      }
      setDet('net',  (r.net_notes||[]).length ? 'Throttling off, TCP tuned' : '--', (r.net_notes||[]).length ? 'var(--success)' : null);
    }
  });

  async function doRestore() {
    restoreBtn.disabled = true; progressLbl.textContent = 'Restoring all settings...';
    window.FX && FX.stage.begin({ kind: 'boost', eyebrow: 'Game Booster', title: 'Restoring your settings', doneTitle: 'Restored', first: 'Restoring all settings' });
    try { await rpc('gaming.boost_restore'); } catch (e) { window.FX && FX.stage.failKind('boost', e.message); fail('Restore', e.message); restoreBtn.disabled = false; }
  }

  let _cachedCands = null;
  const prefetchCands = () => { rpc('gaming.boost_candidates').then(c => { _cachedCands = c || []; }).catch(() => {}); };
  setTimeout(prefetchCands, 100);

  async function openDialog() {
    if (boostBtn.disabled && badge.textContent === 'ACTIVE') {
      notify('Game Booster', 'A boost is already active. Open Game Booster and press Restore first to apply a new one.');
      return;
    }
    boostBtn.disabled = true;
    const checks = [];
    const groups = [['background','Background apps -- will be closed'],['heavy','Other heavy apps (off by default)'],['browser','Browsers (off by default)']];

    const result = await Modal.custom((close) => {
      const list = h('div', { class: 'scroll', style: 'max-height:290px;margin-top:6px;padding-right:6px' });
      const applyBtn = Btn('Apply Boost', { w: 130, bold: true, onclick: () => close(checks.filter(([,cb]) => cb.checked).map(([c]) => c.name.toLowerCase())) });

      function renderItems(cands) {
        list.textContent = '';
        checks.length = 0;
        for (const [kind, title] of groups) {
          const items = cands.filter(c => c.kind === kind);
          if (!items.length) continue;
          list.append(h('div', { class: 'f11 b c-acc', text: title, style: 'margin:8px 0 4px' }));
          for (const c of items) {
            const cb = Check('', { sm: true, checked: c.checked, themed: true }); checks.push([c, cb]);
            const row = h('div', { class: 'row', style: 'padding:4px 6px;border-radius:4px;cursor:pointer;gap:8px',
              onclick: e => { if (!cb.contains(e.target)) cb.toggle(); }},
              cb,
              h('span', { class: 'f12 tp grow ell', text: c.name.replace(/\.exe$/i, '') }),
              h('span', { class: 'f10 ts', text: (c.count > 1 ? c.count+'x  ' : '') + Number(c.ram_mb||0).toFixed(0)+' MB' }));
            row.onmouseenter = () => row.style.background = 'var(--bg_hover)';
            row.onmouseleave = () => row.style.background = '';
            list.append(row);
          }
        }
        if (!checks.length) list.append(h('div', { class: 'f12 ts', style: 'padding:10px 0', text: 'No closable apps found -- system boost will still apply.' }));
      }

      if (_cachedCands) {
        renderItems(_cachedCands);
        // Refresh silently in background
        rpc('gaming.boost_candidates').then(c => { if (c) { _cachedCands = c; renderItems(c); } }).catch(() => {});
      } else {
        const loading = h('div', { class: 'col', style: 'align-items:center;justify-content:center;padding:28px 0;gap:8px' },
          h('span', { class: 'f12 tp', text: 'Scanning running processes…' }),
          h('span', { class: 'f10 ts', text: 'Checking background applications' }));
        list.append(loading);
        rpc('gaming.boost_candidates').then(c => {
          _cachedCands = c || [];
          renderItems(_cachedCands);
        }).catch(e => {
          list.textContent = '';
          list.append(h('div', { class: 'f12 ts', style: 'padding:10px 0;color:var(--error)', text: 'Process scan error: ' + e.message }));
        });
      }

      return h('div', { class: 'modal', style: 'min-width:480px' },
        h('h3', { text: 'Boost -- choose what to close' }),
        h('div', { class: 'f11 ts', style: 'white-space:normal;margin-bottom:4px',
          text: 'Untick anything you want to keep (e.g. Discord). System processes, drivers and anti-cheat are never touched.' }),
        list,
        h('div', { class: 'foot' },
          Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }),
          applyBtn));
    });

    if (result === null) { boostBtn.disabled = false; return; }
    progressLbl.textContent = 'Applying full system boost...';
    window.FX && FX.stage.begin({ kind: 'boost', eyebrow: 'Game Booster', title: 'Boosting your PC', doneTitle: 'Boost active', first: 'Preparing the boost' });
    rpc('gaming.boost_apply', { game_name: '', only: result })
      .catch(e => { boostBtn.disabled = false; window.FX && FX.stage.failKind('boost', e.message); fail('Boost failed', e.message); });
  }

  /* ── lifecycle ───────────────────────────────────────────────── */
  rpc('gaming.boost_state').then(s => {
    if (s && s.active) { setBadge(true); boostBtn.disabled = true; restoreBtn.disabled = false; }
  }).catch(() => {});

  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' },
      h('h1', { text: 'Game Booster' }),
      h('div', { class: 'grow' }),
      h('span', { class: 'f10 ts', text: 'CPU + RAM + GPU + Disk + Network' })),
    h('div', { style: 'flex:1;min-height:0;padding:0 20px 14px;overflow:hidden' }, card));

  // Used by the tray's "Quick Game Boost": same popup as the Boost button, so nothing (Discord, browsers...) is ever closed
  // without the user ticking it.  If a boost is already running there is nothing to apply - just say so.
  function openBoost() {
    if (boostBtn.disabled && badge.textContent === 'ACTIVE') {
      progressLbl.textContent = 'Boost is already active - press Restore first to apply a new one.';
      return;
    }
    if (boostBtn.disabled) return;           // dialog / scan already in progress
    openDialog();
  }

  return {
    el,
    openBoost,
    async onShow() {
      try {
        const s = await rpc('gaming.boost_state');
        if (s && s.active) { setBadge(true); boostBtn.disabled = true; restoreBtn.disabled = false; }
      } catch { /* ignore */ }
      startPoll();
    },
    onHide() { stopPoll(); },
  };
});
