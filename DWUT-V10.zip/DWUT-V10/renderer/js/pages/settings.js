// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* Settings page + HSV colour picker (ring + square, same layout as the original dialog) */
function openColorPicker(initial, onSelect) {
  const BG = 'color-mix(in srgb, var(--bg_card) 60%, transparent)', BG2 = 'color-mix(in srgb, var(--bg_input) 70%, transparent)', TXT = 'var(--text_primary)';
  const RO = 140, RI = 104, SQ = 96, D = RO * 2 + 4, C = RO + 2;
  let hh = 0, ss = 1, vv = 1, dragging = null;
  const hsv2rgb = (h, s, v) => { const i = Math.floor(h * 6), f = h * 6 - i, p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s); const m = [[v, t, p], [q, v, p], [p, v, t], [p, q, v], [t, p, v], [v, p, q]][i % 6]; return m.map((x) => Math.round(x * 255)); };
  const rgb2hsv = (r, g, b) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; let h = 0; if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h /= 6; if (h < 0) h += 1; } return [h, mx ? d / mx : 0, mx]; };
  const hex = () => '#' + hsv2rgb(hh, ss, vv).map((x) => x.toString(16).padStart(2, '0')).join('');
  const setHex = (s) => { const m = /^#?([0-9a-f]{6})$/i.exec(s.trim()); if (!m) return false; const n = parseInt(m[1], 16); [hh, ss, vv] = rgb2hsv(n >> 16, (n >> 8) & 255, n & 255); return true; };
  try { setHex(initial); } catch { /* ignore */ }
  const recent = (openColorPicker._recent = openColorPicker._recent || []);
  return Modal.custom((close) => {
    const cv = h('canvas', { width: D, height: D, style: `width:${D}px;height:${D}px;display:block;margin:0 auto 10px` });
    const ctx = cv.getContext('2d');
    const swatch = h('div', { style: 'width:44px;height:44px;margin-right:10px;border-radius:2px' });
    const hexIn = h('input', { class: 'entry', style: `background:${BG2};color:${TXT};border:0;width:110px;height:36px;font-size:14px;border-radius:2px` });
    const recWrap = h('div', { class: 'row', style: 'gap:4px;margin:2px 0 8px;min-height:32px' });
    const draw = () => {
      ctx.clearRect(0, 0, D, D);
      for (let i = 0; i < 360; i++) {
        const a1 = ((i - 1) * Math.PI) / 180, a2 = ((i + 1) * Math.PI) / 180, [r, g, b] = hsv2rgb(i / 360, 1, 1);
        ctx.fillStyle = `rgb(${r},${g},${b})`; ctx.beginPath();
        ctx.moveTo(C + RO * Math.cos(a1), C - RO * Math.sin(a1)); ctx.lineTo(C + RO * Math.cos(a2), C - RO * Math.sin(a2));
        ctx.lineTo(C + RI * Math.cos(a2), C - RI * Math.sin(a2)); ctx.lineTo(C + RI * Math.cos(a1), C - RI * Math.sin(a1)); ctx.fill();
      }
      const x0 = C - SQ / 2, y0 = C - SQ / 2, ST = 24, st = SQ / ST;
      for (let vi = 0; vi < ST; vi++) for (let si = 0; si < ST; si++) { const [r, g, b] = hsv2rgb(hh, si / (ST - 1), 1 - vi / (ST - 1)); ctx.fillStyle = `rgb(${r},${g},${b})`; ctx.fillRect(x0 + si * st, y0 + vi * st, st + 1, st + 1); }
      const ang = hh * 2 * Math.PI, mr = (RO + RI) / 2; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(C + mr * Math.cos(ang), C - mr * Math.sin(ang), 7, 0, 7); ctx.stroke();
      const mx = x0 + ss * SQ, my = y0 + (1 - vv) * SQ; ctx.beginPath(); ctx.arc(mx, my, 6, 0, 7); ctx.stroke(); ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(mx, my, 4, 0, 7); ctx.stroke();
      swatch.style.background = hex(); if (hexIn.value.toLowerCase() !== hex()) hexIn.value = hex();
    };
    const pos = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    const upd = (x, y) => {
      if (dragging === 'ring') { hh = ((Math.atan2(C - y, x - C) / (2 * Math.PI)) % 1 + 1) % 1; }
      else if (dragging === 'sq') { const x0 = C - SQ / 2, y0 = C - SQ / 2; ss = Math.max(0, Math.min(1, (x - x0) / SQ)); vv = Math.max(0, Math.min(1, 1 - (y - y0) / SQ)); }
      draw();
    };
    cv.addEventListener('mousedown', (e) => {
      const [x, y] = pos(e), dist = Math.hypot(x - C, y - C);
      if (dist > RI && dist <= RO) dragging = 'ring';
      else if (dist <= (SQ / 2) * 1.42 && x >= C - SQ / 2 && x <= C + SQ / 2 && y >= C - SQ / 2 && y <= C + SQ / 2) dragging = 'sq';
      if (dragging) upd(x, y);
    });
    const mv = (e) => { if (dragging) upd(...pos(e)); }, up = () => { dragging = null; };
    addEventListener('mousemove', mv); addEventListener('mouseup', up);
    hexIn.addEventListener('input', () => { if (setHex(hexIn.value)) draw(); });
    const paintRecent = () => { recWrap.textContent = ''; recent.slice(-8).forEach((c) => recWrap.append(h('div', { style: `width:32px;height:32px;background:${c};cursor:pointer;border-radius:2px`, onclick: () => { setHex(c); draw(); } }))); };
    const done = (v) => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); close(v); };
    const box = h('div', { class: 'modal', style: `background:${BG};border-color:var(--fx-line-hi);padding:16px;min-width:340px;width:340px` }, cv,
      h('div', { class: 'row', style: 'margin-bottom:8px' }, swatch, hexIn),
      h('div', { class: 'f9', style: 'color:var(--text_disabled)', text: 'Recent' }), recWrap,
      h('div', { class: 'row', style: 'gap:8px;margin-top:4px' },
        h('button', { class: 'btn f11 b', text: 'Select', style: `width:auto;min-width:0;padding:0 18px;height:34px;border-radius:0;background:${Theme.tokens.accent};color:#fff`, onclick: () => { const c = hex(); if (!recent.includes(c)) recent.push(c); done(c); } }),
        h('button', { class: 'btn f11 b', text: 'Cancel', style: `width:auto;min-width:0;padding:0 18px;height:34px;border-radius:0;background:${BG2};color:${TXT}`, onclick: () => done(null) })));
    paintRecent(); setTimeout(draw, 0);
    return box;
  }).then((c) => { if (c) onSelect(c); });
}

Pages.register('settings', () => {
  const C = Cfg.v;
  const saved = h('span', { class: 'f11 c-ok' });
  const FONTS = ['Segoe UI Variable', 'Segoe UI', 'Inter', 'Roboto', 'Arial', 'Calibri', 'Verdana', 'Tahoma', 'Consolas', 'Courier New'];
  const SCALES = { 'Small (85%)': 0.85, 'Normal (100%)': 1.0, 'Large (110%)': 1.10, 'Larger (120%)': 1.20 };
  const hdr = (title, tipText) => h('div', { class: 'row', style: 'padding:12px 14px 8px' }, h('span', { class: 'f13 b tp', text: title }), tipText ? h('span', { style: 'margin-left:6px' }, Info(tipText)) : null);
  const row = (label, tipText, widget) => h('div', { class: 'row', style: 'padding:4px 14px' }, h('div', { class: 'row grow' }, h('span', { class: 'f11 ts', text: label }), h('span', { style: 'margin-left:4px' }, Info(tipText))), widget);
  const toggles = {}, ints = {}, combos = {};

  // ── appearance ──
  const themeHolder = h('div');
  function themeCard(key, T) {
    const m = Object.assign({}, T.base, T.themes[key]), cur = key === Theme.name;
    // a miniature of the real UI in this theme: sidebar strip, content area, a card with an accent button
    const preview = h('div', { style: `display:flex;height:46px;border-radius:6px;overflow:hidden;background:${m.bg_base};border:1px solid ${m.border}` },
      h('div', { style: `width:20%;background:${m.sidebar_bg};display:flex;flex-direction:column;gap:3px;padding:5px 4px` },
        h('div', { style: `height:4px;border-radius:2px;background:${m.accent}` }), h('div', { style: `height:3px;border-radius:2px;background:${m.text_disabled}` }), h('div', { style: `height:3px;border-radius:2px;background:${m.text_disabled}` })),
      h('div', { style: 'flex:1;padding:5px' },
        h('div', { style: `background:${m.bg_card};border:1px solid ${m.border};border-radius:4px;height:100%;padding:4px 5px;display:flex;flex-direction:column;gap:3px;box-sizing:border-box` },
          h('div', { style: `height:3px;width:70%;border-radius:2px;background:${m.text_primary}` }),
          h('div', { style: `height:3px;width:45%;border-radius:2px;background:${m.text_secondary}` }),
          h('div', { style: `height:8px;width:34px;border-radius:3px;background:${m.accent};margin-top:auto` }))));
    const card = h('div', {
      class: 'col theme-card', tabindex: '0', role: 'button', title: `Use the ${T.names[key]} theme`,
      style: `background:var(--bg_input);border-radius:9px;border:2px solid ${cur ? 'var(--accent)' : 'var(--border)'};width:132px;padding:6px;margin:4px;flex:none;gap:5px;cursor:pointer;transition:border-color .12s, transform .12s`,
      onclick: () => { if (key !== Theme.name) applyTheme(key); },
      onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (key !== Theme.name) applyTheme(key); } },
      onmouseenter: (e) => { if (!cur) e.currentTarget.style.borderColor = 'var(--accent_dim)'; },
      onmouseleave: (e) => { if (!cur) e.currentTarget.style.borderColor = 'var(--border)'; },
    }, preview,
      h('div', { class: 'row', style: 'padding:0 2px' },
        h('span', { class: 'f10 grow', text: T.names[key], style: `font-weight:${cur ? 700 : 500};color:${cur ? 'var(--accent)' : 'var(--text_primary)'};overflow:hidden;text-overflow:ellipsis;white-space:nowrap` }),
        cur ? h('span', { class: 'f9 c-acc', text: 'Active' }) : null));
    return card;
  }
  let themeGroup = 0;
  function renderThemes() {
    const T = window.DW_THEMES; themeHolder.textContent = '';
    const groups = T.groups || [{ title: 'Themes', keys: T.order }];
    if (themeGroup >= groups.length) themeGroup = 0;
    const chips = h('div', { class: 'row wrap', style: 'padding:2px 14px 6px;gap:6px' }, groups.map((g, i) => {
      const n = g.keys.filter((k) => T.themes[k]).length;
      const b = h('button', { class: 'chip' + (i === themeGroup ? ' on' : ''), text: `${g.title}  ·  ${n}`, onclick: () => { themeGroup = i; renderThemes(); } });
      return b;
    }));
    themeHolder.append(chips, h('div', { class: 'theme-grid', style: 'display:flex;flex-wrap:wrap;padding:2px 12px' }, groups[themeGroup].keys.filter((k) => T.themes[k]).map((k) => themeCard(k, T))));
  }
  async function applyTheme(key) {
    Theme.apply(key); Theme.typography(C.ui_font, C.ui_font_scale, C.ui_text_color); Theme._applyExtra(true);
    await Cfg.set({ theme: key }); renderThemes(); Sidebar.build(); typoPreview();
  }
  async function resetTheme() {
    await applyTheme('dark');
    flash('Theme reset to default (Dark)', 'var(--info)');
  }
  const appearance = Card([hdr('Appearance', 'Choose a colour theme for the entire application.\n\nDark/Midnight/Obsidian/Abyss — distinct dark surface palettes\nViolet/Crimson/Ember/Emerald — dark base tinted toward the accent\nNord/Dracula/Solarized       — popular programmer colour schemes\nHigh Contrast                — maximum readability\nDaylight/Paper               — light themes\n\nApplies instantly — the whole app redraws in the new theme.'),
    themeHolder,
    h('div', { class: 'row', style: 'padding:4px 14px 12px;gap:10px' },
      h('span', { class: 'f10 td grow', text: 'Click a card to apply. Theme changes apply instantly.' }),
      Btn('Reset to Default', { variant: 'ghost', h: 28, w: 130, onclick: resetTheme }))], 'col', { marginBottom: '12px' });

  // ── typography ──
  // font picker: every entry is drawn in its own typeface
  function FontSelect(initial, groupsFn, onchange) {
    let val = initial;
    const label = h('span', { class: 't', text: val, style: `font-family:"${val}"` }), arrow = h('span', { class: 'a', text: '▼' });
    const el = h('div', { class: 'opt bordered', style: 'width:230px;height:30px' }, label, arrow);
    Object.defineProperty(el, 'value', { get: () => val });
    el.set = (v) => { val = v; label.textContent = v; label.style.fontFamily = `"${v}"`; };
    el.addEventListener('click', (e) => {
      e.stopPropagation(); document.querySelectorAll('.menu-pop.fontpop').forEach((m) => m.remove());
      const r = el.getBoundingClientRect(), pop = h('div', { class: 'menu-pop fontpop', style: `left:${r.left}px;top:${Math.min(r.bottom + 2, innerHeight - 330)}px;width:${Math.max(260, r.width)}px;max-height:320px` });
      for (const [title, list] of groupsFn()) {
        pop.append(h('div', { class: 'f9 b', style: 'color:var(--accent);letter-spacing:.14em;text-transform:uppercase;cursor:default;padding:6px 10px 2px', text: title }));
        for (const f of list) { const it = h('div', { text: f, style: `font-family:"${f}";font-size:14px${f === val ? ';color:var(--accent)' : ''}` }); it.addEventListener('click', () => { el.set(f); pop.remove(); onchange && onchange(f); }); pop.append(it); }
      }
      document.body.append(pop);
      const off = () => { pop.remove(); document.removeEventListener('mousedown', off, true); };
      setTimeout(() => document.addEventListener('mousedown', (ev) => { if (!pop.contains(ev.target)) off(); }, true), 0);
    });
    return el;
  }
  const fontOpt = FontSelect(C.ui_font || 'Segoe UI Variable', () => DW_FONTS.main(), () => typoPreview());
  const monoOpt = FontSelect(C.ui_font_mono || 'Consolas', () => DW_FONTS.mono(), () => typoPreview());
  const curScale = Object.keys(SCALES).find((k) => Math.abs(SCALES[k] - (C.ui_font_scale || 1)) < 0.01) || 'Normal (100%)';
  const scaleOpt = Option(Object.keys(SCALES), { w: 170, f: 11, value: curScale, onchange: () => typoPreview() });
  combos.ui_font = fontOpt;
  // every text colour of the program, each with a live preview line
  const COLORS = [
    ['text_primary', 'Main text', 'Titles, labels and values', 'DWUT optimized 14 startup items and freed 2.3 GB'],
    ['text_secondary', 'Secondary text', 'Descriptions and hints under titles', 'Scans SFC, DISM and the network stack in a single pass'],
    ['text_disabled', 'Dim text', 'Disabled, empty and waiting states', 'Waiting for the next scan to finish…'],
    ['accent_text', 'Button text', 'Text on solid accent buttons', 'RUN BOOST'],
    ['success', 'Success', 'Done / active / OK messages', 'Boost active: 11 background apps closed'],
    ['warning', 'Warning', 'Caution and pending messages', 'Restart pending: save your work first'],
    ['error', 'Error', 'Failures and problems', 'Could not reach the update server'],
    ['info', 'Info', 'Tips and neutral notes', 'Tip: press Win+R to open the DWUT Run window'],
  ];
  const cur = Object.assign({}, C.ui_text_colors || {}); if (C.ui_text_color) cur.text_primary = C.ui_text_color;
  const colorRows = {}, colorVal = (k) => cur[k] || Theme.tokens[k] || '#ffffff';
  const typoStatus = h('span', { class: 'f10 c-ok', style: 'margin-left:4px' });
  const colorList = h('div', { class: 'col', style: 'padding:0 14px 6px;gap:5px' });
  const samplePreview = h('div', { class: 'typo-sample' });
  for (const [k, name, why, sample] of COLORS) {
    const hex = Entry({ placeholder: '#RRGGBB', w: 86, h: 26, f: 11, value: colorVal(k).toLowerCase() });
    const sw = h('button', { class: 'cswatch', title: 'Open the colour picker' });
    const pv = k === 'accent_text'
      ? h('span', { class: 'typo-btn', text: sample }) : h('span', { class: 'typo-line', text: sample });
    const paint = () => { const v = hex.value.trim(), ok = /^#[0-9a-f]{6}$/i.test(v); sw.style.background = ok ? v : colorVal(k); if (ok) cur[k] = v.toLowerCase(); pv.style.color = ok ? v : colorVal(k); };
    hex.addEventListener('input', paint);
    sw.addEventListener('click', () => openColorPicker(hex.value.trim() || colorVal(k), (c) => { hex.value = c; paint(); }));
    const reset = Btn('Reset', { variant: 'plain', h: 22, w: 46, f: 10, onclick: () => { delete cur[k]; hex.value = (Theme.tokens[k] || '#ffffff').toLowerCase(); sw.style.background = hex.value; pv.style.color = hex.value; } });
    colorRows[k] = { hex, sw, pv, paint, reset };
    colorList.append(h('div', { class: 'typo-row' }, h('div', { class: 'col', style: 'width:130px;flex:none' }, h('span', { class: 'f11 b tp', text: name }), h('span', { class: 'f9 td ell', text: why, title: why })), sw, hex, reset, pv));
    paint();
  }
  const sizes = h('div', { class: 'typo-sizes' });
  function typoPreview() {
    const sc = SCALES[scaleOpt.value] || 1;
    samplePreview.style.fontFamily = `"${fontOpt.value}", sans-serif`; samplePreview.style.fontSize = Math.round(12 * sc) + 'px';
    colorList.style.fontFamily = `"${fontOpt.value}", sans-serif`;
    colorList.querySelectorAll('.typo-line, .typo-btn').forEach((e) => { e.style.fontSize = Math.round(12 * sc) + 'px'; });
    samplePreview.querySelectorAll('.code').forEach((e) => { e.style.fontFamily = `"${monoOpt.value}", monospace`; });
  }
  samplePreview.innerHTML = '<div class="tp-h">DWUT Control Center</div><div class="tp-s">Optimize, repair and tune Windows from one place</div><div class="tp-d">Last scan 4 minutes ago · 0 issues</div><div class="code">C:\\&gt; sfc /scannow  [ OK ] 100%</div>';
  const flash = (t, c) => { typoStatus.textContent = t; typoStatus.style.color = c; setTimeout(() => { typoStatus.textContent = ''; }, 3000); };
  async function applyTypo() {
    const colors = {}; let primary = '';
    for (const [k] of COLORS) {
      const v = (colorRows[k].hex.value || '').trim(); if (!/^#[0-9a-f]{6}$/i.test(v)) { flash('Invalid hex colour — use #RRGGBB', 'var(--error)'); return; }
      const same = v.toLowerCase() === (Theme.tokens[k] || '').toLowerCase();
      if (k === 'text_primary') primary = same ? '' : v.toLowerCase(); else if (!same) colors[k] = v.toLowerCase();
    }
    const vals = { ui_font: fontOpt.value, ui_font_mono: monoOpt.value === 'Consolas' ? '' : monoOpt.value, ui_font_scale: SCALES[scaleOpt.value] || 1.0, ui_text_color: primary, ui_text_colors: colors };
    await Cfg.set(vals); Theme.setExtra(vals.ui_font_mono, colors); Theme.typography(vals.ui_font, vals.ui_font_scale, primary); flash('Applied!', 'var(--success)');
  }
  async function resetTypo() {
    await Cfg.set({ ui_font: 'Segoe UI Variable', ui_font_mono: '', ui_font_scale: 1.0, ui_text_color: '', ui_text_colors: {} });
    fontOpt.set('Segoe UI Variable'); monoOpt.set('Consolas'); scaleOpt.set('Normal (100%)', true);
    for (const [k] of COLORS) { delete cur[k]; const r = colorRows[k]; r.hex.value = (Theme.tokens[k] || '#ffffff').toLowerCase(); r.sw.style.background = r.hex.value; r.pv.style.color = r.hex.value; }
    Theme.setExtra('', {}); Theme.typography('Segoe UI Variable', 1.0, ''); typoPreview(); flash('Reset to default', 'var(--info)');
  }
  const typography = Card([hdr('Typography', 'Customise the fonts, text size and every text colour used across the whole app.\n\nMain font: changes all text, buttons, titles and labels.\nCode font: used for logs, terminals and number read-outs.\nColours: each one has a live preview; press Apply to use them everywhere.'),
    h('div', { class: 'typo-cols' },
      h('div', { class: 'col', style: 'flex:none;width:300px;gap:6px;padding:0 0 0 14px' },
        h('span', { class: 'f10 b ts', text: 'MAIN FONT' }), fontOpt, h('span', { class: 'f10 b ts', style: 'margin-top:6px', text: 'CODE / LOG FONT' }), monoOpt,
        h('span', { class: 'f10 b ts', style: 'margin-top:6px', text: 'TEXT SIZE' }), scaleOpt, h('span', { class: 'f10 b ts', style: 'margin-top:8px', text: 'LIVE PREVIEW' }), samplePreview,
        h('div', { class: 'row', style: 'gap:8px;margin-top:10px' }, Btn('Apply Typography', { h: 32, w: 150, onclick: applyTypo }), Btn('Reset', { variant: 'ghost', h: 32, w: 74, onclick: resetTypo })), typoStatus),
      h('div', { class: 'col grow', style: 'min-width:0' }, h('span', { class: 'f10 b ts', style: 'padding:0 14px 4px', text: 'TEXT COLOURS' }), colorList)),
  ], 'col', { marginBottom: '12px' });
  typoPreview();

  // ── dashboard / safety ──
  const toggle = (label, tipText, attr) => { const sw = Switch({ big: true, checked: C[attr] }); toggles[attr] = sw; return row(label, tipText, sw); };
  const refresh = Entry({ w: 100, h: 28, value: String(C.dashboard_refresh_ms) }); ints.dashboard_refresh_ms = refresh;
  const dashboard = Card([h('div', { class: 'f13 b tp', text: 'Dashboard', style: 'padding:12px 14px 6px' }),
    row('Refresh interval (ms)', 'How often the Dashboard updates CPU, RAM, Disk, and GPU stats.\n\nLower = more responsive but uses slightly more CPU.\nDefault is 2000ms (2 seconds). Minimum is 500ms.', refresh),
    toggle('Ctrl+Shift+Esc opens the DWUT Task Manager', "Replaces the Windows Task Manager shortcut while DWUT is running (even minimised or in the tray).\n\nTurn this off to get the normal Windows Task Manager back.\n\nTo work while an administrator program is in front, DWUT itself must be running as Administrator.", 'hotkey_taskmgr'),
    toggle('Win+R opens the DWUT Run window', "Replaces the Windows Run box (Win+R) while DWUT is running (even minimised or in the tray).\n\nTurn this off to get the normal Windows Run box back.\n\nTo work while an administrator program is in front, DWUT itself must be running as Administrator.", 'hotkey_run'),
  toggle('Show GPU stats', "Display GPU usage and temperature on the Dashboard.\n\nRequires OpenHardwareMonitor to be running. If OHM is not running, GPU cards will show 'N/A'.", 'show_gpu_stats'), h('div', { style: 'height:6px' })], 'col', { marginBottom: '12px' });
  const safety = Card([h('div', { class: 'f13 b tp', text: 'Safety', style: 'padding:12px 14px 6px' }),
    toggle('Auto-create restore point before destructive operations', 'Automatically creates a Windows System Restore point before running Debloat, Feature changes, or Registry Cleaner.\n\nStrongly recommended. Allows rolling back if something goes wrong.\nRequires System Protection to be enabled on the C: drive.', 'auto_restore_point'),
    toggle('Confirm before destructive operations', 'Show a confirmation dialog before deleting files, removing packages, or modifying the registry.\n\nDisable only if you are certain of what you are doing.', 'confirm_destructive'),
    toggle('Restore game boost settings when game closes', 'When the Game Booster detects the game process has exited, automatically restore the original power plan, process priority, and registry settings.\n\nKeeps your system in its normal state when you are not gaming.', 'restore_on_game_close'), h('div', { style: 'height:6px' })], 'col', { marginBottom: '12px' });

  // ── about ──
  const lines = ['Copyright © 2026 Darko / Darko.Dev', '', `Version       10`, `Python        ${C.python || ''}`, '', 'All operations use real Windows APIs — no simulated output, no fake numbers.', 'Every destructive action creates a restore point or backup first.', '', 'Built with Electron, psutil, requests, pywin32.'];
  const about = Card([h('div', { class: 'f13 b tp', text: 'About DWUT', style: 'padding:12px 14px 6px' }),
    lines.map((l) => (l ? h('div', { class: 'f11 ts', text: l, style: 'padding:1px 14px;white-space:pre' }) : h('div', { style: 'height:6px' }))),
    h('div', { class: 'row', style: 'padding:12px 14px;gap:8px' },
      Btn('Open Logs Folder', { variant: 'ghost', h: 30, tip: 'Open the folder containing dwut.log and rotated log files.', onclick: () => rpc('os.open_folder', { which: 'logs' }) }),
      Btn('Open Backups Folder', { variant: 'ghost', h: 30, cls: 'auto', tip: 'Open the folder containing .reg registry backups and debloat session JSON logs.', onclick: () => rpc('os.open_folder', { which: 'backups' }) }),
      Btn('Check for Updates', { variant: 'ghost', h: 30, tip: 'Open the DWUT GitHub page to see the latest release.', onclick: () => rpc('os.open_url', { url: 'https://github.com/supportpantheon-sys/Darkos-Windows-Utility-Tool-DWUT' }) }))], 'col', { marginBottom: '20px' });

  async function save() {
    const v = {};
    const n = parseInt(refresh.value, 10); if (!Number.isNaN(n)) v.dashboard_refresh_ms = n;
    v.ui_font = fontOpt.value;
    for (const [k, sw] of Object.entries(toggles)) v[k] = sw.checked;
    await Cfg.set(v); saved.textContent = 'Saved'; setTimeout(() => { saved.textContent = ''; }, 3000);
  }
  async function resetAllSettings() {
    const ok = await Modal.confirm({ title: 'Reset All Settings', body: 'This will reset the theme to Dark, typography to defaults, and all toggles to their default values.\nAre you sure?' });
    if (!ok) return;
    await applyTheme('dark');
    await resetTypo();
    const defaults = { dashboard_refresh_ms: 2000, hotkey_taskmgr: true, hotkey_run: true, show_gpu_stats: true, auto_restore_point: true, confirm_destructive: true, restore_on_game_close: true };
    for (const [k, sw] of Object.entries(toggles)) { if (defaults[k] !== undefined) sw.set(defaults[k]); }
    refresh.value = '2000';
    await Cfg.set(defaults);
    flash('All settings reset to defaults', 'var(--info)');
  }
  renderThemes();
  const personalize = Cosmetics.panel(openColorPicker);
  const SECTIONS = { Themes: [appearance], Personalize: [personalize], Typography: [typography], 'Dashboard & Safety': [dashboard, safety], About: [about] };
  const sdesc = { Themes: 'Colour themes for the whole app', Personalize: 'Effects · sounds · backgrounds', Typography: 'Fonts · size · every text colour', 'Dashboard & Safety': 'Refresh · shortcuts · safeguards', About: 'Version · logs · updates' };
  const stabs = {}, tabBar = h('div', { class: 'row' }), main = h('div', { class: 'rail-main' });
  const panes = {};
  function showSection(name) {
    for (const [n, t] of Object.entries(stabs)) t.classList.toggle('active', n === name);
    for (const [n, p] of Object.entries(panes)) p.style.display = n === name ? '' : 'none';
    const p = panes[name]; p.classList.remove('dp-in'); void p.offsetWidth; p.classList.add('dp-in');
  }
  for (const [n, parts] of Object.entries(SECTIONS)) {
    const btn = Btn(n, { variant: 'plain', cls: 'tab f12', onclick: () => showSection(n) }); stabs[n] = btn; tabBar.append(h('span', {}, btn));
    const pane = h('div', { class: 'set-pane col' + (n === 'Dashboard & Safety' ? ' two' : n === 'Personalize' ? ' pers' : '') }, ...parts); pane.style.display = 'none'; panes[n] = pane; main.append(pane);
  }
  FX.rail(tabBar, sdesc);
  showSection('Themes');
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' }, h('h1', { text: 'Settings' }), h('div', { class: 'grow' }), saved),
    h('div', { class: 'rail-body' }, tabBar, main),
    h('div', { class: 'row save-bar', style: 'height:48px;flex:none;justify-content:flex-end;padding:0 16px;gap:10px' },
      Btn('Reset All Settings', { variant: 'ghost', h: 34, w: 160, tip: 'Resets theme, typography and all toggles back to factory defaults.', onclick: resetAllSettings }),
      Btn('Save All Settings', { h: 34, w: 180, onclick: save })));
  return { el };
});
