// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* Tools > Health.  Every number shown here comes from the backend scan (modules/health/scanner.py) - real WMI / SMART / event-log / sensor
   readings, nothing simulated.  A reading the PC cannot give is shown as "Not available" and is never part of a score.

   Design = the Game Booster's: same card chrome, same live line graphs, same uppercase section labels, same ACTIVE-style badge, same button row.
   Detail is laid out in COLUMNS (readings, identity, findings, hardware) so there is as little scrolling as possible.
   Every component, every category and the whole PC has a "Fix & Optimize" button (modules/health/fixes.py): it repairs what the scan found,
   then cleans, optimizes and boosts that component.  Colours are fixed (red -> amber -> green) so they keep their meaning in every theme. */
window.HealthTab = function HealthTab(setStatus) {
  const CATS = [
    ['cpu', 'Processor'], ['memory', 'Memory'], ['storage', 'Storage'], ['gpu', 'Graphics'], ['battery', 'Battery'],
    ['thermal', 'Cooling & Thermals'], ['network', 'Network'], ['firmware', 'Motherboard & Firmware'], ['drivers', 'Drivers & Devices'], ['windows', 'Windows'],
  ];
  // Theme colours only (the app maps "good" and "caution" to the accent on purpose - see Theme.tint); real problems stay red.
  const col = (s) => (s == null ? 'var(--text_disabled)' : s < 35 ? 'var(--error-real)' : 'var(--accent)');
  const grad = (s) => (s == null ? 'var(--text_disabled)' : s < 35 ? 'var(--error-real)' : 'linear-gradient(90deg, var(--accent_dim), var(--accent))');
  const LEVEL = { ok: 'var(--accent)', info: 'var(--info)', warn: 'var(--warning)', bad: 'var(--error-real)' };
  const KIND = { fix: ['FIX', 'var(--error-real)'], cleanup: ['CLEANUP', 'var(--info)'], optimize: ['OPTIMIZE', 'var(--accent)'], boost: ['BOOST', 'var(--success)'], check: ['CHECK', 'var(--text_secondary)'] };
  const STATE = { ok: ['✓', 'var(--success)'], warn: ['!', 'var(--warning)'], skip: ['–', 'var(--text_disabled)'], info: ['i', 'var(--info)'], wait: ['·', 'var(--text_disabled)'], run: ['…', 'var(--accent)'] };
  const PHRASE = { cpu: 'Reading processor clocks and error logs', memory: 'Inspecting memory modules', storage: 'Querying SMART data and volumes', gpu: 'Checking graphics adapter and driver', battery: 'Measuring battery wear',
    thermal: 'Reading temperatures and fans', network: 'Testing the connection (VPN-aware)', firmware: 'Reading BIOS and motherboard', drivers: 'Verifying devices and drivers', windows: 'Checking Windows health' };
  const esc = (t) => String(t == null ? '' : t);
  const rate = (s) => (s == null ? 'N/A' : s >= 90 ? 'Excellent' : s >= 75 ? 'Good' : s >= 55 ? 'Fair' : s >= 35 ? 'Poor' : 'Critical');

  if (!document.getElementById('health-css2')) {
    const st = document.createElement('style'); st.id = 'health-css2';
    st.textContent = `
.hl{padding:0 20px 18px}
.hl *{box-sizing:border-box}
.hl-lbl{font-size:max(8px,calc(10px*var(--fs)));font-weight:700;color:var(--text_secondary);padding:6px 14px 5px;letter-spacing:.6px;text-transform:uppercase}
.hl-card{background:color-mix(in srgb, var(--bg_card) 45%, transparent);border:1px solid var(--border);border-radius:10px;padding:10px 12px 8px;display:flex;flex-direction:column;gap:3px;min-width:0}
.hl-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(118px,1fr));gap:8px;padding:0 14px 8px}
.hl-tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;padding:0 14px 8px}
.hl-tile{cursor:pointer;transition:border-color .15s,transform .15s}
.hl-tile:hover{border-color:var(--accent);transform:translateY(-1px)}
.hl-tile .t{display:flex;align-items:center;gap:6px}
.hl-tile .t svg{color:var(--accent);flex:none}
.hl-gbox{margin-top:4px;border-radius:6px;overflow:hidden}
.hl-flat{background:color-mix(in srgb, var(--accent) 5%, transparent);border:1px solid var(--border)}
.hl-gbox canvas{display:block;width:100%}
.hl-att{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:6px 10px;padding:0 14px 10px}
.hl-ai{display:flex;align-items:flex-start;gap:8px;padding:6px 8px;border:1px solid var(--border);border-radius:8px;background:color-mix(in srgb, var(--accent) 5%, transparent);min-width:0}
.hl-ai i,.hl-fd i{flex:none;width:9px;height:9px;border-radius:50%;margin-top:4px;display:block}
.hl-ai .tx{flex:1;min-width:0;font-size:max(8px,calc(11.5px*var(--fs)));line-height:1.35;color:var(--text_secondary)}
.hl-ai .tx b{color:var(--text_primary)}
.hl-inv{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:6px 10px;padding:0 14px 12px}
.hl-ii{display:flex;align-items:center;gap:9px;padding:6px 9px;border:1px solid var(--border);border-radius:8px;background:color-mix(in srgb, var(--accent) 5%, transparent);min-width:0}
.hl-ii svg{color:var(--accent);flex:none}
.hl-ii .c{min-width:0;flex:1}
.hl-ii .g{font-size:max(8px,calc(9.5px*var(--fs)));color:var(--text_secondary);text-transform:uppercase;letter-spacing:.5px;font-weight:700}
.hl-ii .m{font-size:max(8px,calc(12px*var(--fs)));color:var(--text_primary);word-break:break-word}
.hl-ii .m b{font-weight:700}
.hl-ii .d{font-size:max(8px,calc(10px*var(--fs)));color:var(--text_secondary);word-break:break-word}
.hl-sec{margin-top:10px;scroll-margin-top:8px}
.hl-sh{display:flex;align-items:center;gap:9px;padding:10px 14px 6px}
.hl-sh svg{color:var(--accent);flex:none}
.hl-sh .pill{font-size:max(8px,calc(11px*var(--fs)));font-weight:700;padding:2px 10px;border-radius:99px;background:color-mix(in srgb, var(--accent) 5%, transparent);border:1px solid var(--border)}
.hl-cps{display:grid;grid-template-columns:repeat(auto-fit,minmax(400px,1fr));gap:8px;padding:0 14px 12px}
.hl-cp{background:color-mix(in srgb, var(--bg_card) 45%, transparent);border:1px solid var(--border);border-radius:10px;padding:10px 12px;position:relative;overflow:hidden;display:flex;flex-direction:column;gap:7px;min-width:0}
.hl-cp::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--stripe,var(--border))}
.hl-ch{display:flex;gap:10px;align-items:center}
.hl-ch .nm{flex:1;min-width:0}
.hl-ch .nm b{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:max(8px,calc(12.5px*var(--fs)));line-height:1.25;color:var(--text_primary);word-break:break-word}
.hl-ch .nm span{display:block;font-size:max(8px,calc(10.5px*var(--fs)));color:var(--text_secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hl-ch .sc{text-align:right;flex:none}
.hl-ch .sc b{display:block;font-size:max(8px,calc(20px*var(--fs)));line-height:1;color:var(--text_primary)}
.hl-ch .sc small{font-size:max(8px,calc(9.5px*var(--fs)));font-weight:700;text-transform:uppercase;letter-spacing:.03em}
.hl-idg{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:3px 14px;padding:6px 9px;border-radius:8px;border:1px solid var(--border);background:color-mix(in srgb, var(--accent) 5%, transparent)}
.hl-idg .r{min-width:0}
.hl-idg .l{font-size:max(8px,calc(9.5px*var(--fs)));color:var(--text_secondary);text-transform:uppercase;letter-spacing:.4px}
.hl-idg .v{font-size:max(8px,calc(11.5px*var(--fs)));color:var(--text_primary);word-break:break-word}
.hl-idg .v b{font-weight:700}
.hl-idg .v em{color:var(--text_disabled);font-size:.9em}
.hl-mg{display:grid;grid-template-columns:repeat(auto-fill,minmax(148px,1fr));gap:6px}
.hl-mt{padding:6px 8px 7px;border:1px solid var(--border);border-radius:8px;background:color-mix(in srgb, var(--accent) 5%, transparent);min-width:0}
.hl-mt .l{font-size:max(8px,calc(9.5px*var(--fs)));color:var(--text_secondary);text-transform:uppercase;letter-spacing:.4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hl-mt .v{font-size:max(8px,calc(12px*var(--fs)));font-weight:700;color:var(--text_primary);word-break:break-word;margin:1px 0 4px;line-height:1.25}
.hl-mt .v.na{color:var(--text_disabled);font-style:italic;font-weight:400}
.hl-mt .nt{font-size:max(8px,calc(9.5px*var(--fs)));color:var(--text_disabled);line-height:1.25;margin-top:2px}
.hl-bar{height:5px;border-radius:99px;background:color-mix(in srgb, var(--text_primary) 10%, transparent);overflow:hidden}
.hl-bar i{display:block;height:100%;width:0;border-radius:99px;transition:width .9s cubic-bezier(.2,.8,.2,1);background:var(--accent)}
.hl-fds{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:2px 14px;padding-top:6px;border-top:1px solid var(--border)}
.hl-fd{display:flex;gap:8px;font-size:max(8px,calc(11px*var(--fs)));line-height:1.35;color:var(--text_secondary);margin:2px 0}
.hl-cf{display:flex;align-items:center;gap:10px;padding-top:7px;border-top:1px solid var(--border);margin-top:auto}
.hl-skel{display:flex;align-items:center;gap:12px;color:var(--text_secondary);font-size:max(8px,calc(12px*var(--fs)));padding:4px 14px 14px}
.hl-skel .sp{width:26px;height:19px;background:var(--slime-sprite) center/contain no-repeat;transform-origin:50% 100%;animation:slMini .8s ease-in-out infinite;flex:none;filter:drop-shadow(0 0 5px rgba(190,70,255,.6))}
.hl-skel.wait .sp{animation:none}
.hl-err{color:var(--error-real);font-size:max(8px,calc(12px*var(--fs)));padding:8px 12px;margin:0 14px 8px;background:color-mix(in srgb,var(--error-real) 9%,transparent);border:1px solid color-mix(in srgb,var(--error-real) 45%,transparent);border-radius:8px}
.hl-ban{display:flex;align-items:center;gap:12px;padding:8px 12px;margin:0 14px 8px;border-radius:8px;background:color-mix(in srgb,var(--warning) 11%,transparent);border:1px solid color-mix(in srgb,var(--warning) 45%,transparent);font-size:max(8px,calc(11.5px*var(--fs)));color:var(--text_secondary)}
.hl-ban span{flex:1}
.hl-grid2{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:3px 12px}
.hl-step{display:flex;align-items:flex-start;gap:8px;padding:5px 7px;border-radius:6px;border:1px solid transparent;min-width:0}
.hl-step .ic{width:9px;height:9px;border-radius:50%;flex:none;margin:4px 3px 0 0;background:var(--text_disabled);transition:background .3s,box-shadow .3s}
.hl-step.need{border-color:color-mix(in srgb,var(--warning) 45%,transparent)}
.hl-man{display:flex;align-items:center;gap:10px;padding:6px 8px;border:1px solid var(--border);border-radius:7px;background:color-mix(in srgb, var(--accent) 5%, transparent);margin:3px 0}
@keyframes hlSpin{to{transform:rotate(360deg)}}
@keyframes hlIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
@keyframes hlSweep{from{transform:translateY(-160px)}to{transform:translateY(110vh)}}
@keyframes hlPulse{0%,100%{box-shadow:0 0 0 0 color-mix(in srgb,var(--accent) 45%,transparent)}50%{box-shadow:0 0 0 6px color-mix(in srgb,var(--accent) 0%,transparent)}}
@keyframes hlPop{0%{transform:scale(.94)}60%{transform:scale(1.04)}100%{transform:scale(1)}}
@keyframes hlShim{from{transform:translateX(-100%)}to{transform:translateX(100%)}}
.hl-ov{position:absolute;inset:0;z-index:30;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;overflow:hidden;padding:20px;
  background:radial-gradient(ellipse at 50% 24%,color-mix(in srgb,var(--accent) 16%,transparent) 0%,transparent 72%),color-mix(in srgb,var(--bg_base) 58%,transparent);backdrop-filter:blur(6px) saturate(1.15);transition:background .6s}
.hl-ov::before{content:'';position:absolute;left:0;right:0;top:0;height:160px;pointer-events:none;background:linear-gradient(180deg,transparent,color-mix(in srgb,var(--accent) 20%,transparent),transparent);animation:hlSweep 3.4s linear infinite}
.hl-lane{position:relative;width:100%;height:112px;flex:none;margin-top:6px}.hl-ov.fly{background:transparent;backdrop-filter:none}.hl-ov.fly::before{display:none}
.hl-ov .ctr{position:relative;z-index:1;display:flex;flex-direction:column;align-items:center;width:min(880px,100%);transition:opacity .35s}
.hl-ov.fly .ctr .top{opacity:0}
.hl-ov .eyebrow{font-size:max(8px,calc(11px*var(--fs)));letter-spacing:.38em;color:var(--accent);font-weight:700;text-transform:uppercase}
.hl-ov .big{font-size:max(8px,calc(26px*var(--fs)));font-weight:800;color:var(--text_primary);margin:2px 0 12px}
.hl-ov .ringw{position:relative;width:132px;height:132px}
.hl-ov .ringw svg{display:block}
.hl-ov .ringw .spin{transform-origin:66px 66px;animation:hlSpin 6s linear infinite}
.hl-ov .ringw .arc{transition:stroke-dashoffset .4s ease}
.hl-ov .ringw .pct{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:max(8px,calc(30px*var(--fs)));font-weight:800;color:var(--text_primary)}
.hl-ov .now{margin:12px 0 8px;min-height:18px;font-size:max(8px,calc(12px*var(--fs)));color:var(--text_secondary);font-style:italic}
.hl-ov .pb{width:min(520px,90%);margin-bottom:16px}
.hl-ov .grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;width:100%}
@media(max-width:760px){.hl-ov .grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
.hl-lt{position:relative;overflow:hidden;display:flex;align-items:center;gap:9px;padding:9px 10px;border:1px solid var(--border);border-radius:10px;background:color-mix(in srgb, var(--bg_card) 55%, transparent);opacity:.45;transition:opacity .3s,border-color .3s}
.hl-lt svg{color:var(--text_disabled);flex:none;transition:color .3s}
.hl-lt .c{min-width:0;flex:1}
.hl-lt .n{font-size:max(8px,calc(11.5px*var(--fs)));font-weight:700;color:var(--text_primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hl-lt .s{font-size:max(8px,calc(10px*var(--fs)));color:var(--text_secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hl-lt .g{font-size:max(8px,calc(15px*var(--fs)));font-weight:800;color:var(--text_disabled);flex:none;min-width:18px;text-align:right}
.hl-lt.run{opacity:1;border-color:var(--accent);animation:hlPulse 1.1s ease-in-out infinite}
.hl-lt.run svg{color:var(--accent)}
.hl-lt.run::after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,transparent,color-mix(in srgb,var(--accent) 22%,transparent),transparent);animation:hlShim 1s linear infinite}
.hl-lt.done{opacity:1;animation:hlPop .4s ease}
.hl-lt.done svg{color:var(--accent)}
.hl-ov .skip{margin-top:16px}`;
    document.head.appendChild(st);
  }

  // ── colour helpers for the canvas graphs ────────────────────────────────────────────────────────────────────
  const cssVar = (c) => { const m = /^var\((--[\w-]+)\)$/.exec(c || ''); return m ? (getComputedStyle(document.documentElement).getPropertyValue(m[1]).trim() || '#4a7cff') : c; };
  const alpha = (c, a) => {
    c = cssVar(c);
    let m;
    if ((m = /^hsl\(\s*([\d.]+)[ ,]+([\d.]+)%[ ,]+([\d.]+)%/.exec(c))) return `hsla(${m[1]},${m[2]}%,${m[3]}%,${a})`;
    if ((m = /^rgba?\(([^)]+)\)/.exec(c))) { const p = m[1].split(',').slice(0, 3).map((x) => x.trim()); return `rgba(${p.join(',')},${a})`; }
    if ((m = /^#([0-9a-f]{6})$/i.exec(c))) { const n = parseInt(m[1], 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; }
    return c;
  };
  const theme = () => { const cs = getComputedStyle(document.documentElement); return { bg: cs.getPropertyValue('--bg_input').trim() || '#111', grid: cs.getPropertyValue('--border').trim() || '#222' }; };

  /* The Game Booster's graph, generalised: values are 0-1, drawn left to right as a filled line over dashed grid lines. */
  function drawArea(cx, W, H, vals, color, flat) {
    const th = theme();
    cx.clearRect(0, 0, W, H); if (!flat) { cx.fillStyle = th.bg; cx.fillRect(0, 0, W, H); }
    cx.strokeStyle = th.grid; cx.lineWidth = 0.5; cx.setLineDash([2, 4]);
    [0.25, 0.5, 0.75].forEach((p) => { cx.beginPath(); cx.moveTo(0, H * (1 - p)); cx.lineTo(W, H * (1 - p)); cx.stroke(); });
    cx.setLineDash([]);
    const n = vals.length; if (n < 2) return;
    const step = W / (n - 1), c = cssVar(color);
    const g = cx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, alpha(c, 0.4)); g.addColorStop(1, alpha(c, 0.02));
    cx.beginPath(); cx.moveTo(0, H);
    vals.forEach((v, i) => cx.lineTo(i * step, H - v * (H - 4) - 2));
    cx.lineTo(W, H); cx.closePath(); cx.fillStyle = g; cx.fill();
    cx.beginPath(); cx.strokeStyle = c; cx.lineWidth = 1.5;
    vals.forEach((v, i) => { const x = i * step, y = H - v * (H - 4) - 2; i === 0 ? cx.moveTo(x, y) : cx.lineTo(x, y); });
    cx.stroke();
  }

  /* A score with no history yet: the same graph box, filled from the left up to the score (dashed marks at 25 / 50 / 75). */
  function drawGauge(cx, W, H, score, color) {
    const th = theme();
    cx.clearRect(0, 0, W, H);
    if (score != null) {
      const w = Math.max(3, W * score / 100), c = cssVar(color);
      const g = cx.createLinearGradient(0, 0, w, 0); g.addColorStop(0, alpha(c, 0.25)); g.addColorStop(1, alpha(c, 0.75));
      cx.fillStyle = g; cx.fillRect(0, 0, w, H);
      cx.fillStyle = c; cx.fillRect(Math.max(0, w - 2), 0, 2, H);
    }
    cx.strokeStyle = th.grid; cx.lineWidth = 0.5; cx.setLineDash([2, 4]);
    [0.25, 0.5, 0.75].forEach((p) => { cx.beginPath(); cx.moveTo(W * p, 0); cx.lineTo(W * p, H); cx.stroke(); });
    cx.setLineDash([]);
  }

  /* A canvas that always matches its card width; `paint(cx, W, H)` is called again whenever it is resized. */
  function canvas(H, paint) {
    const cv = document.createElement('canvas'); let W = 180;
    cv.width = W; cv.height = H; cv.style.cssText = `width:100%;height:${H}px;display:block`;
    const cx = cv.getContext('2d');
    const go = () => { try { paint(cx, W, H); } catch (e) { /* a graph that cannot draw must never break the page */ } };
    if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => { const w = Math.round(cv.clientWidth); if (w > 20 && w !== W) { W = w; cv.width = w; go(); } }).observe(cv);
    cv.redraw = go; go();
    return cv;
  }

  // ── history of past scores (real scans only) for the trend graphs ───────────────────────────────────────────
  const HK = 'dwut.health.hist';
  const loadHist = () => { try { return JSON.parse(localStorage.getItem(HK) || '[]'); } catch { return []; } };
  function saveHist(r) {
    try {
      const h0 = loadHist(), c = {};
      (r.overall.categories || []).forEach((x) => { if (x.score != null) c[x.key] = x.score; });
      const last = h0[h0.length - 1];
      const entry = { t: Date.now(), o: r.overall.score, c };
      if (last && Date.now() - last.t < 20000) h0[h0.length - 1] = entry; else h0.push(entry);
      localStorage.setItem(HK, JSON.stringify(h0.slice(-30)));
    } catch { /* storage unavailable - the trend graphs fall back to the gauge */ }
  }
  const series = (key) => loadHist().map((e) => (key === 'overall' ? e.o : e.c && e.c[key])).filter((v) => v != null).map((v) => v / 100);

  // ── state ───────────────────────────────────────────────────────────────────────────────────────────────────
  const root = h('div', { style: 'position:absolute;inset:0;overflow:hidden' });
  const scroller = h('div', { class: 'scroll', style: 'position:absolute;inset:0' });
  const wrap = h('div', { class: 'hl' });
  scroller.append(wrap); root.append(scroller);
  let scanId = null, running = false, result = null, scanned = 0, fixing = false, revealed = false, loader = null;
  const byCat = {};
  const lastRun = {};
  let unsubP = null, unsubD = null;

  const scanBtn = Btn('Scan', { h: 32, w: 96, bold: true, onclick: () => start() });
  const copyBtn = Btn('Copy report', { variant: 'ghost', h: 32, w: 112, onclick: () => copyReport() });
  const fixAll = Btn('Fix & Optimize All', { h: 32, w: 160, bold: true, cls: 'hl-fixbtn', onclick: () => openFix({ category: 'all', title: 'the whole PC' }) });
  const badge = h('div', { style: 'padding:3px 10px;border-radius:20px;font-size:10px;font-weight:700;letter-spacing:.7px;border:1px solid transparent;transition:all .3s', text: 'SCANNING' });
  function setBadge(label, color) {
    badge.textContent = String(label).toUpperCase();
    Object.assign(badge.style, color ? { background: `color-mix(in srgb,${color} 15%,transparent)`, color, border: `1px solid color-mix(in srgb,${color} 35%,transparent)` } : { background: 'var(--bg_input)', color: 'var(--text_secondary)', border: '1px solid transparent' });
  }
  setBadge('Scanning');
  const statusLbl = h('div', { class: 'f11 ts', style: 'min-height:16px;font-style:italic;padding:0 14px 4px', text: 'Preparing scan...' });
  const prog = Progress({ height: 5 });
  const errBox = h('div', { class: 'hl-err', style: 'display:none' });
  const banner = h('div', { style: 'display:none' });
  const stats = h('div', { class: 'hl-stats' });
  const tiles = h('div', { class: 'hl-tiles' });
  const attBox = h('div', { class: 'hl-att' });
  const attLbl = h('div', { class: 'hl-lbl', text: 'Needs Attention' });
  const invLbl = h('div', { class: 'hl-lbl', text: 'Your Hardware' });
  const invBox = h('div', { class: 'hl-inv' });
  const secs = {};

  /* live graphs: the very same numbers + graph cards as the Game Booster, polled only while this tab is on screen */
  const live = {};
  function liveCard(key, label, unit, colorVar) {
    const SAMPLES = 90, buf = new Float32Array(SAMPLES); let head = 0;
    const cv = canvas(48, (cx, W, H) => { const v = []; for (let i = 0; i < SAMPLES; i++) v.push(buf[(head - SAMPLES + i + SAMPLES * 10) % SAMPLES]); drawArea(cx, W, H, v, `var(${colorVar})`); });
    const val = h('span', { style: `font-size:20px;font-weight:700;line-height:1;color:var(${colorVar})`, text: '--' });
    const sub = h('span', { class: 'f10 ts', style: 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-height:14px;display:block' });
    live[key] = { push(v) { buf[head++ % SAMPLES] = Math.max(0, Math.min(1, v)); cv.redraw(); }, val, sub };
    return h('div', { class: 'hl-card' }, h('div', { class: 'f10 b ts', text: label, style: 'letter-spacing:.5px;text-transform:uppercase' }),
      h('div', { style: 'display:flex;align-items:baseline' }, val, h('span', { class: 'f10 ts', style: 'margin-left:2px;align-self:flex-end;padding-bottom:2px', text: unit })), sub, h('div', { class: 'hl-gbox' }, cv));
  }
  stats.append(liveCard('cpu', 'CPU', '%', '--accent'), liveCard('ctemp', 'CPU Temp', '°C', '--accent'), liveCard('gpu', 'GPU', '%', '--error'), liveCard('gtemp', 'GPU Temp', '°C', '--error'),
    liveCard('ram', 'RAM', '%', '--success'), liveCard('disk', 'Disk', '%', '--warning'), liveCard('net', 'Network', 'Mbps', '--info'));
  function setLive(k, raw, norm, sub) {
    const L = live[k]; if (!L) return;
    L.val.textContent = raw == null ? '--' : (typeof raw === 'number' ? (raw >= 100 ? Math.round(raw) : raw.toFixed(1)) : raw);
    if (sub != null) L.sub.textContent = sub;
    if (typeof norm === 'number') L.push(norm);
  }
  const shown = () => root.isConnected && root.offsetParent !== null && !!root.closest('.page.active');
  async function sampleStats() {
    if (document.documentElement.classList.contains('idle') || !shown()) return;      // minimised / in the tray: no backend call, no layout read
    try {
      const s = await rpc('gaming.system_stats'); if (!s) return;
      const na = (v) => v == null;
      setLive('cpu', s.cpu, s.cpu / 100, `${s.cpu.toFixed(1)}% used`);
      setLive('gpu', s.gpu, s.gpu / 100, `${s.gpu.toFixed(1)}% used`);
      setLive('ctemp', na(s.cpu_temp) ? 'N/A' : s.cpu_temp, na(s.cpu_temp) ? 0 : s.cpu_temp / 100, na(s.cpu_temp) ? 'no sensor' : (s.cpu_temp_src || 'sensor'));
      setLive('gtemp', na(s.gpu_temp) ? 'N/A' : s.gpu_temp, na(s.gpu_temp) ? 0 : s.gpu_temp / 100, na(s.gpu_temp) ? 'no sensor' : (s.gpu_temp_src || 'sensor'));
      setLive('ram', s.ram, s.ram / 100, `${s.ram.toFixed(1)}% used`);
      setLive('disk', s.disk, s.disk / 100, `R ${Number(s.disk_read || 0).toFixed(1)} / W ${Number(s.disk_write || 0).toFixed(1)} MB/s`);
      setLive('net', s.net, Math.min(1, s.net * 2 / 100), `↑ ${Number(s.net_send || 0).toFixed(1)} / ↓ ${Number(s.net_recv || 0).toFixed(1)} Mbps`);
    } catch { /* backend not ready yet */ }
  }
  setInterval(sampleStats, 1000);
  setTimeout(sampleStats, 400);

  const header = h('div', { class: 'row', style: 'padding:10px 14px 4px;gap:8px;flex-wrap:wrap' },
    h('div', { class: 'col', style: 'gap:2px' }, h('div', { class: 'f14 b tp', text: 'System Health' }), h('div', { class: 'f10 ts', text: 'Scan · Fix · Clean · Optimize · Boost — every component, one click' })),
    h('div', { class: 'grow' }), badge, Sp(6), scanBtn, copyBtn, fixAll);
  const main = Card([header, statusLbl, h('div', { style: 'padding:0 14px 6px' }, prog), errBox, banner,
    h('div', { class: 'hl-lbl', text: 'Live System Stats' }), stats,
    h('div', { class: 'hl-lbl', text: 'Health Scores' }), tiles,
    attLbl, attBox], 'col', { marginTop: '4px' });
  const invCard = Card([invLbl, invBox], 'col', { marginTop: '10px', display: 'none' });
  const idleBox = Card([h('div', { class: 'col', style: 'align-items:center;gap:8px;padding:34px 20px;text-align:center' },
    h('div', { class: 'f16 b tp', text: 'Ready to scan your PC' }),
    h('div', { class: 'f11 ts', style: 'max-width:480px;white-space:normal', text: 'DWUT checks your processor, memory, drives, graphics, cooling, network, firmware, drivers and Windows with real readings - then lists everything in columns, with a Fix & Optimize button for every component.' }),
    Btn('Scan', { h: 40, w: 190, f: 14, bold: true, onclick: () => start() }))], 'col', { marginTop: '10px' });
  wrap.append(main, idleBox, invCard);
  const cpy = h('div', { class: 'f10 td', style: 'text-align:center;padding:14px 0 2px', text: 'Copyright © 2026 Darko / Darko.Dev' });
  for (const [k, title] of CATS) {
    const pill = h('span', { class: 'pill' });
    const hd = h('div', { class: 'hl-sh' });
    const fixBtn = Btn('Fix & Optimize', { h: 28, w: 138, f: 11, bold: true, cls: 'hl-fixbtn', onclick: () => openFix({ category: k, title }) });
    const drvBtn = k === 'drivers' ? Btn('Install Driver Updates', { h: 28, w: 176, f: 11, bold: true, cls: 'hl-fixbtn', tip: 'Finds newer drivers on Windows Update, installs them for real and shows what actually changed.', onclick: () => driverUpdates() }) : null;
    hd.append(h('div', { class: 'f14 b tp', text: title }), pill, h('div', { class: 'grow' }), drvBtn, drvBtn ? Sp(6) : null, fixBtn);
    const grid = h('div', { class: 'hl-cps' });
    const sec = Card([hd, grid], 'col hl-sec', { display: 'none' }); sec.id = 'hl-sec-' + k;
    secs[k] = { sec, grid, pill, title };
    wrap.append(sec);
  }
  wrap.append(cpy);

  const catScore = (cards) => { const v = cards.map((c) => c.score).filter((x) => x != null); return v.length ? 0.6 * (v.reduce((a, b) => a + b, 0) / v.length) + 0.4 * Math.min(...v) : null; };
  const scoreOf = (k) => (result ? (result.overall.categories.find((x) => x.key === k) || {}).score : (Array.isArray(byCat[k]) ? catScore(byCat[k]) : null));

  // ── pieces ──────────────────────────────────────────────────────────────────────────────────────────────────
  function bar(score) {
    const b = h('div', { class: 'hl-bar' }), i = h('i'); b.append(i);
    if (score != null) { i.style.background = grad(score); requestAnimationFrame(() => requestAnimationFrame(() => { i.style.width = Math.max(2, score) + '%'; })); }
    return b;
  }
  const tag = (text, color) => h('span', { class: 'tag', text, style: `background:color-mix(in srgb,${color} 16%,transparent);color:${color};flex:none` });

  function scoreTile(key, title, _unused, score, sub, onclick) {
    const c = score == null ? 'var(--text_disabled)' : col(score), s = series(key);
    const t = h('div', { class: 'hl-card hl-tile' });
    const top = h('div', { class: 't f10 b ts', style: 'letter-spacing:.5px;text-transform:uppercase' }); top.append(h('span', { text: title, style: 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }));
    t.append(top, h('div', { style: 'display:flex;align-items:baseline' }, h('span', { style: `font-size:20px;font-weight:700;line-height:1;color:${c}`, text: score == null ? '--' : String(Math.round(score)) }), h('span', { class: 'f10 ts', style: 'margin-left:2px;align-self:flex-end;padding-bottom:2px', text: '/100' })),
      h('span', { class: 'f10', style: `white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-height:14px;display:block;color:${c}`, text: sub }),
      h('div', { class: 'hl-gbox hl-flat' }, canvas(28, (cx, W, H) => (s.length >= 2 ? drawArea(cx, W, H, s, c, true) : drawGauge(cx, W, H, score, c)))));
    t.addEventListener('click', onclick);
    return t;
  }

  function renderTiles() {
    tiles.textContent = '';
    const done = CATS.some(([k]) => Array.isArray(byCat[k]));
    const o = result ? result.overall.score : null;
    const nIssues = result ? result.findings.length : 0;
    tiles.append(scoreTile('overall', 'Overall', 'pc', o, result ? `${rate(o)} · ${nIssues} issue${nIssues === 1 ? '' : 's'}` : (done ? 'scanning…' : 'waiting…'), () => scroller.scrollTo({ top: 0, behavior: 'smooth' })));
    for (const [k, title] of CATS) {
      const d = byCat[k];
      if (Array.isArray(d) && !d.length) continue;
      const sc = Array.isArray(d) ? scoreOf(k) : null;
      const n = Array.isArray(d) ? d.reduce((a, c) => a + c.findings.filter((f) => f.level === 'bad' || f.level === 'warn').length, 0) : 0;
      tiles.append(scoreTile(k, title, k, sc, Array.isArray(d) ? `${rate(sc)}${n ? ` · ${n} issue${n === 1 ? '' : 's'}` : ''}` : (d === 'scanning' ? 'checking…' : 'waiting…'),
        () => { const s = secs[k].sec; if (s.style.display !== 'none') s.scrollIntoView({ behavior: 'smooth', block: 'start' }); }));
    }
  }

  function renderPanel(c) {
    const el = h('div', { class: 'hl-cp' });
    const color = c.status === 'idle' ? 'var(--text_disabled)' : col(c.score);
    el.style.setProperty('--stripe', color);
    const head = h('div', { class: 'hl-ch' });
    const sc = h('div', { class: 'sc' }); sc.innerHTML = `<b>${c.score == null ? '--' : Math.round(c.score)}</b><small style="color:${color}">${esc(c.label)}</small>`;
    head.append(h('div', { class: 'nm' }, h('b', { text: esc(c.name), title: esc(c.name) }), h('span', { text: esc(c.subtitle), title: esc(c.subtitle) })), sc);
    el.append(head, h('div', { class: 'hl-gbox hl-flat' }, canvas(14, (cx, W, H) => drawGauge(cx, W, H, c.score, color))));

    const idRows = [];
    if (c.brand) idRows.push(['Brand', c.brand, true]);
    if (c.model) idRows.push(['Model', c.model, false]);
    (c.identity || []).forEach((i) => idRows.push([i.label, i.value, false, i.how]));
    if (idRows.length) {
      const box = h('div', { class: 'hl-idg' });
      idRows.forEach(([l, v, bold, how]) => {
        const val = h('div', { class: 'v' }); if (bold) val.append(h('b', { text: v })); else val.append(document.createTextNode(v));
        if (how) val.append(document.createTextNode('  '), h('em', { text: `(${how})` }));
        box.append(h('div', { class: 'r' }, h('div', { class: 'l', text: l }), val));
      });
      el.append(box);
    }
    if (c.metrics.length) {
      const mg = h('div', { class: 'hl-mg' });
      c.metrics.forEach((m) => {
        const na = m.value === 'Not available', t = h('div', { class: 'hl-mt' });
        if (m.note) t.title = m.note;
        t.append(h('div', { class: 'l', text: m.label, title: m.label }), h('div', { class: 'v' + (na ? ' na' : ''), text: m.value }));
        if (m.score != null) t.append(bar(m.score));
        if (m.note && (na || m.score == null)) t.append(h('div', { class: 'nt', text: m.note }));
        mg.append(t);
      });
      el.append(mg);
    }
    if (c.findings.length) {
      const fds = h('div', { class: 'hl-fds' }), order = { bad: 0, warn: 1, info: 2, ok: 3 };
      [...c.findings].sort((a, b) => order[a.level] - order[b.level]).forEach((f) => {
        const dot = document.createElement('i'); dot.style.background = LEVEL[f.level] || LEVEL.info;
        fds.append(h('div', { class: 'hl-fd' }, dot, h('span', { text: f.text })));
      });
      el.append(fds);
    }
    const issues = c.findings.filter((f) => f.level === 'bad' || f.level === 'warn').length;
    el.append(h('div', { class: 'hl-cf' },
      Btn('Fix & Optimize', { h: 26, w: 140, f: 11, bold: true, cls: 'hl-fixbtn', onclick: () => openFix({ category: c.category, card: c.key, title: c.name }) }),
      h('span', { class: 'f10 ts grow', style: 'white-space:normal', text: lastRun[c.key] || (issues ? `${issues} problem${issues === 1 ? '' : 's'} to fix - then cleans, optimizes and boosts this component` : 'Cleans, optimizes and boosts this component') })));
    return el;
  }

  function skeleton(label, waiting) {
    const s = h('div', { class: 'hl-skel' + (waiting ? ' wait' : '') }, h('div', { class: 'sp' }), h('span', { text: label }));
    return s;
  }

  function renderCategory(k) {
    const s = secs[k], data = byCat[k];
    s.grid.textContent = '';
    if (!revealed) { s.sec.style.display = 'none'; return; }
    if (data === 'pending' || data === 'scanning') {
      s.sec.style.display = '';
      s.grid.style.display = 'block'; s.grid.style.padding = '0';
      s.grid.append(skeleton(data === 'scanning' ? `Checking ${s.title.toLowerCase()}...` : `Waiting to check ${s.title.toLowerCase()}...`, data === 'pending'));
      s.pill.textContent = '';
      return;
    }
    s.grid.style.display = ''; s.grid.style.padding = '';
    if (!data || !data.length) { s.sec.style.display = 'none'; return; }          // e.g. no battery on a desktop
    s.sec.style.display = '';
    data.forEach((c) => s.grid.append(renderPanel(c)));
    const sc = scoreOf(k);
    s.pill.textContent = sc == null ? 'Not available' : `${Math.round(sc)} / 100`;
    s.pill.style.color = col(sc);
  }

  function renderAttention() {
    attBox.textContent = '';
    const fs = result ? result.findings : [];
    attLbl.style.display = attBox.style.display = result ? '' : 'none';
    if (!result) return;
    if (!fs.length) { attBox.style.display = 'block'; attBox.append(h('div', { class: 'f12 ts', text: 'Everything looks healthy - no hardware or system problems were found in any component that could be checked.' })); return; }
    attBox.style.display = '';
    fs.forEach((f) => {
      const dot = document.createElement('i'); dot.style.background = LEVEL[f.level];
      const tx = h('div', { class: 'tx' }, h('b', { text: f.card + ': ' }), document.createTextNode(f.text));
      attBox.append(h('div', { class: 'hl-ai' }, dot, tx, Btn('Fix', { h: 24, w: 52, f: 11, bold: true, cls: 'hl-fixbtn', onclick: () => openFix({ category: f.category, card: f.card_key, title: f.card }) })));
    });
  }

  function renderInventory() {
    const rows = result && result.inventory;
    invBox.textContent = '';
    if (!rows || !rows.length) { invCard.style.display = 'none'; return; }
    invCard.style.display = '';
    rows.forEach((r) => {
      invBox.append(h('div', { class: 'hl-ii' }, h('div', { class: 'c' }, h('div', { class: 'g', text: r.group }),
        h('div', { class: 'm' }, h('b', { text: r.brand || '-' }), document.createTextNode(r.model ? '  ' + r.model : '')), r.detail ? h('div', { class: 'd', text: r.detail }) : null)));
    });
  }

  function renderDone() {
    const o = result.overall, n = result.cards;
    const cnt = { excellent: 0, good: 0, fair: 0, poor: 0, critical: 0 };
    n.forEach((c) => { if (cnt[c.status] != null) cnt[c.status]++; });
    prog.set(1);
    if (o.score == null) setBadge('Not enough data'); else setBadge(`${o.label} · ${Math.round(o.score)}`, col(o.score));
    const issues = result.findings.length;
    statusLbl.textContent = `${n.length} component${n.length === 1 ? '' : 's'} checked in ${result.duration}s  ·  ${result.finished}  ·  ${issues ? issues + ' issue' + (issues === 1 ? '' : 's') + ' found' : 'no issues found'}`;
    banner.style.display = 'none';
    if (!result.admin) {
      banner.className = 'hl-ban'; banner.style.display = ''; banner.textContent = '';
      banner.append(h('span', { text: 'Some checks and fixes need Administrator: drive wear and temperature, the TPM, the Windows system-file check, services, power settings and repairs. Those are marked "Not available" / skipped and are not part of the score.' }),
        Btn('Restart as Admin', { h: 28, w: 150, onclick: () => window.dwut?.relaunchAdmin?.() }));
    }
    for (const c of CATS) byCat[c[0]] = result.cards.filter((x) => x.category === c[0]);
    saveHist(result);
    scanBtn.textContent = 'Rescan';
    if (revealed) { renderAttention(); renderInventory(); for (const [k] of CATS) renderCategory(k); renderTiles(); }
    applyBusy();
    setStatus && setStatus(`Health scan finished: ${o.score == null ? 'not enough data' : Math.round(o.score) + '/100 ' + o.label}`);
  }

  // ── scan flow ───────────────────────────────────────────────────────────────────────────────────────────────
  function reset() {
    result = null; scanned = 0; revealed = false; invCard.style.display = 'none'; errBox.style.display = 'none'; banner.style.display = 'none'; attBox.style.display = 'none'; attLbl.style.display = 'none';
    for (const [k] of CATS) { byCat[k] = 'pending'; renderCategory(k); }
    setBadge('Scanning'); idleBox.style.display = 'none'; tiles.style.display = 'none'; tiles.previousSibling.style.display = 'none';
    statusLbl.textContent = 'Reading real sensors, SMART data, drivers and the Windows event log.';
    prog.set(0.02);
  }
  async function start() {
    if (running || fixing) return;
    running = true; scanBtn.disabled = true; scanId = null; applyBusy();
    reset(); openLoader();
    try { const r = await rpc('health.scan'); scanId = r.scan; }
    catch (e) { finishRunning(); closeLoader(true); errBox.style.display = ''; errBox.textContent = 'Could not start the scan: ' + e.message; }
  }
  function finishRunning() { running = false; scanBtn.disabled = false; applyBusy(); }
  function onProgress(d) {
    if (!root.isConnected) { if (root.__seen) { unsubP && unsubP(); unsubD && unsubD(); } return; }
    root.__seen = true;
    if (!d || (scanId && d.scan !== scanId)) return;
    if (!scanId) scanId = d.scan;
    if (d.state === 'start') { byCat[d.key] = 'scanning'; renderCategory(d.key); renderTiles(); return; }
    byCat[d.key] = d.cards || []; scanned += 1;
    renderCategory(d.key); renderTiles();
    prog.set(scanned / CATS.length); statusLbl.textContent = `Scanning… ${Math.round(scanned / CATS.length * 100)}%`;
  }
  function onDone(d) {
    if (!root.isConnected) { if (root.__seen) { unsubP && unsubP(); unsubD && unsubD(); } return; }
    if (!d || (scanId && d.scan !== scanId)) return;
    finishRunning();
    if (d.error || !d.result) { closeLoader(true); errBox.style.display = ''; errBox.textContent = 'The health scan failed: ' + (d.error || 'no result'); setBadge('Failed', 'var(--error-real)'); idleBox.style.display = ''; return; }
    result = d.result; renderDone();
  }
  unsubP = on('health.progress', onProgress);
  unsubD = on('health.done', onDone);


  // ── the loading screen: every component is checked one by one, then the tiles fly into their place on the page ──
  function openLoader() {
    closeLoader(true);
    const C = 1, arc = { style: {} }, pct = { textContent: '' };       // (the old progress ring is gone - the slime and its number chips show the progress now)
    const lane = h('div', { class: 'hl-lane' });
    const now = h('div', { class: 'now', text: 'Starting scan…' });
    const pb = Progress({ height: 6 }); const pbw = h('div', { class: 'pb' }, pb);
    const grid = h('div', { class: 'grid' });
    const tilesL = {};
    for (const [k, title] of CATS) {
      const n = h('div', { class: 'n', text: title }), st = h('div', { class: 's', text: 'waiting…' }), g = h('div', { class: 'g', text: '' });
      const t = h('div', { class: 'hl-lt' }, h('div', { class: 'c' }, n, st), g);
      tilesL[k] = { t, st, g }; grid.append(t);
    }
    const skip = Btn('Skip animation', { variant: 'plain', h: 26, w: 140, f: 11, cls: 'skip', onclick: () => { L.pace = 60; clearInterval(L.timer); L.timer = setInterval(tick, L.pace); } });
    const top = h('div', { class: 'col top', style: 'align-items:center' }, h('div', { class: 'eyebrow', text: 'DWUT · System Health' }), h('div', { class: 'big', text: 'Scanning your PC' }), now, pbw);
    const ctr = h('div', { class: 'ctr' }, top, lane, grid, h('div', { class: 'col top', style: 'align-items:center' }, skip));
    const ov = h('div', { class: 'hl-ov' }, ctr);
    root.append(ov);
    const rider = window.Slime ? Slime.rider(ctr, {
      size: 92, bounce: true,
      anchor: (r, hr) => ({ x: r.left - hr.left + r.width / 2, y: r.top - hr.top - 3, sc: 0.92 }),
      home: () => { const l = lane.getBoundingClientRect(), hr = ctr.getBoundingClientRect(); return { x: l.left - hr.left + l.width / 2, y: l.bottom - hr.top - 4, sc: 1 }; },
      onLand: (t) => { if (t && t.classList) { t.classList.add('land'); setTimeout(() => t.classList.remove('land'), 260); } },
    }) : null;
    const L = loader = { ov, tilesL, idx: 0, pace: 520, timer: null, arc, pct, now, pb, C, finishing: false, rider };

    function mark(i, st) {
      const [k, title] = CATS[i], T = tilesL[k];
      T.t.classList.toggle('run', st === 'run'); T.t.classList.toggle('done', st === 'done');
      if (st === 'run') { T.st.textContent = PHRASE[k]; T.g.textContent = ''; now.textContent = PHRASE[k] + '…'; if (rider) rider.hopTo(T.t); }
    }
    function tick() {
      if (L !== loader) return;
      if (L.idx >= CATS.length) { if (result && !L.finishing) { L.finishing = true; clearInterval(L.timer); finishLoader(); } return; }
      const [k] = CATS[L.idx], d = byCat[k], T = tilesL[k];
      if (!Array.isArray(d)) { mark(L.idx, 'run'); return; }               // the real check for this component has not finished yet
      mark(L.idx, 'done');
      const sc = d.length ? catScore(d) : null, n = d.reduce((a, c) => a + c.findings.filter((f) => f.level === 'bad' || f.level === 'warn').length, 0);
      T.g.textContent = !d.length ? '–' : sc == null ? 'n/a' : String(Math.round(sc));
      T.g.style.color = !d.length ? 'var(--text_disabled)' : col(sc);
      T.st.textContent = !d.length ? 'not present on this PC' : `${rate(sc)}${n ? ` · ${n} issue${n === 1 ? '' : 's'}` : ' · all clear'}`;
      L.idx++;
      const f = L.idx / CATS.length;
      arc.style.strokeDashoffset = String(C * (1 - f)); pct.textContent = Math.round(f * 100) + '%'; pb.set(f); if (rider) rider.chip(Math.round(f * 100) + '%');
      if (L.idx < CATS.length) mark(L.idx, 'run'); else now.textContent = result ? 'Putting everything in order…' : 'Finishing up…';
    }
    L.tick = tick; mark(0, 'run');
    L.timer = setInterval(tick, L.pace);
  }

  function closeLoader(now) {
    if (!loader) return;
    clearInterval(loader.timer);
    const ov = loader.ov, rd = loader.rider; loader = null;
    if (now) { ov.remove(); rd && rd.destroy(); } else { ov.classList.add('fly'); setTimeout(() => { ov.remove(); rd && rd.destroy(); }, 1100); }
  }

  /* hand-over: reveal the page underneath, then fly every loading tile to its score tile and let the sections rise in, column by column */
  function finishLoader() {
    const L = loader; if (!L) return;
    revealed = true; scroller.scrollTop = 0;
    tiles.style.display = ''; tiles.previousSibling.style.display = '';
    renderAttention(); renderInventory(); for (const [k] of CATS) renderCategory(k); renderTiles(); applyBusy();
    const targets = [...tiles.children].slice(1);                              // [0] is the overall tile
    const keys = CATS.map((c) => c[0]).filter((k) => Array.isArray(byCat[k]) && byCat[k].length);
    L.ov.classList.add('fly'); if (L.rider) L.rider.celebrate();
    const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    keys.forEach((k, i) => {
      const from = L.tilesL[k].t, to = targets[i]; if (!to || reduce) return;
      const a = from.getBoundingClientRect(), b = to.getBoundingClientRect(); if (!a.width || !b.width) return;
      to.style.opacity = '0';
      const clone = from; clone.style.position = 'fixed'; clone.style.left = a.left + 'px'; clone.style.top = a.top + 'px'; clone.style.width = a.width + 'px'; clone.style.height = a.height + 'px'; clone.style.margin = '0'; clone.style.zIndex = '60'; clone.style.transformOrigin = 'top left'; clone.classList.remove('run', 'done'); clone.style.opacity = '1';
      document.body.append(clone);
      const anim = clone.animate([{ transform: 'none', opacity: 1 }, { transform: `translate(${b.left - a.left}px,${b.top - a.top}px) scale(${b.width / a.width},${b.height / a.height})`, opacity: 0.2 }],
        { duration: 700, delay: i * 55, easing: 'cubic-bezier(.2,.8,.2,1)', fill: 'forwards' });
      anim.onfinish = () => { clone.remove(); to.style.transition = 'opacity .25s'; to.style.opacity = ''; };
    });
    // sections rise in one after another
    let n = 0;
    for (const [k] of CATS) { const sc = secs[k].sec; if (sc.style.display === 'none') continue; sc.style.animation = `hlIn .55s ease ${0.35 + (n++) * 0.09}s both`; }
    [attBox, attLbl, invCard].forEach((e) => { e.style.animation = 'hlIn .5s ease .3s both'; });
    closeLoader(false);
    setTimeout(() => { for (const [k] of CATS) secs[k].sec.style.animation = ''; [attBox, attLbl, invCard].forEach((e) => { e.style.animation = ''; }); }, 2200);
  }
  window.addEventListener('dwut-theme', () => root.querySelectorAll('canvas').forEach((c) => c.redraw && c.redraw()));

  // ── Fix & Optimize ──────────────────────────────────────────────────────────────────────────────────────────
  function applyBusy() {
    const busy = running || fixing;
    root.querySelectorAll('.hl-fixbtn').forEach((b) => { b.disabled = busy || !result; });
    scanBtn.disabled = busy;
  }
  const GPU_URL = { nvidia: 'https://www.nvidia.com/Download/index.aspx', amd: 'https://www.amd.com/en/support/download/drivers.html', intel: 'https://www.intel.com/content/www/us/en/download-center/home.html' };

  async function manualAction(m) {
    try {
      if (m.action === 'uefi' || m.action === 'bios_page') Nav.go('bios');
      else if (m.action === 'restart') { if (await Modal.confirm('Restart now?', 'The PC restarts in 20 seconds. Save your work first.', { yes: 'Restart', no: 'Cancel' })) await rpc('health.restart'); }
      else if (m.action === 'gpu_driver') { const g = (result && result.cards.find((c) => c.category === 'gpu' && c.ctx && c.ctx.vendor)) || {}; await rpc('os.open_url', { url: GPU_URL[(g.ctx || {}).vendor] || GPU_URL.nvidia }); }
            else if (m.action === 'tool') { const r = await rpc('tools.open', { name: m.tool }); if (r && r.ok === false) warn(m.tool, r.message || 'Could not open it.'); }
      else if (m.action === 'startup') await startupPicker();
    } catch (e) { fail('Fix & Optimize', e.message); }
  }
  const manualRow = (m) => h('div', { class: 'hl-man' }, h('span', { class: 'f11 tp grow', style: 'white-space:normal', text: (m.title ? m.title + ': ' : '') + m.text }), m.action ? Btn(m.label || 'Open', { variant: 'ghost', h: 26, w: 170, f: 11, onclick: () => manualAction(m) }) : null);

  async function startupPicker() {
    const list = await rpc('tools.startup_list');
    const on_ = list.filter((e) => e.enabled), checks = [];
    if (!on_.length) return notify('Startup apps', 'No enabled startup apps were found.');
    const picked = await Modal.custom((close) => {
      const body = h('div', { class: 'scroll', style: 'max-height:min(54vh,460px);margin-top:8px;padding-right:6px' }, h('div', { class: 'hl-grid2' }));
      on_.forEach((e) => {
        const cb = Check('', { sm: true, checked: e.impact === 'High', themed: true }); checks.push([e, cb]);
        const row = h('div', { class: 'hl-step', style: 'cursor:pointer', onclick: (ev) => { if (!cb.contains(ev.target)) cb.toggle(); } }, cb,
          h('div', { class: 'col grow', style: 'min-width:0' }, h('div', { class: 'row', style: 'gap:6px' }, h('span', { class: 'f11 tp b ell', text: e.name }), e.impact && e.impact !== 'Unknown' ? tag(e.impact.toUpperCase(), e.impact === 'High' ? 'var(--error-real)' : 'var(--warning)') : null),
            h('div', { class: 'f10 ts ell', text: e.location, title: e.command })));
        body.firstChild.append(row);
      });
      return h('div', { class: 'modal', style: 'width:min(780px,94%);max-width:none' }, h('h3', { text: 'Startup apps - choose what to turn off' }),
        h('div', { class: 'f11 ts', style: 'white-space:normal', text: 'Turned-off apps stay installed and can be turned back on in Task Manager > Startup. Programs marked HIGH are ticked.' }), body,
        h('div', { class: 'foot' }, Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }), Btn('Turn off selected', { w: 150, bold: true, onclick: () => close(checks.filter(([, cb]) => cb.checked).map(([e]) => e.i)) })));
    });
    if (!picked || !picked.length) return;
    const n = await rpc('tools.startup_set', { indices: picked, enable: false });
    notify('Startup apps', `${n} startup app${n === 1 ? '' : 's'} turned off. They no longer start with Windows.`);
  }

  // ── real driver updates (backend/modules/health/driver_update.py) ─────────────────────────────────────────────────
  // Windows Update's driver channel, driven through the Windows Update Agent: every update is downloaded + installed one by one, the agent's own
  // result is shown, and driver versions are compared before / after - nothing is called "updated" unless it really changed.
  let drvUI = null;
  on('health.drv_check', (d) => drvUI && drvUI.check(d));
  on('health.drv_event', (d) => drvUI && drvUI.event(d));
  on('health.drv_log', (d) => drvUI && drvUI.log(d));
  on('health.drv_done', (d) => drvUI && drvUI.done(d));

  async function driverUpdates() {
    if (running || fixing || drvUI) return;
    const mbs = (b) => (b > 0 ? (b / 1048576).toFixed(b > 1e8 ? 0 : 1) + ' MB' : '');
    const rows = {}, checks = [];
    let busy = false, armed = false;
    const body = h('div', { class: 'scroll', style: 'max-height:min(48vh,420px);margin-top:8px;padding-right:6px' });
    const status = h('div', { class: 'f11 ts', style: 'margin:8px 0 2px;min-height:16px;font-style:italic' });
    const logLine = h('div', { class: 'f10 ts mono ell', style: 'min-height:14px' });
    const bar_ = Progress({ height: 6 });
    const closeBtn = Btn('Close', { variant: 'ghost', w: 100, onclick: () => { drvUI = null; Modal.close(); } });
    const recheck = Btn('Check again', { variant: 'ghost', w: 130, onclick: () => search() });
    const go = Btn('Install selected', { w: 210, bold: true, onclick: () => install() });
    const foot = h('div', { class: 'foot' }, closeBtn, h('div', { class: 'grow' }), recheck, go);
    const picked = () => checks.filter(([, cb]) => cb.checked).map(([u]) => u);
    const syncGo = () => { armed = false; const n = picked().length; go.textContent = n ? `Install selected (${n})` : 'Install selected'; go.disabled = busy || !n; };
    const note = (id, text, color) => { const r = rows[id]; if (!r) return; r.nt.textContent = text || ''; r.nt.style.color = color || ''; };
    const makerRow = () => h('div', { class: 'hl-man' }, h('span', { class: 'f11 tp grow', style: 'white-space:normal', text: 'Graphics (NVIDIA / AMD / Intel), some chipset, audio and Wi-Fi drivers are often newer on the maker\'s own site than on Windows Update. DWUT never pretends those are updated - open the maker\'s page:' }),
      Btn('NVIDIA', { variant: 'ghost', h: 26, w: 80, f: 11, onclick: () => rpc('os.open_url', { url: GPU_URL.nvidia }) }), Btn('AMD', { variant: 'ghost', h: 26, w: 70, f: 11, onclick: () => rpc('os.open_url', { url: GPU_URL.amd }) }),
      Btn('Intel', { variant: 'ghost', h: 26, w: 70, f: 11, onclick: () => rpc('os.open_url', { url: GPU_URL.intel }) }));
    const probRows = (list, title) => !list || !list.length ? null : h('div', { style: 'margin-top:8px' }, h('div', { class: 'f10 b ts', style: 'text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px', text: title }),
      ...list.slice(0, 8).map((d) => h('div', { class: 'f11 tp', style: 'white-space:normal', text: `${d.name || 'Unknown device'}  (Device Manager code ${d.code})` })),
      list.length > 8 ? h('div', { class: 'f10 ts', text: `…and ${list.length - 8} more` }) : null,
      Btn('Open Device Manager', { variant: 'ghost', h: 26, w: 180, f: 11, style: { marginTop: '4px' }, onclick: () => manualAction({ action: 'tool', tool: 'Device Manager' }) }));

    function search() {
      busy = true; body.textContent = ''; checks.length = 0; Object.keys(rows).forEach((k) => delete rows[k]);
      bar_.set(0.05); status.textContent = 'Asking Windows Update for driver updates… this can take a minute or two.'; logLine.textContent = '';
      recheck.disabled = true; closeBtn.disabled = false; syncGo(); go.disabled = true;
      rpc('health.driver_check').then((r) => { if (r && r.ok === false) drvUI && drvUI.check({ ok: false, error: r.error, updates: [], problems: [] }); }).catch((e) => drvUI && drvUI.check({ ok: false, error: e.message, updates: [], problems: [] }));
    }
    async function install() {
      const sel = picked(); if (!sel.length || busy) return;
      // two-step confirm inside this dialog (a separate confirm popup would replace it)
      if (!armed) { armed = true; go.textContent = `Yes, install ${sel.length}`; status.textContent = 'A restore point is created first (if Windows allows one). Screens may flicker and devices may reconnect for a moment; a restart may be needed to finish. Press the button again to start.'; return; }
      armed = false; checks.forEach(([, cb]) => cb.disable(true));
      busy = true; syncGo(); recheck.disabled = true; closeBtn.disabled = true; bar_.set(0.03); status.textContent = 'Installing…';
      sel.forEach((u) => note(u.id, 'waiting…', 'var(--text_disabled)'));
      const r = await rpc('health.driver_install', { ids: sel.map((u) => u.id) }).catch((e) => ({ ok: false, error: e.message }));
      if (!r || !r.ok) { busy = false; closeBtn.disabled = false; recheck.disabled = false; status.textContent = (r && r.error) || 'Could not start.'; syncGo(); }
    }
    let doneCount = 0, total = 0;
    drvUI = {
      check(d) {
        busy = false; recheck.disabled = false; bar_.set(0); body.textContent = '';
        if (!d.ok) { status.textContent = 'Could not ask Windows Update: ' + (d.error || 'unknown error'); body.append(h('div', { class: 'f11 ts', style: 'white-space:normal;padding:6px 0', text: 'Check that you are online and that the Windows Update service is not disabled, then press "Check again".' })); syncGo(); go.disabled = true; return; }
        const ups = d.updates || [];
        status.textContent = ups.length ? `${ups.length} driver update${ups.length === 1 ? '' : 's'} available from Windows Update.` + (d.admin ? '' : '  DWUT is not running as Administrator - installing needs it.') : 'Windows Update has no newer drivers for this PC.';
        ups.forEach((u) => {
          const cb = Check('', { sm: true, checked: true, themed: true, onchange: syncGo }); checks.push([u, cb]);
          const nt = h('div', { class: 'f10 ts', style: 'white-space:normal' }); rows[u.id] = { nt };
          body.append(h('div', { class: 'hl-step', style: 'cursor:pointer', onclick: (ev) => { if (!busy && !cb.contains(ev.target)) { cb.toggle(); syncGo(); } } }, cb,
            h('div', { class: 'col grow', style: 'min-width:0;gap:1px' }, h('div', { class: 'row', style: 'gap:6px' }, u.cls ? tag(String(u.cls).toUpperCase(), 'var(--accent)') : null, h('span', { class: 'f11 tp b', style: 'white-space:normal', text: u.title })),
              h('div', { class: 'f10 ts', style: 'white-space:normal', text: [u.mfr, u.date, mbs(u.size), u.reboot ? 'restart needed' : ''].filter(Boolean).join('  ·  ') }), nt)));
        });
        const pr = probRows(d.problems, 'Devices with a problem right now');
        if (pr) body.append(pr);
        body.append(h('div', { style: 'margin-top:8px' }, makerRow()));
        syncGo();
      },
      event(ev) {
        if (!ev) return;
        if (ev.t === 'start') { total = Math.max(total, picked().length); note(ev.id, 'working…', 'var(--accent)'); status.textContent = `Installing ${ev.n} / ${picked().length}  ·  ${String(ev.title || '').slice(0, 70)}`; bar_.set(Math.max(0.03, doneCount / Math.max(1, picked().length))); }
        else if (ev.t === 'stage') note(ev.id, ev.stage === 'download' ? 'downloading…' : 'installing…', 'var(--accent)');
        else if (ev.t === 'result') { doneCount++; bar_.set(doneCount / Math.max(1, picked().length)); note(ev.id, ev.ok ? `✓ ${ev.text}${ev.reboot ? ' - finishes after a restart' : ''}` : `! ${ev.text}: ${ev.detail || ''}`, ev.ok ? 'var(--success)' : 'var(--warning)'); }
      },
      log(d) { if (d && d.text) logLine.textContent = String(d.text).slice(0, 140); },
      done(res) {
        busy = false; closeBtn.disabled = false; recheck.disabled = false; bar_.set(1); logLine.textContent = '';
        const rs = res.results || [], good = rs.filter((r) => r.ok), bad = rs.filter((r) => !r.ok), ch = res.changed || [];
        status.textContent = res.error && !rs.length ? 'Stopped: ' + res.error : `${good.length} of ${rs.length} installed` + (bad.length ? `  ·  ${bad.length} failed` : '') + (ch.length ? `  ·  ${ch.length} device${ch.length === 1 ? '' : 's'} verified on a new driver` : '');
        const sum = h('div', { style: 'margin-top:10px' });
        if (res.error) sum.append(h('div', { class: 'hl-man' }, h('span', { class: 'f11 tp grow', style: 'white-space:normal', text: res.error })));
        sum.append(h('div', { class: 'f10 b ts', style: 'text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px', text: 'Verified result (driver versions compared before / after)' }));
        if (ch.length) ch.slice(0, 12).forEach((c) => sum.append(h('div', { class: 'f11 tp', style: 'white-space:normal', text: `✓ ${c.name}:  ${c.from}  →  ${c.to}` })));
        else sum.append(h('div', { class: 'f11 ts', style: 'white-space:normal', text: good.length ? (res.reboot ? 'No active driver changed yet - Windows installed them and they become active after a restart.' : 'No active driver version changed.') : 'Nothing was changed.' }));
        const pr = probRows(res.problems_after, 'Still reporting a problem after the update'); if (pr) sum.append(pr);
        if (res.restore_point === 'created') sum.append(h('div', { class: 'f10 ts', style: 'margin-top:6px', text: 'A restore point was created first - System Restore can undo these installs.' }));
        if (res.reboot) sum.append(h('div', { class: 'hl-man', style: 'margin-top:8px' }, h('span', { class: 'f11 tp grow', style: 'white-space:normal', text: 'A restart is needed to finish installing some drivers.' }), Btn('Restart now…', { variant: 'ghost', h: 26, w: 140, f: 11, onclick: () => manualAction({ action: 'restart' }) })));
        sum.append(h('div', { style: 'margin-top:8px' }, makerRow()));
        body.append(sum); body.scrollTop = body.scrollHeight;
        checks.length = 0; syncGo(); go.disabled = true;
        setStatus && setStatus(`Driver updates: ${good.length} installed${ch.length ? ', ' + ch.length + ' verified changed' : ''}`);
      },
    };
    Modal.show(h('div', { class: 'modal', style: 'width:min(860px,94%);max-width:none' }, h('h3', { text: 'Driver updates - Windows Update' }),
      h('div', { class: 'f11 ts', style: 'white-space:normal', text: 'Real installs through Windows Update: each driver is downloaded and installed, the result Windows reports is shown, and the driver versions on your devices are compared before and after.' }),
      bar_, status, logLine, body, foot));
    search();
  }

  async function openFix(scope) {
    if (running || fixing || !result) return;
    let plan;
    try { plan = await rpc('health.fix_plan', { category: scope.category, card: scope.card || null }); }
    catch (e) { return fail('Fix & Optimize', e.message); }
    if (plan.running) return notify('Fix & Optimize', 'A fix is already running - wait for it to finish.');
    const chosen = await pickPlan(scope, plan);
    if (!chosen) return;
    if (!chosen.ids.length) return notify('Fix & Optimize', 'Nothing was selected.');
    runFix(scope, plan, chosen.ids);
  }

  function pickPlan(scope, plan) {
    return Modal.custom((close) => {
      const checks = [];
      const body = h('div', { class: 'scroll', style: 'max-height:min(58vh,540px);margin-top:6px;padding-right:6px' });
      const count = h('span', { class: 'f11 ts' });
      const upd = () => { const n = checks.filter(([, cb]) => cb.checked).length; count.textContent = `${n} of ${checks.length} selected`; go.textContent = `Fix & Optimize (${n})`; };
      for (const g of plan.groups) {
        body.append(h('div', { class: 'row', style: 'margin:10px 0 4px;gap:8px' }, h('span', { class: 'f12 b c-acc', text: g.title }),
          g.problems ? tag(`${g.problems} PROBLEM${g.problems === 1 ? '' : 'S'} FOUND`, 'var(--warning)') : tag('NO PROBLEMS FOUND', 'var(--success)')));
        const grid = h('div', { class: 'hl-grid2' });
        for (const s of g.steps) {
          const cb = Check('', { sm: true, checked: s.checked, themed: true, onchange: upd }); checks.push([s, cb]);
          const [kt, kc] = KIND[s.kind] || KIND.fix;
          const row = h('div', { class: 'hl-step' + (s.needed ? ' need' : ''), style: 'cursor:pointer', onclick: (e) => { if (!cb.contains(e.target)) cb.toggle(); } }, cb,
            h('div', { class: 'col grow', style: 'gap:1px;min-width:0' }, h('div', { class: 'row', style: 'gap:6px' }, tag(kt, kc), h('span', { class: 'f11 tp b', text: s.label })),
              h('div', { class: 'f10 ts', style: 'white-space:normal', text: s.desc + (s.admin && !plan.admin ? '  (needs Administrator)' : '') }),
              s.needed ? h('div', { class: 'f10', style: 'color:var(--warning)', text: 'Fixes a problem the scan found' }) : null));
          grid.append(row);
        }
        body.append(grid);
        if (g.manual.length) {
          body.append(h('div', { class: 'f10 b ts', style: 'margin:8px 0 2px;text-transform:uppercase;letter-spacing:.5px', text: 'Needs you (hardware / BIOS - Windows cannot change these)' }));
          g.manual.forEach((m) => body.append(manualRow(m)));
        }
      }
      if (!plan.groups.length) body.append(h('div', { class: 'f12 ts', style: 'padding:10px 0', text: 'Nothing to do for this component.' }));
      const go = Btn('Fix & Optimize', { w: 170, bold: true, onclick: () => close({ ids: checks.filter(([, cb]) => cb.checked).map(([s]) => s.id) }) });
      const adminRow = plan.admin ? null : h('div', { class: 'hl-ban', style: 'margin:8px 0 0' }, h('span', { text: 'DWUT is not running as Administrator: steps that change Windows settings, services or drives will be skipped.' }), Btn('Restart as Admin', { h: 26, w: 140, f: 11, onclick: () => window.dwut?.relaunchAdmin?.() }));
      upd();
      return h('div', { class: 'modal', style: 'width:min(900px,94%);max-width:none' },
        h('h3', { text: `Fix & Optimize - ${scope.title}` }),
        h('div', { class: 'f11 ts', style: 'white-space:normal', text: 'Repairs what the scan found, then cleans up, optimizes and boosts. Nothing is closed, Xbox is never touched, and the VPN / firewall rules are left alone. Untick anything you do not want.' }),
        adminRow, body,
        h('div', { class: 'foot', style: 'align-items:center' }, count, h('div', { class: 'grow' }),
          Btn('Recommended', { variant: 'ghost', w: 120, onclick: () => { checks.forEach(([s, cb]) => cb.set(s.checked, true)); upd(); } }),
          Btn('Select all', { variant: 'ghost', w: 100, onclick: () => { checks.forEach(([, cb]) => cb.set(true, true)); upd(); } }),
          Btn('Cancel', { variant: 'ghost', w: 90, onclick: () => close(null) }), go));
    });
  }

  let fixUI = null;
  on('health.fix_progress', (d) => fixUI && fixUI.progress(d));
  on('health.fix_log', (d) => fixUI && fixUI.log(d));
  on('health.fix_done', (d) => fixUI && fixUI.done(d));

  async function runFix(scope, plan, ids) {
    const steps = []; plan.groups.forEach((g) => g.steps.forEach((s) => { if (ids.includes(s.id)) steps.push(Object.assign({ cat: g.category, ctitle: g.title }, s)); }));
    const rows = {}, list = h('div', { class: 'hl-grid2' });
    const bar_ = Progress({ height: 6 }), status = h('div', { class: 'f11 ts', style: 'margin:8px 0 2px;min-height:16px;font-style:italic', text: 'Starting…' });
    const logLine = h('div', { class: 'f10 ts mono ell', style: 'min-height:14px' });
    const sum = h('div'), manual = h('div'), foot = h('div', { class: 'foot' });
    const body = h('div', { class: 'scroll', style: 'max-height:min(54vh,500px);margin-top:8px;padding-right:6px' }, sum, list, manual);
    let lastCat = null;
    steps.forEach((s) => {
      if (plan.groups.length > 1 && s.cat !== lastCat) { list.append(h('div', { class: 'f12 b c-acc', style: 'grid-column:1/-1;margin:8px 0 2px', text: s.ctitle })); lastCat = s.cat; }
      const [kt, kc] = KIND[s.kind] || KIND.fix, ic = h('span', { class: 'ic' }), nt = h('div', { class: 'f10 ts', style: 'white-space:normal' });
      rows[s.id] = { ic, nt, row: h('div', { class: 'hl-step' }, ic, h('div', { class: 'col grow', style: 'min-width:0;gap:1px' }, h('div', { class: 'row', style: 'gap:6px' }, tag(kt, kc), h('span', { class: 'f11 tp b', text: s.label })), nt)) };
      list.append(rows[s.id].row);
    });
    const setRow = (id, st, note) => { const r = rows[id]; if (!r) return; const [c, k] = STATE[st] || STATE.info; r.ic.style.background = k; r.ic.style.boxShadow = st === 'run' ? `0 0 10px ${k}` : ''; r.nt.textContent = note || ''; r.nt.style.color = st === 'warn' ? 'var(--warning)' : ''; };
    const closeBtn = Btn('Close', { w: 100, onclick: () => Modal.close() }); closeBtn.disabled = true; foot.append(closeBtn);
    Modal.show(h('div', { class: 'modal', style: 'width:min(900px,94%);max-width:none' }, h('h3', { text: `Fixing & optimizing - ${scope.title}` }), bar_, status, logLine, body, foot));
    fixing = true; applyBusy(); bar_.set(0.02);

    fixUI = {
      progress(d) {
        if (!d) return;
        if (d.state === 'start') { setRow(d.id, 'run', 'working…'); status.textContent = `${d.idx} / ${d.total}  ·  ${d.label}`; bar_.set(Math.max(0.02, (d.idx - 1) / Math.max(1, d.total))); return; }
        setRow(d.id, d.state, d.note); bar_.set(d.idx / Math.max(1, d.total));
      },
      log(d) { if (d && d.text) logLine.textContent = String(d.text).slice(0, 140); },
      done(d) {
        fixUI = null; fixing = false;
        if (d.result) { result = d.result; renderDone(); }
        bar_.set(1); logLine.textContent = '';
        const ok = (d.results || []).filter((r) => r.state === 'ok'), bad = (d.results || []).filter((r) => r.state === 'warn');
        const cnt = (k) => ok.filter((r) => r.kind === k).length;
        const parts = [['fixed', cnt('fix')], ['cleaned', cnt('cleanup')], ['optimized', cnt('optimize')], ['boosted', cnt('boost')]].filter((p) => p[1]).map((p) => `${p[1]} ${p[0]}`);
        status.textContent = d.error ? 'Stopped: ' + d.error : (parts.length ? parts.join('  ·  ') : 'Nothing needed changing') + (bad.length ? `  ·  ${bad.length} could not be completed` : '');
        // per-component "last run" text + score change
        const cats = [...new Set((d.results || []).map((r) => r.cat))];
        const delta = (k) => { const a = d.before && d.before[k], b = d.after && d.after[k]; return a != null && b != null ? `${Math.round(a)} → ${Math.round(b)}` : null; };
        cats.forEach((k) => {
          const rs = (d.results || []).filter((r) => r.cat === k && r.state === 'ok');
          const txt = `Last run: ${rs.length} step${rs.length === 1 ? '' : 's'} done` + (delta(k) ? `  ·  score ${delta(k)}` : '');
          (result ? result.cards.filter((c) => c.category === k && (!scope.card || c.key === scope.card)) : []).forEach((c) => { lastRun[c.key] = txt; });
        });
        if (d.result) { for (const [k] of CATS) renderCategory(k); }
        // summary box
        sum.append(h('div', { class: 'row', style: 'gap:8px;flex-wrap:wrap;margin-bottom:6px' },
          d.overall_after != null ? tag(`OVERALL ${d.overall_before != null ? Math.round(d.overall_before) + ' → ' : ''}${Math.round(d.overall_after)}`, col(d.overall_after)) : null,
          ...cats.filter(delta).map((k) => tag(`${(CATS.find((c) => c[0] === k) || [k, k])[1].toUpperCase()} ${delta(k)}`, col(d.after[k])))));
        if (d.restart) manual.append(h('div', { class: 'hl-man' }, h('span', { class: 'f11 tp grow', style: 'white-space:normal', text: 'A restart finishes some of these changes (memory compression, GPU scheduling, file-system repair, network catalog).' }),
          Btn('Restart now…', { variant: 'ghost', h: 26, w: 140, f: 11, onclick: () => manualAction({ action: 'restart' }) })));
        const mans = (d.manual || []).filter((m, i, a) => a.findIndex((x) => x.text === m.text) === i);
        if (mans.length) { manual.append(h('div', { class: 'f10 b ts', style: 'margin:8px 0 2px;text-transform:uppercase;letter-spacing:.5px', text: 'Still needs you (Windows cannot change these)' })); mans.forEach((m) => manual.append(manualRow(m))); }
        closeBtn.disabled = false;
        setStatus && setStatus('Fix & Optimize finished: ' + (parts.join(', ') || 'nothing needed changing'));
      },
    };
    try {
      const r = await rpc('health.fix', { category: scope.category, card: scope.card || null, only: ids });
      if (!r.ok) { fixUI = null; fixing = false; applyBusy(); closeBtn.disabled = false; status.textContent = r.error || 'Could not start.'; }
    } catch (e) { fixUI = null; fixing = false; applyBusy(); closeBtn.disabled = false; status.textContent = 'Could not start: ' + e.message; }
  }

  // ── report ──────────────────────────────────────────────────────────────────────────────────────────────────
  function copyReport() {
    if (!result) return;
    const L = [`DWUT System Health report  -  ${result.finished}`, `Overall: ${result.overall.score == null ? 'not enough data' : Math.round(result.overall.score) + '/100 (' + result.overall.label + ')'}`, ''];
    if ((result.inventory || []).length) {
      L.push('== Your hardware ==');
      result.inventory.forEach((r) => L.push(`${r.group}: ${[r.brand, r.model].filter(Boolean).join(' ')}${r.detail ? '  (' + r.detail + ')' : ''}`));
      L.push('');
    }
    for (const [k, title] of CATS) {
      const cards = result.cards.filter((c) => c.category === k);
      if (!cards.length) continue;
      L.push(`== ${title} ==`);
      cards.forEach((c) => {
        L.push(`${c.name}${c.subtitle ? '  (' + c.subtitle + ')' : ''}  -  ${c.score == null ? c.label : Math.round(c.score) + '/100 ' + c.label}`);
        if (c.brand) L.push(`   Brand: ${c.brand}`);
        if (c.model) L.push(`   Model: ${c.model}`);
        (c.identity || []).forEach((i) => L.push(`   ${i.label}: ${i.value}${i.how ? ' (' + i.how + ')' : ''}`));
        c.metrics.forEach((m) => L.push(`   ${m.label}: ${m.value}`));
        c.findings.filter((f) => f.level !== 'ok').forEach((f) => L.push(`   [${f.level.toUpperCase()}] ${f.text}`));
      });
      L.push('');
    }
    window.dwut.copy(L.join('\n'));
    setStatus && setStatus('Health report copied to the clipboard');
  }

  // first open: show the last scan if there is one; otherwise wait for the Scan button (no scan starts by itself)
  root.__load = async () => {
    for (const [k] of CATS) byCat[k] = undefined;
    tiles.style.display = 'none'; tiles.previousSibling.style.display = 'none'; attLbl.style.display = 'none'; attBox.style.display = 'none';
    applyBusy();
    try {
      const r = await rpc('health.last');
      if (r.running) { running = true; scanId = r.running; scanBtn.disabled = true; reset(); openLoader(); return; }
      if (r.result) { scanId = r.result.scan; result = r.result; revealed = true; idleBox.style.display = 'none'; tiles.style.display = ''; tiles.previousSibling.style.display = ''; renderDone(); return; }
    } catch { /* no earlier scan */ }
    idleBox.style.display = '';
  };
  return root;
};
