// Copyright © 2026 Darko / Darko.Dev
'use strict';
Pages.register('bios', () => {
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (m) => { status.textContent = m; };
  const content = h('div', { style: 'flex:1;min-height:0;margin:0 0 12px;position:relative' });
  const tabs = {};
  const state = { scan: null, board: null, assist: null };
    const col = { ok: 'var(--success)', warn: 'var(--warning)', bad: 'var(--error)', na: 'var(--text_disabled)' };

  // ── status model: each tile = {t, v, s, d, fix} ──
  function tiles() {
    const S = state.scan, B = state.board;
    if (!S) return [];
    const yn = (x, on, off) => (x === true ? [on, 'ok'] : x === false ? [off, 'warn'] : ['Unknown', 'na']);
    const x = S.xmp, r = S.rebar, f = (B && B.firmware) || {}, bi = (B && B.bios) || {};
    const xv = x.state === 'on' ? ['ON · ' + x.running + ' MT/s', 'ok'] : x.state === 'off' ? ['OFF · ' + x.running + '/' + x.rated, 'bad'] : x.state === 'jedec' ? ['Base speed · ' + x.running, 'warn'] : ['Unknown', 'na'];
    const rv = r.state === 'on' ? ['ON', 'ok'] : r.state === 'off' ? ['OFF', 'bad'] : ['Check manually', 'na'];
    const sb = yn(S.secure_boot, 'ON', 'OFF');
    const tp = S.tpm ? (S.tpm.enabled && S.tpm.active ? ['TPM ' + (S.tpm.version || '2.0') + ' ready', 'ok'] : ['Present · off', 'warn']) : ['Not found', 'bad'];
    const vt = yn(S.cpu.virt_firmware, 'ON', 'OFF');
    const age = bi.age_days;
    const ag = age == null ? ['Unknown', 'na'] : [age > 730 ? Math.round(age / 365 * 10) / 10 + ' yrs old' : age > 365 ? '1+ yr old' : 'Recent', age > 730 ? 'warn' : 'ok'];
    return [
      { t: 'XMP / EXPO', v: xv[0], s: xv[1], d: x.detail, fix: 'Memory' },
      { t: 'Resizable BAR', v: rv[0], s: rv[1], d: r.detail + (r.method ? '  (' + r.method + ')' : ''), fix: 'GPU & PCIe' },
      { t: 'Secure Boot', v: sb[0], s: sb[1], d: 'Required by Windows 11 and several anti-cheats.', fix: 'Security & Boot' },
      { t: 'TPM', v: tp[0], s: tp[1], d: 'Windows 11 and Vanguard need TPM 2.0 (fTPM on AMD, PTT on Intel).', fix: 'Security & Boot' },
      { t: 'Boot mode', v: f.mode || 'Unknown', s: f.mode === 'UEFI' ? 'ok' : f.mode ? 'bad' : 'na', d: 'UEFI is needed for Secure Boot, ReBAR and Windows 11.', fix: 'Security & Boot' },
      { t: 'Virtualization', v: vt[0], s: vt[1], d: 'Intel VT-x / AMD SVM. Needed for WSL2, VMs and Android emulators.', fix: 'Virtualization' },
      { t: 'BIOS age', v: ag[0], s: ag[1], d: bi.version ? `Version ${bi.version}${bi.release_date ? ', released ' + bi.release_date : ''}.` : 'Could not read the BIOS date.', fix: 'Updates & Recovery' },
      { t: 'VBS / Core isolation', v: S.vbs.hvci ? 'Memory integrity ON' : S.vbs.status === 2 ? 'VBS ON' : 'Off', s: S.vbs.status === 2 || S.vbs.hvci ? 'warn' : 'ok', d: 'Can cost a few % FPS in games. Toggle in the Windows tab.', fix: 'Virtualization' },
      { t: 'GPU scheduling (HAGS)', v: S.hags === true ? 'ON' : S.hags === false ? 'OFF' : 'Unknown', s: S.hags === true ? 'ok' : S.hags === false ? 'warn' : 'na', d: 'Hardware-accelerated GPU scheduling. Helps on recent GPUs.', fix: 'GPU & PCIe' },
      { t: 'Fast Startup', v: S.fast_startup === true ? 'ON' : S.fast_startup === false ? 'OFF' : 'Unknown', s: S.fast_startup ? 'warn' : 'ok', d: 'A hybrid shutdown. Can stop BIOS changes and driver updates from applying cleanly.', fix: 'Security & Boot' },
      { t: 'HPET / timer', v: S.hpet_forced === true ? 'Forced ON' : S.hpet_forced === false ? 'Default' : 'Default', s: S.hpet_forced ? 'warn' : 'ok', d: 'A forced platform clock can add latency. Default is best for most.', fix: 'Onboard Devices' },
      { t: 'Game Mode', v: S.game_mode === true ? 'ON' : S.game_mode === false ? 'OFF' : 'Default', s: S.game_mode === false ? 'warn' : 'ok', d: 'Windows Game Mode prioritises the foreground game.', fix: 'CPU & Power' },
    ];
  }

  // ── Overview ──
  function buildOverview() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const grid = h('div', { class: 'bios-grid' });
    const head = h('div', { class: 'bios-sys' });
    const scanBtn = Btn('Scan Firmware', { h: 30, onclick: () => load(true) });
    const render = () => {
      grid.textContent = '';
      const B = state.board || {}, sys = B.system || {}, bd = B.board || {}, bi = B.bios || {};
      head.textContent = '';
      head.append(h('div', { class: 'col grow', style: 'min-width:0' },
        h('span', { class: 'f13 b tp ell', text: [bd.manufacturer || sys.manufacturer, bd.product || sys.model].filter(Boolean).join(' ') || 'Motherboard not identified' }),
        h('span', { class: 'f10 ts ell', text: `BIOS ${bi.vendor || ''} ${bi.version || '?'} · ${bi.release_date || 'date unknown'} · ${((B.firmware || {}).mode) || '?'}` })),
        Btn('Restart into BIOS', { h: 30, variant: 'ghost', tip: 'Restarts in 15 seconds and opens your firmware setup screen.', onclick: restartUefi }), scanBtn);
      const T = tiles();
      if (!T.length) return grid.append(h('div', { class: 'f11 ts', text: 'Scanning your firmware…', style: 'padding:24px' }));
      T.forEach((t, i) => {
        const tile = h('button', { class: 'bios-tile', style: `--i:${i};--sc:${col[t.s]}` },
          h('i', { class: 'bt-dot' }), h('span', { class: 'bt-t', text: t.t }), h('b', { class: 'bt-v', text: t.v }), h('small', { class: 'bt-d', text: t.d }));
        tile.onclick = () => explain(t);
        grid.append(tile);
      });
    };
    const explain = (t) => Modal.custom((close) => h('div', { class: 'modal' },
      h('h3', { text: t.t + ' — ' + t.v, class: 'b', style: `color:${col[t.s]}` }), h('div', { class: 'body f12', text: t.d }),
      h('div', { class: 'foot' }, Btn('Close', { variant: 'ghost', w: 90, onclick: () => close(true) }), Btn('Open in BIOS settings', { w: 170, onclick: () => { close(true); showGuide(t.fix); } }))));
    async function load(force) {
      if (state.scan && !force) return render();
      setStatus('Scanning firmware…'); state.scan = null; render();
      try {
        const [s, b] = await Promise.all([rpc('bios.scan'), rpc('health.motherboard')]);
        state.scan = s; state.board = (b && b.board) || null; setStatus('Scan complete'); render();
      } catch (e) { setStatus('Scan failed: ' + e.message); }
    }
    f.append(head, grid);
    f.__load = () => load(false); return f;
  }

  async function restartUefi() {
    if (await Modal.confirm('Restart into the BIOS / UEFI settings?', 'The PC restarts in 15 seconds and opens its firmware settings. Save your work first.', { yes: 'Restart', no: 'Cancel' })) {
      try { await rpc('bios.restart_uefi', { seconds: 15 }); setStatus('Restarting in 15 s - cancel from the button on this page'); } catch (e) { setStatus('Could not restart: ' + e.message); }
    }
  }

  // ── Update assist ──
  function buildAssist() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const body = h('div', { class: 'upd-grid' });
    const render = () => {
      body.textContent = '';
      const A = state.assist; if (!A) return body.append(h('div', { class: 'f11 ts', text: 'Detecting your board…', style: 'padding:24px' }));
      const verdict = { old: ['Update recommended', 'warn'], aging: ['Worth checking', 'warn'], recent: ['Up to date-ish', 'ok'], unknown: ['Age unknown', 'na'] }[A.age_verdict];
      body.append(
        Card([h('div', { class: 'col', style: 'padding:14px 16px;gap:6px' },
          h('span', { class: 'f10 b ts', text: 'YOUR BIOS' }), h('span', { class: 'f16 b tp', text: A.current.version || 'Unknown version' }),
          h('span', { class: 'f11 ts', text: (A.current.date || 'unknown date') + (A.current.age_days != null ? ` · ${Math.round(A.current.age_days / 30)} months ago` : '') }),
          h('span', { class: 'f12 b', text: verdict[0], style: `color:${col[verdict[1]]};margin-top:6px` }),
          h('span', { class: 'f10 ts', text: `Board / PC: ${A.model || 'not identified'}` }),
          h('div', { class: 'row', style: 'gap:6px;margin-top:10px;flex-wrap:wrap' },
            A.support_url ? Btn('Open ' + (A.vendor || 'maker') + ' support', { h: 30, onclick: () => rpc('os.open_url', { url: A.support_url }) }) : null,
            Btn('Search my model', { h: 30, variant: 'ghost', onclick: () => rpc('os.open_url', { url: A.search_url }) }),
            Btn('Restart into BIOS', { h: 30, variant: 'ghost', onclick: restartUefi })))], 'col', { margin: 0 }),
        Card([h('div', { class: 'col', style: 'padding:14px 16px;gap:6px' }, h('span', { class: 'f10 b ts', text: 'HOW TO FLASH ON YOUR BOARD' }), h('span', { class: 'f11 tp', text: A.flash_note, style: 'white-space:normal' }),
          h('span', { class: 'f10 b ts', text: 'DOWNLOAD CHECKLIST', style: 'margin-top:8px' }),
          h('span', { class: 'f10 ts', style: 'white-space:normal', text: 'Match your exact model AND revision (printed on the board). Read the changelog. Get the file from the maker only.' }))], 'col', { margin: 0 }),
        Card([h('div', { class: 'col', style: 'padding:14px 16px;gap:5px' }, h('span', { class: 'f10 b ts', text: 'BEFORE YOU FLASH' }),
          ...A.safety.map((s, i) => h('span', { class: 'f11 tp', style: 'white-space:normal', text: (i + 1) + '. ' + s })))], 'col', { margin: 0, gridColumn: 'span 2' }));
    };
    async function load() {
      render();
      try {
        if (!state.board) { const b = await rpc('health.motherboard'); state.board = (b && b.board) || null; }
        state.assist = await rpc('bios.assist', { info: state.board || {} }); render();
      } catch (e) { setStatus('Could not build update guide: ' + e.message); }
    }
    f.append(body); f.__load = load; return f;
  }

  // ── BIOS settings (pick what you want, get a personalised plan) ──
  function buildGuide() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const RISK = { s: ['SAFE', 'var(--success)'], c: ['CAUTION', 'var(--warning)'], x: ['ADVANCED', 'var(--accent)'] };
    const key = (ci, r) => BIOS_CATS[ci][0] + '|' + r[0];
    const sel = (() => { try { return new Set(JSON.parse(localStorage.getItem('dwut_bios_sel') || '[]')); } catch (e) { return new Set(); } })();
    const persist = () => { try { localStorage.setItem('dwut_bios_sel', JSON.stringify([...sel])); } catch (e) { /* ignore */ } };
    let cur = 0, q = '';
    const search = Entry({ placeholder: 'Search every BIOS setting…' }); search.style.cssText += ';width:170px;flex:none';
    const info = h('div', { class: 'bs-info' });
    const catList = h('div', { class: 'bs-cats' });
    const head = h('div', { class: 'bs-head' });
    const opts = h('div', { class: 'bs-opts' });
    const total = BIOS_CATS.reduce((a, c) => a + c[2].length, 0);

    const rowsNow = () => q ? BIOS_CATS.flatMap((c, ci) => c[2].filter((r) => (r[0] + ' ' + r[1] + ' ' + r[2] + ' ' + c[0]).toLowerCase().includes(q)).map((r) => [ci, r])) : BIOS_CATS[cur][2].map((r) => [cur, r]);
    const setMany = (pairs, on) => { pairs.forEach(([ci, r]) => { on ? sel.add(key(ci, r)) : sel.delete(key(ci, r)); }); persist(); draw(); };
    const detail = (ci, r) => Modal.custom((close) => h('div', { class: 'modal', style: 'width:540px' }, h('h3', { text: r[0], class: 'b' }),
      h('div', { class: 'body f12', style: 'white-space:normal' }, h('div', { class: 'b', text: 'Recommended: ' + r[1], style: 'color:var(--accent);margin-bottom:6px' }), h('div', { text: r[2] }),
        h('div', { class: 'f11 ts', text: 'Where: ' + r[3] + (r[4] === 'a' ? '  ·  AMD boards' : r[4] === 'i' ? '  ·  Intel boards' : ''), style: 'margin-top:8px' }),
        h('div', { class: 'f10 ts', text: 'Menu names differ per maker and BIOS version - use the BIOS search key (F9 or Ctrl+F) if you cannot find it.', style: 'margin-top:6px' })),
      h('div', { class: 'foot' }, Btn('Close', { w: 90, onclick: () => close(true) }))));

    function draw() {
      // categories
      catList.textContent = '';
      BIOS_CATS.forEach((c, ci) => {
        const n = c[2].filter((r) => sel.has(key(ci, r))).length;
        const sw = Switch({ checked: n === c[2].length, onchange: (v) => setMany(c[2].map((r) => [ci, r]), v) });
        sw.addEventListener('click', (e) => e.stopPropagation());
        const row = h('div', { class: 'bs-cat' + (!q && ci === cur ? ' on' : ''), style: `--i:${ci}`, onclick: () => { cur = ci; q = ''; search.value = ''; draw(); } }, sw,
          h('div', { class: 'col', style: 'min-width:0;flex:1' }, h('b', { text: c[0] }), h('small', { class: n ? 'will' : '', text: n ? `Will modify · ${n}/${c[2].length}` : `${c[2].length} settings` })));
        catList.append(row);
      });
      // header
      const rows = rowsNow();
      head.textContent = '';
      head.append(h('div', { class: 'col grow', style: 'min-width:0' }, h('span', { class: 'f14 b tp', text: q ? `Search results (${rows.length})` : BIOS_CATS[cur][0] }), h('span', { class: 'f10 ts', text: q ? 'Matches across every category.' : BIOS_CATS[cur][1] })),
        Btn('Check All', { variant: 'ghost', h: 26, onclick: () => setMany(rows, true) }), Btn('Uncheck All', { variant: 'ghost', h: 26, onclick: () => setMany(rows, false) }));
      opts.textContent = '';
      if (!rows.length) opts.append(h('div', { class: 'f11 ts', text: 'No matching setting.', style: 'padding:20px' }));
      rows.forEach(([ci, r], i) => {
        const [lab, c] = RISK[r[5]];
        const sw = Switch({ checked: sel.has(key(ci, r)), onchange: (v) => { v ? sel.add(key(ci, r)) : sel.delete(key(ci, r)); persist(); drawCats(); } });
        opts.append(h('div', { class: 'bs-opt', style: `--i:${i};--rc:${c}` }, sw, h('b', { class: 'bs-n', text: r[0] }), h('span', { class: 'bs-v', text: r[1] }), h('span', { class: 'bs-r', text: lab }),
          h('button', { class: 'bs-i', text: 'i', title: 'What is this?', onclick: () => detail(ci, r) })));
      });
      drawSum();
    }
    const drawCats = () => { const s0 = opts.scrollTop; draw(); opts.scrollTop = s0; };
    const drawSum = () => { sum.textContent = `${sel.size} of ${total} selected`; };
    const sum = h('span', { class: 'f10 ts', style: 'margin-right:6px' });

    const allPairs = () => BIOS_CATS.flatMap((c, ci) => c[2].map((r) => [ci, r]));
    async function applyPlan() {
      if (!sel.size) return setStatus('Tick at least one BIOS setting first.');
      const lines = ['DWUT BIOS PLAN', '=============', info.textContent.replace(/\s+/g, ' '), 'Generated ' + new Date().toLocaleString(), '',
        'Enter your BIOS (Delete / F2 on boot, or use Restart into BIOS in DWUT) and set these. Menu names vary by maker; press F9 / Ctrl+F in the BIOS to search.', ''];
      BIOS_CATS.forEach((c, ci) => { const rs = c[2].filter((r) => sel.has(key(ci, r))); if (!rs.length) return; lines.push('## ' + c[0]); rs.forEach((r) => lines.push(`[ ] ${r[0]}  ->  ${r[1]}\n      Where: ${r[3]}${r[5] === 'x' ? '\n      NOTE: advanced / overclocking - test for stability.' : ''}`)); lines.push(''); });
      let path = '';
      try { const r = await rpc('bios.export_plan', { text: lines.join('\n') }); path = r && r.path; } catch (e) { /* ignore */ }
      const go = await Modal.confirm('BIOS plan ready', `${sel.size} settings were put into a step-by-step checklist${path ? ' saved to:\n' + path : ''}.\n\nBIOS settings can only be changed from inside the BIOS itself - no Windows program can safely do it for you. Restart into the BIOS now and tick them off?`, { yes: 'Restart into BIOS', no: 'Not now' });
      if (go) restartUefi();
    }
    const bar = h('div', { class: 'row bs-bar', style: 'gap:6px;margin-bottom:6px;flex:none' }, search,
      Btn('Default', { variant: 'ghost', h: 28, tip: 'Select every SAFE setting.', onclick: () => { sel.clear(); allPairs().filter(([, r]) => r[5] === 's').forEach(([ci, r]) => sel.add(key(ci, r))); persist(); draw(); } }),
      Btn('Check All', { variant: 'ghost', h: 28, onclick: () => setMany(allPairs(), true) }), Btn('Uncheck All', { variant: 'ghost', h: 28, onclick: () => setMany(allPairs(), false) }),
      h('span', { class: 'grow' }), sum, Btn('Clear all', { variant: 'ghost', h: 28, tip: 'Restore defaults: clear every selection.', onclick: () => setMany(allPairs(), false) }), Btn('Apply Settings', { h: 28, tip: 'Build your personal BIOS checklist and open the BIOS.', onclick: applyPlan }));
    search.addEventListener('input', () => { q = search.value.trim().toLowerCase(); draw(); });
    const B = state.board || {};
    const fillInfo = () => { const bd = B.board || {}, sy = B.system || {}; info.textContent = `Motherboard: ${[bd.manufacturer || sy.manufacturer, bd.product || sy.model].filter(Boolean).join(' ') || 'not detected'}   ·   CPU: ${(state.scan && state.scan.cpu && state.scan.cpu.name) || 'not detected'}   ·   BIOS ${((B.bios) || {}).version || '?'}`; };
    fillInfo();
    f.append(bar, info, h('div', { class: 'bs-wrap' }, catList, h('div', { class: 'bs-pane' }, head, opts)));
    f.__show = (name) => { const i = BIOS_CATS.findIndex((c) => c[0] === name); if (i >= 0) { cur = i; q = ''; search.value = ''; draw(); } };
    f.__load = () => { fillInfo(); };
    draw(); return f;
  }

  // ── Windows-side tweaks ──
  const WT = [
    ['hags_on', 'Hardware GPU scheduling', 'Let the GPU manage its own memory scheduling. Needs a recent driver and GPU.', 'Restart required'],
    ['fast_startup_off', 'Turn Fast Startup off', 'Makes Shut down a real shutdown so BIOS/driver changes apply and USB resets.', 'Restart required'],
    ['game_mode_on', 'Game Mode on', 'Prioritises the foreground game and pauses driver installs while you play.', 'Instant'],
    ['hpet_off', 'Use default system timer', 'Removes a forced HPET timer (useplatformclock). Usually lowers latency.', 'Restart · admin'],
    ['dyntick_off', 'Disable dynamic tick', 'Constant timer ticks; can lower input jitter, slightly raises idle power.', 'Restart · admin'],
  ];
  function buildWin() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const grid = h('div', { class: 'act-grid', style: 'align-content:start' });
    WT.forEach(([id, name, desc, note]) => {
      const out = h('span', { class: 'f10 ts', text: note });
      grid.append(Card([h('div', { class: 'row', style: 'padding:10px 12px;gap:10px' },
        h('div', { class: 'col grow', style: 'min-width:0' }, h('span', { class: 'f12 b tp', text: name }), h('span', { class: 'f10 ts', text: desc, style: 'white-space:normal' }), out),
        Btn('Apply', { h: 28, w: 70, onclick: () => run(false) }), Btn('Revert', { h: 28, w: 70, variant: 'ghost', onclick: () => run(true) }))]));
      async function run(rev) {
        try { const r = await rpc('bios.tweak', { id, revert: rev }); out.textContent = (r.ok ? '✔ ' : '✖ ') + r.note; out.style.color = r.ok ? 'var(--success)' : 'var(--error)'; setStatus(name + (rev ? ' reverted' : ' applied')); state.scan = null; }
        catch (e) { out.textContent = '✖ ' + e.message; out.style.color = 'var(--error)'; }
      }
    });
    f.append(h('div', { class: 'f10 ts', text: 'Windows-side settings that interact with your firmware. Every one can be reverted. Some need administrator rights and a restart.', style: 'margin-bottom:8px' }), grid);
    return f;
  }

  const builders = { Detect: buildOverview, 'Update Assist': buildAssist, 'BIOS Settings': buildGuide, 'Windows Side': buildWin };
  function switchTab(name) {
    for (const [n, t] of Object.entries(tabs)) { t.btn.classList.toggle('active', n === name); if (t.frame) t.frame.style.display = n === name ? '' : 'none'; }
    const t = tabs[name];
    if (!t.frame) { t.frame = builders[name](); content.append(t.frame); if (t.frame.__load) t.frame.__load(); }
    t.frame.style.display = '';
  }
  function showGuide(cat) { switchTab('BIOS Settings'); if (tabs['BIOS Settings'].frame.__show) tabs['BIOS Settings'].frame.__show(cat); }
  const tabBar = h('div', { class: 'row', style: 'padding:0 20px' });
  for (const n of Object.keys(builders)) { const btn = Btn(n, { variant: 'plain', cls: 'tab f12', onclick: () => switchTab(n) }); tabs[n] = { btn, frame: null }; tabBar.append(h('span', { style: 'margin:0 2px' }, btn)); }
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' }, h('div', { class: 'title-row' }, h('h1', { text: 'BIOS & Firmware' }), h('div', { class: 'grow' }), status), h('div', { class: 'rail-body' }, tabBar, h('div', { class: 'rail-main' }, content)));
  FX.rail(tabBar, { Detect: 'XMP · ReBAR · Secure Boot', 'Update Assist': 'Find & flash a new BIOS', 'BIOS Settings': `${BIOS_CATS.reduce((a, c) => a + c[2].length, 0)} settings · build your plan`, 'Windows Side': 'Firmware-linked tweaks' });
  switchTab('Detect');
  return { el, openTab: (n) => { if (tabs[n]) switchTab(n); } };
});
