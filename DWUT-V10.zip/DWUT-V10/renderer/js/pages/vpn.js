// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* VPN page - DWUTVPN: free, no account. Connect + protection options + optional imported locations. */
Pages.register('vpn', () => {
  if (!document.getElementById('vp-style')) {
    document.head.append(h('style', { id: 'vp-style', text: `
      .vp-grid{display:grid;grid-template-columns:minmax(300px,360px) minmax(0,1fr);gap:14px;align-items:start}
      @media (max-width:980px){.vp-grid{grid-template-columns:minmax(0,1fr)}}
      .vp-panel{padding:12px;display:flex;flex-direction:column;gap:9px;min-width:0}
      .vp-h{font-size:calc(11px*var(--fs));font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--text_secondary)}
      /* VPN slime badge */
      .vp-slime-wrap{display:flex;flex-direction:column;align-items:center;margin:4px 0 6px;position:relative;min-height:130px;cursor:default}
      .vp-slime-wrap .slime{--sz:110px;transition:filter .4s;filter:grayscale(1) brightness(.6)}
      .vp-slime-wrap.vp-on-st .slime{filter:drop-shadow(0 0 16px var(--accent))}
      .vp-slime-wrap.vp-wait-st .slime{filter:grayscale(.5) brightness(.7);animation:slMini .8s ease-in-out infinite}
      .vp-slime-state{font:800 calc(10px*var(--fs)) var(--hud,Consolas,monospace);letter-spacing:.28em;color:var(--text_disabled);text-transform:uppercase;margin-top:4px;transition:color .3s;text-shadow:none}
      .vp-on-st .vp-slime-state{color:var(--accent);text-shadow:0 0 14px var(--accent)}
      .vp-kv{display:grid;grid-template-columns:auto 1fr;gap:7px 14px;font-size:calc(12px*var(--fs))}
      .vp-kv span:nth-child(odd){color:var(--text_secondary)}
      .vp-kv span:nth-child(even){color:var(--text_primary);font-weight:600;text-align:right;overflow-wrap:anywhere}
      .vp-opt{display:flex;align-items:center;gap:12px;padding:11px 13px;border-radius:8px;background:var(--bg_input);min-width:0}
      .vp-opt .t{flex:1;min-width:0}.vp-opt .t b{display:block;font-size:calc(12px*var(--fs))}
      .vp-opt .t span{display:block;font-size:calc(10.5px*var(--fs));color:var(--text_secondary);margin-top:2px;line-height:1.35}
      .vp-opts{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:8px}
      .vp-note{font-size:calc(11px*var(--fs));color:var(--text_secondary);line-height:1.45;border-left:2px solid var(--accent);padding:2px 0 2px 10px}
      .vp-dirty{display:none;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;background:var(--accent_subtle);border:1px solid var(--accent_dim);font-size:calc(11.5px*var(--fs))}
      .vp-dirty.show{display:flex}
    ` }));
  }


  // ── status badge: slime that turns grey (off) / glowing accent (on) ──
  const badgeWrap = h('div', { class: 'vp-slime-wrap vp-off-st', style: 'position:relative' });
  const badge = badgeWrap;   // alias so the rest of the file still references badge for class toggling
  const slimeLbl = h('div', { class: 'vp-slime-state', text: 'OFF' });
  let vpnSlime = null;
  if (window.Slime) {
    vpnSlime = Slime.create({ size: 110 });
    vpnSlime.el.style.margin = '8px auto 0';
    vpnSlime.el.style.display = 'block';
    badgeWrap.append(vpnSlime.el, slimeLbl);
  } else {
    // fallback: sprite image
    const img = h('div', { style: 'width:110px;height:76px;margin:8px auto 0;background:var(--slime-sprite) center/contain no-repeat;filter:grayscale(1) brightness(.5)' });
    badgeWrap.append(img, slimeLbl);
  }

  const setBadge = (mode) => {                   // 'off' | 'wait' | 'on'
    badgeWrap.className = 'vp-slime-wrap vp-' + (mode === 'on' ? 'on' : mode === 'wait' ? 'wait' : 'off') + '-st';
    slimeLbl.textContent = mode === 'on' ? 'ON' : mode === 'wait' ? '...' : 'OFF';
    if (vpnSlime) {
      if (mode === 'on') { vpnSlime.kick(3); setTimeout(() => vpnSlime.kick(2), 300); }
      else if (mode === 'wait') { vpnSlime.kick(-2); }
    }
  };
  setBadge('off');

  let S = { on: false, busy: false, status: 'off', opts: {} };
  let dirty = false, tick = null;

  const title = h('div', { class: 'f16 b', style: 'text-align:center' });
  const sub = h('div', { class: 'f11 ts', style: 'text-align:center;min-height:30px;overflow-wrap:anywhere' });
  const bar = Progress({ height: 4 });
  const msg = h('div', { class: 'f10 ts', style: 'text-align:center;min-height:14px' });
  const big = Btn('Connect', { h: 40, f: 13, bold: true, onclick: () => toggleConn() });
  const ipBtn = Btn('Check my IP', { variant: 'ghost', h: 32, f: 11, onclick: checkIp });
  const chgBtn = Btn('Change server', { variant: 'ghost', h: 32, f: 11, tip: 'Switches to another connection point right away (servers that do not answer are skipped within seconds).\nWith your own locations added, it moves to the next location instead.', onclick: () => changeServer() });
  big.style.width = ipBtn.style.width = chgBtn.style.width = '100%';
  const kv = {};
  const kvBox = h('div', { class: 'vp-kv' });
  [['ip', 'IP address'], ['loc', 'Exit'], ['srv', 'Server'], ['ping', 'Ping'], ['proto', 'Protocol'], ['up', 'Connected for']].forEach(([k, l]) => {
    kv[k] = h('span', { text: '—' }); kvBox.append(h('span', { text: l }), kv[k]);
  });
  const notes = h('div', { class: 'vp-note', style: 'display:none;white-space:pre-line' });
  const left = Card(h('div', { class: 'vp-panel' },
    h('div', { class: 'vp-h', text: 'Status' }), badge, title, sub, bar, msg, big, chgBtn, ipBtn,
    h('div', { style: 'height:1px;background:var(--border)' }), kvBox, notes), 'col');

  // ── protection options ──
  const dirtyBar = h('div', { class: 'vp-dirty' }, h('span', { class: 'grow', text: 'These changes apply the next time you connect.' }),
    Btn('Reconnect now', { h: 26, f: 11, onclick: async () => { dirty = false; paintDirty(); await rpc('vpn.reconnect'); } }));
  const paintDirty = () => dirtyBar.classList.toggle('show', dirty && S.on);
  const OPTS = [
    ['kill_switch', 'Kill Switch', 'Blocks all internet traffic outside the VPN, so nothing leaks if the connection drops. Devices on your home network (printers, NAS) may be unreachable while it is on. Use \u201cRestore internet\u201d if you ever get stuck.'],
    ['dns_protect', 'DNS Leak Protection', 'Sends every DNS lookup through the tunnel using Cloudflare\u2019s private DNS servers.'],
    ['ipv6_block', 'Block IPv6 Leaks', 'Stops IPv6 traffic from bypassing the tunnel and exposing your real address.'],
    ['browser_protect', 'Browser Protection', 'Chrome, Edge and Brave: stops WebRTC and QUIC from revealing your real IP (restart the browser).'],
    ['auto_reconnect', 'Auto-Reconnect', 'Brings the VPN back up on its own if the connection drops.'],
  ];
  const optSw = {};
  const optBox = h('div', { class: 'vp-opts' });
  OPTS.forEach(([k, name, desc]) => {
    optSw[k] = Switch({ checked: true, onchange: async (v) => {
      S.opts[k] = v; dirty = S.on; paintDirty();
      try { await rpc('vpn.set_opts', { opts: { [k]: v } }); } catch (e) { fail('VPN', e.message); }
    } });
    optBox.append(h('div', { class: 'vp-opt' }, h('div', { class: 't' }, h('b', { text: name }), h('span', { text: desc })), optSw[k]));
  });
  const autoSw = Switch({ checked: false, onchange: onAutostart });
  optBox.append(h('div', { class: 'vp-opt' }, h('div', { class: 't' }, h('b', { text: 'Connect when DWUT starts' }), h('span', { text: 'Reconnects automatically every time DWUT opens. Remembered between restarts.' })), autoSw));
  const panicBtn = Btn('Restore internet (panic)', { variant: 'danger', h: 32, f: 11, onclick: async () => {
    if (await Modal.confirm('Restore internet', 'This removes the VPN tunnel, firewall rules and browser rules right now.\n\nUse it if your internet stops working.', { yes: 'Restore', danger: true })) { await rpc('vpn.panic'); }
  } });
  // ── locations: automatic (built-in free network) + any server files the user imported (e.g. a free Proton account) ──
  let LOCS = [], SEL = '';
  const ccName = (cc) => { try { const n = new Intl.DisplayNames(['en'], { type: 'region' }).of(cc); return n && n !== cc ? n : ''; } catch { return ''; } };
  const locLabel = (id) => {
    if (!id) return 'Automatic (free network)';
    const p = LOCS.find((x) => x.id === id);
    const c = p && p.cc ? ccName(p.cc) : '';
    return c ? `${c}  ·  ${id}` : id;
  };
  const locOpt = Option([''], { w: 300, f: 11, value: '', label: locLabel, onchange: (v) => selectLoc(v) });
  const locRm = Btn('Remove', { variant: 'ghost', h: 28, f: 11, onclick: () => removeLoc() });
  const locAdd = Btn('Add locations…', { variant: 'ghost', h: 28, f: 11, tip: 'Import your own server files (.conf).\nFree Proton accounts can download them: account.proton.me > Downloads > pick Windows and a server.', onclick: () => addLocs() });
  const locBox = h('div', { class: 'vp-opt' }, h('div', { class: 't' }, h('b', { text: 'Location' }),
    h('span', { text: 'Automatic works out of the box. Add your own server files (for example from a free Proton account) to pick a country here.' })),
    h('div', { class: 'col', style: 'gap:6px;align-items:flex-end;flex:none' }, locOpt, h('div', { class: 'row', style: 'gap:6px' }, locAdd, locRm)));
  const paintLocs = () => {
    locOpt.setValues([''].concat(LOCS.map((x) => x.id)), true);
    locOpt.set(SEL && LOCS.some((x) => x.id === SEL) ? SEL : '', true);
    locRm.style.display = locOpt.value ? '' : 'none';
  };
  async function loadLocs() {
    try { const r = await rpc('vpn.profiles'); LOCS = r.profiles || []; SEL = r.selected || ''; paintLocs(); } catch { /* ignore */ }
  }
  async function selectLoc(v) {
    if (S.busy) { paintLocs(); notify('VPN', 'Please wait for the current step to finish.'); return; }
    try {
      const r = await rpc('vpn.profile_select', { pid: v });
      if (!r.ok) { fail('Location', r.error || 'Could not switch location.'); }
      else SEL = v;
    } catch (e) { fail('Location', e.message); }
    paintLocs();
  }
  async function addLocs() {
    let files = null;
    try { files = await window.dwut.dialog.open({ properties: ['openFile', 'multiSelections'], filters: [{ name: 'Server files', extensions: ['conf', 'txt'] }] }); } catch (e) { fail('Locations', e.message); return; }
    if (!files || !files.length) return;
    try {
      const r = await rpc('vpn.profile_import', { paths: files });
      LOCS = r.profiles || LOCS; SEL = r.selected || SEL; paintLocs();
      const ok = (r.added || []).length, bad = r.errors || [];
      if (bad.length) fail('Add locations', (ok ? `Added ${ok}. ` : '') + 'Skipped:\n' + bad.join('\n'));
      else notify('Add locations', `Added ${ok} location${ok === 1 ? '' : 's'}. Pick one from the Location list.`);
    } catch (e) { fail('Add locations', e.message); }
  }
  async function removeLoc() {
    const id = locOpt.value; if (!id) return;
    if (!(await Modal.confirm('Remove location', `Remove "${id}" from your list?`, { yes: 'Remove', danger: true }))) return;
    try {
      const r = await rpc('vpn.profile_remove', { pid: id });
      if (!r.ok) fail('Remove', r.error || 'Could not remove it.');
      else { LOCS = r.profiles || []; SEL = r.selected || ''; paintLocs(); }
    } catch (e) { fail('Remove', e.message); }
  }

  const right = Card(h('div', { class: 'vp-panel' },
    h('div', { class: 'vp-h', text: 'Location' }), locBox,
    h('div', { class: 'row' }, h('div', { class: 'vp-h grow', text: 'Privacy & security' }), panicBtn), dirtyBar, optBox,
    h('div', { class: 'vp-note', text: 'DWUTVPN is completely free and needs no account. It encrypts your traffic (public Wi-Fi, ISP snooping) using Cloudflare WARP. Cloudflare picks the exit near you, so it does not change your location.' })), 'col');

  async function onAutostart(v) {
    await rpc('vpn.autostart_set', { on: v });
    if (!v) return;
    let st = { registered: false, enabled: false };
    try { st = await rpc('vpn.startup_status'); } catch { /* fall through */ }
    let has = st.registered && st.enabled;
    if (!has && window.dwut.hasStartup) { try { has = await window.dwut.hasStartup(); } catch { /* ignore */ } }
    if (has) return;
    if (st.registered && !st.enabled) {
      if (await Modal.confirm('DWUT is set not to start', 'DWUT is in your Windows startup list but turned off, so the VPN could not connect at boot.\n\nTurn it back on?', { yes: 'Turn on', no: 'Not now' })) {
        const ok = await rpc('vpn.startup_enable_existing');
        if (!ok) notify('Startup', 'Could not turn it on. Enable DWUT in Task Manager > Startup apps.');
      }
      return;
    }
    if (await Modal.confirm('Start DWUT with Windows?', 'Auto-connect only works while DWUT is open, and DWUT is not set to start with Windows yet.\n\nAdd DWUT to Windows startup so the VPN connects as soon as you sign in?', { yes: 'Add it', no: 'Not now' })) {
      try { const ok = await window.dwut.addToStartup(); notify('Startup', ok ? 'DWUT will now start with Windows.' : 'Could not add DWUT to startup.'); }
      catch (e) { fail('Startup', e.message); }
    }
  }

  async function toggleConn() {
    if (S.busy) return;
    window.FX && FX.stage.begin({ kind: 'vpn', eyebrow: 'DWUTVPN', title: S.on ? 'Disconnecting' : 'Connecting securely', doneTitle: S.on ? 'Disconnected' : 'Connected', first: S.on ? 'Closing the tunnel' : 'Starting the tunnel' });
    try { await rpc(S.on ? 'vpn.disconnect' : 'vpn.connect', {}); } catch (e) { window.FX && FX.stage.failKind('vpn', e.message); fail('VPN', e.message); }
  }
  async function changeServer() {
    if (S.busy || !S.on) { notify('Switch Server', S.busy ? 'The VPN is busy - wait for the current step to finish.' : 'Connect to the VPN first, then you can switch servers.'); return; }
    const origText = chgBtn.textContent;
    chgBtn.disabled = true;
    chgBtn.textContent = 'Switching…';
    try {
      const ok = await rpc('vpn.change_server');
      if (!ok) notify('Change server', 'Could not start - the VPN is busy or not connected.');
      // on success the button stays disabled until the backend reports the switch is finished (apply() re-enables it)
    } catch (e) { fail('Change server', e.message); }
    finally { chgBtn.textContent = origText; if (!S.busy) chgBtn.disabled = !S.on; }
  }
  async function checkIp() {
    ipBtn.disabled = true;
    try {
      const i = await rpc('vpn.check_ip');
      const where = [i.city, i.country || i.cc].filter(Boolean).join(', ') || 'unknown';
      notify('Your public IP', `${i.ip || 'unknown'}\n${where}\n\n` + (S.on ? 'This is what websites see while the VPN is on.' : 'The VPN is off - this is your real address.'));
    } catch (e) { fail('Check IP', e.message); }
    ipBtn.disabled = false;
  }
  const upt = (t) => { const s = Math.max(0, Math.floor(Date.now() / 1000 - t)); return [Math.floor(s / 3600), Math.floor(s / 60) % 60, s % 60].map((n) => String(n).padStart(2, '0')).join(':'); };

  function apply(s) {
    S = { ...S, ...s };
    if (s.profile !== undefined && (s.profile || '') !== SEL) { SEL = s.profile || ''; paintLocs(); }
    const on = !!s.on, wait = !!s.busy || s.status === 'reconnecting';
    setBadge(on && !wait ? 'on' : wait ? 'wait' : 'off');
    title.textContent = wait ? (s.status === 'switching' ? 'Switching server...' : s.status === 'reconnecting' ? 'Reconnecting…' : on ? 'Updating…' : 'Connecting…') : on ? 'Protected' : s.status === 'degraded' ? 'Connection lost' : 'Not protected';
    sub.textContent = on ? 'Your traffic is encrypted' + (s.ip ? '  ·  ' + s.ip : '') : 'Your traffic is not going through the VPN.';
    big.textContent = on ? 'Disconnect' : wait ? 'Connecting…' : 'Connect';
    big.className = 'btn ' + (on ? 'btn-ghost' : 'btn-primary');
    big.disabled = wait && !on;
    if (!wait && window.FX) FX.stage.finishKind('vpn', on ? 'Your traffic is encrypted' + (s.ip ? '  ·  ' + s.ip : '') : 'Your traffic is not going through the VPN');
    kv.ip.textContent = on ? (s.ip || '…') : '—';
    kv.loc.textContent = on ? ([s.city, s.country].filter(Boolean).join(', ') || 'Automatic') : '—';
    kv.srv.textContent = on ? (s.server_name || 'Server 1') : '-';
    kv.ping.textContent = on ? (s.latency != null ? s.latency + ' ms' : '...') : '-';
    chgBtn.disabled = !on || wait;
    kv.proto.textContent = on ? 'DWUT Tunnel' : '—';
    kv.up.textContent = on ? upt(s.since) : '—';
    const n = (s.notes || []).filter(Boolean);
    notes.textContent = n.join('\n'); notes.style.display = n.length ? '' : 'none';
    Object.entries(optSw).forEach(([k, sw]) => { if (s.opts && k in s.opts) sw.set(s.opts[k], true); });
    paintDirty();
    clearInterval(tick);
    if (on) tick = setInterval(() => { kv.up.textContent = upt(s.since); }, 1000);
    if (!wait) { bar.set(on ? 1 : 0); msg.textContent = ''; }
  }

  on('vpn.state', apply);
  // safety net: never sit on "Connecting…" forever if an update was missed - re-sync from the backend
  let busySince = 0;
  const guard = setInterval(async () => {
    if (!el.isConnected) return;
    if (S.busy) { busySince = busySince || Date.now(); if (Date.now() - busySince > 45000) { busySince = Date.now(); try { apply(await rpc('vpn.state')); } catch { /* ignore */ } } }
    else busySince = 0;
  }, 5000);
  on('vpn.progress', (d) => { msg.textContent = d.msg || ''; if (d.pct != null) bar.set(d.pct); });

  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' }, h('h1', { text: 'VPN' }), h('div', { class: 'grow' }), h('span', { class: 'f11 ts', text: 'DWUTVPN · free' })),
    h('div', { class: 'scroll', style: 'flex:1;min-height:0;padding:0 20px 6px' }, h('div', { class: 'vp-grid' }, left, right)));

  return {
    el,
    async onShow() {
      try { apply(await rpc('vpn.state')); } catch { /* ignore */ }
      loadLocs();
      try { autoSw.set(await rpc('vpn.autostart_get'), true); } catch { /* ignore */ }
    },
    onHide() {
      clearInterval(tick);
    },
    onDestroy() { clearInterval(guard); },
  };
});
