// Copyright © 2026 Darko / Darko.Dev
'use strict';
Pages.register('profiles', () => {
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (m) => { status.textContent = m; };
  const S = {
    games: [], presets: {}, schema: {}, amd_schema: {}, nvidia: false, amd: false,
    sel: null, page: 0, q: '', sort: 0, choice: {}, amd_choice: {},
    win: { gpu: true, fso: true, prio: false, dpi: true, resolution: 'native' }
  };
  const SORTS = ['A–Z', 'Optimized', 'Launcher'];
  const PER = 7;
  const list = h('div', { class: 'gp-list' });
  const pager = h('div', { class: 'row', style: 'gap:8px;justify-content:center;flex:none;height:30px' });
  const side = h('div', { class: 'gp-side' });
  const search = Entry({ placeholder: 'Search games…' }); search.style.cssText += ';flex:1;min-width:0;width:auto';
  const letter = (g) => h('span', { class: 'gp-l', text: g.name.replace(/[^A-Za-z0-9]/g, '').slice(0, 2).toUpperCase() });
  const iconEl = (g, big) => h('span', { class: 'gp-ico' + (big ? ' big' : '') }, g.icon ? h('img', { src: g.icon, alt: '' }) : letter(g));

  const visible = () => {
    let a = S.games.filter((g) => !S.q || (g.name + ' ' + g.publisher + ' ' + g.launcher).toLowerCase().includes(S.q));
    if (S.sort === 1) a = a.slice().sort((x, y) => (!!y.applied - !!x.applied) || x.name.localeCompare(y.name));
    if (S.sort === 2) a = a.slice().sort((x, y) => x.launcher.localeCompare(y.launcher) || x.name.localeCompare(y.name));
    return a;
  };

  const pick = (g) => {
    S.sel = g;
    const a = g.applied;
    S.choice = a && a.nv ? Object.assign({}, a.nv) : {};
    S.amd_choice = a && a.amd ? Object.assign({}, a.amd) : {};
    S.win = a && a.win ? Object.assign({ gpu: false, fso: false, prio: false, dpi: false, resolution: 'native' }, a.win)
                       : { gpu: true, fso: true, prio: false, dpi: true, resolution: 'native' };
    drawList(); drawSide();
  };

  function drawList() {
    list.textContent = '';
    const all = visible(), pages = Math.max(1, Math.ceil(all.length / PER)); S.page = Math.min(S.page, pages - 1);
    all.slice(S.page * PER, S.page * PER + PER).forEach((g, i) => {
      const on = S.sel && S.sel.id === g.id;
      list.append(h('button', { class: 'gp-row' + (on ? ' on' : ''), style: `--i:${i}`, onclick: () => pick(g) }, iconEl(g),
        h('span', { class: 'col', style: 'min-width:0;flex:1;align-items:flex-start' }, h('b', { class: 'gp-n', text: g.name }), h('small', { class: 'gp-m', text: (g.publisher || g.launcher) + ' · ' + g.launcher })),
        h('span', { class: 'gp-badge' + (g.applied ? ' ok' : ''), text: g.applied ? 'OPTIMIZED' : 'READY' })));
    });
    if (!all.length) list.append(h('div', { class: 'f11 ts', style: 'padding:20px;white-space:normal', text: S.games.length ? 'No game matches your search.' : 'No supported games were found on this PC. Install one from Steam, Epic or GOG, then press Refresh.' }));
    pager.textContent = '';
    if (pages > 1) pager.append(Btn('‹', { variant: 'ghost', h: 26, w: 34, onclick: () => { S.page = (S.page + pages - 1) % pages; drawList(); } }), h('span', { class: 'f11 ts', text: `Page ${S.page + 1} of ${pages}` }), Btn('›', { variant: 'ghost', h: 26, w: 34, onclick: () => { S.page = (S.page + 1) % pages; drawList(); } }));
  }

  const chipRow = (key, isAmd) => {
    const sc = isAmd ? S.amd_schema[key] : S.schema[key]; if (!sc) return null;
    const store = isAmd ? S.amd_choice : S.choice;
    const row = h('div', { class: 'gp-set' }, h('span', { class: 'gp-sl', text: sc.label }));
    const chips = h('div', { class: 'gp-chips' });
    const opts = [['', 'Default'], ...Object.entries(sc.options)];
    opts.forEach(([ok, ol]) => chips.append(h('button', { class: 'chip' + ((store[key] || '') === ok ? ' on' : ''), text: ol, onclick: () => { if (ok) store[key] = ok; else delete store[key]; drawSide(); } })));
    row.append(chips); return row;
  };

  const winRow = (label, desc, key) => h('div', { class: 'row', style: 'gap:10px;padding:4px 0' }, h('div', { class: 'col grow', style: 'min-width:0' }, h('span', { class: 'f11 b tp', text: label }), h('span', { class: 'f9 ts', style: 'white-space:normal', text: desc })), Switch({ checked: S.win[key], onchange: (v) => { S.win[key] = v; } }));

  function drawSide() {
    side.textContent = '';
    const g = S.sel;
    if (!g) return side.append(h('div', { class: 'col', style: 'padding:26px;gap:8px' }, h('span', { class: 'f16 b tp', text: 'Select a game' }),
      h('span', { class: 'f11 ts', style: 'white-space:normal', text: 'Only games installed on this PC that DWUT has a profile for are listed. Pick one to tune driver profiles, resolution, and Windows settings.' }),
      h('span', { class: 'f10 ts', style: 'white-space:normal;margin-top:6px', text: S.nvidia ? 'NVIDIA GPU detected - driver profiles available.' : (S.amd ? 'AMD Radeon GPU detected - driver profiles available.' : 'Dedicated GPU driver profiles ready.') })));

    const out = h('div', { class: 'f10', style: 'white-space:normal;min-height:26px;margin-top:6px' });
    const run = async (fn, msg) => {
      setStatus(msg);
      try {
        const r = await fn();
        out.textContent = (r.notes || []).join(' · ');
        out.style.color = r.ok ? 'var(--success)' : 'var(--error)';
        await load(false, g.id, true);
        setStatus(r.ok ? 'Done' : 'Failed');
      } catch (e) {
        out.textContent = e.message;
        out.style.color = 'var(--error)';
        setStatus('Failed');
      }
    };

    const apply = () => run(() => rpc('games.apply', { id: g.id, nv: S.nvidia ? S.choice : {}, amd: S.amd ? S.amd_choice : {}, win: S.win }), 'Applying profile…');
    const recommended = () => {
      S.choice = Object.assign({}, (S.presets.performance || {}).nv || {});
      S.amd_choice = { antilag: 'on', boost: 'on', ris: 'on', vsync: 'off' };
      S.win = { gpu: true, fso: true, prio: false, dpi: true, resolution: 'native' };
      run(() => rpc('games.apply', { id: g.id, nv: S.nvidia ? S.choice : {}, amd: S.amd ? S.amd_choice : {}, win: S.win }), 'Applying recommended…');
    };

    const presets = h('div', { class: 'gp-chips', style: 'margin:2px 0 8px' });
    Object.entries(S.presets).forEach(([k, p]) => presets.append(h('button', { class: 'chip', text: p.name, title: p.desc, onclick: () => { S.choice = Object.assign({}, p.nv); drawSide(); } })));

    // Resolution options
    const resRow = h('div', { class: 'gp-set' }, h('span', { class: 'gp-sl', text: 'Target Display Mode' }));
    const resChips = h('div', { class: 'gp-chips' });
    const resList = [
      ['native', 'Native Resolution'],
      ['1080p', '1080p (1920×1080)'],
      ['1440p', '1440p (2560×1440)'],
      ['4k', '4K (3840×2160)'],
      ['1280x960', '4:3 Stretched (1280×960)'],
      ['1440x1080', '4:3 Stretched (1440×1080)']
    ];
    resList.forEach(([rk, rl]) => resChips.append(h('button', {
      class: 'chip' + ((S.win.resolution || 'native') === rk ? ' on' : ''),
      text: rl,
      onclick: () => { S.win.resolution = rk; drawSide(); }
    })));
    resRow.append(resChips);

    // Continuous sections: Core Settings, Resolution & Display, AMD / NVIDIA Driver Settings, and Windows Optimizations
    const contentSections = [
      h('span', { class: 'gp-h', text: 'QUICK PRESETS' }), presets,
      h('span', { class: 'gp-h', text: 'CORE DRIVER SETTINGS' }),
      ...['vsync', 'fxaa', 'latency'].map((k) => chipRow(k, false)).filter(Boolean),
      h('span', { class: 'gp-h', style: 'margin-top:10px', text: 'RESOLUTION & DISPLAY' }),
      resRow,
      winRow('High-DPI scaling override', 'Prevents Windows from blurring custom stretched game resolutions.', 'dpi'),
    ];

    if (S.amd || Object.keys(S.amd_schema).length) {
      contentSections.push(
        h('span', { class: 'gp-h', style: 'margin-top:10px', text: 'AMD RADEON DRIVER PROFILE' }),
        ...['antilag', 'boost', 'ris', 'enhanced_sync', 'chill', 'vsync'].map((k) => chipRow(k, true)).filter(Boolean)
      );
    }

    contentSections.push(
      h('span', { class: 'gp-h', style: 'margin-top:10px', text: 'ADDITIONAL OPTIONS' }),
      ...['power', 'threaded', 'triple', 'lod', 'aniso', 'trilinear', 'p2'].map((k) => chipRow(k, false)).filter(Boolean),
      h('span', { class: 'gp-h', style: 'margin-top:10px', text: 'SYSTEM OPTIMIZATIONS' }),
      winRow('High-performance GPU', 'Force the dedicated GPU (laptops / iGPU systems).', 'gpu'),
      winRow('Disable fullscreen optimisations', 'Can lower input lag in exclusive fullscreen.', 'fso'),
      winRow('High CPU priority', 'Starts the game at High priority (needs admin).', 'prio'),
      out
    );

    side.append(
      h('div', { class: 'row', style: 'gap:12px;padding:14px 16px 4px' }, iconEl(g, true),
        h('div', { class: 'col grow', style: 'min-width:0' }, h('span', { class: 'f16 b tp ell', text: g.name }), h('span', { class: 'f10 ts ell', text: (g.publisher ? g.publisher + ' · ' : '') + g.launcher + ' · ' + g.exe_name })),
        Btn('▶ Launch Game', { h: 32, variant: 'primary', tip: 'Launch this game now with applied optimizations', onclick: () => run(() => rpc('games.launch', { id: g.id, exe: g.exe, appid: g.appid }), 'Launching game…') }),
        S.nvidia ? Btn('NVIDIA profile', { h: 32, variant: 'ghost', tip: 'Open NVIDIA Profile Inspector.', onclick: () => rpc('games.open_inspector').then((r) => setStatus((r.notes || [])[0] || '')) }) : null),
      h('div', { class: 'gp-banner' + (g.applied ? ' ok' : '') }, h('b', { text: g.applied ? 'Optimized' : 'Ready to configure' }), h('small', { text: g.applied ? 'This profile is applied. Change settings and re-apply any time.' : 'Fine-tune this profile before applying.' })),
      h('div', { class: 'row', style: 'gap:8px;padding:8px 16px 4px;flex-wrap:wrap' },
        Btn(g.applied ? 'Re-apply profile' : 'Apply profile', { h: 32, onclick: apply }),
        Btn('Apply recommended', { h: 32, variant: 'ghost', onclick: recommended }),
        Btn('Reset', { h: 32, variant: 'ghost', onclick: () => run(() => rpc('games.remove', { id: g.id }), 'Resetting…') })),
      h('div', { class: 'col', style: 'padding:6px 16px 16px;gap:2px;flex:1;min-height:0;overflow-y:auto' }, ...contentSections)
    );
  }

  async function load(force, keep, soft) {
    if (!soft) setStatus('Scanning installed games…');
    try {
      const r = await rpc('games.scan', { force: !!force });
      S.games = r.games || [];
      S.presets = r.presets || {};
      S.schema = r.schema || {};
      S.amd_schema = r.amd_schema || {};
      S.nvidia = !!r.nvidia;
      S.amd = !!r.amd;
      const cur = keep && S.games.find((g) => g.id === keep);
      S.sel = cur || null;
      if (cur && soft) { /* keep in-progress choices */ } else if (cur) pick(cur);
      drawList(); drawSide();
      setStatus(`${S.games.length} supported game${S.games.length === 1 ? '' : 's'} installed`);
    } catch (e) { setStatus('Scan failed: ' + e.message); }
  }

  search.addEventListener('input', () => { S.q = search.value.trim().toLowerCase(); S.page = 0; drawList(); });
  drawSide(); list.append(h('div', { class: 'f11 ts', text: 'Scanning installed games…', style: 'padding:20px' }));
  const sortBtn = Btn(SORTS[0], { h: 28, w: 92, tip: 'Change sort order', variant: 'ghost', onclick: () => { S.sort = (S.sort + 1) % SORTS.length; sortBtn.textContent = SORTS[S.sort]; drawList(); } });
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' }, h('h1', { text: 'Game Profiles' }), h('div', { class: 'grow' }), status),
    h('div', { class: 'gp-wrap' },
      h('div', { class: 'col', style: 'width:360px;flex:none;min-height:0' },
        h('div', { class: 'row', style: 'gap:6px;margin-bottom:8px;flex:none' }, search, sortBtn, Btn('↻', { h: 28, w: 34, variant: 'ghost', tip: 'Rescan installed games', onclick: () => load(true, S.sel && S.sel.id) })), list, pager),
      side));
  load(false);
  return { el };
});
