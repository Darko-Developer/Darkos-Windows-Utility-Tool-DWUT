// Copyright © 2026 Darko / Darko.Dev
'use strict';
Pages.register('debloat', () => {
  const status = h('span', { class: 'f11 ts' });
  const setStatus = (m, c) => { status.textContent = m; status.style.color = c || 'var(--text_secondary)'; };
  const pbar = Progress({ height: 3, radius: 0 }); pbar.style.borderRadius = '0';
  const plabel = h('div', { class: 'f10 ts', style: 'padding:2px 2px 0;min-height:14px' });
  const content = h('div', { style: 'flex:1;min-height:0;margin:6px 0 12px;position:relative' });
  let D = null, installed = {}, bloatVars = {}, badges = {}, curBloat = [], privVars = {};
  const tabs = {};

  // ── Bloatware ──
  function buildBloat() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const list = h('div', { class: 'scroll app-grid', style: 'flex:1;padding:2px' });
    const filt = Entry({ placeholder: 'Filter apps…', w: 170, h: 30, onchange: () => applyFilter() }); filt.addEventListener('input', () => applyFilter());
    const os = D.is_win11 ? Object.keys(D.bloat) : ['Windows 10'];
    const osOpt = Option(os, { w: 130, value: D.is_win11 ? 'Windows 11' : 'Windows 10', f: 12, onchange: () => reload() });
    osOpt.classList.add('bordered');
    if (os.length === 1) osOpt.style.pointerEvents = 'none';
    const scan = async () => {
      setStatus('Scanning installed packages…'); pbar.set(0.1);
      window.FX && FX.stage.begin({ kind: 'debloat', eyebrow: 'Debloat', title: 'Scanning your apps', doneTitle: 'Scan complete', first: 'Scanning installed packages' });
      try {
        installed = await rpc('debloat.scan'); let found = 0;
        for (const [pkg, b] of Object.entries(badges)) {
          if (installed[pkg.toLowerCase()]) { found++; paintBadge(b, true); bloatVars[pkg] && bloatVars[pkg].set(true, true); } else paintBadge(b, false);
        }
        setStatus(`Scan complete — ${found} bloatware packages found installed`);
        const have = Object.entries(installed).filter(([, v]) => v).map(([k]) => k);
        const patFor = (k) => (curBloat.find((e) => e.pkg.toLowerCase() === k && e.kind !== 'win32') || {}).pkg;
        const want = have.map(patFor).filter(Boolean);
        if (want.length) rpc('debloat.icons', { pkgs: want }).then((m) => { if (m && typeof m === 'object') for (const [k, v] of Object.entries(m)) { icons[k] = v; setIcon(k); } }).catch(() => {});
        window.FX && FX.stage.finishKind('debloat', `${found} bloatware package${found === 1 ? '' : 's'} found installed`);
      } catch (e) { window.FX && FX.stage.failKind('debloat', e.message); setStatus('Scan failed: ' + e.message, 'var(--error)'); }
      pbar.set(0); plabel.textContent = '';
    };
    const remove = async () => {
      const sel = curBloat.filter((e) => bloatVars[e.pkg] && bloatVars[e.pkg].checked);
      if (!sel.length) return setStatus('Select at least one app to remove.');
      if (!(await Modal.confirm('Confirm Removal', `Remove ${sel.length} selected apps?\n\nA system restore point will be created first.\nThis action can be undone via System Restore.`))) return;
      setStatus(`Removing ${sel.length} packages…`);
      window.FX && FX.stage.begin({ kind: 'debloat', eyebrow: 'Debloat', title: `Removing ${sel.length} app${sel.length === 1 ? '' : 's'}`, doneTitle: 'Removal finished', first: 'Creating a restore point' });
      rpc('debloat.remove', { entries: sel }).catch((e) => { window.FX && FX.stage.failKind('debloat', e.message); setStatus(e.message, 'var(--error)'); });
    };
    f.append(Card([h('div', { class: 'row', style: 'padding:10px 12px 6px;gap:8px' }, h('span', { class: 'f11 ts', text: 'OS:' }), osOpt,
      filt, Btn('Scan Installed', { variant: 'ghost', h: 30, onclick: scan }), Btn('Select All', { variant: 'ghost', h: 30, onclick: () => Object.values(bloatVars).forEach((c) => c.set(true, true)) }),
      Btn('Deselect All', { variant: 'ghost', h: 30, onclick: () => Object.values(bloatVars).forEach((c) => c.set(false, true)) }), Btn('Remove Selected', { variant: 'danger', h: 30, cls: 'auto', onclick: remove }))], 'col', { marginBottom: '8px', flex: 'none' }));
    f.append(list);
    const paintBadge = (b, inst) => {
      b.textContent = inst ? 'INSTALLED' : 'not found';
      b.style.cssText = inst ? 'background:var(--warning);color:#000;font-weight:700;border-radius:4px;padding:0 6px;margin-left:6px' : 'color:var(--text_disabled);margin-left:6px;font-weight:400';
    };
    const icons = {}, icoEls = {}, tileEls = [];
    const initials = (e) => { const w = e.name.replace(/\(.*?\)/g, '').trim().split(/\s+/); return ((w[0] || '?')[0] + (w.length > 1 ? (w[1][0] || '') : '')).toUpperCase(); };
    const setIcon = (pkg) => { const el = icoEls[pkg]; if (!el || !icons[pkg]) return; el.textContent = ''; el.classList.add('img'); el.append(h('img', { src: icons[pkg], draggable: 'false' })); };
    function applyFilter() {
      const q = (filt.value || '').trim().toLowerCase();
      for (const t of tileEls) t.el.style.display = !q || t.text.includes(q) ? '' : 'none';
      list.querySelectorAll('.vendor-h').forEach((vh) => { let n = vh.nextElementSibling, any = false; while (n && !n.classList.contains('vendor-h')) { if (n.style.display !== 'none') any = true; n = n.nextElementSibling; } vh.style.display = any ? '' : 'none'; });
    }
    function reload() {
      list.textContent = ''; bloatVars = {}; badges = {}; tileEls.length = 0;
      const entries = D.bloat[osOpt.value] || []; curBloat = entries;
      if (!entries.length) return list.append(h('div', { class: 'f12 ts', text: 'No database for this OS.', style: 'padding:20px;text-align:center' }));
      const pc = { High: 'var(--accent)', Medium: 'var(--text_primary)', Low: 'var(--text_disabled)' };
      const groups = {};
      entries.forEach((e) => { (groups[e.vendor || 'Other'] = groups[e.vendor || 'Other'] || []).push(e); });
      const order = Object.keys(groups).sort((x, y) => (x === 'Microsoft' ? -1 : y === 'Microsoft' ? 1 : x === 'Other' ? 1 : y === 'Other' ? -1 : x.localeCompare(y)));
      const frag = document.createDocumentFragment();
      for (const v of order) {
        frag.append(h('div', { class: 'vendor-h' }, h('span', { text: v }), h('i', { text: `${groups[v].length} app${groups[v].length === 1 ? '' : 's'}` })));
        groups[v].forEach((e) => {
          const inst = installed[e.pkg.toLowerCase()];
          const cb = Check('', { checked: inst === true, themed: true }); bloatVars[e.pkg] = cb;
          const badge = h('span', { class: 'f9', style: 'margin-left:6px' }); badges[e.pkg] = badge;
          if (inst === true) paintBadge(badge, true); else if (inst === false) paintBadge(badge, false);
          const ico = h('div', { class: 'app-ico' + (e.kind === 'win32' ? ' w32' : ''), text: initials(e) }); icoEls[e.pkg] = ico; if (icons[e.pkg]) setIcon(e.pkg);
          const tile = h('div', { class: 'app-tile' }, cb, ico,
            h('div', { class: 'grow col', style: 'min-width:0;align-items:flex-start' }, h('div', { class: 'row', style: 'max-width:100%' }, h('span', { class: 'f12 b tp ell', text: e.name }), badge), h('span', { class: 'f10 ts ell', style: 'max-width:100%', text: e.desc })),
            h('span', { class: 'app-pri f9 b', text: e.priority, style: `color:${pc[e.priority] || 'var(--text_secondary)'}` }));
          tile.addEventListener('click', (ev) => { if (ev.target.closest('.cb')) return; cb.set(!cb.checked, true); });
          tileEls.push({ el: tile, text: (e.name + ' ' + e.desc + ' ' + (e.vendor || '')).toLowerCase() });
          frag.append(tile);
        });
      }
      list.append(frag); applyFilter();
    }
    reload();
    return f;
  }

  // ── Privacy ──
  function buildPrivacy() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const list = h('div', { class: 'scroll', style: 'flex:1;background:var(--bg_card);border-radius:6px;padding:2px' });
    const items = D.privacy.filter((i) => !i.windows11_only || D.is_win11);
    const apply = async () => {
      const keys = Object.keys(privVars).filter((k) => privVars[k].checked);
      if (!keys.length) return setStatus('Select at least one privacy item.');
      if (!(await Modal.confirm('Apply Privacy Changes', `Apply ${keys.length} privacy changes?\n\nThese will modify registry settings and may\nrequire a restart to take full effect.`))) return;
      setStatus(`Applying ${keys.length} privacy changes…`);
      window.FX && FX.stage.begin({ kind: 'debloat', eyebrow: 'Privacy', title: `Applying ${keys.length} privacy change${keys.length === 1 ? '' : 's'}`, doneTitle: 'Privacy applied', first: 'Starting' });
      rpc('debloat.apply_privacy', { keys }).catch((e) => { window.FX && FX.stage.failKind('debloat', e.message); });
    };
    f.append(Card([h('div', { class: 'row', style: 'padding:10px 12px;gap:6px' }, h('span', { class: 'f11 ts', text: 'Quick presets:' }),
      Btn('Maximum Privacy', { variant: 'danger', h: 30, onclick: () => { Object.values(privVars).forEach((c) => c.set(true, true)); setStatus('Maximum privacy preset selected — click Apply Selected to execute'); } }),
      Btn('Balanced', { variant: 'ghost', h: 30, onclick: () => { const bal = new Set(['telemetry_svc', 'ad_id', 'activity_feed']); for (const [k, c] of Object.entries(privVars)) c.set(bal.has(k), true); setStatus('Balanced privacy preset selected — click Apply Selected to execute'); } }),
      h('div', { class: 'grow' }), Btn('Apply Selected', { h: 30, onclick: apply }))], 'col', { marginBottom: '8px', flex: 'none' }));
    privVars = {};
    items.forEach((it, i) => {
      const cb = Check('', { themed: true }); privVars[it.key] = cb;
      list.append(h('div', { class: 'row', style: `background:var(${i % 2 === 0 ? '--bg_input' : '--bg_card'});border-radius:4px;margin:2px` },
        h('div', { style: 'padding:10px' }, cb), h('div', { class: 'grow col', style: 'padding:8px 0;align-items:flex-start' }, h('span', { class: 'f12 b tp', text: it.title }), h('span', { class: 'f10 ts', text: it.desc }))));
    });
    f.append(list); return f;
  }

  // ── Recall ──
  function buildRecall() {
    const f = h('div', { class: 'scroll', style: 'position:absolute;inset:0' });
    const stat = h('span', { class: 'f12 b ts', text: 'Status: not checked' });
    const check = async () => {
      stat.textContent = 'Checking…'; stat.style.color = 'var(--text_secondary)';
      try {
        const r = await rpc('debloat.recall_status');
        const cm = { Disabled: 'var(--success)', 'Partially disabled': 'var(--warning)', Active: 'var(--error)' };
        stat.textContent = `Status: ${r.label} (${r.disabled_count}/${r.total_checks} checks passed — ${r.pct}%)`; stat.style.color = cm[r.label] || 'var(--text_secondary)';
      } catch (e) { stat.textContent = 'Status: check failed'; }
    };
    const disable = async () => {
      if (!(await Modal.confirm('Disable Windows Recall', 'This will:\n• Disable AI screenshot capture via registry policy\n• Stop Recall-related services\n• Remove Recall app packages\n\nRequires administrator rights.\nA restart is recommended after this operation.\n\nContinue?'))) return;
      setStatus('Disabling Windows Recall…');
      try { await rpc('debloat.recall_disable'); check(); } catch (e) { setStatus('Recall disable failed: ' + e.message, 'var(--error)'); }
    };
    const acts = ['Disables AI data analysis via HKLM and HKCU registry policy', 'Disables Windows Copilot / AI sidebar', 'Disables Activity Feed (EnableActivityFeed = 0)', 'Stops CDPUserSvc and OneSyncSvc services', 'Removes Recall app packages via PowerShell'];
    f.append(
      h('div', { class: 'col hazard-box', style: 'margin-bottom:10px;padding:12px 16px;align-items:center' },
        h('div', { class: 'f14 b', text: 'Windows Recall — AI Screenshot Surveillance', style: 'color:#fff;margin-bottom:2px' }),
        h('div', { class: 'f11', style: 'color:#FFCCCC;text-align:center;max-width:720px', text: 'Windows Recall takes screenshots of everything you do and analyses them with AI.\nDisable it to protect your privacy.' })),
      Card([h('div', { class: 'row', style: 'padding:12px 14px' }, stat, h('div', { class: 'grow' }), Btn('Check Status', { variant: 'ghost', h: 30, onclick: check }))], '', { marginBottom: '10px' }),
      Card([h('div', { class: 'f12 b tp', text: 'What disabling Recall does:', style: 'padding:10px 14px 4px' }), acts.map((a) => h('div', { class: 'f10 ts', text: '   ' + a, style: 'padding:1px 14px' })), h('div', { style: 'height:8px' })], 'col', { marginBottom: '10px' }),
      h('div', { class: 'row' }, Btn('Disable Windows Recall Now', { variant: 'danger', h: 42, cls: 'fill', style: { marginRight: '4px' }, onclick: disable }), Btn('Check Status', { variant: 'ghost', h: 42, cls: 'fill', style: { marginLeft: '4px' }, onclick: check })),
      h('div', { class: 'f10 c-warn', style: 'text-align:center;padding:10px', text: '  Requires administrator privileges.  Restart recommended after disabling.' }));
    return f;
  }

  // ── Restore ──
  function buildRestore() {
    const f = h('div', { class: 'col', style: 'position:absolute;inset:0' });
    const rs = h('div', { class: 'f11 ts', style: 'padding:0 14px 8px' });
    const create = async () => {
      rs.textContent = 'Creating restore point…'; rs.style.color = 'var(--text_secondary)';
      try { const ok = await rpc('debloat.restore_point'); rs.textContent = ok ? ' Restore point created successfully' : ' Failed — make sure System Protection is enabled for C:\\'; rs.style.color = ok ? 'var(--success)' : 'var(--error)'; }
      catch (e) { rs.textContent = ' Failed — ' + e.message; rs.style.color = 'var(--error)'; }
    };
    f.append(
      Card([h('div', { class: 'f14 b tp', text: 'System Restore', style: 'padding:12px 14px 4px' }), h('div', { class: 'f11 ts', style: 'padding:0 14px 10px;max-width:660px;white-space:normal', text: 'Create a restore point before making changes, or open System Restore to roll back.' }), rs,
        h('div', { class: 'row', style: 'padding:0 14px 14px;gap:8px' }, Btn('Create Restore Point', { h: 38, cls: 'auto', onclick: create }), Btn('Open System Restore', { variant: 'ghost', h: 38, cls: 'auto', onclick: () => rpc('debloat.open_restore') }))], 'col', { marginBottom: '12px', flex: 'none' }),
      Card([h('div', { class: 'f12 b tp', text: 'Debloat Session Backups', style: 'padding:10px 14px 4px' }), h('div', { class: 'f10 ts', text: 'JSON logs of every debloat session are stored in the backups/ folder.', style: 'padding:0 14px' }),
        h('div', { style: 'padding:8px 14px 12px' }, Btn('Open Backups Folder', { variant: 'ghost', h: 30, cls: 'auto', onclick: () => rpc('os.open_folder', { which: 'backups' }) }))], 'col', { flex: '1' }));
    return f;
  }

  // ── Popups ──
  function buildPopups() {
    const f = h('div', { class: 'scroll pop-grid', style: 'position:absolute;inset:0;padding:0 2px' });
    f.append(Card([h('div', { class: 'f14 b tp', text: 'Popup & Watermark Suppressor', style: 'padding:12px 14px 2px' }),
      h('div', { class: 'f11 ts', style: 'padding:0 14px 10px;max-width:660px;white-space:pre-wrap', text: 'Suppresses Windows nag prompts without cracking or modifying system files.\nAll changes are registry tweaks that are safely reversible with Re-enable.' })], 'col', { margin: '0 0 10px' }));
    const P = 'modules.debloat.popups';
    const card = (title, desc, dis, en, win11, win10) => {
      if (win11 && !D.is_win11) return;
      if (win10 && D.is_win11) return;       // Windows 10 only: never shown on Windows 11
      const st = h('span', { class: 'f10 td' });
      const run = async (fn, ok, bad) => {
        st.textContent = 'Working…'; st.style.color = 'var(--warning)';
        try { const r = await rpc('call', { module: P, fn, args: [] }); st.textContent = r ? `[OK] ${ok}` : `[FAIL] ${bad}`; st.style.color = r ? 'var(--success)' : 'var(--error)'; }
        catch (e) { st.textContent = `[FAIL] Error: ${e.message}`; st.style.color = 'var(--error)'; }
      };
      f.append(Card([h('div', { class: 'row', style: 'padding:10px 14px 2px' }, h('span', { class: 'f12 b tp', text: title }), h('div', { class: 'grow' }), st),
        h('div', { class: 'f11 ts', style: 'padding:0 14px 8px;max-width:620px;white-space:pre-wrap', text: desc }),
        h('div', { class: 'row', style: 'padding:0 14px 12px;gap:8px' }, Btn('Disable', { h: 32, onclick: () => run(dis, 'Disabled', 'Failed to disable') }), Btn('Re-enable', { variant: 'ghost', h: 32, onclick: () => run(en, 'Re-enabled', 'Failed to re-enable') }))], 'col', { margin: '0 0 8px' }));
    };
    card('Activate Windows Watermark / Prompt', "Removes the 'Activate Windows' text watermark in the bottom-right corner and suppresses the Settings nag prompt.  Works on both Windows 10 and 11.\n\nMethod: sets PaintDesktopVersion=0 in HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion and disables the SoftwareLicensing update notification flag.", '_disable_activation_watermark', '_enable_activation_watermark');
    card('"Your Windows license is expiring" Notification', 'Suppresses the recurring Windows license expiry popup notification that appears in the notification centre and as a system tray balloon.\n\nMethod: disables the activation notification scheduled tasks and the Windows Activation notification agent registry entry.', '_disable_license_expiry_notification', '_enable_license_expiry_notification');
    card('"Personalize your PC" / OOBE Nag Screen', "Prevents the 'Let's finish setting up your PC' / 'Personalize your PC' prompt that appears on login for unactivated or freshly installed Windows.\n\nMethod: sets ContentDeliveryManager and OOBE registry flags.", '_disable_oobe_nag', '_enable_oobe_nag');
    card('Windows 11: Settings → "Activate Windows" Banner', "Hides the prominent orange 'Activate Windows' banner at the top of the Settings app (Windows 11 only).  This is separate from the desktop watermark.\n\nMethod: registry flag under HKLM\\SOFTWARE\\Microsoft\\WindowsRuntime\\ActivationBanner.", '_disable_settings_activation_banner', '_enable_settings_activation_banner', true);
    card('"Get Genuine Windows" / SmartScreen Activation Alert', "Suppresses the SmartScreen-based 'Get Genuine Windows' alert that some Windows 10 builds display as a full-screen overlay at login or periodically.\n\nMethod: disables the LUA/activation SmartScreen scheduled tasks and sets the NoActivationUI DWORD.", '_disable_get_genuine_windows', '_enable_get_genuine_windows', false, true);
    return f;
  }

  const builders = { Bloatware: buildBloat, Privacy: buildPrivacy, Recall: buildRecall, Restore: buildRestore, Popups: buildPopups };
  function switchTab(name) {
    for (const [n, t] of Object.entries(tabs)) { t.btn.classList.toggle('active', n === name); if (t.frame) t.frame.style.display = n === name ? '' : 'none'; }
    const t = tabs[name];
    if (!t.frame) { t.frame = builders[name](); content.append(t.frame); }
    t.frame.style.display = '';
  }
  const tabBar = h('div', { class: 'row', style: 'padding:0 20px' });
  function initTabs() {
    const names = ['Bloatware', 'Privacy', 'Restore', 'Popups']; if (D.is_win11) names.splice(2, 0, 'Recall');
    for (const n of names) { const btn = Btn(n, { variant: 'plain', cls: 'tab f12', onclick: () => switchTab(n) }); tabs[n] = { btn, frame: null }; tabBar.append(h('span', { style: 'margin:0 2px' }, btn)); }
    FX.rail(tabBar, { Bloatware: 'Scan & remove apps', Privacy: 'Telemetry · ads · tracking', Recall: 'Recall & AI features', Restore: 'Backups & undo', Popups: 'Nag screens & prompts' });
    switchTab('Bloatware');
  }
  on('debloat.progress', (d) => { pbar.set(d.pct || 0); plabel.textContent = d.step || ''; setStatus(d.step || ''); });
  on('debloat.done', (d) => {
    const applied = d.applied || 0, failed = d.failed || [];
    let msg = `Done — ${applied} applied`; if (failed.length) msg += `, ${failed.length} failed: ${failed.slice(0, 3).join(', ')}`;
    setStatus(msg); pbar.set(1); plabel.textContent = msg;
    if (failed.length) warn('Partial Completion', `${applied} changes applied successfully.\n\n${failed.length} failed:\n` + failed.slice(0, 10).map((n) => '• ' + n).join('\n'));
  });
  const el = h('div', { class: 'col', style: 'flex:1;min-height:0' },
    h('div', { class: 'title-row' }, h('h1', { text: 'Debloat & Windows Utility' }), h('div', { class: 'grow' }), status),
    h('div', { class: 'rail-body' }, tabBar, h('div', { class: 'rail-main' }, pbar, plabel, content)));
  rpc('debloat.static').then((d) => { D = d; initTabs(); }).catch((e) => setStatus('Failed to load: ' + e.message, 'var(--error)'));
  return { el };
});
