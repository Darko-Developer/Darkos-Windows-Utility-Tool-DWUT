// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* App shell: titlebar, sidebar, navigation, splash, update banner, boot sequence */

const NAV_ITEMS = [
  ['dashboard', 'Dashboard', 'D'], ['optimizer', 'Optimizer', 'O'], ['gaming', 'Gaming', 'G'],
  ['debloat', 'Debloat', 'D'], ...(window.SHOW_PROXY ? [['proxy', 'Proxy Center', 'P']] : []), ['vpn', 'VPN', 'V'],
  ['network', 'Network Monitor', 'N'],
  ['usb', 'USB Flasher', 'U'], ['vm', 'VM Builder', 'M'], ['tools', 'Tools', 'T'],
  ['cleaner', 'Cleaner', 'C'], ['bios', 'BIOS & Firmware', 'B'], ['profiles', 'Game Profiles', 'P'], ['settings', 'Settings', 'S'],
];
const NAV_SHORT = { dashboard: 'Home', optimizer: 'Optimizer', gaming: 'Gaming', debloat: 'Debloat', proxy: 'Proxy', vpn: 'VPN', network: 'Network', usb: 'USB', vm: 'VMs', tools: 'Tools', cleaner: 'Cleaner', bios: 'BIOS', profiles: 'Profiles', settings: 'Settings' };

const Nav = {
  pages: {}, current: '', sidebarCollapsed: false, isAdmin: false,

  // Build a page and insert it into the DOM without activating it.
  _build(name) {
    if (this.pages[name] || !Pages.factories[name]) return;
    const p = this.pages[name] = Pages.factories[name]();
    p.root = h('div', { class: 'page' }, p.el);
    $('#content').append(p.root);
  },

  go(name) {
    if (!Pages.factories[name] || name === this.current) return;
    this._build(name);                              // no-op if already built
    const p    = this.pages[name];
    const prev = this.pages[this.current];
    if (prev) { prev.root.classList.remove('active'); prev.onHide && prev.onHide(); }
    p.root.classList.add('active');
    this.current = name; window.__currentPage = name;
    Sidebar.setActive(name);
    p.onShow && p.onShow();
  },
};

/* The old sidebar is now the top navigation bar (#dock) + the command hub on the Dashboard.  The object keeps its old name so every caller
   (Settings -> theme change, Personalization -> "Sidebar animation" / "Sidebar expand/collapse") keeps working: the pills keep the
   .sb-item markup, so every sidebar animation preset still plays on them. */
const Sidebar = {
  build() {
    const dk = $('#dock');
    const col = false;                       // the compact mode and its arrow are gone: every category always shows its name
    Nav.sidebarCollapsed = false;
    dk.classList.remove('collapsed');
    dk.textContent = '';
    if (this._clk) clearInterval(this._clk);
    const admin = Nav.isAdmin;
    const sys = window.OS ? (OS.name || '') + (OS.version ? ' ' + OS.version : '') : '';
    const brand = h('button', { class: 'dk-brand', title: 'Back to the dashboard', onclick: () => Nav.go('dashboard') },
      h('span', { class: 'dk-pet' }),
      h('span', { class: 'dk-name' }, h('b', { text: 'DWUT' }), h('i', { text: (admin ? 'ADMIN' : 'NO ADMIN') + (sys ? ' · ' + sys : ''), style: { color: admin ? 'var(--accent)' : 'var(--warning)' } })));
    const nav = h('nav', { class: 'dk-nav' }), pills = h('div', { class: 'dk-pills' });
    nav.append(pills, h('div', { class: 'dk-hubtitle', text: "DARKO'S WINDOWS UTILITY TOOL" }));
    this.items = {};
    for (const [key, label] of NAV_ITEMS) {
      const btn = h('button', { class: 'f12', title: label, onclick: () => Nav.go(key) }, h('span', { class: 'sb-label', text: NAV_SHORT[key] || label }));
      const row = h('div', { class: 'sb-item', 'data-key': key }, h('div', { class: 'bar' }), btn);
      this.items[key] = row; pills.append(row);
    }
    const toggle = h('button', { class: 'sb-toggle f13', title: 'Compact / expand the menu', text: col ? '›' : '‹', onclick: () => this.toggle() });
    const sysEl = h('div', { class: 'dk-sys' });
    const clock = h('span', { class: 'dk-clock mono f11' });
    // tiny slime sprite replaces the blue LED dot
    const slimeIcon = h('span', { class: 'dk-slime-ico', title: 'DWUT is running' });
    // window controls live here, inside the draggable dock but with no-drag on themselves
    const winMin  = h('button', { class: 'dk-wc dk-wc-min',  title: 'Minimize',     onclick: () => { try { dwut.win.minimize(); } catch { ipcRenderer && ipcRenderer.send('win:minimize'); } } }, h('span', { text: '−' }));
    const winMax  = h('button', { class: 'dk-wc dk-wc-max',  title: 'Maximize',     onclick: () => { try { dwut.win.maximize(); } catch { ipcRenderer && ipcRenderer.send('win:maximize'); } } }, h('span', { text: '□' }));
    const winClose= h('button', { class: 'dk-wc dk-wc-cls',  title: 'Close to tray',onclick: () => { try { dwut.win.close();    } catch { ipcRenderer && ipcRenderer.send('win:close');    } } }, h('span', { text: '×' }));
    const right = h('div', { class: 'dk-right' }, slimeIcon, sysEl, clock, winMin, winMax, winClose);
    dk.append(brand, nav, right);
    const tick = () => {
      if (document.documentElement.classList.contains('idle')) return;      // minimised / in the tray: nobody sees the clock
      const d = new Date(); clock.textContent = [d.getHours(), d.getMinutes(), d.getSeconds()].map((n) => String(n).padStart(2, '0')).join(':');
      const s = window.__sys;
      if (s && s.cpu != null) {
        const pct  = (v, d=0) => v != null ? Math.round(v) + '%' : '—';
        const temp = (v)       => v != null ? Math.round(v) + '°' : null;
        const mb   = (v)       => v != null ? (v >= 1024 ? (v/1024).toFixed(1)+'GB' : Math.round(v)+'MB') : null;
        const parts = [
          `CPU ${pct(s.cpu)}`,
          s.cpu_temp_c != null  ? temp(s.cpu_temp_c) : null,
          `RAM ${pct(s.ram)}`,
          s.gpu != null         ? `GPU ${pct(s.gpu)}`         : null,
          s.gpu_temp_c != null  ? temp(s.gpu_temp_c)          : null,
          s.disk != null        ? `DISK ${pct(s.disk)}`       : null,
          s.net_recv != null    ? `↓${mb(s.net_recv * 1024 / 8) || '0MB'}` : null,
        ].filter(Boolean);
        sysEl.textContent = parts.join('  ');
      } else {
        sysEl.textContent = '';
      }
    };
    tick(); this._clk = setInterval(tick, 1000);
    if (Nav.current) this.setActive(Nav.current);
  },

  setActive(key) {
    const dk = $('#dock'); if (dk) dk.dataset.page = key;
    for (const [k, row] of Object.entries(this.items || {})) {
      const wasActive = row.classList.contains('active');
      const nowActive = k === key;
      if (nowActive && !wasActive) {
        // Force-restart any CSS animation on the button by triggering reflow
        const btn = row.querySelector('button');
        if (btn) { btn.style.animation = 'none'; void btn.offsetWidth; btn.style.animation = ''; }
        row.classList.remove('active'); void row.offsetWidth; row.classList.add('active');
      } else if (!nowActive) {
        row.classList.remove('active');
      }
    }
  },

  toggle() {
    Nav.sidebarCollapsed = !Nav.sidebarCollapsed;
    Cfg.set({ sidebar_collapsed: Nav.sidebarCollapsed });
    const sb = $('#dock');
    const col = Nav.sidebarCollapsed;
    if (this._toggleTimer) clearTimeout(this._toggleTimer);
    sb.removeAttribute('data-sb-toggling');
    void sb.offsetWidth; // force reflow so animation re-triggers on every toggle
    sb.setAttribute('data-sb-toggling', col ? 'collapse' : 'expand');
    sb.classList.toggle('collapsed', col);
    const toggleBtn = sb.querySelector('.sb-toggle');
    if (toggleBtn) toggleBtn.textContent = col ? '›' : '‹';
    this._toggleTimer = setTimeout(() => { sb.removeAttribute('data-sb-toggling'); }, 640);
  },
};

function buildTitlebar() {
  // #titlebar is a CSS-only 8px drag strip — no content needed.
}

let _toastShown = false;
function showUpdateBanner(info) {
  if (_toastShown) return; _toastShown = true;
  const host = $('#banner-host');
  const bar = h('div', { class: 'tbar' });
  const title = h('div', { class: 'f13 b', text: 'Update available', style: 'color:var(--text_primary)' });
  const sub = h('div', { class: 'f11 ts', text: `DWUT ${info.version || 'new version'} is ready to install`, style: 'margin-top:2px' });
  const btn = Btn('Update now', { h: 28, w: 120, bold: true, onclick: (e) => { e.stopPropagation(); install(); } });
  const toast = h('div', { class: 'toast', onclick: () => install() }, h('div', { style: 'padding:12px 14px 12px' }, title, sub, h('div', { style: 'margin-top:10px' }, btn)), bar);
  let installing = false, timer = null;
  async function install() {
    if (installing) return; installing = true; clearTimeout(timer);
    bar.style.transition = 'none'; bar.style.width = '100%';
    title.textContent = 'Installing update…'; sub.textContent = 'DWUT will close and restart by itself.'; btn.style.display = 'none';
    try { await dwut.updateNow(); } catch (e) { title.textContent = 'Update failed'; sub.textContent = String(e.message || e); setTimeout(() => toast.remove(), 6000); }
  }
  host.append(toast);
  requestAnimationFrame(() => requestAnimationFrame(() => { bar.style.width = '0%'; }));       // smooth 5 s countdown, full -> empty
  timer = setTimeout(() => { if (installing) return; toast.classList.add('out'); setTimeout(() => toast.remove(), 300); }, 5000);
}

// ── starfield + splash (same parameters as the original Tk widget) ───────────
function Starfield(canvas, bg, starColor) {
  const ctx = canvas.getContext('2d');
  const hex = (c) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
  const B = hex(bg), S = hex(starColor);
  const dim = S.map((v, i) => v + (B[i] - v) * 0.55);
  let stars = [], W = 0, Hh = 0, timer = null;
  const mix = (t) => `rgb(${dim.map((d, i) => Math.round(d + (S[i] - d) * t)).join(',')})`;
  const seed = () => {
    const dpr = devicePixelRatio || 1;
    W = canvas.clientWidth; Hh = canvas.clientHeight; canvas.width = W * dpr; canvas.height = Hh * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.min(140, Math.max(24, Math.floor(W * Hh / 6000)));
    stars = [];
    for (let i = 0; i < n; i++) {
      const sp = (2 + Math.random() * 8) / 60;
      stars.push({ x: Math.random() * W, y: Math.random() * Hh, r: [0.6, 0.8, 1.0, 1.0, 1.3, 1.6][Math.floor(Math.random() * 6)],
        vx: sp * (Math.random() * 0.6 - 0.3), vy: sp * (0.3 + Math.random() * 0.7), ph: Math.random() * 6.283, ts: 0.03 + Math.random() * 0.07 });
    }
  };
  const tick = () => {
    ctx.clearRect(0, 0, W, Hh);
    for (const s of stars) {
      s.x += s.vx; s.y += s.vy;
      if (s.x < -2) s.x = W + 2; else if (s.x > W + 2) s.x = -2;
      if (s.y < -2) s.y = Hh + 2; else if (s.y > Hh + 2) s.y = -2;
      s.ph += s.ts;
      let t = (Math.sin(s.ph) + 1) / 2;
      if (Math.random() < 0.012) t = Math.random() < 0.5 ? 0 : 1;
      ctx.fillStyle = mix(t); ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 6.283); ctx.fill();
    }
  };
  return { start() { seed(); timer = setInterval(tick, 50); }, stop() { clearInterval(timer); } };
}

function runSplash() {
  const TITLE = "Darko's Windows Utility Tool";
  const sp = $('#splash'); sp.textContent = '';
  const canvas = h('canvas'); sp.append(canvas);
  const w = innerWidth;
  const fontSize = Math.max(16, Math.min(26, Math.floor(w / 40)));
  const ty = h('div', { class: 'ty', style: { fontSize: fontSize + 'px' } });
  const sub = h('div', { class: 'sub', text: 'DWUT', style: { fontSize: Math.max(9, fontSize - 7) + 'px' } });
  const cpy = h('div', { text: 'Copyright © 2026 Darko / Darko.Dev', style: { position: 'absolute', left: '0', right: '0', bottom: '16px', textAlign: 'center', fontSize: '11px', color: 'var(--text_secondary)', opacity: '.8', zIndex: '2' } });
  sp.append(ty, sub, cpy);
  if (window.Slime) { const sl = h('div', { class: 'slime-splash', style: 'top:calc(46% - 122px)' }); sl.append(Slime.create({ size: 120 }).el); sp.append(sl); }
  // centre using the full-string width (like the original measure())
  const probe = h('span', { text: TITLE + '|', style: { position: 'absolute', visibility: 'hidden', fontFamily: 'Consolas,monospace', fontWeight: '700', fontSize: fontSize + 'px', whiteSpace: 'pre' } });
  document.body.append(probe); const fullW = probe.offsetWidth; probe.remove();
  ty.style.left = Math.max((w - fullW) / 2, 12) + 'px';
  const field = Starfield(canvas, Theme.tokens.bg_shell, Theme.tokens.accent);
  field.start();
  let i = 0, on = true, closed = false, tmr;
  const type = () => {
    if (closed) return;
    if (i <= TITLE.length) { ty.textContent = TITLE.slice(0, i) + (on ? '|' : ' '); i++; tmr = setTimeout(type, 45); }
    else blink();
  };
  const blink = () => { if (closed) return; on = !on; ty.textContent = TITLE + (on ? '|' : ' '); tmr = setTimeout(blink, 420); };
  setTimeout(type, 150);
  const t0 = Date.now();
  return async function dismiss() {
    if (closed) return;
    const elapsed = Date.now() - t0;
    if (elapsed < 2800) await sleep(2800 - elapsed);
    closed = true; clearTimeout(tmr); sp.style.opacity = '0';
    await sleep(260);
    field.stop(); sp.remove();
  };
}

// ── boot ─────────────────────────────────────────────────────────────────────
(async function boot() {
  Theme.apply(localStorage.getItem('dwut_theme') || 'dark');
  buildTitlebar();
  const dismissSplash = runSplash();
  let cfg = null;
  for (let i = 0; i < 60 && !cfg; i++) {
    try { cfg = await Cfg.load(); } catch { await sleep(500); }
  }
  if (!cfg) { document.body.append(h('div', { style: 'position:absolute;inset:60px;color:#f66', text: 'Could not reach the DWUT backend. See %APPDATA%\\DWUT\\logs\\electron-backend.log' })); return; }
  Theme.apply(cfg.theme);
  Theme._mono = cfg.ui_font_mono || ''; Theme._colors = cfg.ui_text_colors || {};
  Theme.typography(cfg.ui_font || null, cfg.ui_font_scale || 1, cfg.ui_text_color || '');
  Theme._applyExtra(false);
  Nav.isAdmin = !!cfg.is_admin; Nav.sidebarCollapsed = !!cfg.sidebar_collapsed;
  try { window.OS = await rpc('system.os_info'); } catch { window.OS = null; }   // family / edition / version / build for OS-specific UI
  Sidebar.build();

  on('app.update_available', showUpdateBanner);
  on('backend.crashed', () => console.warn('backend restarted'));

  const start = 'dashboard';      // the program always opens on the Dashboard (the command hub)
  Nav.go(start);          // page builds underneath the splash

  // Wait for 2 animation frames so the entire UI and start page are painted before revealing
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

  // Smoothly fade out splash over fully-rendered app
  await dismissSplash();
  try { window.FX && FX.open(Nav.pages[start].root, true); window.Mascot && Mascot.start(); } catch (e) { console.error('intro', e); }

  // Remembered settings: reconnect the VPN (if the user enabled it) and resume the network monitor.
  setTimeout(() => { rpc('vpn.autostart_run').catch(() => {}); rpc('netmon.autostart_run').catch(() => {}); }, 1500);

  // Pre-build every other page in the background (one per idle frame) so
  // first-click navigation is always instant -- no factory call on the critical path.
  const idle = window.requestIdleCallback || ((fn) => setTimeout(fn, 16));
  const remaining = NAV_ITEMS.map(n => n[0]).filter(n => n !== start);
  let ri = 0;
  function buildNext() {
    if (ri >= remaining.length) return;
    Nav._build(remaining[ri++]);
    idle(buildNext);
  }
  idle(buildNext);
})();
