// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* Personalisation - sidebar animations, button-click animations, click sounds (+ your own), animated / image / GIF backgrounds with
   particle themes, and music-reactive backgrounds (browsers + games only).  Free for everyone.

   Settings live in localStorage 'dwut_cosmetics' so the Task Manager and Run window (same origin) follow them live. */
const Cosmetics = (() => {
  const KEY = 'dwut_cosmetics';
  const SB     = { none:'None', slide:'Slide', glow:'Glow pulse', sweep:'Light sweep', neon:'Neon bar', bounce:'Bounce', wave:'Wave-in', pulse:'Heartbeat pulse', matrix:'Matrix scanline', fire:'Fire shimmer', ripple:'Glow ripple', shimmer:'Silver shimmer', electric:'Cyber electric', 'fade-up':'Fade-up float' };
  const SBTOG  = { smooth:'Smooth', elastic:'Elastic spring', fade:'Fade', blur:'Blur fade', none:'Instant' };
  const CLICK  = { none:'None', ripple:'Ripple', ring:'Pulse rings', burst:'Spark burst', pop:'Pop', glitch:'Glitch', shockwave:'Shockwave', trail:'Spark trail' };
  const SOUND  = { off:'Off', soft:'Soft click', pop:'Pop', blip:'Blip', mech:'Mechanical', chime:'Chime', bubble:'Bubble', zap:'Zap', crystal:'Crystal', thunk:'Thunk', whoosh:'Whoosh', tick:'Tick', laser:'Laser', custom:'My own sound' };
  const MODES = { default: 'Default (follows my theme)', gradient: 'Animated gradient', media: 'My own image / GIF / video' };
  const PARTS = { stars: 'Stars', sakura: 'Sakura petals', cherry: 'Cherry blossoms', embers: 'Fire embers', rain: 'Rain', leaves: 'Weed leaves', snow: 'Snow', fireflies: 'Fireflies', none: 'No particles' };
  const PART_COLORS = { stars: '#ffffff', sakura: '#ffb7c5', cherry: '#ff7597', embers: '#ff5a1a', rain: '#b9cdff', leaves: '#4ade80', snow: '#ffffff', fireflies: '#beff78' };
  const PART_NAMES  = { stars: 'Star', sakura: 'Sakura petal', cherry: 'Cherry petal', embers: 'Ember', rain: 'Rain', leaves: 'Leaf', snow: 'Snow', fireflies: 'Firefly' };
  const PRESETS = { aurora: 'Aurora', sunset: 'Sunset', ocean: 'Ocean', neon: 'Neon', forest: 'Forest', candy: 'Candy', fire: 'Fire', galaxy: 'Galaxy', theme: 'Match my theme', custom: 'Custom colours' };
  const invert = (o) => Object.fromEntries(Object.entries(o).map(([k, v]) => [v, k]));

  const DEFAULTS = () => ({
    sb: 'sweep', sbToggle: 'elastic', click: 'glitch', sound: { preset: 'soft', custom: '', volume: 0.5 },
    bg: { mode: 'default', preset: 'aurora', colors: ['#ff3df0', '#03e1ff', '#7a5cff'], speed: 1, particleSpeed: 1, particles: 'stars', density: 1, media: '', dim: 0.35, audio: false, syncDelay: 0, mousePush: false, emberColor: '', particleColors: {}, bgOpacity: 1, bgBrightness: 1, bgTransparency: 1, transparency: 0 },
  });
  let S = DEFAULTS();

  function sanitize(obj) {
    if (!obj || typeof obj !== 'object') return DEFAULTS();
    const d = DEFAULTS();
    const res = Object.assign(d, obj);
    res.sound = Object.assign(d.sound, obj.sound || {});
    res.bg = Object.assign(d.bg, obj.bg || {});
    if (res.bg.particleSpeed == null) res.bg.particleSpeed = 1;
    // Migrate old bgOpacity -> bgBrightness
    if (res.bg.bgOpacity != null && res.bg.bgBrightness == null) res.bg.bgBrightness = res.bg.bgOpacity;
    if (res.bg.bgBrightness == null) res.bg.bgBrightness = 1;
    // Forward / backward compatibility for transparency (0 = solid, 0.85 = ghost):
    if (res.bg.transparency == null) {
      if (res.bg.bgTransparency != null && res.bg.bgTransparency <= 1) {
        res.bg.transparency = Math.max(0, Math.min(0.85, 1 - res.bg.bgTransparency));
      } else {
        res.bg.transparency = 0;
      }
    }
    res.bg.bgTransparency = 1 - res.bg.transparency;
    if (!Array.isArray(res.bg.colors) || res.bg.colors.length < 3) {
      res.bg.colors = ['#ff3df0', '#03e1ff', '#7a5cff'];
    }
    return res;
  }

  function load() {
    try {
      const j = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (j) S = sanitize(j);
    } catch { S = DEFAULTS(); }
  }

  let _saveTimer = null;
  function pushTheme() { try { if (window.Theme && window.Theme.push) window.Theme.push(); } catch {} }   // tells the other windows (reads the saved prefs, so it runs AFTER save)
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* quota */ }
    try { rpc('cosmetics.set_prefs', { prefs: S }).catch(() => {}); } catch { /* offline */ }
  }
  function saveDebounced() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; save(); pushTheme(); }, 250);
  }

  // ---- applying ----
  function apply() {
    document.documentElement.dataset.sbAnim   = S.sb || 'sweep';
    document.documentElement.dataset.sbToggle = S.sbToggle || 'elastic';
    document.documentElement.dataset.clickAnim = S.click || 'glitch';
    if (window.DwutBg) window.DwutBg.configure(S.bg);
    syncAudio();
  }
  let audioOn = false;
  function syncAudio() {
    const want = !!S.bg.audio;
    if (want === audioOn) return;
    audioOn = want;
    rpc('cosmetics.audio', { enable: want }).catch(() => {});
    if (!want && window.DwutBg) window.DwutBg.setAudio(0);
  }
  // While a slider is being dragged only the cheap live part runs (once per frame): apply().  Saving, the backend call and syncing the
  // other windows happen once, debounced / on release - doing them on every input event is what made the sliders stutter.
  let _applyRaf = 0;
  function commit(immediate = false) {
    if (immediate) {
      if (_saveTimer) { clearTimeout(_saveTimer); _saveTimer = null; }
      if (_applyRaf) { cancelAnimationFrame(_applyRaf); _applyRaf = 0; }
      save(); apply(); pushTheme();
    } else {
      saveDebounced();
      if (!_applyRaf) _applyRaf = requestAnimationFrame(() => { _applyRaf = 0; apply(); });
    }
  }

  // ---- click effects ----
  let fx = null;
  const layer = () => { if (!fx) { fx = document.createElement('div'); fx.id = 'fx-layer'; document.body.append(fx); } return fx; };
  const clickable = (el) => el && el.closest && el.closest('button, .btn, [role="button"], .theme-card, .sb-item, .tab, summary, select');
  function spawnFx(kind, x, y, target) {
    const L = layer();
    const mk = (cls, css) => { const d = document.createElement('div'); d.className = 'fx ' + cls; d.style.left = x + 'px'; d.style.top = y + 'px'; if (css) d.style.cssText += css; L.append(d); setTimeout(() => d.remove(), 900); return d; };
    if (kind === 'ripple') mk('fx-ripple');
    else if (kind === 'ring') { mk('fx-ring'); mk('fx-ring r2'); }
    else if (kind === 'burst') { for (let i = 0; i < 12; i++) { const a = (i / 12) * 6.283 + Math.random() * .4, d = 22 + Math.random() * 26; mk('fx-spark', `--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d}px`); } }
    else if (kind === 'pop' || kind === 'glitch') { const el = clickable(target); if (el) { const c = 'fx-' + kind; el.classList.remove(c); void el.offsetWidth; el.classList.add(c); setTimeout(() => el.classList.remove(c), 340); } }
    else if (kind === 'shockwave') { mk('fx-shockwave'); mk('fx-shockwave s2'); mk('fx-shockwave s3'); }
    else if (kind === 'trail') { for (let i = 0; i < 10; i++) { const ang = (i / 10) * 360; const dist = 24 + Math.random() * 20; mk('fx-trail', `--ang:${ang}deg;--dist:${dist};animation-delay:${i * 0.025}s`); } }
  }

  // ---- click sounds ----
  let actx = null;
  function tone(freq, dur, type = 'sine', vol = 0.25, slideTo = null, when = 0) {
    const t0 = actx.currentTime + when, o = actx.createOscillator(), g = actx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t0); if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol * S.sound.volume * 2), t0 + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(actx.destination); o.start(t0); o.stop(t0 + dur + 0.02);
  }
  function noise(dur, vol, hp = 1500) {
    const n = Math.floor(actx.sampleRate * dur), buf = actx.createBuffer(1, n, actx.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const s = actx.createBufferSource(), f = actx.createBiquadFilter(), g = actx.createGain();
    f.type = 'highpass'; f.frequency.value = hp; g.gain.value = vol * S.sound.volume * 2; s.buffer = buf; s.connect(f).connect(g).connect(actx.destination); s.start();
  }
  const customCache = {};
  function playSound() {
    const p = S.sound.preset;
    if (p === 'off') return;
    if (p === 'custom') {
      if (!S.sound.custom) return;
      const url = window.DwutBg.fileUrl(S.sound.custom);
      const a = (customCache[url] = customCache[url] || new Audio(url));
      const c = a.cloneNode(true); c.volume = Math.min(1, S.sound.volume); c.play().catch(() => {}); return;
    }
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      if (actx.state === 'suspended') actx.resume();
      if (p === 'soft') tone(620, .07, 'sine', .22, 380);
      else if (p === 'pop') tone(260, .1, 'sine', .3, 80);
      else if (p === 'blip') tone(900, .05, 'square', .09);
      else if (p === 'mech') { noise(.04, .25, 2200); tone(130, .07, 'sine', .3, 70); }
      else if (p === 'chime') { tone(1047, .28, 'sine', .16); tone(1568, .34, 'sine', .1, null, .05); }
      else if (p === 'bubble') tone(320, .13, 'sine', .25, 950);
      else if (p === 'zap') { noise(.025, .35, 3500); tone(480, .08, 'sawtooth', .18, 80); }
      else if (p === 'crystal') { tone(2093, .22, 'sine', .12); tone(2637, .28, 'sine', .07, null, .04); tone(1760, .15, 'sine', .06, null, .09); }
      else if (p === 'thunk') { noise(.06, .4, 100); tone(90, .12, 'sine', .35, 50); }
      else if (p === 'whoosh') { noise(.12, .3, 600); tone(420, .14, 'sine', .18, 120); }
      else if (p === 'tick') tone(1800, .025, 'triangle', .28);
      else if (p === 'laser') tone(1400, .08, 'sawtooth', .2, 180);
    } catch { /* audio blocked */ }
  }

  document.addEventListener('pointerdown', (e) => {
    if (e.button > 0 || !clickable(e.target)) return;
    if (S.click !== 'none') spawnFx(S.click, e.clientX, e.clientY, e.target);
    playSound();
  }, true);

  // ---- boot ----
  let audioStatusEl = null;
  function init() {
    load(); apply();
    on('cosmetics.audio', (d) => { if (window.DwutBg && S.bg.audio) window.DwutBg.setAudio(d.level, d.beat, d.s, d.t); });
    on('cosmetics.audio_status', (d) => {
      if (audioStatusEl) {
        audioStatusEl.textContent = !S.bg.audio ? '' : (d.available === false ? d.paused : (d.paused || (d.source ? `Listening to ${d.source}` : 'Waiting for music...')));
      }
    });
    // Async load persistent settings from disk file (handles restarts / elevated relaunch)
    try {
      rpc('cosmetics.get_prefs').then((r) => {
        if (r && r.ok && r.prefs && typeof r.prefs === 'object' && Object.keys(r.prefs).length) {
          S = sanitize(r.prefs);
          try { localStorage.setItem(KEY, JSON.stringify(S)); } catch {}
          apply();
        }
      }).catch(() => {});
    } catch {}
  }

  // ====================================================================================================================
  // Settings panel
  // ====================================================================================================================
  function panel(openColorPicker) { return view(openColorPicker); }

  function view(openColorPicker) {
    const lbl = (t, tipText) => h('div', { class: 'row grow' }, h('span', { class: 'f11 ts', text: t }), tipText ? h('span', { style: 'margin-left:4px' }, Info(tipText)) : null);
    const row = (t, tipText, ...w) => h('div', { class: 'row', style: 'padding:4px 14px;gap:8px' }, lbl(t, tipText), ...w);
    const slider = (min, max, step, val, fn, opts = {}) => {
      const pct = (v) => Math.max(0, Math.min(100, (v - min) / (max - min) * 100)).toFixed(1) + '%';
      const formatVal = (v) => {
        if (opts.format) return opts.format(v);
        return Math.round(v * 100) === v * 100 ? (v * 100).toFixed(0) + '%' : v.toFixed(2);
      };
      // fixed width: the label text changes length while dragging (e.g. '69%' -> '70% Ghost'); a badge that resizes shifts the slider under the cursor and makes it jitter
      const valLbl = h('span', { class: 'slider-val-badge', text: formatVal(val), style: 'width:88px;min-width:88px;white-space:nowrap;box-sizing:border-box;font-variant-numeric:tabular-nums' });
      const inp = h('input', { type: 'range', class: 'slider', min, max, step, value: val,
        style: `width:${opts.w || 160}px;flex:none;--pct:${pct(val)}`,
        oninput: (e) => {
          const v = +e.target.value;
          inp.style.setProperty('--pct', pct(v));
          valLbl.textContent = formatVal(v);
          if (opts.chipsWrap) {
            opts.chipsWrap.querySelectorAll('.slider-chip').forEach(c => {
              c.classList.toggle('active', Math.abs(+c.dataset.val - v) < 0.03);
            });
          }
          fn(v);
        },
      });
      inp.addEventListener('change', () => { commit(true); });
      const controls = [inp, valLbl];
      if (opts.resetVal != null) {
        const resetBtn = h('button', {
          style: 'background:transparent;border:0;color:var(--text_disabled);cursor:pointer;padding:2px 5px;border-radius:4px;font-size:12px;line-height:1;transition:color .15s,transform .18s;flex:none',
          title: `Reset to ${formatVal(opts.resetVal)}`,
          onclick: () => {
            inp.value = opts.resetVal;
            inp.style.setProperty('--pct', pct(opts.resetVal));
            valLbl.textContent = formatVal(opts.resetVal);
            if (opts.chipsWrap) {
              opts.chipsWrap.querySelectorAll('.slider-chip').forEach(c => {
                c.classList.toggle('active', Math.abs(+c.dataset.val - opts.resetVal) < 0.03);
              });
            }
            fn(opts.resetVal);
          },
        }, '↺');
        resetBtn.addEventListener('mouseenter', () => { resetBtn.style.color = 'var(--accent)'; resetBtn.style.transform = 'rotate(-45deg)'; });
        resetBtn.addEventListener('mouseleave', () => { resetBtn.style.color = 'var(--text_disabled)'; resetBtn.style.transform = 'none'; });
        controls.push(resetBtn);
      }
      const wrap = h('div', { class: 'row', style: 'gap:8px;align-items:center;flex:none' }, ...controls);
      if (opts.chips && opts.chips.length) {
        const chipsWrap = h('div', { class: 'row', style: 'gap:4px;margin-top:4px' });
        opts.chipsWrap = chipsWrap;
        opts.chips.forEach(c => {
          const chip = h('button', {
            class: 'slider-chip' + (Math.abs(c.val - val) < 0.03 ? ' active' : ''),
            dataset: { val: c.val },
            text: c.label,
            onclick: () => {
              inp.value = c.val;
              inp.style.setProperty('--pct', pct(c.val));
              valLbl.textContent = formatVal(c.val);
              chipsWrap.querySelectorAll('.slider-chip').forEach(el => el.classList.remove('active'));
              chip.classList.add('active');
              fn(c.val);
            }
          });
          chipsWrap.append(chip);
        });
        return h('div', { class: 'col', style: 'align-items:flex-end;gap:2px;flex:none' }, wrap, chipsWrap);
      }
      return wrap;
    };
    const sect = (t) => h('div', { class: 'f10 b ts', style: 'padding:10px 14px 2px;letter-spacing:.8px;text-transform:uppercase', text: t });
    const pick = async (kind, filters) => {
      const f = await window.dwut.dialog.open({ properties: ['openFile'], filters });
      if (!f || !f.length) return null;
      const r = await rpc('cosmetics.import_asset', { path: f[0], kind });
      if (!r.ok) { fail('Import', r.error); return null; }
      return r.path;
    };

    // sidebar anim + toggle + click
    const sb    = Option(Object.values(SB),    { w:170, f:11, value:SB[S.sb],          onchange:() => { S.sb          = invert(SB)[sb.value];    commit(); } });
    const sbtog = Option(Object.values(SBTOG), { w:170, f:11, value:SBTOG[S.sbToggle || 'smooth'], onchange:() => { S.sbToggle = invert(SBTOG)[sbtog.value]; commit(); } });
    const ck    = Option(Object.values(CLICK), { w:170, f:11, value:CLICK[S.click],    onchange:() => { S.click        = invert(CLICK)[ck.value];  commit(); } });

    // sounds
    const snd = Option(Object.values(SOUND), { w: 170, f: 11, value: SOUND[S.sound.preset], onchange: () => { S.sound.preset = invert(SOUND)[snd.value]; commit(); if (S.sound.preset !== 'off') playSound(); } });
    const sndName = h('span', { class: 'f10 td', text: S.sound.custom ? S.sound.custom.split(/[\\/]/).pop().replace(/_[0-9a-f]{6}(\.[^.]+)$/, '$1') : 'No file imported' });
    const vol = slider(0, 1, 0.05, S.sound.volume, (v) => { S.sound.volume = v; save(); }, { resetVal: 0.5 });
    vol.addEventListener('change', () => playSound());

    // background
    const mode = Option(Object.values(MODES), { w: 240, f: 11, value: MODES[S.bg.mode], onchange: () => { S.bg.mode = invert(MODES)[mode.value]; commit(); paintBg(); } });
    const bgBody = h('div');
    function paintBg() {
      bgBody.textContent = '';
      const B = S.bg;
      if (B.mode === 'gradient') {
        const pre = Option(Object.values(PRESETS), { w: 170, f: 11, value: PRESETS[B.preset] || 'Aurora', onchange: () => { B.preset = invert(PRESETS)[pre.value]; commit(); paintBg(); } });
        bgBody.append(row('Gradient colours', 'The colours cycle and drift continuously, with the particles on top.', pre));
        if (B.preset === 'custom') {
          if (!Array.isArray(B.colors) || B.colors.length < 3) B.colors = ['#ff3df0', '#03e1ff', '#7a5cff'];
          const sw = h('div', { class: 'row', style: 'gap:6px' }, [0, 1, 2].map((i) => {
            const swBtn = h('button', {
              style: `width:38px;height:28px;border-radius:5px;border:2px solid var(--border);cursor:pointer;background:${B.colors[i] || '#888'}`,
              title: `Pick colour ${i + 1}`,
              onclick: () => {
                openColorPicker(B.colors[i] || '#888888', (c) => {
                  if (!c) return;
                  B.colors[i] = c;
                  swBtn.style.background = c;
                  commit();
                  paintBg();
                });
              }
            });
            return swBtn;
          }));
          const resetCols = Btn('Reset', { variant: 'ghost', h: 26, onclick: () => {
            B.colors = ['#ff3df0', '#03e1ff', '#7a5cff'];
            commit();
            paintBg();
          }});
          bgBody.append(row('Your colours', 'Click a swatch to change it.', sw, resetCols));
        }
        bgBody.append(row('Animation speed', 'How fast the colours move.', slider(0.2, 3, 0.1, B.speed, (v) => { B.speed = v; commit(); }, { resetVal: 1, format: (v) => v.toFixed(1) + 'x' })));
      }
      if (B.mode === 'media') {
        const nm = h('span', { class: 'f10 td', text: B.media ? B.media.split(/[\\/]/).pop().replace(/_[0-9a-f]{6}(\.[^.]+)$/, '$1') : 'Nothing chosen' });
        bgBody.append(row('Background file', 'PNG, JPG, GIF, WebP, MP4 or WebM. GIFs and videos play animated.', nm,
          Btn('Choose image / GIF / video...', { variant: 'ghost', h: 28, onclick: async () => { const p = await pick('image', [{ name: 'Images, GIFs and video', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'mp4', 'webm'] }]); if (p) { B.media = p; commit(); paintBg(); } } })));
        bgBody.append(row('Darken background', 'Dims your picture so the app stays readable.', slider(0, 0.85, 0.05, B.dim, (v) => { B.dim = v; commit(); }, { resetVal: 0.35 })));
      }
      if (B.mode !== 'default' || true) {
        const pt = Option(Object.values(PARTS), { w: 170, f: 11, value: PARTS[B.particles], onchange: () => { B.particles = invert(PARTS)[pt.value]; commit(); paintBg(); } });
        bgBody.append(row('Particles on top', 'The animation layered over the background.', pt));
        bgBody.append(row('Particle amount', 'More or fewer particles. Weak PCs thin them out automatically.', slider(0.2, 2.2, 0.1, B.density, (v) => { B.density = v; commit(); }, { resetVal: 1, format: (v) => v.toFixed(1) + 'x' })));
        bgBody.append(row('Particle speed', 'How fast particles move, drift and rotate across the screen.', slider(0.2, 3, 0.1, B.particleSpeed != null ? B.particleSpeed : 1, (v) => { B.particleSpeed = v; commit(); }, { resetVal: 1, format: (v) => v.toFixed(1) + 'x' })));
        // Particle colour — customisable for all particle types, using openColorPicker so it saves permanently
        if (B.particles && B.particles !== 'none') {
          B.particleColors = B.particleColors || {};
          if (B.particles === 'embers' && B.emberColor && !B.particleColors.embers) {
            B.particleColors.embers = B.emberColor;
          }
          const defaultColor = PART_COLORS[B.particles] || '#ffffff';
          const currentColor = B.particleColors[B.particles] || (B.particles === 'embers' ? B.emberColor : '') || defaultColor;
          const partName = PART_NAMES[B.particles] || 'Particle';

          const partSwatch = h('button', {
            style: `width:38px;height:28px;border-radius:5px;border:2px solid var(--border);cursor:pointer;background:${currentColor};position:relative;flex:none`,
            title: `Pick ${partName.toLowerCase()} colour`,
            onclick: () => {
              openColorPicker(currentColor, (c) => {
                B.particleColors[B.particles] = c;
                if (B.particles === 'embers') B.emberColor = c;
                partSwatch.style.background = c;
                commit();
                paintBg();
              });
            },
          });
          const resetPart = Btn('Reset', { variant: 'ghost', h: 26, onclick: () => {
            B.particleColors[B.particles] = '';
            if (B.particles === 'embers') B.emberColor = '';
            partSwatch.style.background = defaultColor;
            commit();
            paintBg();
          }});
          bgBody.append(row(`${partName} colour`, `The custom colour for ${PARTS[B.particles].toLowerCase()}. Click the swatch to customise.`, partSwatch, resetPart));
        }
        const au = Switch({ big: true, checked: !!B.audio, onchange: (val) => {
          B.audio = (val != null) ? !!val : au.checked;
          if (!B.audio && audioStatusEl) audioStatusEl.textContent = '';
          commit();
        } });
        const au2 = h('span', { class: 'f10 td', style: 'min-width:140px;display:inline-block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;vertical-align:middle;margin-left:8px' });
        audioStatusEl = au2;
        const auWrap = h('div', { class: 'row', style: 'align-items:center;flex-shrink:0' }, au, au2);
        bgBody.append(row('Sync with music', 'Particles pulse to the beat of whatever your PC is playing (kicks, snares and hats are detected separately).\n\nThe sound is analysed live in memory for volume and beats only - it is never recorded, saved or sent anywhere. Voice-call apps (Discord, Teams, Zoom ...) are never used: if only a call is audible, the sync pauses.', auWrap));
        const mp = Switch({ big: true, checked: !!B.mousePush, onchange: (val) => {
          B.mousePush = (val != null) ? !!val : mp.checked;
          commit();
        } });
        bgBody.append(row('Mouse particle push', 'When on, moving your mouse near the falling particles pushes them away (snow, petals, rain, embers, stars ... all of them). They drift back to their normal motion a moment later. Works in every DWUT window.', mp));
        const DL = [0, 25, 50, 80, 120, 180, 250];
        const dl = Option(DL.map((v) => (v ? `${v} ms later` : 'No delay')), { w: 140, f: 12, value: (B.syncDelay ? `${B.syncDelay} ms later` : 'No delay'),
          onchange: (v) => { B.syncDelay = parseInt(v, 10) || 0; commit(); } });
        dl.classList.add('bordered');
        bgBody.append(row('Visual delay', 'Normally leave this at No delay. If your speakers or Bluetooth headphones play the sound later than the PC captures it, the visuals can look slightly early - delay them here until the beat and the flash line up.', dl));
      }
    }

    const resetCosmetics = () => {
      S = DEFAULTS();
      commit();
      if (window.flash) window.flash('Personalization reset to default', 'var(--info)');
    };

    const head = h('div', { class: 'row', style: 'padding:12px 14px 4px;gap:10px;align-items:center' },
      h('span', { class: 'f13 b tp', text: 'Personalization' }),
      h('div', { class: 'grow' }),
      Btn('Reset to Default', { variant: 'ghost', h: 26, onclick: resetCosmetics, title: 'Reset all personalization settings to factory defaults' })
    );

    const body = Card([head,
      sect('Interface'),
      row('Menu bar animation',    'Animation on the sidebar buttons when hovering or navigating.', sb),
      row('Button click animation', 'Effect when you click a button.', ck),
      sect('Click sound'),
      row('Sound', 'A sound on every button click.', snd),
      row('Your own sound', 'WAV, MP3 or OGG up to 8 MB.', sndName, Btn('Import sound...', { variant: 'ghost', h: 28, onclick: async () => { const p = await pick('sound', [{ name: 'Audio', extensions: ['wav', 'mp3', 'ogg', 'm4a', 'flac'] }]); if (p) { S.sound.custom = p; S.sound.preset = 'custom'; snd.set(SOUND.custom, true); sndName.textContent = p.split(/[\/\\]/).pop().replace(/_[0-9a-f]{6}(\.[^.]+)$/, '$1'); commit(); playSound(); } } })),
      row('Volume', 'Click sound volume.', vol),
      sect('Background'),
      row('Background', 'The animated layer behind the whole app (also in the Task Manager and Run window).', mode),
      row('Background brightness', 'Makes the gradient or background picture brighter or darker. Particles always stay fully visible on top regardless of this setting.',
        slider(0, 1, 0.01, S.bg.bgBrightness != null ? S.bg.bgBrightness : 1, (v) => { S.bg.bgBrightness = v; commit(); }, { resetVal: 1 })),
      row('Background transparency', 'Makes the entire app window transparent so you can see your desktop wallpaper behind it. Slide right for more transparency.',
        slider(0, 0.85, 0.01, S.bg.transparency != null ? S.bg.transparency : 0, (v) => {
          S.bg.transparency = v;
          S.bg.bgTransparency = 1 - v;
          commit();
        }, {
          resetVal: 0,
          format: (v) => (v <= 0.01 ? 'Solid (0%)' : (v >= 0.70 ? (v * 100).toFixed(0) + '% Ghost' : (v * 100).toFixed(0) + '%')),
          chips: [
            { label: 'Solid (0%)', val: 0.0 },
            { label: 'Subtle (20%)', val: 0.20 },
            { label: 'Glass (35%)', val: 0.35 },
            { label: 'Ghost (60%)', val: 0.60 },
          ],
        })),
      bgBody,
      h('div', { style: 'height:10px' })], 'col', { marginBottom: '12px' });
    paintBg();
    return body;
  }

  return { init, panel, state: () => S };
})();
Cosmetics.init();
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => Cosmetics.init());
