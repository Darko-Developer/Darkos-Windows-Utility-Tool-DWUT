// Copyright © 2026 Darko / Darko.Dev
'use strict';
/* The hub at the top of the Dashboard.  Ten category tiles arranged around a live "core"
   (rotating HUD rings + CPU / RAM / DISK gauges) where the slime mascot lives.
   Clicking the slime triggers the Game Boost flow. */
(function () {
  const TILES = [
    ['optimizer', 'Optimizer', 'SFC · DISM · network reset · repair tools'],
    ['gaming', 'Game Booster', 'Process priority · power plan · FPS unlock'],
    ['debloat', 'Debloat', 'Bloatware · telemetry · privacy · Recall'],
    ['vpn', 'VPN', 'Secure tunnel · kill switch · DNS leak guard'],
    ['network', 'Network Monitor', 'Live connections · latency · blocked IPs'],
    ['usb', 'USB Flasher', 'Write ISOs · Ventoy · restore sticks'],
    ['vm', 'VM Builder', 'Build and set up virtual machines'],
    ['tools', 'Tools', 'Health scan · registry · disk cleanup · shells'],
    ['cleaner', 'Cleaner', 'Multi-phase deep clean with wrap-up'],
    ['bios', 'BIOS & Firmware', 'XMP · Resizable BAR · updates · tweaks'],
    ['profiles', 'Game Profiles', 'NVIDIA + Windows profiles for your games'],
    ['settings', 'Settings', 'Themes · personalization · typography'],
  ];
  const NS = 'http://www.w3.org/2000/svg';
  const svgEl = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };
  const C = 170, SWEEP = 0.66;

  function build(go) {
    const root = document.createElement('section'); root.className = 'hub';
    const left = document.createElement('div'), right = document.createElement('div');
    left.className = 'hub-col l'; right.className = 'hub-col r';
    const tiles = {};
    TILES.forEach(([key, name, desc], i) => {
      const slot = document.createElement('div'); slot.className = 'hub-slot'; slot.style.setProperty('--i', String(i % 6));
      const t = document.createElement('button'); t.className = 'hub-tile'; t.dataset.key = key; t.type = 'button';
      t.innerHTML = `<i class="ht-n">${String(i + 1).padStart(2, '0')}</i><span class="ht-t"><b></b><small></small></span><i class="ht-led"></i><i class="ht-arrow"></i>`;
      t.querySelector('b').textContent = name; t.querySelector('small').textContent = desc;
      t.addEventListener('click', () => { t.classList.add('lock'); setTimeout(() => t.classList.remove('lock'), 600); if (window.Mascot) Mascot.lookAtEl(t); setTimeout(() => go(key), 170); });
      t.addEventListener('pointerenter', () => { root.classList.add('hot'); if (window.Mascot) Mascot.lookAtEl(t); });
      t.addEventListener('pointerleave', () => { root.classList.remove('hot'); if (window.Mascot) Mascot.lookAtEl(null); });
      slot.append(t); tiles[key] = t; (i < 6 ? left : right).append(slot);
    });

    // ── the core ──
    const core = document.createElement('div'); core.className = 'hub-core';
    const svg = svgEl('svg', { class: 'core-svg', viewBox: '0 0 340 340' });
    const defs = svgEl('defs', {});
    defs.innerHTML = `<linearGradient id="hubSweep" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="var(--accent)" stop-opacity="0"/><stop offset="1" stop-color="var(--accent)" stop-opacity=".55"/></linearGradient>
      <radialGradient id="hubDisc" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="var(--accent)" stop-opacity=".16"/><stop offset=".7" stop-color="var(--accent)" stop-opacity=".05"/><stop offset="1" stop-color="var(--accent)" stop-opacity="0"/></radialGradient>`;
    svg.append(defs);
    svg.append(svgEl('circle', { cx: C, cy: C, r: 112, fill: 'url(#hubDisc)' }));
    const spinA = svgEl('g', { class: 'core-spin a' });
    spinA.append(svgEl('circle', { cx: C, cy: C, r: 164, fill: 'none', stroke: 'var(--accent)', 'stroke-opacity': '.38', 'stroke-width': '1', 'stroke-dasharray': '3 11' }));
    for (let a = 0; a < 360; a += 30) {
      const r1 = 158, r2 = a % 90 === 0 ? 148 : 153, rad = a * Math.PI / 180;
      spinA.append(svgEl('line', { x1: C + r1 * Math.cos(rad), y1: C + r1 * Math.sin(rad), x2: C + r2 * Math.cos(rad), y2: C + r2 * Math.sin(rad), stroke: 'var(--accent)', 'stroke-opacity': a % 90 === 0 ? '.9' : '.45', 'stroke-width': a % 90 === 0 ? '2' : '1' }));
    }
    svg.append(spinA);
    const spinB = svgEl('g', { class: 'core-spin b' });
    spinB.append(svgEl('circle', { cx: C, cy: C, r: 104, fill: 'none', stroke: 'var(--info)', 'stroke-opacity': '.45', 'stroke-width': '1.2', 'stroke-dasharray': '1 7' }));
    spinB.append(svgEl('path', { d: `M ${C - 104} ${C} A 104 104 0 0 1 ${C} ${C - 104}`, fill: 'none', stroke: 'var(--accent)', 'stroke-opacity': '.8', 'stroke-width': '2', 'stroke-linecap': 'round' }));
    svg.append(spinB);

    const gauges = {};
    [['cpu', 'CPU', 140], ['ram', 'RAM', 128], ['disk', 'DISK', 116]].forEach(([k, label, r], gi) => {
      const circ = 2 * Math.PI * r;
      const g = svgEl('g', { class: 'core-gauge', transform: `rotate(151.2 ${C} ${C})`, style: `--gi:${gi}` });
      g.append(svgEl('circle', { cx: C, cy: C, r, fill: 'none', stroke: 'var(--border)', 'stroke-opacity': '.8', 'stroke-width': '5', 'stroke-dasharray': `${circ * SWEEP} ${circ}`, 'stroke-linecap': 'round' }));
      const val = svgEl('circle', { class: 'gv', cx: C, cy: C, r, fill: 'none', stroke: 'var(--accent)', 'stroke-width': '5', 'stroke-dasharray': `0 ${circ}`, 'stroke-linecap': 'round' });
      g.append(val); svg.append(g);
      gauges[k] = { val, circ, label };
    });
    core.append(svg);

    const slot = document.createElement('div'); slot.className = 'core-slot'; core.append(slot);

    const readout = document.createElement('div'); readout.className = 'core-read';
    readout.innerHTML = [['cpu','CPU'],['ram','RAM'],['disk','DISK'],['health','HEALTH'],['gpu','GPU'],['stor','STORAGE'],['ctemp','CPU °C'],['gtemp','GPU °C']]
      .map(([k,l]) => `<span data-k="${k}"><i>${l}</i><b>--</b></span>`).join('');
    core.append(readout);

    // "CLICK TO BOOST" hint — replaces the old button
    const boostHint = document.createElement('div');
    boostHint.className = 'core-boost-hint';
    boostHint.textContent = 'CLICK TO BOOST';
    core.append(boostHint);

    // Single root assembly
    root.append(left, core, right);

    // pointer parallax
    let raf = 0, pe = null;
    root.addEventListener('pointermove', (e) => {
      pe = e; if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const r = root.getBoundingClientRect();
        root.style.setProperty('--px', (((pe.clientX - r.left) / r.width) * 2 - 1).toFixed(3));
        root.style.setProperty('--py', (((pe.clientY - r.top) / r.height) * 2 - 1).toFixed(3));
      });
    });

    const setGauge = (k, pct) => {
      const g = gauges[k]; if (!g || pct == null || isNaN(pct)) return;
      const f = Math.max(0, Math.min(100, pct)) / 100;
      g.val.setAttribute('stroke-dasharray', `${g.circ * SWEEP * f} ${g.circ}`);
      g.val.classList.toggle('hi', pct >= 85);
    };
    const setTxt = (k, t) => { const b = readout.querySelector(`[data-k="${k}"] b`); if (b) b.textContent = t; };

    // Boost logic — triggered by clicking the slime / core-slot
    function doBoost() {
      try {
        Nav._build('gaming');
        const g = Nav.pages.gaming;
        if (g && g.openBoost) g.openBoost();
      } catch (e) { fail('Boost', e.message); }
    }
    window.runGameBooster = doBoost;

    slot.style.cursor = 'pointer';
    slot.title = 'Click the slime to Boost — same as Game Booster page';
    slot.addEventListener('click', () => doBoost());

    return {
      el: root, tiles, slot,
      update(snap, health) {
        if (!snap) return;
        setGauge('cpu', snap.cpu_pct); setGauge('ram', snap.ram_pct); setGauge('disk', snap.disk_active_pct);
        const pc = (v) => (v != null && !isNaN(v) ? Number(v).toFixed(0) + '%' : '--');
        const dg = (v) => (v != null && !isNaN(v) ? Number(v).toFixed(0) + '°' : '--');
        const g = snap.gpu || null;
        setTxt('gpu', g ? pc(g.usage_pct) : '--'); setTxt('stor', pc(snap.disk_pct));
        setTxt('ctemp', dg(snap.cpu_temp_c)); setTxt('gtemp', g ? dg(g.temp_c) : '--');
        setTxt('cpu', snap.cpu_pct != null ? snap.cpu_pct.toFixed(0) + '%' : '--');
        setTxt('ram', snap.ram_pct != null ? snap.ram_pct.toFixed(0) + '%' : '--');
        setTxt('disk', snap.disk_active_pct != null ? snap.disk_active_pct.toFixed(0) + '%' : '--');
        if (health) setTxt('health', health.total + '%');
        window.__sys = {
          cpu:        snap.cpu_pct,
          ram:        snap.ram_pct,
          disk:       snap.disk_active_pct,
          gpu:        g ? g.usage_pct : null,
          cpu_temp_c: snap.cpu_temp_c,
          gpu_temp_c: g ? g.temp_c : null,
          net_recv:   snap.net_recv_mbps,
          net_send:   snap.net_send_mbps,
        };
      },
    };
  }
  window.Hub = { build, TILES };
})();
