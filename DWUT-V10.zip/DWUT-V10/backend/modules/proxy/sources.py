# Copyright © 2026 Darko / Darko.Dev
"""
modules/proxy/sources.py

Proxy fetcher.  Downloads many public lists in parallel, then PRIORITISES them:

  * a proxy listed by several independent sources is far more likely to be alive than one that appears once,
  * small maintained lists ("curated") are checked far more often than giant unchecked dumps ("bulk"),
  * bulk dumps are only SAMPLED -- they are hundreds of thousands of lines of mostly dead entries.

The protocol label of a source is only a HINT (free lists mislabel constantly); the checker auto-detects the real one.
"""

from __future__ import annotations

import json
import random
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Optional

import requests

from core.events import Events, bus
from core.logger import get_logger
from modules.proxy.ports import is_blocked_port

_log = get_logger(__name__)

_GH = "https://raw.githubusercontent.com/"


def _gh(path: str, protocol: str, tier: str = "curated") -> dict:
    return {"url": _GH + path, "protocol": protocol, "tier": tier}


def _api(url: str, protocol: str) -> dict:
    return {"url": url, "protocol": protocol, "tier": "curated"}


# curated = small / maintained / usually pre-checked; bulk = giant dumps (sampled)
_SOURCES: list[dict] = [
    # Live verified API endpoints (updated continuously with high-uptime proxies)
    _api("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=1500&country=all", "socks5"),
    _api("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=1500&country=all&ssl=yes", "http"),
    _api("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=1500&country=all", "socks4"),
    _gh("hookzof/socks5_list/master/proxy.txt", "socks5"),
    # TheSpeedX
    _gh("TheSpeedX/PROXY-List/master/http.txt", "http"),
    _gh("TheSpeedX/PROXY-List/master/socks4.txt", "socks4"),
    _gh("TheSpeedX/PROXY-List/master/socks5.txt", "socks5"),
    # monosans
    _gh("monosans/proxy-list/main/proxies/all.txt", "socks5"),
    _gh("monosans/proxy-list/main/proxies/http.txt", "http"),
    _gh("monosans/proxy-list/main/proxies/socks4.txt", "socks4"),
    _gh("monosans/proxy-list/main/proxies/socks5.txt", "socks5"),
    # proxifly
    _gh("proxifly/free-proxy-list/main/proxies/protocols/http/data.txt", "http"),
    _gh("proxifly/free-proxy-list/main/proxies/protocols/socks4/data.txt", "socks4"),
    _gh("proxifly/free-proxy-list/main/proxies/protocols/socks5/data.txt", "socks5", "bulk"),
    # jetkai
    _gh("jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt", "http"),
    _gh("jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt", "socks4"),
    _gh("jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt", "socks5"),
    # vmheaven
    _gh("vmheaven/VMHeaven-Free-Proxy-Updated/main/http.txt", "http"),
    _gh("vmheaven/VMHeaven-Free-Proxy-Updated/main/socks4.txt", "socks4"),
    _gh("vmheaven/VMHeaven-Free-Proxy-Updated/main/socks5.txt", "socks5"),
    # r00tee
    _gh("r00tee/Proxy-List/main/Https.txt", "http"),
    _gh("r00tee/Proxy-List/main/Socks4.txt", "socks4"),
    _gh("r00tee/Proxy-List/main/Socks5.txt", "socks5"),
    # vakhov / ALIILAPRO / rdavydov / mmpx12 / roosterkid
    _gh("vakhov/fresh-proxy-list/master/http.txt", "http"),
    _gh("vakhov/fresh-proxy-list/master/https.txt", "http"),
    _gh("vakhov/fresh-proxy-list/master/socks4.txt", "socks4"),
    _gh("vakhov/fresh-proxy-list/master/socks5.txt", "socks5"),
    _gh("ALIILAPRO/Proxy/main/http.txt", "http"),
    _gh("ALIILAPRO/Proxy/main/socks4.txt", "socks4"),
    _gh("ALIILAPRO/Proxy/main/socks5.txt", "socks5"),
    _gh("rdavydov/proxy-list/main/proxies/http.txt", "http"),
    _gh("rdavydov/proxy-list/main/proxies/socks4.txt", "socks4"),
    _gh("rdavydov/proxy-list/main/proxies/socks5.txt", "socks5"),
    _gh("mmpx12/proxy-list/master/http.txt", "http"),
    _gh("mmpx12/proxy-list/master/socks5.txt", "socks5"),
    _gh("roosterkid/openproxylist/main/HTTPS_RAW.txt", "http"),
    _gh("roosterkid/openproxylist/main/SOCKS4_RAW.txt", "socks4"),
    _gh("roosterkid/openproxylist/main/SOCKS5_RAW.txt", "socks5"),
    # verified / pre-checked collections
    _gh("elliottophellia/yakumo/master/results/http/global/http_checked.txt", "http"),
    _gh("elliottophellia/yakumo/master/results/socks4/global/socks4_checked.txt", "socks4"),
    _gh("elliottophellia/yakumo/master/results/socks5/global/socks5_checked.txt", "socks5"),
    _gh("ClearProxy/checked-proxy-list/main/http/raw/all.txt", "http"),
    _gh("ClearProxy/checked-proxy-list/main/socks4/raw/all.txt", "socks4"),
    _gh("ClearProxy/checked-proxy-list/main/socks5/raw/all.txt", "socks5"),
    _gh("Skillter/ProxyGather/master/proxies/working-proxies-all.txt", "http"),
    _gh("iplocate/free-proxy-list/main/protocols/http.txt", "http"),
    _gh("iplocate/free-proxy-list/main/protocols/socks4.txt", "socks4"),
    _gh("iplocate/free-proxy-list/main/protocols/socks5.txt", "socks5"),
    # misc maintained lists
    _gh("zloi-user/hideip.me/main/http.txt", "http"),
    _gh("zloi-user/hideip.me/main/socks4.txt", "socks4"),
    _gh("zloi-user/hideip.me/main/socks5.txt", "socks5"),
    _gh("Zaeem20/FREE_PROXIES_LIST/master/http.txt", "http"),
    _gh("Zaeem20/FREE_PROXIES_LIST/master/https.txt", "http"),
    _gh("Zaeem20/FREE_PROXIES_LIST/master/socks4.txt", "socks4"),
    _gh("Zaeem20/FREE_PROXIES_LIST/master/socks5.txt", "socks5"),
    _gh("Vann-Dev/proxy-list/main/proxies/http.txt", "http"),
    _gh("Vann-Dev/proxy-list/main/proxies/socks4.txt", "socks4"),
    _gh("Vann-Dev/proxy-list/main/proxies/socks5.txt", "socks5"),
    _gh("B4RC0DE-TM/proxy-list/main/HTTP.txt", "http"),
    _gh("B4RC0DE-TM/proxy-list/main/SOCKS4.txt", "socks4"),
    _gh("B4RC0DE-TM/proxy-list/main/SOCKS5.txt", "socks5"),
    _gh("prxchk/proxy-list/main/http.txt", "http"),
    _gh("prxchk/proxy-list/main/socks4.txt", "socks4"),
    _gh("prxchk/proxy-list/main/socks5.txt", "socks5"),
    _gh("ShiftyTR/Proxy-List/master/proxy.txt", "http"),
    _gh("ShiftyTR/Proxy-List/master/socks4.txt", "socks4"),
    _gh("ShiftyTR/Proxy-List/master/socks5.txt", "socks5"),
    _gh("clarketm/proxy-list/master/proxy-list-raw.txt", "http"),
    _gh("sunny9577/proxy-scraper/master/proxies.txt", "http"),
    _gh("hendrikbgr/Free-Proxy-Repo/master/proxy_list.txt", "http"),
    _gh("saisuiu/Lionkings-Http-Proxys-Proxies/main/free.txt", "http"),
    _gh("almroot/proxylist/master/list.txt", "http"),
    _gh("andigwandi/free-proxy/main/proxy_list.txt", "http"),
    _gh("themiralay/Proxy-List-World/master/data.txt", "http"),
    _gh("MrMarble/proxy-list/main/all.txt", "http"),
    _gh("dpangestuw/Free-Proxy/main/http_proxies.txt", "http"),
    _gh("dpangestuw/Free-Proxy/main/socks4_proxies.txt", "socks4"),
    _gh("dpangestuw/Free-Proxy/main/socks5_proxies.txt", "socks5"),
    _gh("Anonym0usWork1221/Free-Proxies/master/proxy_files/http_proxies.txt", "http"),
    _gh("TuanMinPay/live-proxy/master/http.txt", "http"),
    _gh("TuanMinPay/live-proxy/master/socks4.txt", "socks4"),
    _gh("ObcbO/getproxy/master/file/http.txt", "http"),
    _gh("ObcbO/getproxy/master/file/socks4.txt", "socks4"),
    # more live APIs
    _api("https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=ipport&format=text&protocol=http", "http"),
    _api("https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=ipport&format=text&protocol=socks4", "socks4"),
    _api("https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&proxy_format=ipport&format=text&protocol=socks5", "socks5"),
    _api("https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=250&country=all&ssl=all&anonymity=elite", "http"),
    _api("https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=250&country=all&ssl=yes&anonymity=all", "http"),
    _api("https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=250&country=all", "socks5"),
    _api("https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4&timeout=250&country=all", "socks4"),
    _api("https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=latency&sort_type=asc&speed=fast&filterUpTime=90&protocols=socks5", "socks5"),
    _api("https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=latency&sort_type=asc&speed=fast&filterUpTime=90&protocols=http,https", "http"),
    _api("https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=8000&country=all&ssl=all&anonymity=all", "http"),
    _api("https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4&timeout=8000&country=all", "socks4"),
    _api("https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=8000&country=all", "socks5"),
    _api("https://www.proxy-list.download/api/v1/get?type=http", "http"),
    _api("https://www.proxy-list.download/api/v1/get?type=socks4", "socks4"),
    _api("https://www.proxy-list.download/api/v1/get?type=socks5", "socks5"),
    _api("https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=lastChecked&sort_type=desc&protocols=http,https", "http"),
    _api("https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=lastChecked&sort_type=desc&protocols=socks4", "socks4"),
    _api("https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=lastChecked&sort_type=desc&protocols=socks5", "socks5"),
    # openproxylist
    _api("https://openproxylist.xyz/http.txt", "http"),
    _api("https://openproxylist.xyz/socks4.txt", "socks4"),
    _api("https://openproxylist.xyz/socks5.txt", "socks5"),
    # freeproxy.world top 200 fast
    _api("https://www.freeproxy.world/?type=http&anonymity=&country=&speed=b&port=&page=1", "http"),
    _api("https://www.freeproxy.world/?type=socks5&anonymity=&country=&speed=b&port=&page=1", "socks5"),
    # pubproxy fast preset
    _api("http://pubproxy.com/api/proxy?limit=20&format=txt&type=socks5&speed=10", "socks5"),
    _api("http://pubproxy.com/api/proxy?limit=20&format=txt&type=http&speed=10", "http"),
    # bulk dumps (sampled -- huge and mostly dead, but worth a slice)
    _gh("proxifly/free-proxy-list/main/proxies/all/data.txt", "http", "bulk"),
    _gh("zevtyardt/proxy-list/main/all.txt", "http", "bulk"),
    _gh("MuRongPIG/Proxy-Master/main/http.txt", "http", "bulk"),
    _gh("MuRongPIG/Proxy-Master/main/socks4.txt", "socks4", "bulk"),
    _gh("MuRongPIG/Proxy-Master/main/socks5.txt", "socks5", "bulk"),
    _gh("ErcinDedeoglu/proxies/main/proxies/http.txt", "http", "bulk"),
    _gh("ErcinDedeoglu/proxies/main/proxies/socks4.txt", "socks4", "bulk"),
    _gh("ErcinDedeoglu/proxies/main/proxies/socks5.txt", "socks5", "bulk"),
    _gh("casals-ar/proxy-list/main/socks4", "socks4", "bulk"),
    _gh("casals-ar/proxy-list/main/socks5", "socks5", "bulk"),
    _gh("hookzof/socks5_list/master/proxy.txt", "socks5", "bulk"),
]

MAX_CANDIDATES = 70000        # what is kept in memory / offered to the checker (the TCP stage scans them all in about a minute)
BULK_SAMPLE = 30000           # how many single-vote bulk entries are kept


# ------------------------------------------------------------------------------
# Types
# ------------------------------------------------------------------------------

@dataclass
class ProxyRecord:
    ip: str
    port: int
    protocol: str          # "http" | "socks4" | "socks5"   (a hint until the checker detects the real one)
    credentials: Optional[str] = None

    status: str = "unchecked"
    latency_ms: Optional[float] = None
    country: Optional[str] = None
    country_code: Optional[str] = None
    isp: Optional[str] = None
    asn: Optional[str] = None
    anonymity: Optional[str] = None
    exit_ip: Optional[str] = None
    is_pooled: Optional[bool] = None
    score: Optional[int] = None
    youtube_ok: Optional[bool] = None

    # fetch-time metadata used to prioritise checking
    votes: int = 1                              # how many sources listed this ip:port
    tier_rank: int = 1                          # 0 = listed by a curated source, 1 = bulk only
    hints: tuple = field(default_factory=tuple)  # other protocols other sources claimed

    def address(self) -> str:
        return f"{self.ip}:{self.port}"

    def uri(self, remote_dns: bool = False) -> str:
        proto = self.protocol
        if remote_dns:
            if proto == "socks5":
                proto = "socks5h"
            elif proto == "socks4":
                proto = "socks4a"
        if self.credentials:
            return f"{proto}://{self.credentials}@{self.ip}:{self.port}"
        return f"{proto}://{self.ip}:{self.port}"

    def requests_proxies(self) -> dict[str, str]:
        u = self.uri(remote_dns=True)
        return {"http": u, "https": u}

    def __hash__(self):
        return hash((self.ip, self.port, self.protocol))

    def __eq__(self, other):
        if not isinstance(other, ProxyRecord):
            return False
        return self.ip == other.ip and self.port == other.port and self.protocol == other.protocol


# ------------------------------------------------------------------------------
# Parsers
# ------------------------------------------------------------------------------

_IP_PORT_RE = re.compile(
    r"(?:(?P<proto>https?|socks[45])://)?(?:(?P<creds>[^@\s]+)@)?"
    r"(?P<ip>\d{1,3}(?:\.\d{1,3}){3}):(?P<port>\d{2,5})"
)


def _valid(ip: str, port: int) -> bool:
    if port < 1 or port > 65535 or is_blocked_port(port):      # RAT / miner / Tor / service ports are never queued
        return False
    o = [int(x) for x in ip.split(".")]
    if any(x > 255 for x in o):
        return False
    # never queue private / loopback / reserved ranges
    if o[0] in (0, 10, 127) or o[0] >= 224 or (o[0] == 172 and 16 <= o[1] <= 31) or (o[0] == 192 and o[1] == 168) or (o[0] == 169 and o[1] == 254):
        return False
    return True


def parse_proxy_line(line: str, default_protocol: str = "http") -> Optional[ProxyRecord]:
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    m = _IP_PORT_RE.search(line)
    if not m:
        return None
    ip, port = m.group("ip"), int(m.group("port"))
    if not _valid(ip, port):
        return None
    proto = (m.group("proto") or default_protocol).lower().replace("https", "http")
    return ProxyRecord(ip=ip, port=port, protocol=proto, credentials=m.group("creds") or None)


def parse_proxy_text(text: str, default_protocol: str = "http") -> list[ProxyRecord]:
    out = []
    for line in text.splitlines():
        rec = parse_proxy_line(line, default_protocol)
        if rec:
            out.append(rec)
    return out


def _parse_light(text: str, default_protocol: str) -> list[tuple]:
    """Fast parse into (ip, port, proto) tuples -- no object per line, so 100k-line dumps stay cheap."""
    out = []
    for m in _IP_PORT_RE.finditer(text):
        ip, port = m.group("ip"), int(m.group("port"))
        if not _valid(ip, port):
            continue
        proto = (m.group("proto") or default_protocol).lower().replace("https", "http")
        out.append((ip, port, proto))
    return out


# ------------------------------------------------------------------------------
# Fetcher
# ------------------------------------------------------------------------------

_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36"}


LAST_FETCH: dict = {"ok": 0, "failed": 0, "total": 0, "errors": {}}   # read by the API: "37/40 sources OK, 3 x Timeout"


def _fetch_one(source: dict, timeout: int = 15) -> tuple[str, list[tuple], str]:
    url, proto, tier = source["url"], source.get("protocol", "http"), source.get("tier", "curated")
    last_exc: Optional[Exception] = None
    text = None
    for attempt in (1, 2):                       # one retry: a single dropped connection must not lose a whole list
        try:
            s = requests.Session()
            s.trust_env = False                  # never route list downloads through a system proxy we may have set
            resp = s.get(url, timeout=timeout, headers=_HEADERS)
            resp.raise_for_status()
            text = resp.text
            break
        except Exception as exc:
            last_exc = exc
            if isinstance(exc, requests.HTTPError) and exc.response is not None and exc.response.status_code in (403, 404, 410):
                break                            # gone for good - retrying is pointless
            time.sleep(0.6)
    if text is None:
        _log.debug("Source fetch failed [%s]: %s", url, last_exc)
        return url, [], tier + "|" + type(last_exc).__name__
    try:
        recs: list[tuple] = []
        if text.lstrip().startswith(("{", "[")):
            try:
                data = json.loads(text)
                items = data.get("data") if isinstance(data, dict) else data
                for item in items or []:
                    if isinstance(item, dict) and "ip" in item and "port" in item:
                        p = proto
                        prots = item.get("protocols")
                        if isinstance(prots, list) and prots:
                            p = str(prots[0]).lower().replace("https", "http")
                        if _valid(str(item["ip"]), int(item["port"])):
                            recs.append((str(item["ip"]), int(item["port"]), p))
            except Exception:
                recs = []
        if not recs:
            recs = _parse_light(text, proto)
        return url, recs, tier
    except Exception as exc:
        _log.debug("Source parse failed [%s]: %s", url, exc)
        return url, [], tier + "|ParseError"


def fetch_all_sources(max_workers: int = 24, timeout_s: int = 15, sources: Optional[list[dict]] = None) -> list[ProxyRecord]:
    """
    Fetch every source in parallel, merge by ip:port counting how many sources list each one, and return a
    prioritised, size-capped list (most-listed + curated first).

    Publishes PROXY_FETCH_PROGRESS after each source and PROXY_FETCH_DONE with the final list.
    """
    source_list = sources or _SOURCES
    total = len(source_list)
    completed = 0
    _log.info("Fetching proxies from %d sources (%d workers)", total, max_workers)
    t_start = time.monotonic()

    # (ip, port) -> [votes, best_tier_rank, {proto: count}]
    merged: dict[tuple, list] = {}
    failed_n, errors = 0, {}

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = [pool.submit(_fetch_one, src, timeout_s) for src in source_list]
        for fut in as_completed(futures):
            url, recs, tier = fut.result()
            completed += 1
            if "|" in tier:                                  # failure marker from _fetch_one
                tier, err = tier.split("|", 1)
                failed_n += 1
                errors[err] = errors.get(err, 0) + 1
            rank = 0 if tier == "curated" else 1
            new_count = 0
            seen_here: set[tuple] = set()
            for ip, port, proto in recs:
                key = (ip, port)
                if key in seen_here:
                    continue
                seen_here.add(key)
                ent = merged.get(key)
                if ent is None:
                    merged[key] = [1, rank, {proto: 1}]
                    new_count += 1
                else:
                    ent[0] += 1
                    ent[1] = min(ent[1], rank)
                    ent[2][proto] = ent[2].get(proto, 0) + 1
            bus.publish(Events.PROXY_FETCH_PROGRESS, {
                "completed": completed, "total": total, "url": url,
                "new_proxies": new_count, "running_total": len(merged),
            })

    # -- prioritise + cap ------------------------------------------------------------------------------
    multi, curated_single, bulk_single = [], [], []
    for (ip, port), (votes, rank, protos) in merged.items():
        item = (ip, port, votes, rank, protos)
        if votes >= 2:
            multi.append(item)
        elif rank == 0:
            curated_single.append(item)
        else:
            bulk_single.append(item)
    random.shuffle(curated_single)
    random.shuffle(bulk_single)
    multi.sort(key=lambda x: (-x[2], x[3]))
    chosen = multi + curated_single + bulk_single[:BULK_SAMPLE]
    chosen = chosen[:MAX_CANDIDATES]

    records: list[ProxyRecord] = []
    for ip, port, votes, rank, protos in chosen:
        ordered = sorted(protos.items(), key=lambda kv: -kv[1])
        main = ordered[0][0]
        hints = tuple(p for p, _ in ordered[1:])
        records.append(ProxyRecord(ip=ip, port=port, protocol=main, votes=votes, tier_rank=rank, hints=hints))

    LAST_FETCH.update(ok=total - failed_n, failed=failed_n, total=total, errors=dict(errors))
    if failed_n:
        _log.warning("Fetch: %d/%d sources failed (%s)", failed_n, total, errors)
    _log.info("Fetch complete: %d unique proxies seen, %d queued (%d listed by 2+ sources) from %d sources in %.1fs",
              len(merged), len(records), len(multi), total, time.monotonic() - t_start)
    bus.publish(Events.PROXY_FETCH_DONE, records)
    return records
