# Copyright © 2026 Darko / Darko.Dev
"""
modules/proxy/ports.py - ports DWUT never checks or connects to.

A "proxy" listening on one of these ports is far more likely to be a RAT / botnet C2 / miner pool / Tor relay / honeypot than a
real proxy server, and connecting to it (even just to test it) is pointless at best and risky at worst.
They are dropped when lists are fetched, when you import a list, and again right before a check starts.
"""
from __future__ import annotations

# port -> why it is blocked
BLOCKED_PORTS: dict[int, str] = {
    # remote-access trojans / backdoors
    1177: "njRAT", 1604: "DarkComet", 5552: "njRAT", 3460: "Poison Ivy", 4444: "Metasploit / miner", 4443: "RAT/C2",
    12345: "NetBus", 12346: "NetBus", 20034: "NetBus 2", 27374: "SubSeven", 6711: "SubSeven", 6712: "SubSeven", 6713: "SubSeven",
    6776: "SubSeven", 16959: "SubSeven", 31337: "Back Orifice", 31335: "Trin00", 54320: "Back Orifice 2000", 54321: "Back Orifice 2000",
    1243: "SubSeven", 2140: "Deep Throat", 3150: "Deep Throat", 6969: "GateCrasher", 7626: "Glacier", 23432: "Asylum",
    26274: "Delta Source", 30100: "NetSphere", 33333: "Prosiak", 40421: "Masters Paradise", 47262: "Delta Source",
    50505: "Sockets de Troie", 61466: "Telecommando", 65000: "Devil", 65535: "RC1 trojan", 1337: "common backdoor", 7777: "RAT / Tini",
    9999: "RAT/C2", 5555: "ADB / RAT", 6666: "RAT / IRC bot", 6667: "IRC bot", 6668: "IRC bot", 6669: "IRC bot", 6697: "IRC bot",
    3127: "MyDoom",
    # crypto-miner pools (stratum)
    3333: "miner pool", 14444: "miner pool", 14433: "miner pool", 45560: "miner pool", 45700: "miner pool",
    # Tor relays / control (slow, and not general-purpose proxies)
    9001: "Tor relay", 9030: "Tor directory", 9050: "Tor SOCKS", 9051: "Tor control", 9150: "Tor Browser SOCKS",
    # databases, remote desktop, mail, file sharing, etc. - never proxies
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 110: "POP3", 111: "RPC", 135: "RPC", 137: "NetBIOS", 138: "NetBIOS",
    139: "NetBIOS", 143: "IMAP", 445: "SMB", 465: "SMTPS", 587: "SMTP", 993: "IMAPS", 995: "POP3S", 1433: "MSSQL", 1521: "Oracle",
    2049: "NFS", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 5901: "VNC", 6379: "Redis", 6000: "X11",
    9200: "Elasticsearch", 11211: "Memcached", 27017: "MongoDB", 10000: "Webmin / backdoor", 2000: "Cisco SCCP / backdoor",
}


def is_blocked_port(port: int) -> bool:
    """True for ports we never test.  Everything below 80 is blocked too (those are services, not proxies)."""
    try:
        p = int(port)
    except (TypeError, ValueError):
        return True
    return p < 80 or p in BLOCKED_PORTS


def blocked_reason(port: int) -> str:
    return BLOCKED_PORTS.get(int(port), "system service port" if int(port) < 80 else "")
