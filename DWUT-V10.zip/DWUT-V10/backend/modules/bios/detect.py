# Copyright © 2026 Darko / Darko.Dev
"""modules/bios/detect.py - native-Windows detection of the BIOS/firmware settings gamers never know the state of
(XMP/EXPO, Resizable BAR, Secure Boot, TPM, virtualization, HPET, VBS ...).  Everything is read-only."""
from __future__ import annotations

import re
import subprocess
import sys
from typing import Optional

from core.logger import get_logger
from modules.health.psrun import ps_json, as_list, NO_WINDOW

_log = get_logger(__name__)

_PS = r"""
$o=@{}
$m=@(Get-CimInstance Win32_PhysicalMemory)
$o.mem=@($m|%{@{loc=$_.DeviceLocator;gb=[math]::Round($_.Capacity/1GB);speed=$_.Speed;conf=$_.ConfiguredClockSpeed;mfr=$_.Manufacturer;part=($_.PartNumber+'').Trim();type=$_.SMBIOSMemoryType;volt=$_.ConfiguredVoltage}})
$o.cpu=(Get-CimInstance Win32_Processor|select -First 1 Name,Manufacturer,MaxClockSpeed,VirtualizationFirmwareEnabled,SecondLevelAddressTranslationExtensions,NumberOfCores,NumberOfLogicalProcessors)
$o.gpus=@(Get-CimInstance Win32_VideoController|%{@{name=$_.Name;ram=$_.AdapterRAM;drv=$_.DriverVersion;pnp=$_.PNPDeviceID}})
try{$o.sb=Confirm-SecureBootUEFI}catch{$o.sb=$null}
$t=Get-CimInstance -Namespace root\cimv2\Security\MicrosoftTpm -ClassName Win32_Tpm -ErrorAction SilentlyContinue
if($t){$o.tpm=@{en=$t.IsEnabled_InitialValue;ac=$t.IsActivated_InitialValue;ver=$t.SpecVersion}}
$dg=Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue
if($dg){$o.vbs=$dg.VirtualizationBasedSecurityStatus;$o.hvci=@($dg.SecurityServicesRunning)}
$o.hyperv=(Get-CimInstance Win32_ComputerSystem).HypervisorPresent
$o.hags=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -ErrorAction SilentlyContinue).HwSchMode
$o.fast=(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -ErrorAction SilentlyContinue).HiberbootEnabled
$o.gm=(Get-ItemProperty 'HKCU:\Software\Microsoft\GameBar' -ErrorAction SilentlyContinue).AutoGameModeEnabled
$o.pcie=@(Get-CimInstance Win32_SystemSlot|?{$_.SlotDesignation}|%{@{n=$_.SlotDesignation;u=$_.CurrentUsage}})
$o|ConvertTo-Json -Depth 5 -Compress
"""

SMBIOS_MEM = {26: "DDR4", 34: "DDR5", 24: "DDR3", 20: "DDR", 21: "DDR2"}
# JEDEC default (non-XMP) data rates per generation - anything above on a kit means a profile is active
JEDEC_MAX = {"DDR3": 1600, "DDR4": 2666, "DDR5": 4800}


def _bcd() -> dict:
    out = {}
    if sys.platform != "win32":
        return out
    try:
        r = subprocess.run(["bcdedit", "/enum", "{current}"], capture_output=True, timeout=15, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
        txt = (r.stdout or b"").decode("utf-8", "replace")
        for line in txt.splitlines():
            m = re.match(r"^\s*(\S+)\s+(.+?)\s*$", line)
            if m:
                out[m.group(1).lower()] = m.group(2).lower()
    except Exception as exc:
        _log.debug("bcdedit: %s", exc)
    return out


def _smi() -> dict:
    """nvidia-smi: BAR1 total is >= VRAM size when Resizable BAR is on (256 MiB otherwise)."""
    info = {}
    if sys.platform != "win32":
        return info
    try:
        r = subprocess.run(["nvidia-smi", "-q", "-d", "MEMORY"], capture_output=True, timeout=15, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
        txt = (r.stdout or b"").decode("utf-8", "replace")
        sec = re.search(r"BAR1 Memory Usage\s*\n\s*Total\s*:\s*(\d+)\s*MiB", txt)
        fb = re.search(r"FB Memory Usage\s*\n\s*Total\s*:\s*(\d+)\s*MiB", txt)
        if sec:
            info["bar1_mib"] = int(sec.group(1))
        if fb:
            info["vram_mib"] = int(fb.group(1))
    except Exception as exc:
        _log.debug("nvidia-smi: %s", exc)
    return info


def _rebar(gpus: list) -> dict:
    names = " ".join((g.get("name") or "") for g in gpus).lower()
    vendor = "nvidia" if "nvidia" in names or "geforce" in names or "rtx" in names else "amd" if "radeon" in names or "amd" in names else "intel" if "arc" in names else None
    res = {"state": "unknown", "vendor": vendor, "detail": "", "method": ""}
    if vendor == "nvidia":
        s = _smi()
        if s.get("bar1_mib") and s.get("vram_mib"):
            on = s["bar1_mib"] >= max(512, s["vram_mib"] - 64)
            res.update(state="on" if on else "off", method="nvidia-smi BAR1 aperture",
                       detail=f"BAR1 aperture is {s['bar1_mib']} MiB for {s['vram_mib']} MiB of VRAM." +
                              ("" if on else " A 256 MiB aperture means Resizable BAR is OFF (or unsupported by the card/BIOS)."))
            return res
        res["detail"] = "nvidia-smi was not found or did not report BAR1. Install/update the NVIDIA driver and re-scan."
    elif vendor == "amd":
        res["detail"] = ("Windows has no native API that reports Smart Access Memory. Open AMD Software > Performance > Tuning "
                         "(or Adrenalin > Smart Access Memory) - it states Enabled/Disabled there.")
    elif vendor == "intel":
        res["detail"] = "Intel Arc requires Resizable BAR; check Intel Arc Control > System for its state."
    else:
        res["detail"] = "No discrete GPU was identified."
    return res


def _xmp(mem: list) -> dict:
    res = {"state": "unknown", "gen": None, "profile_name": "Intel XMP / AMD EXPO", "rated": None, "running": None, "detail": "", "modules": mem}
    if not mem:
        res["detail"] = "No memory modules were reported."
        return res
    gen = SMBIOS_MEM.get(int(mem[0].get("type") or 0))
    res["gen"] = gen
    rated = max(int(m.get("speed") or 0) for m in mem)
    running = max(int(m.get("conf") or 0) for m in mem)
    res["rated"], res["running"] = rated, running
    base = JEDEC_MAX.get(gen or "", 0)
    if gen == "DDR5":
        res["profile_name"] = "XMP 3.0 / AMD EXPO"
    if rated and running:
        if running + 50 < rated:
            res["state"] = "off"
            res["detail"] = f"Your RAM is rated {rated} MT/s but is running at {running} MT/s - the XMP/EXPO profile is NOT enabled. Free performance left on the table."
        elif base and running > base + 50:
            res["state"] = "on"
            res["detail"] = f"Running at {running} MT/s (above the {gen} JEDEC default of {base}) - a memory profile is active."
        else:
            res["state"] = "jedec"
            res["detail"] = (f"Running at {running} MT/s, which is the standard {gen or 'JEDEC'} speed. If your kit is sold as faster than this, "
                             "enable XMP/EXPO in the BIOS; if it really is a base-speed kit, nothing is missing.")
    return res


def scan() -> dict:
    d = ps_json(_PS, 90) or {}
    mem = as_list(d.get("mem"))
    gpus = as_list(d.get("gpus"))
    cpu = d.get("cpu") or {}
    bcd = _bcd()
    tpm = d.get("tpm")
    hvci = [int(x) for x in as_list(d.get("hvci"))]
    boot_hpet = bcd.get("useplatformclock")
    hags = d.get("hags")
    out = {
        "ok": bool(d),
        "xmp": _xmp(mem),
        "rebar": _rebar(gpus),
        "cpu": {"name": cpu.get("Name"), "virt_firmware": cpu.get("VirtualizationFirmwareEnabled"), "slat": cpu.get("SecondLevelAddressTranslationExtensions"),
                "cores": cpu.get("NumberOfCores"), "threads": cpu.get("NumberOfLogicalProcessors"),
                "smt": (cpu.get("NumberOfLogicalProcessors") or 0) > (cpu.get("NumberOfCores") or 0),
                "vendor": "amd" if "amd" in (cpu.get("Manufacturer") or "").lower() else "intel" if "intel" in (cpu.get("Manufacturer") or "").lower() else None},
        "gpus": [{"name": g.get("name"), "driver": g.get("drv")} for g in gpus],
        "secure_boot": d.get("sb"),
        "tpm": {"enabled": tpm.get("en"), "active": tpm.get("ac"), "version": (tpm.get("ver") or "").split(",")[0]} if tpm else None,
        "vbs": {"status": d.get("vbs"), "hvci": 2 in hvci or 3 in hvci, "hyperv": bool(d.get("hyperv"))},
        "hags": {1: False, 2: True}.get(hags) if hags is not None else None,
        "fast_startup": None if d.get("fast") is None else bool(d.get("fast")),
        "game_mode": None if d.get("gm") is None else bool(d.get("gm")),
        "hpet_forced": None if boot_hpet is None else boot_hpet == "yes",
        "dynamic_tick_disabled": None if "disabledynamictick" not in bcd else bcd["disabledynamictick"] == "yes",
        "pcie_slots": as_list(d.get("pcie")),
    }
    return out
