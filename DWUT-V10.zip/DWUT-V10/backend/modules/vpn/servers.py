# Copyright © 2026 Darko / Darko.Dev
"""
modules/vpn/servers.py - the list of alternative connection points ("servers") the built-in VPN can use.

DWUTVPN rides Cloudflare's free network.  Cloudflare answers on several anycast addresses and ports; some paths are
faster (or simply not throttled / blocked) on a given network.  "Change server" hops to another entry from this list.
We deliberately do NOT offer locations here - exit country is chosen by the network, not by us - only
"another connection point".  (Real locations come from the optional imported profiles, see vpn_api.)

The list is ordered: PRIMARY entries are the well-known, reliably-answering addresses and are tried first; EXTRA
entries are kept only so older saved choices still resolve and as a last resort.
"""
from __future__ import annotations

_PRIMARY_HOSTS = [
    "162.159.192.1", "162.159.193.1", "162.159.195.1",
    "188.114.96.1", "188.114.97.1", "188.114.98.1", "188.114.99.1",
    "engage.cloudflareclient.com",
]
_PORTS = [2408, 500, 4500, 1701]

_EXTRA_HOSTS = [
    "162.159.192.2", "162.159.192.3", "162.159.192.4", "162.159.192.5",
    "162.159.193.2", "162.159.193.5", "162.159.193.9", "162.159.193.10",
    "162.159.195.2", "162.159.195.3", "162.159.195.4", "162.159.195.5",
    "188.114.96.2", "188.114.97.2", "188.114.98.2", "188.114.99.2",
]

PRIMARY: list[str] = [f"{h}:{p}" for p in _PORTS for h in _PRIMARY_HOSTS]
EXTRA: list[str] = [f"{h}:{p}" for p in _PORTS for h in _EXTRA_HOSTS]
# index 0 is always the default every new profile starts with
ENDPOINTS: list[str] = PRIMARY + EXTRA


def index_of(endpoint: str | None) -> int:
    try:
        return ENDPOINTS.index(endpoint) if endpoint else 0
    except ValueError:
        return 0


def label(endpoint: str | None) -> str:
    """Friendly, stable name shown in the UI (never mentions the underlying technology)."""
    return f"Server {index_of(endpoint) + 1}"


def _port(ep: str) -> str:
    return ep.rpartition(":")[2]


def next_candidates(current: str | None, count: int = 3, bad: set[str] | None = None) -> list[str]:
    """Up to `count` other endpoints to try.  Same-port neighbours first (a path that already works on this network
    usually works for its siblings), then the other ports; endpoints that already failed this session are skipped."""
    bad = bad or set()
    cur = current or ENDPOINTS[0]
    start = PRIMARY.index(cur) if cur in PRIMARY else 0
    n = len(PRIMARY)
    rotated = [PRIMARY[(start + k) % n] for k in range(1, n)]
    same = [e for e in rotated if _port(e) == _port(cur)]
    other = [e for e in rotated if _port(e) != _port(cur)]
    out: list[str] = []
    for ep in same + other + EXTRA:
        if ep != cur and ep not in bad and ep not in out:
            out.append(ep)
        if len(out) >= count:
            break
    return out
