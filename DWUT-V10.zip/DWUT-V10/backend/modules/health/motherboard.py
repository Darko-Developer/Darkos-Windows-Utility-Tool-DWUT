# Copyright © 2026 Darko / Darko.Dev
"""modules/health/motherboard.py - motherboard / BIOS / firmware DETECTION (no scoring).

Kept separate on purpose: the Health scan builds its "Motherboard & Firmware" card from this, and a future BIOS category can call
detect() directly.  Every field is read from the machine (SMBIOS via WMI, kernel firmware type, registry, TPM provider, and
LibreHardwareMonitor / OpenHardwareMonitor sensors when one of them is running).  A field that cannot be read is None - never guessed.

detect() -> {
  "board":    {manufacturer, product, version, has_serial, status, hosting},
  "system":   {manufacturer, model, family, sku, chassis, chassis_code, is_laptop, virtual_machine},
  "bios":     {vendor, version, smbios_version, release_date, age_days, status, embedded_controller},
  "firmware": {mode: 'UEFI'|'Legacy BIOS'|None, secure_boot: True|False|None, tpm: {present, enabled, activated, version, vendor}|None,
               virtualization_enabled: True|False|None, is_admin},
  "cpu_socket": str|None, "memory": {slots, populated, max_gb, types: [...]}, "chipset": str|None,
  "sensors": {"source": 'LibreHW'|'OHM'|None, "voltages": [{name, volts}], "temps": [{name, c}], "fans": [{name, rpm}]},
}
"""
from __future__ import annotations

import ctypes
import sys
from datetime import date, datetime
from typing import Optional

from core.logger import get_logger
from modules.health.psrun import as_list, ps_json

_log = get_logger(__name__)

CHASSIS = {1: "Other", 2: "Unknown", 3: "Desktop", 4: "Low-profile desktop", 5: "Pizza box", 6: "Mini tower", 7: "Tower", 8: "Portable",
           9: "Laptop", 10: "Notebook", 11: "Hand held", 12: "Docking station", 13: "All-in-one", 14: "Sub-notebook", 15: "Space-saving",
           16: "Lunch box", 17: "Main server chassis", 18: "Expansion chassis", 19: "Sub-chassis", 20: "Bus expansion chassis",
           21: "Peripheral chassis", 22: "RAID chassis", 23: "Rack-mount", 24: "Sealed-case PC", 30: "Tablet", 31: "Convertible",
           32: "Detachable", 33: "IoT gateway", 34: "Embedded PC", 35: "Mini PC", 36: "Stick PC"}
LAPTOP_CODES = {8, 9, 10, 11, 14, 30, 31, 32}
MEM_TYPES = {20: "DDR", 21: "DDR2", 24: "DDR3", 26: "DDR4", 29: "LPDDR2", 30: "LPDDR3", 31: "LPDDR4", 34: "DDR5", 35: "LPDDR5"}

_PS = r"""
$bb = Get-CimInstance Win32_BaseBoard | Select-Object -First 1
$cs = Get-CimInstance Win32_ComputerSystem | Select-Object -First 1
$en = Get-CimInstance Win32_SystemEnclosure | Select-Object -First 1
$bi = Get-CimInstance Win32_BIOS | Select-Object -First 1
$cp = Get-CimInstance Win32_Processor | Select-Object -First 1
$ma = Get-CimInstance Win32_PhysicalMemoryArray | Select-Object -First 1
$pm = @(Get-CimInstance Win32_PhysicalMemory)
$sbk = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State'
$tpm = Get-CimInstance -Namespace 'root\cimv2\Security\MicrosoftTpm' -ClassName Win32_Tpm | Select-Object -First 1
$lpc = Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match 'LPC|eSPI|ISA bridge|Chipset|SMBus' } | Select-Object -First 1
$hw = @(); $src = ''
foreach($ns in @('root\LibreHardwareMonitor','root\OpenHardwareMonitor')){
  $s = @(Get-CimInstance -Namespace $ns -ClassName Sensor)
  if($s.Count -gt 0){ $src = $ns; $hw = @($s | Where-Object { @('Voltage','Temperature','Fan') -contains [string]$_.SensorType } | ForEach-Object { [pscustomobject]@{ n=[string]$_.Name; t=[string]$_.SensorType; v=[double]$_.Value; id=[string]$_.Identifier } }); break }
}
$out = [ordered]@{
  bb_mfr=[string]$bb.Manufacturer; bb_product=[string]$bb.Product; bb_version=[string]$bb.Version; bb_serial=([string]$bb.SerialNumber).Trim(); bb_status=[string]$bb.Status;
  cs_mfr=[string]$cs.Manufacturer; cs_model=[string]$cs.Model; cs_family=[string]$cs.SystemFamily; cs_sku=[string]$cs.SystemSKUNumber; cs_hv=[bool]$cs.HypervisorPresent;
  chassis=@($en.ChassisTypes | ForEach-Object { [int]$_ });
  bios_vendor=[string]$bi.Manufacturer; bios_version=[string]$bi.SMBIOSBIOSVersion; bios_status=[string]$bi.Status;
  bios_date=$(if($bi.ReleaseDate){ $bi.ReleaseDate.ToString('yyyy-MM-dd') } else { '' });
  smbios=$(if($bi.SMBIOSMajorVersion -ne $null){ '' + $bi.SMBIOSMajorVersion + '.' + $bi.SMBIOSMinorVersion } else { '' });
  ec=$(if($bi.EmbeddedControllerMajorVersion -ne $null -and $bi.EmbeddedControllerMajorVersion -ne 255){ '' + $bi.EmbeddedControllerMajorVersion + '.' + $bi.EmbeddedControllerMinorVersion } else { '' });
  socket=[string]$cp.SocketDesignation; virt=$(if($cp.VirtualizationFirmwareEnabled -ne $null){ [bool]$cp.VirtualizationFirmwareEnabled } else { $null });
  slots=$(if($ma){ [int]$ma.MemoryDevices } else { 0 }); max_kb=$(if($ma){ [double]$ma.MaxCapacity } else { 0 }); max_kbx=$(if($ma){ [double]$ma.MaxCapacityEx } else { 0 });
  populated=$pm.Count; mem_types=@($pm | ForEach-Object { [int]$_.SMBIOSMemoryType });
  secure_boot=$(if($sbk -ne $null){ [int]$sbk.UEFISecureBootEnabled } else { -1 });
  tpm_present=$(if($tpm){ $true } else { $false }); tpm_enabled=$(if($tpm){ [bool]$tpm.IsEnabled_InitialValue } else { $null });
  tpm_active=$(if($tpm){ [bool]$tpm.IsActivated_InitialValue } else { $null }); tpm_spec=$(if($tpm){ [string]$tpm.SpecVersion } else { '' });
  tpm_mfr=$(if($tpm){ [string]$tpm.ManufacturerIdTxt } else { '' });
  chipset=[string]$lpc.Name; hw_source=$src; hw=$hw
}
ConvertTo-Json -InputObject $out -Depth 4 -Compress
"""


def _s(v) -> Optional[str]:
    v = ("" if v is None else str(v)).strip()
    return v or None


def _junk(v: Optional[str]) -> Optional[str]:
    """OEM placeholders that boards ship with instead of real data."""
    if v is None:
        return None
    return None if v.strip().lower() in {"to be filled by o.e.m.", "default string", "system product name", "system manufacturer",
                                         "not applicable", "none", "o.e.m.", "unknown", "n/a", "type1productconfigid"} else v


def firmware_mode() -> Optional[str]:
    """UEFI or legacy BIOS straight from the kernel (GetFirmwareType: 1 = BIOS, 2 = UEFI).  No admin needed."""
    if sys.platform != "win32":
        return None
    try:
        t = ctypes.c_uint(0)
        if ctypes.windll.kernel32.GetFirmwareType(ctypes.byref(t)):
            return {1: "Legacy BIOS", 2: "UEFI"}.get(t.value)
    except Exception:
        pass
    return None


def _age_days(iso: Optional[str]) -> Optional[int]:
    try:
        return max(0, (date.today() - datetime.strptime(iso or "", "%Y-%m-%d").date()).days)
    except ValueError:
        return None


def detect() -> dict:
    d = ps_json(_PS, 60) or {}
    chassis_codes = [int(x) for x in as_list(d.get("chassis"))]
    code = next((c for c in chassis_codes if c not in (1, 2)), chassis_codes[0] if chassis_codes else None)
    mode = firmware_mode()
    sb = d.get("secure_boot")
    secure_boot = None if sb in (None, -1) else bool(sb)
    if mode == "Legacy BIOS":
        secure_boot = False                                  # Secure Boot cannot exist on a legacy-BIOS boot
    # MaxCapacity is in KB; when it reads 0x80000000 the real figure is in MaxCapacityEx (also KB)
    kb = float(d.get("max_kbx") or 0) if float(d.get("max_kb") or 0) >= 2147483648 else float(d.get("max_kb") or 0)
    max_gb = round(kb / (1024 ** 2)) or None
    mem_types = sorted({MEM_TYPES.get(int(t), "") for t in as_list(d.get("mem_types")) if int(t) in MEM_TYPES})

    sensors = {"source": None, "voltages": [], "temps": [], "fans": []}
    src = _s(d.get("hw_source"))
    if src:
        sensors["source"] = "LibreHW" if "Libre" in src else "OHM"
        for s in as_list(d.get("hw")):
            n, t, v, i = s.get("n") or "", s.get("t"), s.get("v"), (s.get("id") or "").lower()
            if v is None:
                continue
            if t == "Voltage" and ("/lpc/" in i or "/motherboard" in i or "/superio" in i):
                sensors["voltages"].append({"name": n, "volts": round(float(v), 3)})
            elif t == "Temperature" and ("/lpc/" in i or "/motherboard" in i or "/superio" in i):
                if 0 < float(v) < 130:
                    sensors["temps"].append({"name": n, "c": round(float(v), 1)})
            elif t == "Fan" and float(v) >= 0:
                sensors["fans"].append({"name": n, "rpm": int(round(float(v)))})

    tpm = None
    if d.get("tpm_present"):
        tpm = {"present": True, "enabled": d.get("tpm_enabled"), "activated": d.get("tpm_active"),
               "version": _s(d.get("tpm_spec")), "vendor": _s(d.get("tpm_mfr"))}
    rel = _s(d.get("bios_date"))
    return {
        "board": {"manufacturer": _junk(_s(d.get("bb_mfr"))), "product": _junk(_s(d.get("bb_product"))), "version": _junk(_s(d.get("bb_version"))),
                  "has_serial": bool(_junk(_s(d.get("bb_serial")))), "status": _s(d.get("bb_status")), "hosting": None},
        "system": {"manufacturer": _junk(_s(d.get("cs_mfr"))), "model": _junk(_s(d.get("cs_model"))), "family": _junk(_s(d.get("cs_family"))),
                   "sku": _junk(_s(d.get("cs_sku"))), "chassis": CHASSIS.get(code) if code else None, "chassis_code": code,
                   "is_laptop": code in LAPTOP_CODES if code else None, "virtual_machine": bool(d.get("cs_hv")) and (_s(d.get("cs_mfr")) or "").lower() in
                   ("microsoft corporation", "vmware, inc.", "innotek gmbh", "qemu", "xen", "parallels software international inc.")},
        "bios": {"vendor": _s(d.get("bios_vendor")), "version": _s(d.get("bios_version")), "smbios_version": _s(d.get("smbios")),
                 "release_date": rel, "age_days": _age_days(rel), "status": _s(d.get("bios_status")), "embedded_controller": _s(d.get("ec"))},
        "firmware": {"mode": mode, "secure_boot": secure_boot, "tpm": tpm, "virtualization_enabled": d.get("virt"), "got_data": bool(d)},
        "cpu_socket": _s(d.get("socket")),
        "memory": {"slots": int(d.get("slots") or 0) or None, "populated": int(d.get("populated") or 0), "max_gb": max_gb, "types": mem_types},
        "chipset": _s(d.get("chipset")),
        "sensors": sensors,
    }
