# Copyright © 2026 Darko / Darko.Dev
"""modules/health/fixes.py - "Fix & Optimize" for every component the Health scan checks.

Each component (Processor, Memory, Storage, Graphics, Battery, Cooling, Network, Firmware, Drivers, Windows) has a list of STEPS.  A step is ONE real,
safe action and carries a kind so the UI can say what it is:

    fix       repairs a problem the scan found (only ticked by default when the scan really found that problem)
    cleanup   frees space / clears junk
    optimize  a lasting setting that makes the component run better
    boost     a one-off push right now (frees RAM, lowers background load ...) - nothing is closed, nothing needs undoing

What a hardware fault needs (a dying drive, a dusty heatsink, a BIOS setting) cannot be changed from Windows: those become "manual" items with a button
that opens the right place - they are never pretended to be fixed.  Nothing here closes a user's program, touches Xbox, or resets the firewall / VPN.
Steps that need Administrator say so instead of failing silently.  After a run the category is scanned again so the new score is real.
"""
from __future__ import annotations

import ctypes
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import psutil

from core.logger import get_logger

_log = get_logger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
KINDS = ("fix", "cleanup", "optimize", "boost")
_PS_PRE = "$ErrorActionPreference='SilentlyContinue';$ProgressPreference='SilentlyContinue';"


# ═════════════════════════════════════════════════════════════════════ helpers
def _run(cmd, timeout: int = 120) -> tuple[bool, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WINDOW, errors="replace", stdin=subprocess.DEVNULL)
        return r.returncode == 0, ((r.stdout or "") + (r.stderr or "")).strip()
    except subprocess.TimeoutExpired:
        return False, f"timed out after {timeout}s"
    except Exception as exc:
        return False, str(exc)


def _ps(script: str, timeout: int = 120, strict: bool = False) -> tuple[bool, str]:
    pre = "$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';" if strict else _PS_PRE
    return _run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", pre + script], timeout)


def _is_admin() -> bool:
    try:
        from app.permissions import is_admin
        return bool(is_admin())
    except Exception:
        return False


def _last_line(text: str, n: int = 140) -> str:
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    return (lines[-1] if lines else "")[:n]


class Ctx:
    """What one run knows: which component it was started from (card ctx), a log, and whether Windows needs a restart afterwards."""

    def __init__(self, card: Optional[dict], log: Callable[[str], None]) -> None:
        self.card = card or {}
        self.cx = (card or {}).get("ctx") or {}
        self.log = log
        self.restart = False

    @property
    def letters(self) -> list:
        return list(self.cx.get("letters") or [])


@dataclass
class Step:
    id: str
    cat: str
    kind: str
    label: str
    desc: str
    fn: Callable[[Ctx], tuple]
    triggers: tuple = ()          # regexes - when a scan finding matches, this step fixes a FOUND problem
    needed_only: bool = False     # only ticked by default when a finding matched (slow, disruptive or pointless otherwise)
    admin: bool = True
    scoped: Optional[Callable[[dict], bool]] = None      # card-level runs: only offered when this is true for the card's ctx (None = always)


STEPS: dict = {}
BY_CAT: dict = {}


def step(cat: str, sid: str, kind: str, label: str, desc: str, triggers=(), needed_only: bool = False, admin: bool = True, scoped=None):
    def deco(fn):
        s = Step(f"{cat}.{sid}", cat, kind, label, desc, fn, tuple(triggers), needed_only, admin, scoped)
        STEPS[s.id] = s
        BY_CAT.setdefault(cat, []).append(s)
        return fn
    return deco


# manual items: (finding regex, text, optional action dict {action, label, url|tool})
MANUAL: dict = {
    "cpu": [
        (r"very hot|warm|held back|firmware limited|hardware error", "A hot, throttled or error-logging CPU is a hardware / BIOS matter: clean the heatsink and fans, check the cooler's mounting, and reset any overclock in the BIOS.", None),
    ],
    "memory": [
        (r"hardware errors in your RAM", "Test each memory stick on its own and replace the faulty one. DWUT opens the Windows Memory Diagnostic for you under 'Fix'.", None),
        (r"XMP|EXPO", "Your RAM runs below its rated speed: turn on XMP / EXPO in the BIOS (only the BIOS can do this).", {"action": "uefi", "label": "Restart into BIOS…"}),
        (r"one memory stick", "A second matching stick enables dual-channel mode - a hardware change.", None),
    ],
    "storage": [
        (r"UNHEALTHY|predicts|will fail|used \d+% of its rated|uncorrectable|'Warning'", "This drive is wearing out or failing. No software can repair that: back up your files NOW and plan to replace the drive.", None),
        (r"hot", "Improve case airflow or add a heatsink (NVMe drives run hot).", None),
    ],
    "gpu": [
        (r"generic graphics driver|graphics driver is|crashed and recovered|Device Manager code", "Install the newest driver from the graphics maker (a clean install is best after crashes).", {"action": "gpu_driver", "label": "Open the driver page"}),
        (r"very hot|is hot|too hot|slowdown", "Check the GPU fans, dust and case airflow - this is hardware.", None),
        (r"ECC", "Uncorrectable GPU memory errors mean the card is faulty - contact the maker.", None),
    ],
    "battery": [
        (r"holds only|only holds|worn down", "A worn battery cannot be restored. Replace it when the runtime is no longer enough.", None),
    ],
    "thermal": [
        (r"0 RPM|fan with a fault", "A stopped or faulty fan is a hardware problem: check its cable, spin it by hand, or replace it before the PC overheats.", None),
        (r"holding the processor", "Clean dust from the heatsink and fans and renew the thermal paste if the PC is old.", None),
    ],
    "network": [
        (r"Ethernet link negotiated only", "Replace the Ethernet cable with a Cat5e/Cat6 one and try another router port - a worn cable or port is the usual cause.", None),
        (r"Wi-Fi signal is weak", "Move closer to the router, remove obstacles, or switch to a cable / the 5 GHz band.", None),
        (r"router did not answer", "Restart the router (unplug it for 30 seconds).", None),
    ],
    "firmware": [
        (r"BIOS is .* old", "A newer BIOS may fix stability and security problems. Download it from the maker and follow THEIR update instructions (never interrupt a BIOS update).", {"action": "bios_page", "label": "Open the maker's support page"}),
        (r"legacy BIOS|Secure Boot|TPM", "This is changed in the BIOS / UEFI settings, not in Windows.", {"action": "uefi", "label": "Restart into BIOS…"}),
        (r"power rail", "A weak power supply can cause crashes and data corruption - test or replace the PSU.", None),
    ],
    "drivers": [
        (r"Unsigned driver", "Remove or replace the unsigned driver with the maker's signed version (Device Manager > driver tab).", {"action": "tool", "label": "Open Device Manager", "tool": "Device Manager"}),
        (r"Old driver", "Download newer drivers from the hardware maker's website.", None),
    ],
    "windows": [
        (r"restart", "Windows is waiting for a restart (or has not had one for a long time).", {"action": "restart", "label": "Restart now…"}),
        (r"unexpectedly|blue-screen", "Crashes usually come from a driver, overheating or bad RAM. Fix the drivers (Drivers section), then test the RAM.", None),
        (r"startup took", "Choose which startup programs to turn off.", {"action": "startup", "label": "Choose startup apps…"}),
        (r"component store is corrupted", "A repair install of Windows may be needed (Settings > System > Recovery).", None),
    ],
}


# ═════════════════════════════════════════════════════════════════════ shared actions
def _lower_busy_background(threshold: float = 3.0) -> list:
    """Lower the priority of programs that really use the CPU right now (nothing is closed; the program you are using is never touched)."""
    me = os.getpid()
    protected = {me}
    try:
        cur = psutil.Process(me)
        protected.update(p.pid for p in cur.parents())
        protected.update(p.pid for p in cur.children(recursive=True))
    except Exception:
        pass
    fg = 0
    try:
        u32 = ctypes.windll.user32
        pid = ctypes.c_ulong(0)
        u32.GetWindowThreadProcessId(u32.GetForegroundWindow(), ctypes.byref(pid))
        fg = pid.value
    except Exception:
        pass
    keep = {"system", "system idle process", "registry", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe", "lsass.exe", "svchost.exe", "dwm.exe",
            "explorer.exe", "audiodg.exe", "sihost.exe", "ctfmon.exe", "fontdrvhost.exe", "taskmgr.exe", "searchhost.exe", "startmenuexperiencehost.exe",
            "shellexperiencehost.exe", "textinputhost.exe", "msmpeng.exe", "memcompression"}
    try:
        me_user = psutil.Process(me).username()
    except Exception:
        me_user = None
    procs = []
    for p in psutil.process_iter(["pid", "name", "username"]):
        try:
            p.cpu_percent(None)
            procs.append(p)
        except Exception:
            continue
    time.sleep(1.5)
    ncpu = psutil.cpu_count(logical=True) or 1
    names = []
    for p in procs:
        try:
            if p.pid in protected or p.pid == fg or (p.info.get("name") or "").lower() in keep:
                continue
            if me_user and p.info.get("username") and p.info["username"] != me_user:
                continue
            if p.cpu_percent(None) / ncpu < threshold:
                continue
            if p.nice() in (psutil.BELOW_NORMAL_PRIORITY_CLASS, psutil.IDLE_PRIORITY_CLASS):
                continue
            p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
            names.append(p.info.get("name") or str(p.pid))
        except Exception:
            continue
    return sorted(set(names))


def _powercfg(*parts: str) -> bool:
    return _run(["powercfg", *parts], 20)[0]


def _lower_bg_result(x: Ctx) -> tuple:
    names = _lower_busy_background()
    if names:
        x.log("Lowered the priority (nothing was closed) of: " + ", ".join(names[:8]))
        return "ok", f"{len(names)} busy background program(s) now yield to what you are using"
    return "skip", "no background program was hogging the CPU right now"


# ═════════════════════════════════════════════════════════════════════ PROCESSOR
@step("cpu", "power_repair", "fix", "Re-enable processor idle states", "Fixes a CPU stuck at high load / not idling, then re-applies the power plan.",
      triggers=(r"held back", r"power plan", r"limited the CPU"), admin=False)
def cpu_power_repair(x: Ctx):
    from modules.system import winutil as wu
    r = wu.repair_high_cpu_power_config()
    return ("ok", "idle states re-enabled and the power plan re-applied") if r.success else ("warn", "some power settings were refused")


@step("cpu", "max_state", "fix", "Remove the processor speed cap", "Sets the maximum processor state to 100 % so Windows is not holding the CPU below its clock.",
      triggers=(r"held back", r"only running at"), admin=False)
def cpu_max_state(x: Ctx):
    good = sum(_powercfg(m, "SCHEME_CURRENT", "SUB_PROCESSOR", "PROCTHROTTLEMAX", "100") for m in ("/setacvalueindex", "/setdcvalueindex"))
    _powercfg("/setactive", "SCHEME_CURRENT")
    return ("ok", "maximum processor state is 100 % on AC and battery") if good == 2 else ("warn", f"{good}/2 power settings applied")


@step("cpu", "unpark", "optimize", "Un-park cores + turbo (plugged in)", "All cores stay awake and turbo boost is aggressive while plugged in. Battery settings are untouched.", admin=False)
def cpu_unpark(x: Ctx):
    cmds = [["/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "CPMINCORES", "100"], ["/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PERFBOOSTMODE", "2"], ["/setactive", "SCHEME_CURRENT"]]
    good = sum(_powercfg(*c) for c in cmds)
    return ("ok", "all cores un-parked and turbo boost on while plugged in") if good == len(cmds) else ("warn", f"{good}/{len(cmds)} power settings applied")


@step("cpu", "background", "boost", "Free the CPU from busy background programs", "Lowers the priority of programs hogging the CPU. Nothing is closed.", admin=False)
def cpu_background(x: Ctx):
    return _lower_bg_result(x)


# ═════════════════════════════════════════════════════════════════════ MEMORY
@step("memory", "trim", "boost", "Free RAM now", "Trims the working set of running programs and purges the standby list.", triggers=(r"almost full", r"Commit charge", r"ran out of memory"), admin=False)
def mem_trim(x: Ctx):
    from modules.cleaner import speed

    class _E:
        log = staticmethod(x.log)
    before = psutil.virtual_memory().available
    speed.exec_ram_trim(_E())
    gained = (psutil.virtual_memory().available - before) / 1048576
    return "ok", f"{max(gained, 0):.0f} MB more RAM is available now"


@step("memory", "compression", "optimize", "Memory compression + page combining", "Keeps more in RAM instead of the slow page file (fully active after a restart).")
def mem_compression(x: Ctx):
    ok, out = _ps("if (Get-Command Enable-MMAgent -ErrorAction SilentlyContinue) { Enable-MMAgent -MemoryCompression -PageCombining -ErrorAction Stop; 'MM' }", 40)
    if "MM" in out:
        x.restart = True
        return "ok", "memory compression and page combining are on"
    return "skip", "this Windows build has no memory-agent settings"


@step("memory", "pagefile", "fix", "Let Windows manage the page file", "Memory ran out or is nearly full: a fixed, too-small page file is a common cause.", triggers=(r"Commit charge", r"ran out of memory"), needed_only=True)
def mem_pagefile(x: Ctx):
    ok, out = _ps("$cs=Get-WmiObject Win32_ComputerSystem -EnableAllPrivileges; if(-not $cs.AutomaticManagedPagefile){ $cs.AutomaticManagedPagefile=$true; [void]$cs.Put(); 'CHANGED' } else { 'ALREADY' }", 40)
    if "CHANGED" in out:
        x.restart = True
        return "ok", "the page file is now managed by Windows (restart to apply)"
    if "ALREADY" in out:
        return "skip", "the page file was already managed by Windows"
    return "warn", "could not change the page file settings"


@step("memory", "diag", "fix", "Open the Windows Memory Diagnostic", "The last test found RAM errors: run it again (Windows asks to restart).", triggers=(r"hardware errors in your RAM",), needed_only=True, admin=False)
def mem_diag(x: Ctx):
    try:
        subprocess.Popen(["mdsched.exe"], creationflags=_NO_WINDOW)
        return "info", "Windows Memory Diagnostic opened - choose 'Restart now and check for problems'"
    except Exception as exc:
        return "warn", str(exc)[:100]


# ═════════════════════════════════════════════════════════════════════ STORAGE
def _fixed_letters(x: Ctx) -> list:
    if x.letters:
        return x.letters
    ok, out = _ps("Get-Volume | Where-Object { $_.DriveType -eq 'Fixed' -and $_.DriveLetter -and $_.FileSystem -in 'NTFS','ReFS' } | ForEach-Object { $_.DriveLetter }", 40)
    return [l.strip() for l in out.splitlines() if len(l.strip()) == 1 and l.strip().isalpha()]


@step("storage", "cleanup", "cleanup", "Clean junk files on all drives", "Temp files, caches, logs, thumbnails ... (the safe categories only).", triggers=(r"almost full", r"free\)"), admin=False)
def disk_cleanup(x: Ctx):
    from modules.system import disk_cleanup as dc
    keys = [c.key for c in dc._make_categories() if not c.aggressive]
    r = dc.clean_categories(keys)
    mb = r.total_bytes_freed / 1048576
    x.log(f"{r.files_deleted} files removed, {mb:.0f} MB freed")
    return "ok", f"{mb:.0f} MB freed ({r.files_deleted} items)"


@step("storage", "update_cache", "cleanup", "Clear the Windows Update download cache", "Old update downloads Windows no longer needs.", triggers=(r"almost full",))
def disk_update_cache(x: Ctx):
    from modules.system import winutil as wu
    r = wu.clear_update_cache()
    return "ok", f"{r.mb_freed:.0f} MB freed"


@step("storage", "recycle", "cleanup", "Empty the Recycle Bin", "Permanently removes what is in it.", triggers=(r"almost full",), admin=False)
def disk_recycle(x: Ctx):
    ok, _ = _ps("Clear-RecycleBin -Force -ErrorAction SilentlyContinue", 90)
    return ("ok", "Recycle Bin emptied") if ok else ("warn", "could not empty the Recycle Bin")


@step("storage", "verify", "fix", "Check the file system for errors", "Online scan; if errors are found a repair is scheduled for the next restart.", triggers=(r"chkdsk", r"marks volume", r"disk error event", r"uncorrectable"), needed_only=True)
def disk_verify(x: Ctx):
    letters = _fixed_letters(x)
    if not letters:
        return "skip", "no NTFS volume to check"
    bad = []
    for l in letters:
        ok, out = _ps(f"(Repair-Volume -DriveLetter {l} -Scan -ErrorAction Stop | Out-String).Trim()", 900, strict=True)
        x.log(f"{l}: {_last_line(out) or 'checked'}")
        compact = out.lower().replace(" ", "")
        if "noerrorsfound" not in compact and "errorsfound" in compact:
            bad.append(l)
            _run(["cmd", "/c", f"echo Y| chkdsk {l}: /f"], 60)
    if bad:
        x.restart = True
        return "warn", f"errors found on {', '.join(b + ':' for b in bad)} - a repair is scheduled for the next restart"
    return "ok", f"no file-system errors on {', '.join(l + ':' for l in letters)}"


@step("storage", "optimize", "optimize", "Optimize the drive (TRIM / defrag)", "SSD = TRIM, hard disk = defrag (a big hard disk can take a while).")
def disk_optimize(x: Ctx):
    letters = _fixed_letters(x)
    if not letters:
        return "skip", "no NTFS volume to optimize"
    done = 0
    for l in letters:
        flag = "-ReTrim" if x.cx.get("ssd") else ""
        x.log(f"Optimizing {l}: …")
        ok, out = _ps(f"Optimize-Volume -DriveLetter {l} {flag} -ErrorAction Stop", 3600, strict=True)
        x.log(f"{l}: " + ("done" if ok else "skipped - " + _last_line(out, 100)))
        done += 1 if ok else 0
    return ("ok", f"{done}/{len(letters)} drive(s) optimized") if done else ("warn", "Windows skipped the optimization")


@step("storage", "temp", "cleanup", "Clean user + system temp folders", "Files programs left behind in the temp folders.", admin=False)
def disk_temp(x: Ctx):
    from modules.system import winutil as wu
    r = wu.clean_temp_files()
    return "ok", f"{r.mb_freed:.0f} MB freed"


# ═════════════════════════════════════════════════════════════════════ GRAPHICS
@step("gpu", "shader", "cleanup", "Clear GPU shader caches", "Games rebuild them on the next launch (a corrupt cache causes stutter and crashes).", triggers=(r"crashed and recovered",), admin=False)
def gpu_shader(x: Ctx):
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    dirs = [local / "D3DSCache", local / "NVIDIA" / "DXCache", local / "NVIDIA" / "GLCache", local / "AMD" / "DxCache", local / "AMD" / "GLCache", local / "AMD" / "VkCache", local / "Intel" / "ShaderCache"]
    freed = files = 0
    for d in dirs:
        if not d.is_dir():
            continue
        for item in list(d.iterdir()):
            try:
                if item.is_dir():
                    sz = sum(f.stat().st_size for f in item.rglob("*") if f.is_file())
                    shutil.rmtree(item, ignore_errors=False)
                else:
                    sz = item.stat().st_size
                    item.unlink()
                freed += sz
                files += 1
            except Exception:
                continue                                                         # in use by a running game - leave it
    return "ok", f"{freed / 1048576:.0f} MB of shader caches cleared ({files} items)"


@step("gpu", "hags", "optimize", "Hardware-accelerated GPU scheduling", "Lower GPU latency on Windows 10 2004 and newer.")
def gpu_hags(x: Ctx):
    import winreg
    path = r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as k:
            try:
                cur, _ = winreg.QueryValueEx(k, "HwSchMode")
            except FileNotFoundError:
                return "skip", "this GPU / driver does not offer hardware GPU scheduling"
            if cur == 2:
                return "skip", "already on"
            winreg.SetValueEx(k, "HwSchMode", 0, winreg.REG_DWORD, 2)
            x.restart = True
            return "ok", "turned on (takes effect after a restart)"
    except PermissionError:
        return "warn", "needs administrator rights"
    except OSError as exc:
        return "warn", str(exc)[:100]


@step("gpu", "apps", "boost", "Set every app to the high-performance GPU", "Windows' per-app GPU preference (matters on laptops with two graphics chips). Can take a minute.")
def gpu_apps(x: Ctx):
    from modules.system import gpu_prefs
    r = gpu_prefs.set_all_high_performance(lambda m: x.log(m))
    if not r["total"]:
        return "warn", "the app list could not be read"
    note = f"{r['changed']} app(s) switched to High performance, {r['already']} already were"
    return ("ok", note) if not r["failed"] else ("warn", f"{note}; {r['failed']} refused")


@step("gpu", "driver_scan", "fix", "Look for a newer graphics driver", "Re-detects devices and asks Windows Update to search for drivers.", triggers=(r"generic graphics driver", r"graphics driver is", r"Device Manager code", r"crashed and recovered"), admin=False)
def gpu_driver_scan(x: Ctx):
    return _driver_scan(x)


# ═════════════════════════════════════════════════════════════════════ BATTERY
@step("battery", "report", "optimize", "Create the Windows battery report", "Shows capacity history and usage; DWUT opens it for you.", admin=False)
def bat_report(x: Ctx):
    out = Path(tempfile.gettempdir()) / "DWUT"
    out.mkdir(parents=True, exist_ok=True)
    f = out / "battery-report.html"
    ok, o = _run(["powercfg", "/batteryreport", "/output", str(f)], 60)
    if ok and f.exists():
        try:
            os.startfile(str(f))                                                  # type: ignore[attr-defined]
        except Exception:
            pass
        return "ok", "battery report created and opened"
    return "warn", _last_line(o) or "powercfg could not create the report"


@step("battery", "saver", "optimize", "Battery saver at 20 %", "Windows turns on Battery saver automatically when the charge drops to 20 %.", admin=False)
def bat_saver(x: Ctx):
    ok = _powercfg("/setdcvalueindex", "SCHEME_CURRENT", "SUB_ENERGYSAVER", "ESBATTTHRESHOLD", "20")
    _powercfg("/setactive", "SCHEME_CURRENT")
    return ("ok", "Battery saver switches on at 20 %") if ok else ("warn", "this power plan has no battery-saver setting")


# ═════════════════════════════════════════════════════════════════════ COOLING & THERMALS
@step("thermal", "cooling", "fix", "Active cooling policy", "Fans spin up BEFORE Windows slows the CPU down (AC and battery).", triggers=(r"holding the processor", r"very hot", r"warm", r"hot"), admin=False)
def therm_cooling(x: Ctx):
    good = sum(_powercfg(m, "SCHEME_CURRENT", "SUB_PROCESSOR", "SYSCOOLPOL", "1") for m in ("/setacvalueindex", "/setdcvalueindex"))
    _powercfg("/setactive", "SCHEME_CURRENT")
    return ("ok", "the fans now react before the CPU is slowed") if good == 2 else ("warn", f"{good}/2 settings applied")


@step("thermal", "cap", "fix", "Remove the processor speed cap", "A cap below 100 % is often left over from an old power plan.", triggers=(r"holding the processor",), needed_only=True, admin=False)
def therm_cap(x: Ctx):
    return cpu_max_state(x)


@step("thermal", "background", "boost", "Cool down: lower background load", "Less background work = less heat. Nothing is closed.", triggers=(r"hot", r"warm", r"holding the processor"), admin=False)
def therm_background(x: Ctx):
    return _lower_bg_result(x)


# ═════════════════════════════════════════════════════════════════════ NETWORK  (never touches the VPN or the firewall)
def _vpn_active(x: Ctx) -> bool:
    return bool(x.cx.get("vpn") or x.cx.get("vpn_active"))


def _physical_up_indexes(x: Ctx) -> list:
    if x.cx.get("ifindex") and not x.cx.get("vpn"):
        return [int(x.cx["ifindex"])]
    ok, out = _ps("Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' } | ForEach-Object { $_.ifIndex }", 30)
    return [int(l) for l in out.split() if l.strip().isdigit()]


@step("network", "dns_flush", "cleanup", "Flush and re-register the DNS cache", "Removes stale / wrong name lookups.", triggers=(r"DNS", r"Name lookups"), admin=False)
def net_dns_flush(x: Ctx):
    a = _run(["ipconfig", "/flushdns"], 20)[0]
    b = _run(["ipconfig", "/registerdns"], 30)[0]
    return ("ok", "DNS cache flushed and re-registered") if a else ("warn", "the DNS cache could not be flushed")


@step("network", "dns_server", "fix", "Use fast public DNS (1.1.1.1 / 1.0.0.1)", "Name lookups failed: sets Cloudflare DNS on the connected adapter(s).", triggers=(r"Name lookups", r"DNS"), needed_only=True)
def net_dns_server(x: Ctx):
    if _vpn_active(x) and x.cx.get("vpn"):
        return "skip", "the VPN controls DNS while it is connected"
    idx = _physical_up_indexes(x)
    if not idx:
        return "skip", "no connected adapter"
    done = 0
    for i in idx:
        ok, _ = _ps(f"Set-DnsClientServerAddress -InterfaceIndex {i} -ServerAddresses ('1.1.1.1','1.0.0.1') -ErrorAction Stop", 30, strict=True)
        done += 1 if ok else 0
    _run(["ipconfig", "/flushdns"], 20)
    return ("ok", f"DNS set on {done} adapter(s)") if done else ("warn", "Windows refused the DNS change")


@step("network", "renew", "fix", "Renew the connection (DHCP lease)", "Gets a fresh address from the router. Skipped while a VPN is on.", triggers=(r"packet loss", r"connection", r"router", r"not reachable"), needed_only=True)
def net_renew(x: Ctx):
    if _vpn_active(x):
        return "skip", "a VPN is active - renewing would drop the tunnel"
    names = []
    if x.cx.get("name") and not x.cx.get("vpn"):
        names = [str(x.cx["name"])]
    else:
        ok, out = _ps("Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' } | ForEach-Object { $_.Name }", 30)
        names = [l.strip() for l in out.splitlines() if l.strip()]
    good = 0
    for n in names:
        ok, out = _run(["ipconfig", "/renew", n], 40)
        good += 1 if ok else 0
    return ("ok", f"new address obtained on {good} adapter(s)") if good else ("warn", "the router did not hand out a new address")


@step("network", "tcp_tune", "optimize", "Tune TCP (auto-tuning, RSS, no throttling)", "Normal TCP receive auto-tuning, receive-side scaling on, and Windows' multimedia network throttling off.")
def net_tcp_tune(x: Ctx):
    import winreg
    good = 0
    for args in (["int", "tcp", "set", "global", "autotuninglevel=normal"], ["int", "tcp", "set", "global", "rss=enabled"]):
        good += 1 if _run(["netsh", *args], 20)[0] else 0
    try:
        with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile", 0, winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, "NetworkThrottlingIndex", 0, winreg.REG_DWORD, 0xFFFFFFFF)
            good += 1
    except OSError:
        pass
    return ("ok", "TCP tuned and network throttling off") if good == 3 else ("warn", f"{good}/3 settings applied")


@step("network", "wifi_power", "boost", "Stop Windows powering the Wi-Fi adapter down", "Power-saving on a Wi-Fi card causes drops and lag.", triggers=(r"Wi-Fi signal", r"packet loss"), scoped=lambda cx: bool(cx.get("wifi")) or not cx)
def net_wifi_power(x: Ctx):
    if x.cx and not x.cx.get("wifi"):
        return "skip", "this is not a Wi-Fi adapter"
    ok, out = _ps("$n=0; Get-NetAdapter -Physical | Where-Object { $_.Status -eq 'Up' -and (([string]$_.InterfaceDescription) -match 'Wi-?Fi|Wireless|802\\.11|WLAN') } | ForEach-Object { Set-NetAdapterPowerManagement -Name $_.Name -AllowComputerToTurnOffDevice Disabled -ErrorAction SilentlyContinue; $n++ }; $n", 40)
    n = int(out.split()[-1]) if out.split() and out.split()[-1].isdigit() else 0
    return ("ok", f"power saving off on {n} Wi-Fi adapter(s)") if n else ("skip", "no connected Wi-Fi adapter")


@step("network", "winsock", "fix", "Reset Winsock", "Repairs a broken network catalog (finishes after a restart). Skipped while a VPN is on.", triggers=(r"not reachable", r"neither ping"), needed_only=True)
def net_winsock(x: Ctx):
    if _vpn_active(x):
        return "skip", "a VPN is active - not touching the network catalog"
    ok, out = _run(["netsh", "winsock", "reset"], 40)
    if ok:
        x.restart = True
    return ("ok", "Winsock reset (restart to finish)") if ok else ("warn", _last_line(out) or "failed")


# ═════════════════════════════════════════════════════════════════════ MOTHERBOARD & FIRMWARE  (Windows cannot change firmware - it opens the right place)
@step("firmware", "bios_page", "fix", "Open the maker's BIOS / support page", "Looks up your board's BIOS download page in the browser.", triggers=(r"BIOS is .* old", r"legacy", r"Secure Boot", r"TPM"), admin=False)
def fw_bios_page(x: Ctx):
    return _open_bios_page(x.card)


@step("firmware", "tpm", "fix", "Open the TPM console", "Shows whether the TPM is ready.", triggers=(r"TPM",), needed_only=True, admin=False)
def fw_tpm(x: Ctx):
    try:
        subprocess.Popen(["mmc.exe", "tpm.msc"], creationflags=_NO_WINDOW)
        return "info", "TPM console opened"
    except Exception as exc:
        return "warn", str(exc)[:100]


def _open_bios_page(card: Optional[dict]) -> tuple:
    import webbrowser
    from urllib.parse import quote_plus
    card = card or {}
    maker, model = card.get("brand") or "", card.get("model") or card.get("name") or ""
    q = f"{maker} {model} BIOS update download".strip()
    webbrowser.open("https://www.google.com/search?q=" + quote_plus(q))
    return "info", f"opened a search for: {q}"


# ═════════════════════════════════════════════════════════════════════ DRIVERS & DEVICES
def _driver_scan(x: Ctx) -> tuple:
    a = _run(["pnputil", "/scan-devices"], 60)[0]
    b = _run(["UsoClient.exe", "StartScan"], 30)[0]
    if a or b:
        return "info", "devices re-detected and a Windows Update search was started - this only LOOKS for drivers, it installs nothing (use 'Install driver updates' on the Drivers section)"
    return "warn", "could not start the device scan"


@step("drivers", "rescan", "fix", "Re-detect all devices", "Windows re-reads every device - often clears a stuck 'code 10 / 43' device.", triggers=(r"error code", r"Device Manager"), admin=True)
def drv_rescan(x: Ctx):
    return ("ok", "device scan finished") if _run(["pnputil", "/scan-devices"], 90)[0] else ("warn", "the device scan failed")


@step("drivers", "restart_bad", "fix", "Restart devices that report an error", "Restarts only the devices Device Manager marks with an error.", triggers=(r"error code",), needed_only=True)
def drv_restart_bad(x: Ctx):
    ok, out = _ps("Get-PnpDevice -PresentOnly | Where-Object { $_.Status -eq 'Error' } | ForEach-Object { $_.InstanceId }", 40)
    ids = [l.strip() for l in out.splitlines() if l.strip()]
    if not ids:
        return "skip", "no device reports an error right now"
    good = 0
    for i in ids[:12]:
        good += 1 if _run(["pnputil", "/restart-device", i], 40)[0] else 0
    return ("ok", f"{good}/{len(ids)} device(s) restarted") if good else ("warn", "Windows could not restart the faulty device(s) - a new driver is needed")


@step("drivers", "update_all", "fix", "Install driver updates from Windows Update (real install)",
      "Finds every newer driver Windows Update offers for this PC, installs each one, then compares driver versions before/after and reports only what really changed. Makes a restore point first.",
      triggers=(r"Old driver", r"error code", r"no driver", r"not installed"), needed_only=True)
def drv_update_all(x: Ctx):
    from modules.health import driver_update as du
    if du.busy():
        return "warn", "a driver update is already running"
    chk = du.check(x.log)
    if not chk["ok"]:
        return "warn", "could not ask Windows Update: " + (chk["error"] or "unknown error")[:130]
    if not chk["updates"]:
        return "skip", "Windows Update has no newer drivers for this PC (maker-only drivers, e.g. latest graphics, are not offered there)"
    res = du.install([], x.log)
    x.restart = x.restart or bool(res.get("reboot"))
    state, note = du.summarize(res)
    left = res.get("problems_after") or []
    if left:
        note += f"; {len(left)} device(s) still report a problem: " + ", ".join((d.get("name") or "?")[:30] for d in left[:3])
        state = "warn"
    return state, note


@step("drivers", "winupdate", "optimize", "Start a background Windows Update scan (search only)", "Only asks Windows to look for updates in the background - it does NOT install anything. Use the real install step above.", triggers=(), admin=False, needed_only=True)
def drv_winupdate(x: Ctx):
    ok = _run(["UsoClient.exe", "StartScan"], 30)[0]
    return ("info", "scan started - nothing has been installed by this step") if ok else ("warn", "could not start the Windows Update scan")


# ═════════════════════════════════════════════════════════════════════ WINDOWS
@step("windows", "repair", "fix", "Repair Windows system files (DISM + SFC)", "Repairs damaged system files. Needs internet and can take 10-20 minutes.", triggers=(r"system files are damaged", r"component store"), needed_only=True)
def win_repair(x: Ctx):
    from modules.system import winutil as wu
    x.log("DISM RestoreHealth …")
    d = wu.run_dism()
    x.log("SFC /scannow …")
    s = wu.run_sfc()
    if d.success and s.success:
        return "ok", "component store and system files are healthy"
    return "warn", "a repair reported a problem - see C:\\Windows\\Logs\\CBS\\CBS.log"


@step("windows", "defender_update", "fix", "Update antivirus definitions", "Downloads the newest Microsoft Defender definitions.", triggers=(r"definitions",), admin=False)
def win_defender_update(x: Ctx):
    ok, out = _ps("Update-MpSignature -ErrorAction Stop", 300, strict=True)
    return ("ok", "definitions updated") if ok else ("warn", _last_line(out) or "the update failed (are you online?)")


@step("windows", "defender_on", "fix", "Turn Microsoft Defender protection on", "No antivirus is active: switches real-time protection on.", triggers=(r"No antivirus",), needed_only=True)
def win_defender_on(x: Ctx):
    ok, out = _ps("Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction Stop", 40, strict=True)
    return ("ok", "real-time protection is on") if ok else ("warn", "Windows refused (another security product or policy controls it)")


@step("windows", "firewall", "fix", "Turn Windows Firewall on", "Switches the firewall back on for the profiles that are off. Existing rules (and a VPN's) are kept.", triggers=(r"Firewall is turned off",), needed_only=True)
def win_firewall(x: Ctx):
    ok, out = _ps("Get-NetFirewallProfile | Where-Object { -not $_.Enabled } | ForEach-Object { Set-NetFirewallProfile -Name $_.Name -Enabled True -ErrorAction Stop; $_.Name }", 40, strict=True)
    return ("ok", "firewall is on for: " + ", ".join(out.split())) if ok and out.strip() else ("skip", "the firewall was already on") if ok else ("warn", "Windows refused (policy or another firewall)")


@step("windows", "updates", "fix", "Check for Windows updates", "Starts a Windows Update scan in the background.", triggers=(r"Windows update was installed", r"waiting for a restart"), admin=False)
def win_updates(x: Ctx):
    return ("ok", "Windows Update is checking in the background") if _run(["UsoClient.exe", "StartScan"], 30)[0] else ("warn", "could not start Windows Update")


@step("windows", "cleanup", "cleanup", "Clean temp files + update cache", "Temp folders and the Windows Update download cache.")
def win_cleanup(x: Ctx):
    from modules.system import winutil as wu
    a = wu.clean_temp_files()
    b = wu.clear_update_cache()
    return "ok", f"{a.mb_freed + b.mb_freed:.0f} MB freed"


@step("windows", "component", "cleanup", "Clean superseded Windows update files", "DISM component-store cleanup (can take several minutes).", needed_only=True)
def win_component(x: Ctx):
    ok, out = _run(["dism.exe", "/Online", "/Cleanup-Image", "/StartComponentCleanup"], 1800)
    return ("ok", "component store cleaned") if ok else ("warn", _last_line(out) or "DISM could not clean the component store")


@step("windows", "ntp", "optimize", "Keep the clock in sync", "Turns on automatic time sync (a wrong clock breaks HTTPS and updates).")
def win_ntp(x: Ctx):
    from modules.system import winutil as wu
    r = wu.enable_ntp_sync()
    return ("ok", "automatic time sync is on") if r.success else ("warn", "the time service refused")


@step("windows", "boot", "boost", "Free RAM before you work", "Trims memory and purges the standby list.", admin=False)
def win_boot(x: Ctx):
    return mem_trim(x)


# ═════════════════════════════════════════════════════════════════════ plan / run
def _cards_for(res: Optional[dict], cat: str, card_key: Optional[str]) -> list:
    if not res:
        return []
    return [c for c in res.get("cards", []) if c["category"] == cat and (not card_key or c["key"] == card_key)]


def _texts(cards: list) -> list:
    return [f["text"] for c in cards for f in c.get("findings", []) if f.get("level") in ("bad", "warn", "info")]


def _title(cat: str) -> str:
    from modules.health.scoring import CATEGORIES
    return next((t for k, t, _ in CATEGORIES if k == cat), cat)


def plan(category: str, card_key: Optional[str] = None) -> dict:
    """What a Fix & Optimize run would do for this component (or category, or 'all'), with every step marked 'fixes a found problem' or 'routine'."""
    from modules.health import scanner
    res = scanner.last_result()
    cats = [k for k, _, _ in scanner.COLLECTORS] if category == "all" else [category]
    groups = []
    for cat in cats:
        cards = _cards_for(res, cat, card_key if category != "all" else None)
        if res and not cards and category == "all":
            continue                                                            # e.g. no battery in a desktop
        texts = _texts(cards)
        cx = (cards[0].get("ctx") if (card_key and cards) else {}) or {}
        steps = []
        for s in BY_CAT.get(cat, []):
            if card_key and s.scoped and not s.scoped(cx):
                continue
            needed = any(re.search(t, txt, re.I) for t in s.triggers for txt in texts)
            steps.append({"id": s.id, "kind": s.kind, "label": s.label, "desc": s.desc, "needed": needed, "checked": needed or not s.needed_only, "admin": s.admin})
        manual = []
        for rx, text, act in MANUAL.get(cat, []):
            if any(re.search(rx, txt, re.I) for txt in texts):
                m = {"text": text}
                if act:
                    m.update(act)
                manual.append(m)
        groups.append({"category": cat, "title": _title(cat), "steps": steps, "manual": manual,
                       "problems": sum(1 for c in cards for f in c.get("findings", []) if f.get("level") in ("bad", "warn"))})
    return {"groups": groups, "admin": _is_admin(), "scanned": bool(res)}


_run_lock = threading.Lock()
_active: dict = {"id": None}


def start(category: str, card_key: Optional[str], only: Optional[list], emit: Callable, run_id: str) -> bool:
    """Run the chosen steps in the background.  Progress: 'health.fix_progress'; the end: 'health.fix_done' with the re-scanned result."""
    with _run_lock:
        if _active["id"]:
            return False
        _active["id"] = run_id

    def work() -> None:
        from modules.health import scanner
        results, restart, touched = [], False, []
        try:
            res = scanner.last_result()
            p = plan(category, card_key)
            want = set(only) if only is not None else {s["id"] for g in p["groups"] for s in g["steps"] if s["checked"]}
            order = [(g["category"], STEPS[s["id"]]) for g in p["groups"] for s in g["steps"] if s["id"] in want and s["id"] in STEPS]
            before = {c["key"]: c.get("score") for c in (res or {}).get("overall", {}).get("categories", [])}
            admin = _is_admin()
            total = len(order)
            for idx, (cat, st) in enumerate(order, 1):
                cards = _cards_for(res, cat, card_key if category != "all" else None)
                x = Ctx(cards[0] if (card_key and cards) else None, lambda m, _i=st.id: emit("health.fix_log", {"run": run_id, "id": _i, "text": m}))
                emit("health.fix_progress", {"run": run_id, "id": st.id, "cat": cat, "kind": st.kind, "label": st.label, "state": "start", "idx": idx, "total": total})
                t0 = time.time()
                if st.admin and not admin:
                    state, note = "skip", "needs Administrator - use 'Restart as Admin' and run it again"
                else:
                    try:
                        state, note = st.fn(x)
                    except Exception as exc:
                        _log.exception("fix step %s failed", st.id)
                        state, note = "warn", f"{type(exc).__name__}: {str(exc)[:120]}"
                restart = restart or x.restart
                if cat not in touched:
                    touched.append(cat)
                row = {"id": st.id, "cat": cat, "kind": st.kind, "label": st.label, "state": state, "note": note, "secs": round(time.time() - t0, 1)}
                results.append(row)
                emit("health.fix_progress", dict(row, run=run_id, idx=idx, total=total))
            new = res
            for cat in touched:                                                  # re-check what was touched so the new score is a real reading
                emit("health.fix_progress", {"run": run_id, "id": "rescan." + cat, "cat": cat, "kind": "check", "label": f"Checking {_title(cat).lower()} again", "state": "start", "idx": len(order), "total": len(order)})
                new = scanner.rescan_category(cat) or new
            after = {c["key"]: c.get("score") for c in (new or {}).get("overall", {}).get("categories", [])}
            manual = []
            for g in p["groups"]:
                manual.extend([dict(m, title=g["title"]) for m in g["manual"]])
            emit("health.fix_done", {"run": run_id, "category": category, "results": results, "restart": restart, "manual": manual, "before": before, "after": after,
                                     "overall_before": (res or {}).get("overall", {}).get("score"), "overall_after": (new or {}).get("overall", {}).get("score"), "result": new})
        except Exception as exc:
            _log.exception("health fix run failed")
            emit("health.fix_done", {"run": run_id, "category": category, "results": results, "error": str(exc), "restart": restart, "manual": [], "before": {}, "after": {}})
        finally:
            with _run_lock:
                _active["id"] = None

    threading.Thread(target=work, daemon=True, name="health-fix").start()
    return True


def running() -> Optional[str]:
    return _active["id"]


# ═════════════════════════════════════════════════════════════════════ small helpers the UI calls
def restart_now(seconds: int = 20) -> bool:
    return _run(["shutdown", "/r", "/t", str(int(seconds)), "/c", "DWUT: restarting to finish the Health fixes"], 15)[0]


def restart_to_uefi(seconds: int = 15) -> bool:
    return _run(["shutdown", "/r", "/fw", "/t", str(int(seconds)), "/c", "DWUT: restarting into the BIOS / UEFI settings"], 15)[0]


def bios_page(card: Optional[dict] = None) -> tuple:
    return _open_bios_page(card)
