# Copyright © 2026 Darko / Darko.Dev
"""modules/health/identity.py - turn the raw identifiers Windows gives (names, vendor codes, part numbers, PCI IDs, EDID codes) into brands.

Everything here is a lookup of an identifier that was READ from the machine.  If an identifier is not in a table the raw value is shown
unchanged; no brand is ever invented.  Serial numbers and MAC addresses are deliberately never collected, so a copied report is safe to share.
"""
from __future__ import annotations

import re
from typing import Optional

# keyword (regex, case-insensitive) -> brand.  The keyword that appears EARLIEST in the text wins ("Killer Wi-Fi 6 (Intel)" -> Killer).
_BRANDS = [
    (r"genuineintel|\bintel", "Intel"), (r"authenticamd|advanced micro|\bamd\b|\bryzen|\bradeon", "AMD"), (r"nvidia|geforce", "NVIDIA"),
    (r"samsung", "Samsung"), (r"western digital|\bwdc\b|^wd\b|\bwd[ _-]", "Western Digital"), (r"seagate|^st\d{3,}", "Seagate"),
    (r"toshiba", "Toshiba"), (r"kioxia", "Kioxia"), (r"crucial", "Crucial"), (r"micron", "Micron"), (r"kingston|hyperx", "Kingston"),
    (r"corsair", "Corsair"), (r"sandisk", "SanDisk"), (r"sabrent", "Sabrent"), (r"sk[ _-]?hynix|\bhynix", "SK hynix"), (r"adata|\bxpg\b", "ADATA"),
    (r"patriot", "Patriot"), (r"\bpny\b", "PNY"), (r"lexar", "Lexar"), (r"silicon[ _-]?power", "Silicon Power"), (r"team[ _-]?group", "TeamGroup"),
    (r"g\.?skill", "G.Skill"), (r"hewlett|^hp\b|\bhp ", "HP"), (r"\bdell", "Dell"), (r"lenovo", "Lenovo"), (r"\bacer\b", "Acer"),
    (r"asustek|\basus\b|\brog\b", "ASUS"), (r"micro-star|\bmsi\b", "MSI"), (r"gigabyte|\baorus", "Gigabyte"), (r"asrock", "ASRock"),
    (r"biostar", "Biostar"), (r"\bevga\b", "EVGA"), (r"zotac", "ZOTAC"), (r"sapphire", "Sapphire"), (r"powercolor", "PowerColor"), (r"\bxfx\b", "XFX"),
    (r"realtek", "Realtek"), (r"qualcomm", "Qualcomm"), (r"atheros", "Qualcomm Atheros"), (r"broadcom", "Broadcom"), (r"mediatek|ralink", "MediaTek"),
    (r"\bkiller\b", "Killer"), (r"razer", "Razer"), (r"apple", "Apple"), (r"microsoft", "Microsoft"), (r"vmware", "VMware"),
    (r"virtualbox|innotek", "VirtualBox"), (r"qemu", "QEMU"), (r"marvell", "Marvell"), (r"aquantia", "Aquantia"), (r"logitech", "Logitech"),
    (r"lg electronics|^lg\b", "LG"), (r"sony", "Sony"), (r"huawei", "Huawei"), (r"xiaomi", "Xiaomi"), (r"msi", "MSI"),
]
_BRAND_RES = [(re.compile(p, re.I), b) for p, b in _BRANDS]


def brand_from(*texts: Optional[str]) -> Optional[str]:
    best = None
    for t in texts:
        t = (t or "").strip()
        if not t:
            continue
        for rx, brand in _BRAND_RES:
            m = rx.search(t)
            if m and (best is None or m.start() < best[0]):
                best = (m.start(), brand)
        if best:
            return best[1]
    return None


def clean_model(name: str, brand: Optional[str] = None) -> str:
    """'Intel(R) Core(TM) i7-12700K CPU @ 3.60GHz' -> 'Core i7-12700K' ; 'NVIDIA GeForce RTX 3070' -> 'GeForce RTX 3070'."""
    n = re.sub(r"\((r|tm)\)", "", name or "", flags=re.I)
    n = re.sub(r"\s+CPU\b.*$|\s+@\s*[\d.]+\s*GHz.*$|\s+Processor\b.*$", "", n, flags=re.I)
    n = re.sub(r"\s+\d+-Core$", "", n, flags=re.I)
    n = re.sub(r"\s+", " ", n).strip()
    if brand:
        n = re.sub(r"^" + re.escape(brand) + r"[\s,:-]*", "", n, flags=re.I).strip() or n
    return n


# ── memory ───────────────────────────────────────────────────────────────────────────────────────────────────
JEDEC = {"802C": "Micron", "80AD": "SK hynix", "80CE": "Samsung", "859B": "Crucial", "04CD": "G.Skill", "0198": "Kingston", "029E": "Corsair"}


def memory_brand(manufacturer: str, part: str):
    """-> (brand, how).  how is 'reported' (the module says so), 'JEDEC code' (decoded from its manufacturer ID) or 'part number' (prefix rule)."""
    m = (manufacturer or "").strip()
    if m and m.lower() not in ("unknown", "undefined", "unspecified", "0000", "ffff", "to be filled by o.e.m."):
        code = m.upper().replace("0X", "")
        if code in JEDEC:
            return JEDEC[code], "JEDEC code"
        if not re.fullmatch(r"[0-9A-F]{4,}", code):
            return (brand_from(m) or m), "reported"
    p = (part or "").strip().upper()
    for rx, b in ((r"^CM[KWHTVXRU]|^CMS|^CMD", "Corsair"), (r"^F[3-5]-", "G.Skill"), (r"^KF\d|^KHX|^HX\d|^KVR|^KCP", "Kingston"),
                  (r"^CT\d|^BL[SK]?\d|^CP\d", "Crucial"), (r"^M3[79]\d|^M4\d\d[A-Z]\d", "Samsung"), (r"^HM[ATC]\d|^H5", "SK hynix"),
                  (r"^MT\d", "Micron"), (r"^AX[34]U|^AD[45]U|^AO1", "ADATA"), (r"^TF[GD]|^TL[GD]|^TD[GP]|^TP[GD]", "TeamGroup")):
        if re.search(rx, p):
            return b, "part number"
    if m:
        return None, f"unrecognised maker code {m}"
    return None, ""


FORM = {8: "DIMM", 12: "SODIMM", 13: "SRIMM", 9: "RIMM", 11: "FB-DIMM"}

# ── PCI vendor / subsystem-vendor IDs (GPU maker and board partner) ─────────────────────────────────────────────
PCI_VENDOR = {"10DE": "NVIDIA", "1002": "AMD", "1022": "AMD", "8086": "Intel", "1414": "Microsoft", "15AD": "VMware", "80EE": "VirtualBox"}
PCI_PARTNER = {"1043": "ASUS", "1462": "MSI", "1458": "Gigabyte", "3842": "EVGA", "19DA": "ZOTAC", "1682": "XFX", "1DA2": "Sapphire",
               "1849": "ASRock", "196E": "PNY", "148C": "PowerColor", "10B0": "Gainward", "1B4C": "KFA2 / Galax", "107D": "Leadtek",
               "1028": "Dell", "103C": "HP", "17AA": "Lenovo", "1025": "Acer", "10DE": "NVIDIA (reference / Founders Edition)", "1002": "AMD (reference)",
               "1569": "Palit", "7377": "Colorful", "8086": "Intel"}


def pci_ids(pnp: str):
    """'PCI\\VEN_10DE&DEV_2484&SUBSYS_87AD1043&REV_A1' -> (vendor_id, device_id, subsystem_vendor_id) or Nones."""
    m = re.search(r"VEN_([0-9A-F]{4})&DEV_([0-9A-F]{4})(?:&SUBSYS_([0-9A-F]{4})([0-9A-F]{4}))?", (pnp or "").upper())
    if not m:
        return None, None, None
    return m.group(1), m.group(2), m.group(4)


# ── monitors: the 3-letter PnP manufacturer code from the screen's EDID ──────────────────────────────────────────
MONITOR = {"GSM": "LG", "LGD": "LG Display", "SAM": "Samsung", "SDC": "Samsung Display", "DEL": "Dell", "ACR": "Acer", "AUS": "ASUS", "BNQ": "BenQ",
           "MSI": "MSI", "GBT": "Gigabyte", "AOC": "AOC", "HWP": "HP", "HPN": "HP", "LEN": "Lenovo", "PHL": "Philips", "VSC": "ViewSonic",
           "SNY": "Sony", "NEC": "NEC", "IVM": "Iiyama", "ENC": "Eizo", "AUO": "AU Optronics", "BOE": "BOE", "CMN": "Chimei Innolux",
           "APP": "Apple", "MEI": "Panasonic", "HSD": "HannStar", "TSB": "Toshiba", "SHP": "Sharp", "MAX": "Maxdata", "ONK": "ONKYO", "XMI": "Xiaomi",
           "KOA": "KOGAN", "NVT": "Novatek", "ENV": "Envision", "GWY": "Gateway", "MJI": "MAG InnoVision", "ARZ": "Alienware / Dell", "AMW": "Alienware"}

CHEMISTRY = {1: "Other", 2: "Unknown", 3: "Lead acid", 4: "Nickel-cadmium", 5: "Nickel metal hydride", 6: "Lithium-ion", 7: "Zinc air", 8: "Lithium polymer"}
