# Copyright © 2026 Darko / Darko.Dev
"""modules/health/psrun.py - tiny PowerShell-to-JSON runner shared by every health collector (and later by a BIOS category)."""
from __future__ import annotations

import json
import subprocess
import sys
from typing import Any, Optional

from core.logger import get_logger

_log = get_logger(__name__)
NO_WINDOW = 0x08000000

# Ev <log> <provider> <ids|$null> <days>  -> array of matching events, newest first (empty array when there are none)
_PRE = ("$ErrorActionPreference='SilentlyContinue';$ProgressPreference='SilentlyContinue';"
        "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;"
        "function Ev($log,$prov,$ids,$days){$f=@{LogName=$log;StartTime=(Get-Date).AddDays(-$days)};"
        "if($prov){$f.ProviderName=$prov};if($ids){$f.Id=$ids};"
        "@(Get-WinEvent -FilterHashtable $f -MaxEvents 1000 -ErrorAction SilentlyContinue)};")


def ps_json(script: str, timeout: int = 60) -> Optional[Any]:
    """Run a PowerShell snippet whose last statement prints JSON; returns the parsed value, or None if it failed / printed nothing."""
    if sys.platform != "win32":
        return None
    try:
        r = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _PRE + script],
                           capture_output=True, timeout=timeout, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
    except Exception as exc:
        _log.debug("ps_json failed: %s", exc)
        return None
    out = (r.stdout or b"").decode("utf-8", "replace").strip()
    if not out:
        return None
    start = min([i for i in (out.find("{"), out.find("[")) if i >= 0] or [0])
    try:
        return json.loads(out[start:])
    except Exception as exc:
        _log.debug("ps_json parse failed: %s | %.200s", exc, out)
        return None


def as_list(v) -> list:
    """PowerShell collapses 1-element arrays to objects and empty ones to null; undo that."""
    if v is None:
        return []
    return v if isinstance(v, list) else [v]
