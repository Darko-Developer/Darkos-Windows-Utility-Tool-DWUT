# Copyright © 2026 Darko / Darko.Dev
"""modules/health/scanner.py - REAL hardware / OS health scan.

Everything shown comes from the machine: WMI / CIM, Storage Management (SMART reliability counters), the Windows event log, NVML for NVIDIA
GPUs, psutil, and (if running) LibreHardwareMonitor sensors.  Nothing is simulated or estimated.  When a reading is unavailable (the PC does
not expose it, or it needs Administrator) the metric says so and is left out of the score.
"""
from __future__ import annotations

import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime
from typing import Callable, Optional

import psutil

from core.logger import get_logger
from modules.health import identity as ident
from modules.health import motherboard
from modules.health.psrun import NO_WINDOW, as_list, ps_json
from modules.health.scoring import Card, lin, overall, soft

_log = get_logger(__name__)
DAYS = 30                                   # how far back the event-log checks look


def _is_admin() -> bool:
    try:
        from app.permissions import is_admin
        return bool(is_admin())
    except Exception:
        return False


def _gb(b) -> str:
    try:
        b = float(b)
    except (TypeError, ValueError):
        return "?"
    return f"{b / 1e12:.2f} TB" if b >= 1e12 else f"{b / 1e9:.0f} GB" if b >= 1e10 else f"{b / 1e9:.1f} GB"


def _dur(sec: float) -> str:
    sec = int(sec)
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    return f"{d}d {h}h" if d else f"{h}h {m}m" if h else f"{m}m"


def _n(v, default=0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _count_score(n: int, per: float = 20.0, floor: float = 0.0) -> float:
    return max(floor, 100.0 - per * n)


def _unknown(key: str, cat: str, name: str, icon: str, why: str) -> Card:
    c = Card(key, cat, name, "", icon)
    c.find("info", why)
    return c


# ═════════════════════════════════════════════════════════════════════ CPU
_CPU_PS = r"""
$p = Get-CimInstance Win32_Processor | Select-Object -First 1
$pi = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation | Where-Object { $_.Name -eq '_Total' } | Select-Object -First 1
$w = @(Ev 'System' 'Microsoft-Windows-WHEA-Logger' $null 30)
$t = @(Ev 'System' 'Microsoft-Windows-Kernel-Processor-Power' 37 30)
$out = [ordered]@{
  name=[string]$p.Name; cores=[int]$p.NumberOfCores; threads=[int]$p.NumberOfLogicalProcessors; max_mhz=[int]$p.MaxClockSpeed; cur_mhz=[int]$p.CurrentClockSpeed;
  status=[string]$p.Status; l3_kb=[int]$p.L3CacheSize; mfr=[string]$p.Manufacturer; desc=[string]$p.Description; socket=[string]$p.SocketDesignation;
  freq_mhz=$(if($pi){ [double]$pi.ProcessorFrequency } else { $null }); pct_max=$(if($pi){ [double]$pi.PercentofMaximumFrequency } else { $null });
  whea=$w.Count; whea_last=$(if($w.Count -gt 0){ $w[0].TimeCreated.ToString('yyyy-MM-dd') } else { '' }); throttle=$t.Count
}
ConvertTo-Json -InputObject $out -Depth 3 -Compress
"""


def collect_cpu() -> list:
    psutil.cpu_percent(interval=None, percpu=True)                       # prime; the PowerShell call below takes > 1 s
    d = ps_json(_CPU_PS, 45)
    per = psutil.cpu_percent(interval=0.6, percpu=True) or [0.0]
    total = sum(per) / len(per)
    name = (d or {}).get("name", "").strip() or "Processor"
    if not d:
        d = {}
    c = Card("cpu", "cpu", name, f"{d.get('cores', 0) or psutil.cpu_count(logical=False)} cores / {d.get('threads', 0) or psutil.cpu_count()} threads", "cpu")
    c.brand = ident.brand_from(d.get("mfr"), name) or (d.get("mfr") or "").strip()
    c.model = ident.clean_model(name, c.brand)
    c.ident("Processor family", d.get("desc"))
    c.ident("Socket", d.get("socket"))
    if d.get("max_mhz"):
        c.ident("Base clock", f"{d['max_mhz'] / 1000:.2f} GHz")

    # temperature (shared sampler: LibreHW > thermal-zone counter > ACPI zone)
    try:
        from modules.system.temps import temps
        tr = temps.read()
        t, src = tr.get("cpu"), tr.get("cpu_src") or ""
    except Exception:
        t, src = None, ""
    if t is not None:
        c.metric("Temperature", f"{t:.0f} °C  ({src})", lin(t, 60, 95), 1.5, "CPU die temperature" if src in ("LibreHW", "OHM") else "ACPI thermal zone reading - the CPU itself can be a few degrees hotter")
        if t >= 90:
            c.find("bad", f"The CPU is running very hot ({t:.0f} °C). Check the cooler, fans and thermal paste.")
        elif t >= 80:
            c.find("warn", f"The CPU is warm ({t:.0f} °C). Clean the dust filters / heatsink and check airflow.")
    else:
        c.metric("Temperature", None, None, note="Windows does not expose a CPU temperature on this PC. Run LibreHardwareMonitor to get one.")

    c.metric("Load right now", f"{total:.0f} %", soft(lin(total, 90, 100)), 0.5, "momentary - a busy second is not a fault")
    hot = max(range(len(per)), key=lambda i: per[i])
    c.metric("Busiest core", f"core {hot}  ·  {per[hot]:.0f} %")

    if d.get("cur_mhz") and d.get("max_mhz"):
        pm = d.get("pct_max")
        shown = f"{_n(d.get('freq_mhz') or d['cur_mhz']) / 1000:.2f} GHz  of {d['max_mhz'] / 1000:.2f} GHz base"
        sc = None
        if pm is not None and total >= 60:                                   # only judge the clock while the CPU is actually busy
            sc = lin(pm, 90, 50)
            if pm < 70:
                c.find("warn", f"Under load the CPU is only running at {pm:.0f}% of its maximum clock - it is being held back (heat, power limit or a power plan).")
        c.metric("Clock speed", shown, sc, 1.0, "judged only while the CPU is busy; idle downclocking is normal" if sc is None else "while busy")

    whea = int(d.get("whea") or 0)
    if d:
        sc = 100.0 if whea == 0 else 65.0 if whea <= 3 else 40.0 if whea <= 10 else 20.0
        c.metric(f"Hardware error reports ({DAYS} d)", "none" if whea == 0 else f"{whea}  (last {d.get('whea_last')})", sc, 2.0,
                 "WHEA: errors the CPU / cache / memory controller / PCIe bus reported to Windows")
        if whea:
            c.find("bad" if whea > 3 else "warn", f"Windows logged {whea} hardware error report(s) in the last {DAYS} days. They can come from the CPU, its cache, the memory controller or the PCIe bus - unstable overclocks and failing parts show up here.")
            if whea > 10:
                c.cap(45)
        th = int(d.get("throttle") or 0)
        sc = 100.0 if th == 0 else round(30 + 0.7 * (lin(th, 0, 100) or 0), 1)
        c.metric(f"Firmware speed limiting ({DAYS} d)", "none" if th == 0 else f"{th} events", sc, 1.0, "the BIOS / firmware forced the CPU to slow down")
        if th:
            c.find("warn", f"Firmware limited the CPU speed {th} time(s) in {DAYS} days (usually heat, power delivery or a battery / power-limit setting).")
        if (d.get("status") or "OK") != "OK":
            c.cap(30)
            c.find("bad", f"Windows reports the processor status as '{d.get('status')}'.")
    if d.get("l3_kb"):
        c.metric("L3 cache", f"{d['l3_kb'] // 1024} MB")
    if not d:
        c.find("info", "Windows did not answer the detailed processor query, so only live readings are shown and no health score is given.")
    elif not c.findings:
        c.find("ok", "No CPU problems found.")
    return [c]


# ═════════════════════════════════════════════════════════════════════ MEMORY
_MEM_PS = r"""
$m = @(Get-CimInstance Win32_PhysicalMemory | ForEach-Object { [pscustomobject]@{ gb=[math]::Round($_.Capacity/1GB,1); speed=[int]$_.Speed; cfg=[int]$_.ConfiguredClockSpeed; mfr=([string]$_.Manufacturer).Trim(); part=([string]$_.PartNumber).Trim(); type=[int]$_.SMBIOSMemoryType; loc=[string]$_.DeviceLocator; ff=[int]$_.FormFactor } })
$d = @(Ev 'System' 'Microsoft-Windows-MemoryDiagnostics-Results' @(1201,1202) 3650)
$x = @(Ev 'System' 'Microsoft-Windows-Resource-Exhaustion-Detector' 2004 30)
$pf = @(Get-CimInstance Win32_PageFileUsage | ForEach-Object { [pscustomobject]@{ name=[string]$_.Name; alloc=[int]$_.AllocatedBaseSize; cur=[int]$_.CurrentUsage; peak=[int]$_.PeakUsage } })
$pm = Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory | Select-Object -First 1
$out = [ordered]@{
  modules=$m; diag_id=$(if($d.Count -gt 0){ [int]$d[0].Id } else { 0 }); diag_time=$(if($d.Count -gt 0){ $d[0].TimeCreated.ToString('yyyy-MM-dd') } else { '' });
  exhaust=$x.Count; pagefile=$pf; pages_sec=$(if($pm){ [double]$pm.PagesPersec } else { $null }); commit_pct=$(if($pm){ [double]$pm.PercentCommittedBytesInUse } else { $null })
}
ConvertTo-Json -InputObject $out -Depth 4 -Compress
"""


def collect_memory() -> list:
    d = ps_json(_MEM_PS, 45) or {}
    vm = psutil.virtual_memory()
    mods = as_list(d.get("modules"))
    types = {20: "DDR", 21: "DDR2", 24: "DDR3", 26: "DDR4", 34: "DDR5", 29: "LPDDR2", 30: "LPDDR3", 31: "LPDDR4", 35: "LPDDR5"}
    kind = next((types[m["type"]] for m in mods if m.get("type") in types), "")
    c = Card("memory", "memory", f"System memory  {_gb(vm.total)}", " · ".join(x for x in [kind, f"{len(mods)} module(s)" if mods else ""] if x), "memory")
    c.metric("In use", f"{vm.percent:.0f} %  ({_gb(vm.used)} of {_gb(vm.total)})", lin(vm.percent, 80, 97), 1.5, "RAM actually in use right now")
    if vm.percent >= 90:
        c.find("warn", "Memory is almost full - Windows will start using the slow page file. Close heavy apps or add RAM.")
    if d.get("commit_pct") is not None:
        cp = _n(d["commit_pct"])
        c.metric("Commit charge", f"{cp:.0f} %", lin(cp, 75, 98), 1.0, "memory promised to programs vs. what RAM + page file can back")
        if cp >= 90:
            c.find("warn", "Commit charge is above 90% - programs may start failing to allocate memory.")
    if d.get("pages_sec") is not None:
        ps = _n(d["pages_sec"])
        c.metric("Paging activity", f"{ps:.0f} pages/s", soft(lin(ps, 100, 1000)), 0.5, "sustained high values mean the PC is short of RAM")
    for pf in as_list(d.get("pagefile")):
        if pf.get("alloc"):
            used = _n(pf.get("cur")) / _n(pf["alloc"]) * 100
            c.metric(f"Page file ({(pf.get('name') or '').split(chr(92))[0] or 'C:'})", f"{used:.0f} %  of {pf['alloc']} MB", lin(used, 60, 95), 0.5)
    if d:
        ex = int(d.get("exhaust") or 0)
        c.metric(f"Out-of-memory events ({DAYS} d)", "none" if ex == 0 else f"{ex}", 100.0 if ex == 0 else max(10.0, 70.0 - 15 * ex), 1.5, "Windows warned it was running out of memory")
        if ex:
            c.find("bad", f"Windows ran out of memory {ex} time(s) in the last {DAYS} days.")
            if ex >= 3:
                c.cap(50)
        if d.get("diag_id") == 1201:
            c.metric("Windows Memory Diagnostic", f"passed  ({d.get('diag_time')})", 100.0, 2.0, "last run on record")
        elif d.get("diag_id") == 1202:
            c.metric("Windows Memory Diagnostic", f"FOUND ERRORS  ({d.get('diag_time')})", 0.0, 3.0)
            c.find("bad", "The last Windows Memory Diagnostic found hardware errors in your RAM. Test each stick on its own and replace the faulty one.")
            c.cap(25)
        else:
            c.metric("Windows Memory Diagnostic", "never run", None, note="Search 'Windows Memory Diagnostic' in the Start menu to run a full RAM test (needs a restart)")
    speeds = {(m.get("speed"), m.get("cfg")) for m in mods if m.get("speed")}
    if mods:
        sp = max((m.get("speed") or 0) for m in mods)
        cfg = max((m.get("cfg") or 0) for m in mods)
        if sp and cfg:
            c.metric("Speed", f"{cfg} MT/s  (rated {sp})")
            if cfg < sp * 0.9:
                c.find("info", f"Your RAM is rated for {sp} MT/s but runs at {cfg}. Enable XMP / EXPO in the BIOS to use its full speed.")
        brands, parts = [], []
        for m in mods:
            b, how = ident.memory_brand(m.get("mfr"), m.get("part"))
            brands.append(b)
            part = (m.get("part") or "").strip()
            parts.append(part)
            bits = [f"{m.get('gb'):g} GB", (b or "unknown brand"), part, f"{kind} {m.get('cfg') or m.get('speed') or ''}".strip(), ident.FORM.get(m.get("ff"), "")]
            c.ident(m.get("loc") or "Module", "  ·  ".join(x for x in bits if x), f"brand from {how}" if b and how and how != "reported" else "")
            c.inv.append({"group": "Memory", "icon": "memory", "brand": b or "unknown brand", "model": part,
                          "detail": f"{m.get('gb'):g} GB · {kind} {m.get('cfg') or m.get('speed') or ''} · {m.get('loc') or 'module'}".replace("  ", " ")})
        uniq = {b for b in brands if b}
        c.brand = next(iter(uniq)) if len(uniq) == 1 else ("mixed brands" if uniq else "")
        up = {p for p in parts if p}
        c.model = next(iter(up)) if len(up) == 1 else (f"{len(up)} different modules" if up else "")
        if len(mods) == 1 and vm.total > 4e9:
            c.find("info", "Only one memory stick is installed - a second matching stick enables dual-channel (faster) mode.")
    if not d:
        c.find("info", "Windows did not answer the detailed memory query, so only live readings are shown.")
    elif not any(f["level"] in ("warn", "bad") for f in c.findings):
        c.find("ok", "No memory problems found.")
    return [c]


# ═════════════════════════════════════════════════════════════════════ STORAGE
_DISK_PS = r"""
$dd = @(Get-CimInstance Win32_DiskDrive | ForEach-Object { [pscustomobject]@{ fw=[string]$_.FirmwareRevision; index=[int]$_.Index; pnp=[string]$_.PNPDeviceID; status=[string]$_.Status; iface=[string]$_.InterfaceType; model=[string]$_.Model } })
$pf = @(Get-CimInstance -Namespace 'root\wmi' -ClassName MSStorageDriver_FailurePredictStatus | ForEach-Object { [pscustomobject]@{ inst=[string]$_.InstanceName; fail=[bool]$_.PredictFailure } })
$pd = @(Get-PhysicalDisk | ForEach-Object {
  $r = $_ | Get-StorageReliabilityCounter
  [pscustomobject]@{ num=[int]$_.DeviceId; model=[string]$_.FriendlyName; media=[string]$_.MediaType; bus=[string]$_.BusType; size=[double]$_.Size; health=[string]$_.HealthStatus; fwv=[string]$_.FirmwareVersion; mfr=[string]$_.Manufacturer;
    oper=(@($_.OperationalStatus) -join ', '); spindle=[double]$_.SpindleSpeed; temp=$r.Temperature; wear=$r.Wear; hours=$r.PowerOnHours;
    rdunc=$r.ReadErrorsUncorrected; wrunc=$r.WriteErrorsUncorrected; loads=$r.LoadUnloadCycleCount; starts=$r.StartStopCycleCount }
})
$vols = @(Get-Volume | Where-Object { $_.DriveLetter -and $_.DriveType -eq 'Fixed' } | ForEach-Object {
  $dl = [string]$_.DriveLetter; $pt = Get-Partition -DriveLetter $dl | Select-Object -First 1
  [pscustomobject]@{ letter=$dl; disk=$(if($pt){ [int]$pt.DiskNumber } else { -1 }); fs=[string]$_.FileSystem; health=[string]$_.HealthStatus; size=[double]$_.Size; free=[double]$_.SizeRemaining; label=[string]$_.FileSystemLabel }
})
$ev = @((Ev 'System' 'disk' @(7,11,51,52,153) 30) + (Ev 'System' 'Ntfs' @(55) 30)) | ForEach-Object {
  $dk = -1; if($_.Message -match 'Harddisk(\d+)'){ $dk = [int]$Matches[1] } elseif($_.Message -match 'Disk (\d+)'){ $dk = [int]$Matches[1] }
  [pscustomobject]@{ id=[int]$_.Id; disk=$dk; time=$_.TimeCreated.ToString('yyyy-MM-dd'); src=[string]$_.ProviderName }
}
$out = [ordered]@{ dd=$dd; pf=$pf; pd=$pd; vols=$vols; ev=@($ev) }
ConvertTo-Json -InputObject $out -Depth 5 -Compress
"""


def collect_storage() -> list:
    d = ps_json(_DISK_PS, 90)
    admin = _is_admin()
    if not d:
        return [_unknown("storage", "storage", "Storage", "storage", "Could not query the storage subsystem (Storage Management / WMI did not answer).")]
    drives, preds, vols, evs = as_list(d.get("dd")), as_list(d.get("pf")), as_list(d.get("vols")), as_list(d.get("ev"))
    cards = []
    for p in as_list(d.get("pd")):
        num = int(p.get("num", -1))
        media = (p.get("media") or "").replace("Unspecified", "").strip()
        bus = p.get("bus") or ""
        ssd = media.upper() in ("SSD", "SCM") or bus.upper() == "NVME"
        hdd = media.upper() == "HDD"
        kind = "NVMe SSD" if bus.upper() == "NVME" else "SSD" if ssd else "Hard disk (HDD)" if hdd else (media or "Drive")
        c = Card(f"disk{num}", "storage", (p.get("model") or f"Disk {num}").strip(), f"Disk {num} · {kind} · {bus} · {_gb(p.get('size'))}", "storage")

        mfr = (p.get("mfr") or "").strip()
        c.brand = ident.brand_from(p.get("model"), mfr) or (mfr if mfr.upper() not in ("", "ATA", "NVME", "SCSI", "(STANDARD DISK DRIVES)") else "")
        c.model = ident.clean_model(p.get("model") or "", c.brand)
        _dd0 = next((x for x in drives if x.get("index") == num), None) or {}
        c.ctx = {"disk": num, "ssd": bool(ssd), "hdd": bool(hdd),
                 "letters": sorted({str(v.get("letter")) for v in vols if v.get("disk") == num and v.get("letter")})}
        c.ident("Firmware", p.get("fwv") or _dd0.get("fw"))
        c.ident("Type", f"{kind}  ·  {bus}" if bus else kind)
        c.ident("Capacity", _gb(p.get("size")))
        h = (p.get("health") or "").lower()
        if h:
            c.metric("Windows health status", p.get("health"), 100.0 if h == "healthy" else 35.0 if h == "warning" else 0.0 if h == "unhealthy" else None, 2.0, f"operational: {p.get('oper')}")
            if h == "warning":
                c.find("warn", "Windows reports this drive as 'Warning'. Back up your data now.")
                c.cap(50)
            elif h == "unhealthy":
                c.find("bad", "Windows reports this drive as UNHEALTHY. Back up your data immediately and replace the drive.")
                c.cap(10)
        dd = next((x for x in drives if x.get("index") == num), None)
        if dd:
            if (dd.get("status") or "").lower().startswith("pred"):
                c.metric("SMART", "FAILURE PREDICTED", 0.0, 3.0)
                c.find("bad", "The drive's own SMART system predicts it will fail soon. Back up and replace it.")
                c.cap(5)
            else:
                pid = (dd.get("pnp") or "").lower()
                pr = next((x for x in preds if pid and (x.get("inst") or "").lower().startswith(pid)), None)
                if pr is not None:
                    c.metric("SMART failure prediction", "FAILING" if pr.get("fail") else "none", 0.0 if pr.get("fail") else 100.0, 3.0, "the drive's own self-assessment")
                    if pr.get("fail"):
                        c.find("bad", "The drive's SMART data predicts failure. Back up and replace it.")
                        c.cap(5)
                else:
                    c.metric("SMART status", dd.get("status") or "OK", 100.0 if (dd.get("status") or "OK") == "OK" else 40.0, 1.0)

        wear = p.get("wear")
        if wear is not None and ssd:
            w = _n(wear)
            c.metric("Life used (wear)", f"{w:.0f} %", lin(w, 30, 100), 2.0, "how much of the flash write endurance is consumed")
            if w >= 90:
                c.find("bad", f"This SSD has used {w:.0f}% of its rated lifetime. Plan to replace it.")
            elif w >= 70:
                c.find("warn", f"This SSD has used {w:.0f}% of its rated lifetime.")
        elif ssd:
            c.metric("Life used (wear)", None, None, note="Admin rights needed, or this drive does not report wear" if not admin else "This drive does not report wear")
        if p.get("temp") is not None and _n(p["temp"]) > 0:
            t = _n(p["temp"])
            c.metric("Temperature", f"{t:.0f} °C", lin(t, 55, 75) if ssd else lin(t, 40, 60), 1.0)
            if t >= (70 if ssd else 55):
                c.find("warn", f"The drive is hot ({t:.0f} °C). Improve airflow; NVMe drives may need a heatsink.")
        elif not admin:
            c.metric("Temperature", None, None, note="Run DWUT as Administrator to read drive sensors")
        ru, wu = p.get("rdunc"), p.get("wrunc")
        if ru is not None or wu is not None:
            errs = int(_n(ru) + _n(wu))
            c.metric("Uncorrectable read/write errors", "none" if errs == 0 else str(errs), 100.0 if errs == 0 else max(0.0, 60.0 - 10 * errs), 2.5)
            if errs:
                c.find("bad", f"The drive logged {errs} uncorrectable read/write error(s). That means data could not be read or written reliably.")
                c.cap(35)
        if p.get("hours") is not None:
            hrs = _n(p["hours"])
            c.metric("Power-on time", f"{hrs:,.0f} h  ({hrs / 24 / 365:.1f} years)", lin(hrs, 25000, 60000) if hdd else None, 0.4, "age of a spinning disk raises failure risk" if hdd else "")
        if hdd and p.get("loads") is not None and _n(p["loads"]) > 0:
            c.metric("Head park cycles", f"{_n(p['loads']):,.0f}", lin(_n(p["loads"]), 300000, 600000), 0.6, "spinning drives are rated for roughly 300 000 - 600 000")
        if hdd and p.get("spindle"):
            c.metric("Spindle speed", f"{_n(p['spindle']):.0f} RPM")

        mine = [e for e in evs if e.get("disk") == num]
        if d.get("ev") is not None:
            c.metric(f"Disk error events ({DAYS} d)", "none" if not mine else f"{len(mine)}  (last {max(e['time'] for e in mine)})", 100.0 if not mine else max(10.0, 65.0 - 8 * len(mine)), 2.0, "bad blocks, controller errors, retried I/O, paging errors")
            if mine:
                c.find("bad" if len(mine) >= 5 else "warn", f"Windows logged {len(mine)} disk error event(s) for this drive in {DAYS} days (bad blocks / controller errors / retried I/O). Check the cable and back up important data.")
                if len(mine) >= 5:
                    c.cap(40)
        for v in sorted((x for x in vols if x.get("disk") == num), key=lambda x: x.get("letter") or ""):
            size, free = _n(v.get("size")), _n(v.get("free"))
            if size > 0:
                fp = free / size * 100
                c.metric(f"Volume {v['letter']}:  {v.get('label') or ''}".rstrip(), f"{fp:.0f} % free  ({_gb(free)} of {_gb(size)}, {v.get('fs')})", lin(fp, 20, 5), 1.0)
                if fp < 10:
                    c.find("warn", f"Volume {v['letter']}: is almost full ({fp:.0f}% free). Low free space slows Windows and shortens SSD life.")
            vh = (v.get("health") or "").lower()
            if vh and vh != "healthy":
                c.find("bad", f"Windows marks volume {v['letter']}: as '{v.get('health')}'. Run chkdsk.")
                c.cap(45)
        if not any(f["level"] in ("warn", "bad") for f in c.findings):
            c.find("ok", "No storage problems found.")
        cards.append(c)
    other = [e for e in evs if e.get("disk", -1) < 0]
    if other and cards:
        cards[0].find("info", f"{len(other)} more disk event(s) in the last {DAYS} days could not be matched to a specific drive.")
    return cards or [_unknown("storage", "storage", "Storage", "storage", "No physical drives were reported.")]


# ═════════════════════════════════════════════════════════════════════ GPU
_GPU_PS = r"""
$v = @(Get-CimInstance Win32_VideoController | ForEach-Object { [pscustomobject]@{ name=[string]$_.Name; driver=[string]$_.DriverVersion; date=$(if($_.DriverDate){ $_.DriverDate.ToString('yyyy-MM-dd') } else { '' }); status=[string]$_.Status; err=[int]$_.ConfigManagerErrorCode; vendor=[string]$_.AdapterCompatibility; pnp=[string]$_.PNPDeviceID; chip=[string]$_.VideoProcessor; hres=[int]$_.CurrentHorizontalResolution; vres=[int]$_.CurrentVerticalResolution; hz=[int]$_.CurrentRefreshRate } })
$vr = @(Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11cd-be10-08002be10318}\0*' | ForEach-Object { [pscustomobject]@{ desc=[string]$_.DriverDesc; vram=$_.'HardwareInformation.qwMemorySize' } })
$tdr = @(Ev 'System' 'Display' 4101 30)
$out = [ordered]@{ v=$v; vr=$vr; tdr=$tdr.Count; tdr_last=$(if($tdr.Count -gt 0){ $tdr[0].TimeCreated.ToString('yyyy-MM-dd') } else { '' }) }
ConvertTo-Json -InputObject $out -Depth 4 -Compress
"""


def _nvml_gpus() -> list:
    out = []
    try:
        import pynvml
        pynvml.nvmlInit()
    except Exception:
        return out
    try:
        def _s(x):
            return x.decode("utf-8", "replace") if isinstance(x, bytes) else str(x)
        try:
            drv = _s(pynvml.nvmlSystemGetDriverVersion())
        except Exception:
            drv = ""
        for i in range(pynvml.nvmlDeviceGetCount()):
            h = pynvml.nvmlDeviceGetHandleByIndex(i)
            g = {"name": _s(pynvml.nvmlDeviceGetName(h)), "driver": drv}

            def get(key, fn):
                try:
                    g[key] = fn()
                except Exception:
                    g[key] = None
            get("temp", lambda: pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU))
            get("util", lambda: pynvml.nvmlDeviceGetUtilizationRates(h).gpu)
            get("mem_used", lambda: pynvml.nvmlDeviceGetMemoryInfo(h).used)
            get("mem_total", lambda: pynvml.nvmlDeviceGetMemoryInfo(h).total)
            get("power", lambda: pynvml.nvmlDeviceGetPowerUsage(h) / 1000.0)
            get("power_limit", lambda: pynvml.nvmlDeviceGetEnforcedPowerLimit(h) / 1000.0)
            get("fan", lambda: pynvml.nvmlDeviceGetFanSpeed(h))
            get("clk", lambda: pynvml.nvmlDeviceGetClockInfo(h, pynvml.NVML_CLOCK_GRAPHICS))
            get("clk_max", lambda: pynvml.nvmlDeviceGetMaxClockInfo(h, pynvml.NVML_CLOCK_GRAPHICS))
            fn = getattr(pynvml, "nvmlDeviceGetCurrentClocksEventReasons", None) or getattr(pynvml, "nvmlDeviceGetCurrentClocksThrottleReasons", None)
            get("throttle", (lambda: fn(h)) if fn else (lambda: None))
            get("pcie_gen", lambda: pynvml.nvmlDeviceGetCurrPcieLinkGeneration(h))
            get("pcie_gen_max", lambda: pynvml.nvmlDeviceGetMaxPcieLinkGeneration(h))
            get("pcie_w", lambda: pynvml.nvmlDeviceGetCurrPcieLinkWidth(h))
            get("pcie_w_max", lambda: pynvml.nvmlDeviceGetMaxPcieLinkWidth(h))
            get("ecc_unc", lambda: pynvml.nvmlDeviceGetTotalEccErrors(h, pynvml.NVML_MEMORY_ERROR_TYPE_UNCORRECTED, pynvml.NVML_VOLATILE_ECC))
            out.append(g)
    finally:
        try:
            pynvml.nvmlShutdown()
        except Exception:
            pass
    return out


def collect_gpu() -> list:
    d = ps_json(_GPU_PS, 45) or {}
    nv = _nvml_gpus()
    vrams = as_list(d.get("vr"))
    cards = []
    tdr = int(d.get("tdr") or 0)
    adapters = [a for a in as_list(d.get("v")) if not any(x in (a.get("name") or "").lower() for x in ("remote display", "virtual", "meta ", "displaylink", "indirect"))]
    if not adapters:
        return [_unknown("gpu", "gpu", "Graphics", "gpu", "No graphics adapter was reported by Windows.")]
    for idx, a in enumerate(adapters):
        name = (a.get("name") or "Graphics adapter").strip()
        g = next((x for x in nv if x["name"].lower() in name.lower() or name.lower() in x["name"].lower()), None)
        res = f"{a['hres']}x{a['vres']} @ {a['hz']} Hz" if a.get("hres") else ""
        c = Card(f"gpu{idx}", "gpu", name, " · ".join(x for x in [a.get("vendor"), res] if x), "gpu")
        ven, dev, sub = ident.pci_ids(a.get("pnp"))
        c.brand = ident.PCI_VENDOR.get(ven or "") or ident.brand_from(a.get("vendor"), name) or (a.get("vendor") or "").strip()
        c.model = ident.clean_model(name, c.brand)
        _bn = (c.brand + " " + name).lower()
        c.ctx = {"vendor": "nvidia" if "nvidia" in _bn or "geforce" in _bn else "amd" if ("amd" in _bn or "radeon" in _bn or "advanced micro" in _bn) else "intel" if "intel" in _bn else ""}
        if (a.get("chip") or "").strip().lower() != name.lower():
            c.ident("Graphics chip", a.get("chip"))
        if ven and dev:
            c.ident("PCI ID (vendor:device)", f"{ven}:{dev}")
        if sub and sub in ident.PCI_PARTNER and sub != ven:
            c.ident("Card maker", ident.PCI_PARTNER[sub], "from PCI subsystem ID")
        elif sub and sub == ven:
            c.ident("Card maker", ident.PCI_PARTNER.get(sub, c.brand), "from PCI subsystem ID")
        err = int(a.get("err") or 0)
        c.metric("Device status", "working properly" if err == 0 and (a.get("status") or "OK") == "OK" else f"problem (code {err})", 100.0 if err == 0 and (a.get("status") or "OK") == "OK" else 10.0, 2.0)
        if err:
            c.find("bad", f"Windows reports a problem with this graphics device (Device Manager code {err}).")
            c.cap(20)
        if "basic display" in name.lower() or "basic render" in name.lower():
            c.find("warn", "Windows is using its generic graphics driver. Install the real driver from NVIDIA / AMD / Intel for full performance.")
            c.cap(55)
        age = None
        try:
            age = (date.today() - datetime.strptime(a.get("date") or "", "%Y-%m-%d").date()).days / 365.25
        except ValueError:
            pass
        c.metric("Driver", f"{a.get('driver') or '?'}" + (f"  ({a['date']}, {age:.1f} years old)" if age is not None else ""), None)
        if age is not None and age > 2 and "basic" not in name.lower():
            c.find("info", f"The graphics driver is {age:.1f} years old. A newer one may fix bugs and improve game performance.")
        vram = next((v.get("vram") for v in vrams if (v.get("desc") or "").lower() == name.lower() and isinstance(v.get("vram"), (int, float))), None)
        if g:
            if g["temp"] is not None:
                c.metric("Temperature", f"{g['temp']} °C", lin(g["temp"], 70, 92), 1.5, "GPU core (NVML)")
                if g["temp"] >= 88:
                    c.find("bad", f"The GPU is very hot ({g['temp']} °C). Check fans and case airflow.")
                elif g["temp"] >= 80:
                    c.find("warn", f"The GPU is hot ({g['temp']} °C).")
            if g["util"] is not None:
                c.metric("Load right now", f"{g['util']} %")
            if g["mem_total"]:
                mp = g["mem_used"] / g["mem_total"] * 100
                c.metric("Video memory", f"{mp:.0f} %  ({g['mem_used'] / 2**30:.1f} of {g['mem_total'] / 2**30:.0f} GB)", soft(lin(mp, 92, 100)), 0.5)
            if g["power"] is not None and g["power_limit"]:
                c.metric("Power draw", f"{g['power']:.0f} W of {g['power_limit']:.0f} W limit")
            if g["fan"] is not None:
                c.metric("Fan speed", f"{g['fan']} %", None, note="0 % at idle is normal (zero-RPM mode)")
            if g["clk"] and g["clk_max"]:
                c.metric("Core clock", f"{g['clk']} MHz  of {g['clk_max']} MHz max")
            thr = g.get("throttle")
            if thr is not None:
                thermal, hw_slow = bool(thr & (0x20 | 0x40)), bool(thr & (0x8 | 0x80))
                state = "thermal slowdown" if thermal else "hardware slowdown" if hw_slow else "none"
                c.metric("Clock throttling now", state, 25.0 if thermal else 40.0 if hw_slow else 100.0, 1.5, "the GPU is lowering its clock to protect itself")
                if thermal:
                    c.find("bad", "The GPU is slowing itself down because it is too hot.")
                elif hw_slow:
                    c.find("warn", "The GPU is in a hardware slowdown (power or temperature protection).")
            if g.get("pcie_w") and g.get("pcie_w_max"):
                c.metric("PCIe link", f"Gen{g['pcie_gen']} x{g['pcie_w']}  (max Gen{g['pcie_gen_max']} x{g['pcie_w_max']})", None, note="the link drops while idle to save power; check it under load")
            if g.get("ecc_unc"):
                c.metric("Uncorrected memory errors", str(g["ecc_unc"]), 0.0, 3.0)
                c.find("bad", "The GPU's memory reported uncorrectable ECC errors.")
                c.cap(30)
            vram = g["mem_total"] or vram
        else:
            gt = None
            try:
                from modules.system.temps import temps
                tr = temps.read()
                gt = tr.get("gpu")
                gsrc = tr.get("gpu_src") or ""
            except Exception:
                gsrc = ""
            if gt is not None and len(adapters) == 1:
                c.metric("Temperature", f"{gt:.0f} °C  ({gsrc})", lin(gt, 70, 92), 1.5)
                if gt >= 88:
                    c.find("bad", f"The GPU is very hot ({gt:.0f} °C). Check fans and case airflow.")
            else:
                c.metric("Temperature", None, None, note="This GPU's temperature is not exposed by Windows. Run LibreHardwareMonitor to read it.")
        if vram:
            c.metric("Video memory (total)", f"{_n(vram) / 2**30:.0f} GB" if _n(vram) >= 2**30 else f"{_n(vram) / 2**20:.0f} MB")
        if idx == 0 or len(adapters) == 1:
            c.metric(f"Driver crashes ({DAYS} d)", "none" if tdr == 0 else f"{tdr}  (last {d.get('tdr_last')})", 100.0 if tdr == 0 else max(10.0, 75.0 - 20 * tdr), 2.0, "'Display driver stopped responding and recovered'")
            if tdr:
                c.find("bad" if tdr >= 3 else "warn", f"The graphics driver crashed and recovered {tdr} time(s) in {DAYS} days (screen flicker / black screen). Update or cleanly reinstall the driver; check temperatures and overclocks.")
                if tdr >= 3:
                    c.cap(45)
        if not any(f["level"] in ("warn", "bad") for f in c.findings):
            c.find("ok", "No graphics problems found.")
        cards.append(c)
    return cards


# ═════════════════════════════════════════════════════════════════════ BATTERY
_BAT_PS = r"""
$b = Get-CimInstance Win32_Battery | Select-Object -First 1
if($b){
  $s = Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryStaticData | Select-Object -First 1
  $f = Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryFullChargedCapacity | Select-Object -First 1
  $c = Get-CimInstance -Namespace 'root\wmi' -ClassName BatteryCycleCount | Select-Object -First 1
  $out = [ordered]@{ present=$true; name=[string]$b.Name; design=$(if($s){ [double]$s.DesignedCapacity } else { $null }); full=$(if($f){ [double]$f.FullChargedCapacity } else { $null });
    cycles=$(if($c){ [double]$c.CycleCount } else { $null }); mfr=$(if($s){ [string]$s.ManufactureName } else { '' }); devname=$(if($s){ [string]$s.DeviceName } else { '' }); status=[int]$b.BatteryStatus; chem=[int]$b.Chemistry }
} else { $out = [ordered]@{ present=$false } }
ConvertTo-Json -InputObject $out -Depth 3 -Compress
"""


def collect_battery() -> list:
    d = ps_json(_BAT_PS, 30) or {}
    if not d.get("present"):
        return []
    sb = None
    try:
        sb = psutil.sensors_battery()
    except Exception:
        pass
    c = Card("battery", "battery", (d.get("name") or "Battery").strip() or "Battery", (d.get("mfr") or "").strip(), "battery")
    c.brand = ident.brand_from(d.get("mfr"), d.get("devname")) or (d.get("mfr") or "").strip()
    c.model = (d.get("devname") or d.get("name") or "").strip()
    c.ident("Chemistry", ident.CHEMISTRY.get(int(d.get("chem") or 0)) if int(d.get("chem") or 0) not in (0, 1, 2) else "")
    if d.get("design"):
        c.ident("Design capacity", f"{_n(d['design']) / 1000:.1f} Wh")
    design, full = d.get("design"), d.get("full")
    if design and full and _n(design) > 0:
        hp = min(100.0, _n(full) / _n(design) * 100)
        c.metric("Battery health", f"{hp:.0f} %  ({_n(full) / 1000:.1f} of {_n(design) / 1000:.1f} Wh)", lin(hp, 90, 40), 3.0, "present full-charge capacity vs. the capacity it was built with")
        if hp < 60:
            c.find("bad", f"The battery only holds {hp:.0f}% of its original charge. Consider replacing it.")
        elif hp < 80:
            c.find("warn", f"The battery has worn down to {hp:.0f}% of its original capacity.")
    else:
        c.metric("Battery health", None, None, note="This battery does not report its design capacity to Windows")
    if d.get("cycles") is not None and _n(d["cycles"]) > 0:
        cy = _n(d["cycles"])
        c.metric("Charge cycles", f"{cy:.0f}", lin(cy, 400, 1200), 1.0, "most laptop batteries are good for roughly 500 - 1000")
    if sb is not None:
        c.metric("Charge now", f"{sb.percent:.0f} %  ({'plugged in' if sb.power_plugged else 'on battery'})")
    if not c.findings:
        c.find("ok", "No battery problems found.")
    return [c]


# ═════════════════════════════════════════════════════════════════════ THERMALS / COOLING
_THERM_PS = r"""
$z = @(Get-CimInstance Win32_PerfFormattedData_Counters_ThermalZoneInformation | ForEach-Object { [pscustomobject]@{ name=[string]$_.Name; k=[double]$_.Temperature; limit=[double]$_.PercentPassiveLimit; reasons=[int]$_.ThrottleReasons } })
$a = @(Get-CimInstance -Namespace 'root\wmi' -ClassName MSAcpi_ThermalZoneTemperature | ForEach-Object { [pscustomobject]@{ name=[string]$_.InstanceName; dk=[double]$_.CurrentTemperature } })
$f = @(Get-CimInstance Win32_Fan | ForEach-Object { [pscustomobject]@{ name=[string]$_.Name; status=[string]$_.Status } })
$out = [ordered]@{ z=$z; a=$a; fans=$f }
ConvertTo-Json -InputObject $out -Depth 4 -Compress
"""


def collect_thermal(board: dict) -> list:
    d = ps_json(_THERM_PS, 30) or {}
    c = Card("thermal", "thermal", "Temperatures & cooling", "", "thermal")
    zones = [z for z in as_list(d.get("z")) if _n(z.get("k")) > 200]
    for z in zones[:6]:
        t = _n(z["k"]) - 273.15
        if 0 < t < 130:
            c.metric(f"Thermal zone {(z.get('name') or '').replace(chr(92), '').strip() or '?'}", f"{t:.0f} °C", lin(t, 70, 95), 1.0, "ACPI thermal zone (chassis / board sensor)")
    if zones:
        lim = min(_n(z.get("limit"), 100) for z in zones)
        c.metric("Thermal throttling limit", "none" if lim >= 100 else f"CPU held to {lim:.0f} %", lin(lim, 100, 40), 2.0, "100 % = Windows is not holding the CPU back for heat")
        if lim < 100:
            c.find("bad" if lim < 70 else "warn", f"Windows is holding the processor to {lim:.0f}% of its power to keep it cool.")
    elif not zones:
        for a in as_list(d.get("a"))[:4]:
            t = _n(a.get("dk")) / 10.0 - 273.15
            if 0 < t < 130:
                c.metric("ACPI thermal zone", f"{t:.0f} °C", lin(t, 70, 95), 1.0)
    sens = board.get("sensors") or {}
    for t in sens.get("temps", [])[:6]:
        c.metric(f"Board: {t['name']}", f"{t['c']:.0f} °C", lin(t["c"], 65, 90), 1.0, f"{sens.get('source')} sensor")
    fans = sens.get("fans", [])
    for f in fans[:8]:
        c.metric(f"Fan: {f['name']}", f"{f['rpm']} RPM" if f["rpm"] else "stopped", None, note="0 RPM can be normal at low temperature (zero-RPM mode)")
    stopped = [f for f in fans if f["rpm"] == 0 and any(k in f["name"].lower() for k in ("cpu", "pump"))]
    if stopped:
        c.find("bad", f"{stopped[0]['name']} reads 0 RPM. A stopped CPU fan or pump will overheat the processor.")
        c.cap(30)
    wf = as_list(d.get("fans"))
    if wf:
        bad = [f for f in wf if (f.get("status") or "OK") not in ("OK", "")]
        c.metric("Fan devices reported by Windows", f"{len(wf)}", 100.0 if not bad else 30.0, 1.0)
        if bad:
            c.find("bad", "Windows reports a cooling fan with a fault.")
    if not c.metrics:
        c.metric("Temperature sensors", None, None, note="This PC does not expose thermal sensors to Windows. Run LibreHardwareMonitor / OpenHardwareMonitor and DWUT will read fans, board temperatures and voltages from it.")
        c.find("info", "No temperature or fan sensors are available to read on this PC.")
    elif not c.findings:
        c.find("ok", "No cooling problems found.")
    return [c]


# ═════════════════════════════════════════════════════════════════════ NETWORK
# VPN-aware.  A ping (ICMP) test says "100 % packet loss" whenever a VPN kill switch, a VPN server or a firewall drops ping - the connection itself can be
# perfect.  So: (1) detect an active VPN, (2) when ping gets no answer at all, measure real TCP connections instead, (3) only call something a problem when
# BOTH kinds of test fail.  A router that the VPN hides from the PC (kill switch) is reported as "normal", never as packet loss.
_NET_PS = r"""
function Pg($h,$n){ $p=New-Object System.Net.NetworkInformation.Ping; $t=@(); $l=0; $s=0
  for($i=0;$i -lt $n;$i++){ $s++; try{ $r=$p.Send($h,1000); if($r.Status -eq 'Success'){ $t+=[double]$r.RoundtripTime } else { $l++ } }catch{ $l++ }
    if($t.Count -eq 0 -and $l -ge 4){ break }; Start-Sleep -Milliseconds 100 }
  [pscustomobject]@{ host=$h; sent=$s; lost=$l; times=@($t) } }
function Tc($h,$ports,$n){ $t=@(); $l=0
  for($i=0;$i -lt $n;$i++){ $ok=$false
    foreach($pt in $ports){ $c=New-Object System.Net.Sockets.TcpClient
      try{ $sw=[Diagnostics.Stopwatch]::StartNew(); $ar=$c.BeginConnect($h,[int]$pt,$null,$null)
        if($ar.AsyncWaitHandle.WaitOne(1200,$false)){
          try{ $c.EndConnect($ar); $ok=$true }catch{ $se=$_.Exception.InnerException; if(-not $se){ $se=$_.Exception }; if("$($se.SocketErrorCode)" -eq 'ConnectionRefused'){ $ok=$true } }
          $sw.Stop(); if($ok){ $t+=[double]$sw.Elapsed.TotalMilliseconds } } }catch{} finally{ $c.Close() }
      if($ok){ break } }
    if(-not $ok){ $l++ }; Start-Sleep -Milliseconds 80 }
  [pscustomobject]@{ host=$h; sent=$n; lost=$l; times=@($t) } }
$vpnRx = 'Wintun|WireGuard|TAP-Windows|TAP-Win32|OpenVPN|NordLynx|Proton|Mullvad|Surfshark|ExpressVPN|AnyConnect|Fortinet|FortiClient|Juniper|Pulse Secure|PANGP|GlobalProtect|SonicWall|Hamachi|ZeroTier|Tailscale|WARP|VPN|PPP|L2TP|SSTP|IKEv2'
$skipRx = 'Teredo|6to4|ISATAP|Hyper-V|vEthernet|VMware|VirtualBox|Bluetooth|Loopback|Kernel Debug'
$route = Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Sort-Object { $_.RouteMetric + $_.InterfaceMetric } | Select-Object -First 1
$prim = $(if($route){ [int]$route.InterfaceIndex } else { 0 })
$vp = @(Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and -not $_.HardwareInterface -and (([string]$_.InterfaceDescription + ' ' + [string]$_.Name) -match $vpnRx) -and (([string]$_.InterfaceDescription) -notmatch $skipRx) } |
  ForEach-Object { [pscustomobject]@{ name=[string]$_.Name; desc=[string]$_.InterfaceDescription; ifindex=[int]$_.ifIndex; speed=[double]$_.Speed; drvv=[string]$_.DriverVersionString; drvp=[string]$_.DriverProvider } })
$vc = @(Get-VpnConnection -ErrorAction SilentlyContinue | Where-Object { [string]$_.ConnectionStatus -eq 'Connected' } | ForEach-Object { [string]$_.Name })
$primAd = $null; if($prim -gt 0){ $primAd = Get-NetAdapter -InterfaceIndex $prim -ErrorAction SilentlyContinue }
$via = [bool]($primAd -and -not $primAd.HardwareInterface -and (([string]$primAd.InterfaceDescription) -notmatch $skipRx))
$vpnOn = [bool](@($vp).Count -gt 0 -or @($vc).Count -gt 0 -or $via)
$ads = @(Get-NetAdapter -Physical | ForEach-Object {
  $a = $_; $st = $a | Get-NetAdapterStatistics; $ip = Get-NetIPConfiguration -InterfaceIndex $a.ifIndex
  $gw = $null; if($ip.IPv4DefaultGateway){ $gw = [string]$ip.IPv4DefaultGateway.NextHop }
  $gp = $null; $gt = $null
  if($a.Status -eq 'Up' -and $gw){ $gp = Pg $gw 8; if(@($gp.times).Count -eq 0){ $gt = Tc $gw @(80,443,53,8080) 5 } }
  $sig = $null
  if($a.Status -eq 'Up' -and (([string]$a.InterfaceDescription) -match 'Wi-?Fi|Wireless|802\.11|WLAN' -or ([string]$a.PhysicalMediaType) -match '802\.11|Native')){ $o = (netsh wlan show interfaces) -join ' '; if($o -match '(\d{1,3})%'){ $sig = [int]$Matches[1] } }
  [pscustomobject]@{ drvv=[string]$a.DriverVersionString; drvp=[string]$a.DriverProvider; name=[string]$a.Name; desc=[string]$a.InterfaceDescription; status=[string]$a.Status; speed=[double]$a.Speed; media=[string]$a.PhysicalMediaType; ifindex=[int]$a.ifIndex;
    gw=$gw; gwping=$gp; gwtcp=$gt; sig=$sig; rxerr=[double]$st.ReceivedPacketErrors; rxdisc=[double]$st.ReceivedDiscardedPackets; txerr=[double]$st.OutboundPacketErrors;
    txdisc=[double]$st.OutboundDiscardedPackets; rxpk=[double]$st.ReceivedUnicastPackets; txpk=[double]$st.SentUnicastPackets }
})
$net = $null; $nett = $null; $nett2 = $null; $dns = $null
if($prim -gt 0){
  $net = Pg '1.1.1.1' 8
  if(@($net.times).Count -eq 0){ $nett = Tc '1.1.1.1' @(443,53) 8; if(@($nett.times).Count -eq 0){ $nett2 = Tc '8.8.8.8' @(443,53) 5 } }
  $sw = [Diagnostics.Stopwatch]::StartNew(); $r = Resolve-DnsName -Name 'www.microsoft.com' -Type A -DnsOnly -NoHostsFile -ErrorAction SilentlyContinue; $sw.Stop()
  if($r){ $dns = [double]$sw.ElapsedMilliseconds }
}
$out = [ordered]@{ prim=$prim; ads=$ads; vpn=$vp; vpnconn=$vc; via=$via; vpn_on=$vpnOn; net=$net; nett=$nett; nett2=$nett2; dns=$dns }
ConvertTo-Json -InputObject $out -Depth 5 -Compress
"""


def _answers(p) -> int:
    return len(as_list((p or {}).get("times")))


def _probe_metrics(c: Card, label: str, icmp, tcp, vpn: bool = False, net_ok: bool = True, role: str = "internet") -> None:
    """Ping first; when ping gets no answer at all fall back to real TCP connections; only report a problem when BOTH fail."""
    internet = role == "internet"
    if icmp and _answers(icmp) > 0:
        times = [float(x) for x in as_list(icmp.get("times"))]
        sent, lost = int(icmp.get("sent") or 0), int(icmp.get("lost") or 0)
        lp = lost / sent * 100 if sent else 0
        c.metric(f"{label} packet loss", f"{lp:.0f} %  ({lost} of {sent} lost)", lin(lp, 0, 25), 2.0)
        avg = sum(times) / len(times)
        jit = (sum((x - avg) ** 2 for x in times) / len(times)) ** 0.5
        good, bad = ((40, 300) if vpn else (20, 150)) if internet else (5, 60)
        c.metric(f"{label} latency", f"{avg:.0f} ms  (jitter {jit:.0f} ms)", lin(avg, good, bad), 1.0, "includes the VPN tunnel's extra distance" if vpn and internet else "")
        c.metric(f"{label} jitter", f"{jit:.0f} ms", lin(jit, 8 if vpn else 5, 80 if vpn else 60), 0.6)
        if lp >= 10:
            c.find("bad" if lp >= 25 else "warn", f"{label} packet loss is {lp:.0f}%. Check the cable / Wi-Fi signal and your router.")
        return
    if tcp and _answers(tcp) > 0:
        times = [float(x) for x in as_list(tcp.get("times"))]
        sent, lost = int(tcp.get("sent") or 0), int(tcp.get("lost") or 0)
        fp = lost / sent * 100 if sent else 0
        why = "Ping is blocked here (normal while a VPN or firewall is active), so DWUT tested real connections instead - not a problem."
        c.metric(f"{label} connection test", f"{fp:.0f} % failed  ({lost} of {sent})", lin(fp, 0, 25), 2.0, why)
        avg = sum(times) / len(times)
        good, bad = ((40, 300) if vpn else (20, 150)) if internet else (5, 60)
        c.metric(f"{label} connect time", f"{avg:.0f} ms", lin(avg, good, bad), 1.0)
        if fp >= 10:
            c.find("bad" if fp >= 25 else "warn", f"{fp:.0f}% of test connections to the {label.lower()} failed. Check the cable / Wi-Fi signal and your router.")
        return
    if not internet:                                                            # the router answered nothing at all
        if vpn:
            c.metric(f"{label}", "hidden by the VPN", None, note="The VPN's kill switch blocks the local network on purpose. This is normal and is NOT packet loss.")
        elif net_ok:
            c.metric(f"{label}", "does not answer test packets", None, note="Many routers ignore ping. The internet works, so this is not a problem.")
        else:
            c.metric(f"{label} test", "no answer", 0.0, 2.0)
            c.find("bad", "The router did not answer and the internet is not reachable either. Check the cable / Wi-Fi, then restart the router.")
        return
    c.metric(f"{label} test", "no answer", 0.0, 3.0, "neither ping nor real connections got through")
    c.find("bad", "The internet is not reachable (neither ping nor test connections got through). Check the cable / Wi-Fi, the router, or the VPN.")


def _internet_block(c: Card, d: dict, vpn: bool, net_ok: bool) -> None:
    label = "Internet (VPN)" if vpn else "Internet"
    tcp = d.get("nett") if _answers(d.get("nett")) else (d.get("nett2") or d.get("nett"))
    _probe_metrics(c, label, d.get("net"), tcp, vpn=vpn, net_ok=net_ok, role="internet")
    if d.get("dns") is not None:
        c.metric("DNS lookup time", f"{_n(d['dns']):.0f} ms", lin(_n(d["dns"]), 60, 500), 0.8, "time to resolve a name (cached answers are faster)")
    elif net_ok:
        c.metric("DNS lookup time", "FAILED", 0.0, 1.5)
        c.find("bad", "Name lookups (DNS) failed even though the network is up. Try a different DNS server (1.1.1.1 or 8.8.8.8).")


def collect_network() -> list:
    d = ps_json(_NET_PS, 150)
    if not d:
        return [_unknown("network", "network", "Network", "network", "Could not query the network adapters.")]
    cards = []
    vpn_on = bool(d.get("vpn_on"))
    vpns = as_list(d.get("vpn"))
    prim = d.get("prim")
    net_ok = _answers(d.get("net")) > 0 or _answers(d.get("nett")) > 0 or _answers(d.get("nett2")) > 0
    internet_done = False

    for v in vpns:                                                                  # the VPN tunnel is shown as its own adapter
        c = Card(f"vpn{v.get('ifindex')}", "network", (v.get("desc") or v.get("name") or "VPN adapter").strip(), f"{v.get('name') or 'VPN'} · VPN tunnel · connected", "network")
        c.brand = ident.brand_from(v.get("desc"), v.get("drvp")) or (v.get("drvp") or "").strip()
        c.model = ident.clean_model(v.get("desc") or "", c.brand)
        c.ident("Driver", " ".join(x for x in [(v.get("drvp") or "").strip(), (v.get("drvv") or "").strip()] if x))
        c.ctx = {"ifindex": v.get("ifindex"), "name": v.get("name"), "vpn": True}
        c.metric("VPN tunnel", "active", None, note="Traffic to the internet goes through this tunnel.")
        if v.get("ifindex") == prim or (d.get("via") and not internet_done):
            _internet_block(c, d, True, net_ok)
            internet_done = True
        c.find("info", "A VPN is active. Ping to your router is blocked by the VPN's kill switch, so DWUT tests real connections instead - that is normal and is not reported as packet loss.")
        if not any(f["level"] in ("warn", "bad") for f in c.findings):
            c.find("ok", "No network problems found.")
        cards.append(c)

    for a in as_list(d.get("ads")):
        up = (a.get("status") or "") == "Up"
        spd = _n(a.get("speed")) / 1e6
        wifi = a.get("sig") is not None or "802.11" in (a.get("media") or "")
        kind = "Wi-Fi" if wifi else "Ethernet"
        parts = [a.get("name") if (a.get("name") or "").lower() not in (kind.lower(), "wi-fi", "wifi") else None, kind, "connected" if up else (a.get("status") or "not connected")]
        c = Card(f"net{a.get('ifindex')}", "network", (a.get("desc") or a.get("name") or "Adapter").strip(), " · ".join(x for x in parts if x), "network")
        c.brand = ident.brand_from(a.get("desc"), a.get("drvp")) or (a.get("drvp") or "").strip()
        c.model = ident.clean_model(a.get("desc") or "", c.brand)
        c.ident("Driver", " ".join(x for x in [(a.get("drvp") or "").strip(), (a.get("drvv") or "").strip()] if x))
        c.ctx = {"ifindex": a.get("ifindex"), "name": a.get("name"), "wifi": wifi, "vpn_active": vpn_on}
        if not up:
            c.idle = True
            c.metric("State", a.get("status") or "Not connected")
            c.find("info", "This adapter is not connected, so there is nothing to score.")
            cards.append(c)
            continue
        c.metric("Link speed", f"{spd:,.0f} Mbps" if spd < 1000 else f"{spd / 1000:g} Gbps", None if wifi else lin(spd, 1000, 10), 0.6,
                 "negotiated speed; an Ethernet link far below 1 Gbps often points to a bad cable" if not wifi else "")
        if not wifi and 0 < spd <= 100:
            c.find("warn", f"The Ethernet link negotiated only {spd:.0f} Mbps. A worn cable or an old port / router can cause this.")
        if a.get("sig") is not None:
            c.metric("Wi-Fi signal", f"{a['sig']} %", lin(a["sig"], 70, 30), 2.0)
            if a["sig"] < 40:
                c.find("warn", f"The Wi-Fi signal is weak ({a['sig']}%). Move closer to the router or use a cable.")
        total_rx, total_tx = _n(a.get("rxpk")), _n(a.get("txpk"))
        bad_rx = _n(a.get("rxerr")) + _n(a.get("rxdisc"))
        bad_tx = _n(a.get("txerr")) + _n(a.get("txdisc"))
        if total_rx > 1000:
            rp = bad_rx / total_rx * 100
            c.metric("Receive errors / drops", f"{bad_rx:,.0f}  ({rp:.3f} %)", lin(rp, 0.0, 1.0), 1.0, "since the adapter came up")
        if total_tx > 1000:
            tp = bad_tx / total_tx * 100
            c.metric("Send errors / drops", f"{bad_tx:,.0f}  ({tp:.3f} %)", lin(tp, 0.0, 1.0), 1.0, "since the adapter came up")
        if a.get("gw"):
            _probe_metrics(c, "Router", a.get("gwping"), a.get("gwtcp"), vpn=vpn_on, net_ok=net_ok, role="router")
        if not internet_done and (a.get("ifindex") == prim or (vpn_on and not vpns)):
            _internet_block(c, d, vpn_on, net_ok)
            internet_done = True
        if not any(f["level"] in ("warn", "bad") for f in c.findings):
            c.find("ok", "No network problems found.")
        cards.append(c)
    return cards or [_unknown("network", "network", "Network", "network", "No physical network adapters were found.")]


# ═════════════════════════════════════════════════════════════════════ MOTHERBOARD & FIRMWARE
def _short_maker(m: str) -> str:
    import re
    pat = re.compile(r"[,\s]+(inc\.?|corporation|corp\.?|co\.?,?|ltd\.?|computer|technology|technologies)\s*$", re.I)
    m = m.strip()
    while True:
        n = pat.sub("", m).strip(" ,.")
        if n == m or not n:
            return m
        m = n


def collect_firmware(board: dict) -> list:
    b, s, bi, fw = board["board"], board["system"], board["bios"], board["firmware"]
    maker = _short_maker(b.get("manufacturer") or s.get("manufacturer") or "")
    model = b.get("product") or s.get("model") or "Motherboard"
    c = Card("firmware", "firmware", f"{maker} {model}".strip(), " · ".join(x for x in [s.get("chassis"), board.get("cpu_socket")] if x), "firmware")
    c.brand, c.model = (ident.brand_from(maker) or maker), b.get("product") or s.get("model") or ""
    c.ident("Board maker", b.get("manufacturer"))
    c.ident("Board model", b.get("product"))
    c.ident("Board revision", b.get("version"))
    if s.get("model") and s.get("model") != b.get("product"):
        c.ident("System (OEM)", " ".join(x for x in [s.get("manufacturer"), s.get("model")] if x))
    c.ident("BIOS", "  ·  ".join(x for x in [bi.get("vendor"), bi.get("version"), bi.get("release_date")] if x))
    if s.get("model") and s.get("model") != b.get("product"):
        pass
    if board.get("chipset"):
        c.metric("Chipset device", board["chipset"])
    if board.get("cpu_socket"):
        c.metric("CPU socket", board["cpu_socket"])
    m = board.get("memory") or {}
    if m.get("slots"):
        c.metric("Memory slots", f"{m['populated']} of {m['slots']} used" + (f"  ·  up to {m['max_gb']:.0f} GB" if m.get("max_gb") else "") + (f"  ·  {', '.join(m['types'])}" if m.get("types") else ""))
    st = (b.get("status") or "").strip()
    if st:
        c.metric("Board status (SMBIOS)", st, 100.0 if st.upper() == "OK" else 25.0, 1.0)
        if st.upper() != "OK":
            c.find("bad", f"The motherboard reports status '{st}'.")
    if bi.get("version"):
        age = bi.get("age_days")
        txt = f"{bi['version']}  ({bi.get('vendor') or ''})".strip()
        if bi.get("release_date"):
            txt += f"  ·  {bi['release_date']}"
        sc = soft(lin(age / 365.25, 3, 9), 50) if age is not None else None
        c.metric("BIOS / UEFI version", txt, sc, 0.5, "age only - DWUT cannot check offline whether a newer version exists" if age is not None else "")
        if age is not None and age > 365 * 6:
            c.find("info", f"The BIOS is {age / 365.25:.0f} years old. Check {maker or 'the maker'}'s support page for updates (CPU microcode, security and stability fixes).")
    if bi.get("smbios_version"):
        c.metric("SMBIOS version", bi["smbios_version"])
    if bi.get("embedded_controller"):
        c.metric("Embedded controller firmware", bi["embedded_controller"])

    mode = fw.get("mode")
    if mode:
        c.metric("Boot mode", mode, 100.0 if mode == "UEFI" else 60.0, 0.8, "UEFI is required for Secure Boot and Windows 11")
        if mode != "UEFI":
            c.find("warn", "Windows is booted in legacy BIOS mode. UEFI is more secure and is required by Windows 11.")
    sbv = fw.get("secure_boot")
    if sbv is not None:
        c.metric("Secure Boot", "enabled" if sbv else "disabled", 100.0 if sbv else 55.0, 1.0, "blocks unsigned boot-time malware")
        if not sbv and mode == "UEFI":
            c.find("warn", "Secure Boot is turned off. Turn it on in the BIOS for protection against boot-level malware (and for Windows 11 / many anti-cheats).")
    tpm = fw.get("tpm")
    if tpm:
        ready = bool(tpm.get("enabled")) and bool(tpm.get("activated")) if tpm.get("enabled") is not None else None
        ver = (tpm.get("version") or "").split(",")[0]
        c.metric("TPM", f"{'ready' if ready else 'present but not active' if ready is False else 'present'}" + (f"  ·  spec {ver}" if ver else "") + (f"  ·  {tpm['vendor']}" if tpm.get("vendor") else ""),
                 100.0 if ready else 55.0 if ready is False else None, 1.0)
        if ready is False:
            c.find("warn", "A TPM chip is present but not enabled / activated. Enable it in the BIOS (fTPM / PTT) - Windows 11 needs it.")
    else:
        c.metric("TPM", None, None, note="Not found, or Administrator rights are needed to read it" if not _is_admin() else "No TPM found - enable fTPM / PTT in the BIOS if your board has one")
    if fw.get("virtualization_enabled") is not None:
        c.metric("CPU virtualization (VT-x / AMD-V)", "enabled" if fw["virtualization_enabled"] else "disabled", None, note="needed for virtual machines and the Android / Windows subsystems")
    sens = board.get("sensors") or {}
    rails = {"12": 12.0, "5": 5.0, "3.3": 3.3, "3v3": 3.3, "3vcc": 3.3}
    checked = 0
    for v in sens.get("voltages", []):
        nm = v["name"].lower().replace("+", "").replace(" ", "")
        nominal = next((val for key, val in rails.items() if nm in (key + "v", "v" + key, key + "vsb", "vcc" + key, key, f"{key}v rail")), None)
        if nominal is None and not (nm.startswith("12v") or nm.startswith("5v") or nm.startswith("3.3v")):
            continue
        nominal = nominal or (12.0 if nm.startswith("12v") else 5.0 if nm.startswith("5v") else 3.3)
        dev = abs(v["volts"] - nominal) / nominal * 100
        if v["volts"] < nominal * 0.5:
            continue                                                    # unconnected / scaled pin, not a real rail reading
        c.metric(f"Power rail {nominal:g} V", f"{v['volts']:.2f} V  ({dev:.1f} % off)", lin(dev, 2.5, 8), 1.5, "ATX allows ±5 %")
        checked += 1
        if dev > 5:
            c.find("bad", f"The {nominal:g} V power rail reads {v['volts']:.2f} V ({dev:.1f}% off nominal). A weak power supply can cause crashes and data corruption.")
            c.cap(40)
    if not sens.get("source"):
        c.metric("Voltage sensors", None, None, note="Run LibreHardwareMonitor to let DWUT read the motherboard's voltage rails and fan headers")
    if not fw.get("got_data") and not b.get("manufacturer"):
        c.find("info", "The motherboard did not answer the SMBIOS query - it may be a virtual machine or an unusual board.")
    if s.get("virtual_machine"):
        c.find("info", "This is a virtual machine; the board and BIOS are virtual, so hardware checks are limited.")
    if not any(f["level"] in ("warn", "bad", "info") for f in c.findings):
        c.find("ok", "No motherboard or firmware problems found.")
    return [c]


# ═════════════════════════════════════════════════════════════════════ DRIVERS & DEVICES
_DRV_PS = r"""
$pnp = @(Get-CimInstance Win32_PnPEntity)
$bad = @($pnp | Where-Object { $_.ConfigManagerErrorCode -and @(22,24,45) -notcontains [int]$_.ConfigManagerErrorCode } | ForEach-Object { [pscustomobject]@{ name=[string]$_.Name; cls=[string]$_.PNPClass; code=[int]$_.ConfigManagerErrorCode } })
$dis = @($pnp | Where-Object { [int]$_.ConfigManagerErrorCode -eq 22 }).Count
$drv = @(Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DeviceName })
$uns = @($drv | Where-Object { $_.IsSigned -eq $false } | Select-Object -First 8 | ForEach-Object { [pscustomobject]@{ name=[string]$_.DeviceName; vendor=[string]$_.Manufacturer } })
$old = @($drv | Where-Object { $_.DriverDate -and $_.DriverDate -lt (Get-Date).AddYears(-3) -and ([string]$_.Manufacturer) -notmatch 'Microsoft' -and @('DISPLAY','NET','MEDIA','BLUETOOTH','SCSIADAPTER','HDC') -contains [string]$_.DeviceClass } | Select-Object -First 8 | ForEach-Object { [pscustomobject]@{ name=[string]$_.DeviceName; date=$_.DriverDate.ToString('yyyy-MM-dd'); vendor=[string]$_.Manufacturer } })
$out = [ordered]@{ total=$pnp.Count; bad=$bad; disabled=$dis; unsigned=$uns; old=$old; drivers=$drv.Count }
ConvertTo-Json -InputObject $out -Depth 4 -Compress
"""


def collect_drivers() -> list:
    d = ps_json(_DRV_PS, 120)
    if not d:
        return [_unknown("drivers", "drivers", "Drivers & devices", "drivers", "Could not enumerate devices (WMI did not answer).")]
    c = Card("drivers", "drivers", "Drivers & devices", f"{d.get('total')} devices · {d.get('drivers')} drivers", "drivers")
    bad = as_list(d.get("bad"))
    c.metric("Devices with a problem", "none" if not bad else str(len(bad)), _count_score(len(bad), 22), 3.0, "Device Manager errors (yellow warning icons)")
    for b in bad[:6]:
        c.find("bad", f"{b.get('name') or 'Unknown device'} ({b.get('cls') or 'device'}) has Device Manager error code {b.get('code')}.")
    if len(bad) >= 4:
        c.cap(40)
    uns = as_list(d.get("unsigned"))
    c.metric("Unsigned drivers", "none" if not uns else str(len(uns)) + ("+" if len(uns) >= 8 else ""), 100.0 if not uns else max(30.0, 80.0 - 10 * len(uns)), 1.5, "drivers without a valid signature are a stability and security risk")
    for u in uns[:3]:
        c.find("warn", f"Unsigned driver: {u.get('name')} ({u.get('vendor') or 'unknown vendor'}).")
    old = as_list(d.get("old"))
    c.metric("Hardware drivers older than 3 years", "none" if not old else str(len(old)) + ("+" if len(old) >= 8 else ""), None, note="display, network, audio, Bluetooth and storage drivers from a hardware maker")
    for o in old[:4]:
        c.find("info", f"Old driver: {o.get('name')} - {o.get('date')} ({o.get('vendor') or ''}). Check the maker's site for an update.")
    if d.get("disabled"):
        c.metric("Devices you disabled", str(d["disabled"]), None)
    if not any(f["level"] in ("warn", "bad") for f in c.findings):
        c.find("ok", "Every device has a working driver.")
    return [c]


# ═════════════════════════════════════════════════════════════════════ WINDOWS
_WIN_PS = r"""
$os = Get-CimInstance Win32_OperatingSystem
$kp = @(Ev 'System' 'Microsoft-Windows-Kernel-Power' 41 30)
$bc = @(Ev 'System' 'Microsoft-Windows-WER-SystemErrorReporting' 1001 30)
$pend = [bool]((Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'))
$mp = Get-MpComputerStatus
$avs = @(Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct | ForEach-Object { [pscustomobject]@{ name=[string]$_.displayName; state=[int]$_.productState } })
$fw = @(Get-NetFirewallProfile | ForEach-Object { [pscustomobject]@{ name=[string]$_.Name; on=([string]$_.Enabled -eq 'True') } })
$hf = Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1
$bt = @(Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-Diagnostics-Performance/Operational'; Id=100} -MaxEvents 3 -ErrorAction SilentlyContinue)
$boot = $null
if($bt.Count -gt 0){ $x = ([xml]$bt[0].ToXml()).Event.EventData.Data | Where-Object { $_.Name -eq 'BootTime' } | Select-Object -First 1; if($x){ $boot = [double]$x.'#text' } }
$dumps = @(Get-ChildItem (Join-Path $env:SystemRoot 'Minidump') -Filter *.dmp | Where-Object { $_.LastWriteTime -gt (Get-Date).AddDays(-30) }).Count
$out = [ordered]@{
  caption=[string]$os.Caption; build=[string]$os.BuildNumber; version=[string]$os.Version; boot_ts=$(if($os.LastBootUpTime){ $os.LastBootUpTime.ToString('yyyy-MM-dd HH:mm') } else { '' });
  kp41=$kp.Count; kp41_last=$(if($kp.Count -gt 0){ $kp[0].TimeCreated.ToString('yyyy-MM-dd') } else { '' }); bugchecks=$bc.Count; dumps=$dumps; pending=$pend;
  defender=$(if($mp){ [ordered]@{ av=[bool]$mp.AntivirusEnabled; rt=[bool]$mp.RealTimeProtectionEnabled; sigage=[int]$mp.AntivirusSignatureAge } } else { $null });
  avs=$avs; fw=$fw; hotfix=$(if($hf -and $hf.InstalledOn){ $hf.InstalledOn.ToString('yyyy-MM-dd') } else { '' }); boot_ms=$boot
}
ConvertTo-Json -InputObject $out -Depth 4 -Compress
"""


def _dism_check() -> Optional[str]:
    """DISM component-store check.  Returns 'healthy' | 'repairable' | 'unknown' | None (needs admin / failed to run)."""
    if sys.platform != "win32" or not _is_admin():
        return None
    try:
        r = subprocess.run(["dism.exe", "/Online", "/Cleanup-Image", "/CheckHealth"], capture_output=True, timeout=120, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
    except Exception:
        return None
    out = (r.stdout or b"").decode("utf-8", "replace").lower()
    if "no component store corruption detected" in out:
        return "healthy"
    if "repairable" in out and "not repairable" not in out:
        return "repairable"
    if "not repairable" in out:
        return "unrepairable"
    return "unknown"


def collect_windows() -> list:
    d = ps_json(_WIN_PS, 150)
    dism = _dism_check()
    if not d:
        return [_unknown("windows", "windows", "Windows", "windows", "Could not read the Windows system information.")]
    c = Card("windows", "windows", d.get("caption") or "Windows", f"build {d.get('build')} · {d.get('version')}", "windows")
    c.brand, c.model = "Microsoft", (d.get("caption") or "Windows").replace("Microsoft ", "")
    c.ident("Build", f"{d.get('build')}  ({d.get('version')})")
    kp, bc, dumps = int(d.get("kp41") or 0), int(d.get("bugchecks") or 0), int(d.get("dumps") or 0)
    c.metric(f"Unexpected shutdowns ({DAYS} d)", "none" if kp == 0 else f"{kp}  (last {d.get('kp41_last')})", _count_score(kp, 16, 5), 2.0, "power loss, hard resets or crashes (Kernel-Power 41)")
    if kp:
        c.find("bad" if kp >= 4 else "warn", f"The PC shut down unexpectedly {kp} time(s) in {DAYS} days (power cut, hard reset, overheating or a crash).")
    c.metric(f"Blue-screen crashes ({DAYS} d)", "none" if bc == 0 else str(bc), _count_score(bc, 25), 3.0, "Windows bug-check reports")
    if bc:
        c.find("bad", f"Windows blue-screened {bc} time(s) in {DAYS} days" + (f" ({dumps} crash dump file(s) saved)." if dumps else ".") + " Update drivers and run a RAM test.")
        if bc >= 3:
            c.cap(40)
    if dism is not None:
        if dism == "healthy":
            c.metric("Windows component store (DISM)", "no corruption detected", 100.0, 2.0)
        elif dism == "repairable":
            c.metric("Windows component store (DISM)", "corruption found - repairable", 35.0, 2.0)
            c.find("bad", "Windows system files are damaged but repairable. Run 'DISM /Online /Cleanup-Image /RestoreHealth' then 'sfc /scannow' (DWUT's Optimizer > Repairs does this).")
        elif dism == "unrepairable":
            c.metric("Windows component store (DISM)", "corrupted - NOT repairable", 5.0, 2.0)
            c.find("bad", "The Windows component store is corrupted and cannot be repaired online. A repair install may be needed.")
            c.cap(25)
        else:
            c.metric("Windows component store (DISM)", "check ran, result not recognised", None, note="DWUT reads DISM's English output; on other languages run it from Optimizer > Repairs")
    else:
        c.metric("Windows component store (DISM)", None, None, note="Run DWUT as Administrator to check Windows system files")
    avs = as_list(d.get("avs"))
    live = [a for a in avs if int(a.get("state") or 0) & 0x1000]
    df = d.get("defender") or {}
    if avs or df:
        if live:
            names = ", ".join(sorted({a["name"] for a in live}))
            stale = [a for a in live if int(a.get("state") or 0) & 0x10]
            c.metric("Antivirus", names + ("  (definitions out of date)" if stale else ""), 55.0 if stale else 100.0, 1.5)
            if stale:
                c.find("warn", "The antivirus reports its definitions are out of date. Update it.")
        else:
            c.metric("Antivirus", "none active", 20.0, 1.5)
            c.find("bad", "No antivirus is turned on. Enable Windows Security (Microsoft Defender) or install another antivirus.")
        if df.get("sigage") is not None and df.get("av"):
            c.metric("Defender definitions age", f"{df['sigage']} day(s)", lin(df["sigage"], 2, 14), 0.8)
    fw = as_list(d.get("fw"))
    if fw:
        off = [f["name"] for f in fw if not f.get("on")]
        c.metric("Windows Firewall", "on for all networks" if not off else f"OFF for: {', '.join(off)}", 100.0 if not off else 60.0 if len(off) == 1 else 30.0 if len(off) == 2 else 15.0, 1.0)
        if off:
            c.find("warn", f"Windows Firewall is turned off for the {', '.join(off)} network profile(s).")
    if d.get("hotfix"):
        try:
            days = (date.today() - datetime.strptime(d["hotfix"], "%Y-%m-%d").date()).days
            c.metric("Last Windows update installed", f"{d['hotfix']}  ({days} days ago)", lin(days, 45, 240), 0.8)
            if days > 120:
                c.find("warn", f"The last Windows update was installed {days} days ago. Check Windows Update for security fixes.")
        except ValueError:
            pass
    if d.get("pending"):
        c.metric("Restart pending", "yes", 80.0, 0.5, "Windows is waiting for a restart to finish installing updates")
        c.find("info", "Windows is waiting for a restart to finish installing updates.")
    try:
        up = time.time() - psutil.boot_time()
        c.metric("Uptime", _dur(up), soft(lin(up / 86400, 14, 60), 55), 0.4, "a restart now and then clears memory leaks and finishes updates")
        if up > 30 * 86400:
            c.find("info", f"The PC has not been restarted for {up / 86400:.0f} days.")
    except Exception:
        pass
    if d.get("boot_ms"):
        bs = _n(d["boot_ms"]) / 1000
        c.metric("Last boot time", f"{bs:.0f} s", lin(bs, 30, 120), 0.8, "from Windows' own boot-performance log")
        if bs > 90:
            c.find("warn", f"The last startup took {bs:.0f} seconds. Disable heavy startup apps (Task Manager > Startup).")
    if not any(f["level"] in ("warn", "bad") for f in c.findings):
        c.find("ok", "No Windows problems found.")
    return [c]



# ═════════════════════════════════════════════════════════════════════ HARDWARE INVENTORY (who made what)
_EXTRA_PS = r"""
function Dec($a){ if($a -eq $null){ return '' }; (($a | Where-Object { $_ -ne 0 } | ForEach-Object { [char]$_ }) -join '').Trim() }
$mon = @(Get-CimInstance -Namespace 'root\wmi' -ClassName WmiMonitorID | ForEach-Object { [pscustomobject]@{ mfr=(Dec $_.ManufacturerName); name=(Dec $_.UserFriendlyName); code=(Dec $_.ProductCodeID); year=[int]$_.YearOfManufacture } })
$snd = @(Get-CimInstance Win32_SoundDevice | ForEach-Object { [pscustomobject]@{ name=[string]$_.Name; mfr=[string]$_.Manufacturer } })
$os = Get-CimInstance Win32_OperatingSystem | Select-Object -First 1
$out = [ordered]@{ mon=$mon; snd=$snd; os=[string]$os.Caption; arch=[string]$os.OSArchitecture; build=[string]$os.BuildNumber }
ConvertTo-Json -InputObject $out -Depth 4 -Compress
"""


def collect_extras() -> dict:
    return ps_json(_EXTRA_PS, 45) or {}


def build_inventory(cards: list, extras: dict) -> list:
    """One row per piece of hardware: group, brand, model, detail.  Built only from identifiers that were read (cards + monitors / audio / OS)."""
    rows = []
    groups = {"cpu": "Processor", "memory": "Memory", "storage": "Storage", "gpu": "Graphics", "firmware": "Motherboard", "network": "Network", "battery": "Battery"}
    for c in cards:
        g = groups.get(c["category"])
        if c.get("inv"):
            rows.extend(c["inv"])
            continue
        if not g or not (c.get("brand") or c.get("model")):
            continue
        if c["category"] == "network" and c.get("status") == "idle":
            continue
        detail = c.get("subtitle") or ""
        if c["category"] == "memory":
            detail = " · ".join(x for x in [c["name"].replace("System memory", "").strip(), c.get("subtitle")] if x)
        if c.get("brand") and detail.startswith(c["brand"] + " · "):
            detail = detail[len(c["brand"]) + 3:]
        rows.append({"group": g, "icon": c["category"], "brand": c.get("brand") or "", "model": c.get("model") or "", "detail": detail})
        if c["category"] == "firmware":
            bios = next((i["value"] for i in c.get("identity", []) if i["label"] == "BIOS"), "")
            if bios:
                parts = [x.strip() for x in bios.split("·")]
                rows.append({"group": "BIOS / UEFI", "icon": "firmware", "brand": parts[0] if parts else "", "model": parts[1] if len(parts) > 1 else "",
                             "detail": parts[2] if len(parts) > 2 else ""})
    for m in as_list(extras.get("mon")):
        code = (m.get("mfr") or "").upper()
        brand = ident.MONITOR.get(code) or (code and f"maker code {code}") or ""
        name = (m.get("name") or "").strip()
        if not (brand or name):
            continue
        rows.append({"group": "Display", "icon": "gpu", "brand": brand, "model": name or "monitor", "detail": f"made {m['year']}" if m.get("year") else ""})
    for a in as_list(extras.get("snd")):
        n = (a.get("name") or "").strip()
        if not n or any(x in n.lower() for x in ("virtual", "remote audio", "steam streaming")):
            continue
        rows.append({"group": "Audio", "icon": "drivers", "brand": ident.brand_from(a.get("mfr"), n) or (a.get("mfr") or "").strip(), "model": ident.clean_model(n, ident.brand_from(a.get("mfr"), n)), "detail": ""})
    if extras.get("os"):
        rows.append({"group": "Operating system", "icon": "windows", "brand": "Microsoft", "model": extras["os"].replace("Microsoft ", ""),
                     "detail": " · ".join(x for x in [extras.get("arch"), f"build {extras.get('build')}" if extras.get("build") else ""] if x)})
    return rows


# ═════════════════════════════════════════════════════════════════════ orchestration
COLLECTORS = [
    ("cpu", "Processor", lambda b: collect_cpu()),
    ("memory", "Memory", lambda b: collect_memory()),
    ("storage", "Storage", lambda b: collect_storage()),
    ("gpu", "Graphics", lambda b: collect_gpu()),
    ("battery", "Battery", lambda b: collect_battery()),
    ("thermal", "Cooling & thermals", lambda b: collect_thermal(b)),
    ("network", "Network", lambda b: collect_network()),
    ("firmware", "Motherboard & firmware", lambda b: collect_firmware(b)),
    ("drivers", "Drivers & devices", lambda b: collect_drivers()),
    ("windows", "Windows", lambda b: collect_windows()),
]

_lock = threading.Lock()
_running: Optional[str] = None
_last: Optional[dict] = None
_board: dict = {}                              # the motherboard read, kept so a single-category rescan does not have to detect it again


def last_result() -> Optional[dict]:
    return _last


def scan(emit: Callable[[str, dict], None], scan_id: str) -> dict:
    """Run every collector in parallel, emitting health.progress as each finishes, and return the full result."""
    global _last
    t0 = time.time()
    all_cards: list = []
    board_holder: dict = {}
    lock = threading.Lock()

    board_ready = threading.Event()

    def run_one(key: str, title: str, fn) -> None:
        emit("health.progress", {"scan": scan_id, "key": key, "title": title, "state": "start"})
        try:
            if key in ("thermal", "firmware"):
                board_ready.wait(timeout=90)                          # the board is detected once, in parallel with the other checks
                board = board_holder.get("board")
                if board is None:
                    raise RuntimeError("motherboard detection did not finish")
                cards = fn(board)
            else:
                cards = fn(None)
        except Exception as exc:
            _log.exception("health collector %s failed", key)
            cards = [_unknown(key, key, title, key, f"This check could not run: {exc}")]
        dicts = [c.to_dict() for c in cards]
        with lock:
            all_cards.extend(dicts)
        emit("health.progress", {"scan": scan_id, "key": key, "title": title, "state": "done", "cards": dicts})

    def prefetch_board() -> None:
        try:
            board_holder["board"] = motherboard.detect()
            _board["board"] = board_holder["board"]
        except Exception:
            _log.exception("motherboard detection failed")
        finally:
            board_ready.set()

    with ThreadPoolExecutor(max_workers=len(COLLECTORS) + 1, thread_name_prefix="health") as pool:
        pool.submit(prefetch_board)
        extras_f = pool.submit(collect_extras)
        futs = [pool.submit(run_one, k, t, f) for k, t, f in COLLECTORS]
        for f in futs:
            f.result()
        try:
            extras = extras_f.result()
        except Exception:
            extras = {}
    order = {k: i for i, (k, _, _) in enumerate(COLLECTORS)}
    all_cards.sort(key=lambda c: (order.get(c["category"], 99), c["key"]))
    result = {"scan": scan_id, "overall": overall(all_cards), "cards": all_cards, "inventory": build_inventory(all_cards, extras), "duration": round(time.time() - t0, 1),
              "finished": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "admin": _is_admin(),
              "findings": _findings_of(all_cards)}
    _last = result
    return result


def _findings_of(cards: list) -> list:
    return sorted([{"level": f["level"], "card": c["name"], "card_key": c["key"], "category": c["category"], "text": f["text"]} for c in cards for f in c["findings"] if f["level"] in ("bad", "warn")],
                  key=lambda f: (0 if f["level"] == "bad" else 1))


def rescan_category(key: str) -> Optional[dict]:
    """Re-run ONE category (after a fix) and fold the fresh cards, scores and findings into the last result.  Returns the updated result."""
    global _last
    entry = next(((k, t, f) for k, t, f in COLLECTORS if k == key), None)
    if entry is None or _last is None:
        return _last
    k, title, fn = entry
    try:
        board = None
        if k in ("thermal", "firmware"):
            board = _board.get("board") or motherboard.detect()
            _board["board"] = board
        cards = fn(board)
    except Exception as exc:
        _log.exception("rescan %s failed", key)
        cards = [_unknown(k, k, title, k, f"This check could not run: {exc}")]
    dicts = [c.to_dict() for c in cards]
    with _lock:
        others = [c for c in _last["cards"] if c["category"] != k]
        allc = others + dicts
        order = {kk: i for i, (kk, _, _) in enumerate(COLLECTORS)}
        allc.sort(key=lambda c: (order.get(c["category"], 99), c["key"]))
        res = dict(_last)
        res.update({"cards": allc, "overall": overall(allc), "findings": _findings_of(allc), "finished": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "admin": _is_admin()})
        _last = res
    return _last
