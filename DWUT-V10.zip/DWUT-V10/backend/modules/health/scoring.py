# Copyright © 2026 Darko / Darko.Dev
"""modules/health/scoring.py - turns real readings into 0-100 health scores.

A score is ONLY ever produced from a value that was actually read from the machine.  A reading that is not available (sensor not exposed,
needs Administrator, ...) has score=None, is shown as "Not available" with the reason, and is left OUT of the average - it is never guessed.
"""
from __future__ import annotations

from typing import Optional


def lin(value: Optional[float], good: float, bad: float) -> Optional[float]:
    """100 at (or better than) `good`, 0 at (or worse than) `bad`, straight line between.  Works for both directions."""
    if value is None:
        return None
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    if good == bad:
        return 100.0
    t = (v - bad) / (good - bad)
    return round(max(0.0, min(1.0, t)) * 100.0, 1)


def soft(score: Optional[float], floor: float = 40.0) -> Optional[float]:
    """For momentary readings (a busy second is not a sick CPU): squeeze 0-100 into floor-100 so one reading can't sink a card."""
    if score is None:
        return None
    return round(floor + (100.0 - floor) * score / 100.0, 1)


def rating(score: Optional[float]) -> str:
    if score is None:
        return "unknown"
    if score >= 90:
        return "excellent"
    if score >= 75:
        return "good"
    if score >= 55:
        return "fair"
    if score >= 35:
        return "poor"
    return "critical"


RATING_TEXT = {"excellent": "Excellent", "good": "Good", "fair": "Fair", "poor": "Poor", "critical": "Critical",
               "unknown": "Not available", "idle": "Not connected"}


class Card:
    """One hardware item: a set of real metrics, each optionally scored, plus findings written in plain words."""

    def __init__(self, key: str, category: str, name: str, subtitle: str = "", icon: str = "") -> None:
        self.key, self.category, self.name, self.subtitle, self.icon = key, category, name, subtitle, icon
        self.metrics: list = []
        self.findings: list = []
        self._scored: list = []          # (score, weight)
        self._caps: list = []            # (limit, reason)
        self.brand = ""                  # who made it (e.g. 'Samsung') and what it is (e.g. '970 EVO Plus') - read from the machine, see identity.py
        self.model = ""
        self.inv: list = []              # explicit rows for the 'Your hardware' list (one per DIMM, etc.); empty = one row from brand/model
        self.identity: list = []         # [(label, value)] extra identifiers: firmware, part number, PCI ID ...
        self.idle = False                # present but not in use (e.g. cable unplugged): shown, but never scored
        self.ctx: dict = {}              # what a fix needs to act on THIS component only (drive letters, adapter index ...) - never shown, never scored
        self.min_weight = 1.5            # a card is only scored when enough REAL evidence backs it (one load reading is not a health check)

    def metric(self, label: str, value, score: Optional[float] = None, weight: float = 1.0, note: str = "") -> None:
        shown = "Not available" if value is None or value == "" else str(value)
        self.metrics.append({"label": label, "value": shown, "score": None if score is None else round(float(score), 1), "note": note})
        if score is not None:
            self._scored.append((float(score), float(weight)))

    def ident(self, label: str, value, how: str = "") -> None:
        v = ("" if value is None else str(value)).strip()
        if v:
            self.identity.append({"label": label, "value": v, "how": how})

    def find(self, level: str, text: str) -> None:
        self.findings.append({"level": level, "text": text})

    def cap(self, limit: float, reason: str = "") -> None:
        self._caps.append((float(limit), reason))

    def score(self) -> Optional[float]:
        if self.idle or not self._scored:
            return None
        wsum = sum(w for _, w in self._scored)
        if wsum < self.min_weight:
            return None
        mean = sum(s * w for s, w in self._scored) / wsum if wsum else 0.0
        worst = min(s for s, _ in self._scored)
        val = 0.6 * mean + 0.4 * worst              # one bad reading must pull the card down, not hide in an average
        for limit, _ in self._caps:
            val = min(val, limit)
        return round(max(0.0, min(100.0, val)), 1)

    def to_dict(self) -> dict:
        sc = self.score()
        st = "idle" if self.idle else rating(sc)
        return {"key": self.key, "category": self.category, "name": self.name, "subtitle": self.subtitle, "icon": self.icon or self.category,
                "score": sc, "status": st, "label": RATING_TEXT[st], "brand": self.brand, "model": self.model, "identity": self.identity, "inv": self.inv, "metrics": self.metrics, "findings": self.findings, "ctx": self.ctx}


# category key -> (title, weight in the overall score)
CATEGORIES = [
    ("cpu", "Processor", 1.2), ("memory", "Memory", 1.0), ("storage", "Storage", 1.5), ("gpu", "Graphics", 1.0),
    ("battery", "Battery", 0.8), ("thermal", "Cooling & Thermals", 0.8), ("network", "Network", 0.6),
    ("firmware", "Motherboard & Firmware", 0.6), ("drivers", "Drivers & Devices", 0.8), ("windows", "Windows", 1.0),
]


def category_score(cards: list) -> Optional[float]:
    vals = [c["score"] for c in cards if c.get("score") is not None]
    if not vals:
        return None
    return round(0.6 * (sum(vals) / len(vals)) + 0.4 * min(vals), 1)


def overall(cards: list) -> dict:
    """Weighted mean of the category scores, capped so one failing area keeps the headline honest (a dying disk is not 'Excellent')."""
    per, num, den = [], 0.0, 0.0
    for key, title, weight in CATEGORIES:
        sc = category_score([c for c in cards if c["category"] == key])
        per.append({"key": key, "title": title, "score": sc, "status": rating(sc), "label": RATING_TEXT[rating(sc)]})
        if sc is not None:
            num += sc * weight
            den += weight
    if not den or sum(1 for p in per if p["score"] is not None) < 3:        # a headline number needs several areas behind it
        return {"score": None, "status": "unknown", "label": RATING_TEXT["unknown"], "categories": per}
    val = num / den
    worst = min(p["score"] for p in per if p["score"] is not None)
    val = min(val, worst + 30.0)
    val = round(max(0.0, min(100.0, val)), 1)
    return {"score": val, "status": rating(val), "label": RATING_TEXT[rating(val)], "categories": per}
