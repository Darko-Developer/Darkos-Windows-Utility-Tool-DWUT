# Copyright © 2026 Darko / Darko.Dev
"""modules/health/driver_update.py - REAL driver updating for Health > Drivers & Devices.

Source of drivers: the Windows Update *driver* channel, driven through the official Windows Update Agent COM API (the same engine that
Settings > Windows Update > Advanced options > Optional updates uses).  Unlike a "scan started" message, every update here is
downloaded and installed one at a time and the Windows Update Agent's own result code is reported:

    2 Succeeded   3 Succeeded with errors   4 Failed   5 Aborted

Nothing is reported as updated unless it is true:
  * a snapshot of every installed driver (version / date / .inf) is taken BEFORE and AFTER and compared - "changed" means the version
    that is active on the device really changed;
  * a driver Windows installed but that only becomes active after a restart is reported as exactly that;
  * devices that still have an error / no driver afterwards are listed by name, never hidden.

Drivers that makers publish only on their own website (often the newest graphics / chipset / audio packages) are NOT on Windows Update:
they are reported as "not available here" so the UI can point to the maker - they are never claimed as updated.
"""
from __future__ import annotations

import json
import os
import subprocess
import tempfile
import threading
import time
import uuid
from typing import Callable, Optional

from core.logger import get_logger

_log = get_logger("driver_update")
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
_UTF8 = "[Console]::OutputEncoding=[Text.Encoding]::UTF8;$OutputEncoding=[Text.Encoding]::UTF8;$ProgressPreference='SilentlyContinue';"
RESULT_TEXT = {0: "not started", 1: "in progress", 2: "installed", 3: "installed with warnings", 4: "failed", 5: "aborted"}

_busy = threading.Lock()


def busy() -> bool:
    return _busy.locked()


def _script_dir() -> str:
    base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    d = os.path.join(base, "DWUT", "tmp")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        d = tempfile.gettempdir()
    return d


def _purge_old_scripts(d: str) -> None:
    """Remove leftover driver-script files older than a day."""
    try:
        cutoff = time.time() - 86400
        for n in os.listdir(d):
            if n.startswith("dwut_drv_") and n.endswith(".ps1"):
                fp = os.path.join(d, n)
                try:
                    if os.path.getmtime(fp) < cutoff:
                        os.remove(fp)
                except Exception:
                    pass
    except Exception:
        pass


def _script_args(script: str) -> list[str]:
    """Write the PowerShell script to a plain .ps1 file and return the command line that runs it.

    (The script used to be passed to PowerShell in encoded form; it is now a plain readable file with identical behaviour.)"""
    d = _script_dir()
    _purge_old_scripts(d)
    fp = os.path.join(d, "dwut_drv_%d_%s.ps1" % (os.getpid(), uuid.uuid4().hex[:8]))
    with open(fp, "w", encoding="utf-8-sig", newline="\r\n") as f:   # BOM so Windows PowerShell reads it as UTF-8
        f.write(_UTF8 + script)
    return ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", fp]


def _ps_json(script: str, timeout: int) -> tuple[bool, object, str]:
    """Run a PowerShell script that prints one JSON document.  -> (ok, parsed json or None, raw text)"""
    try:
        r = subprocess.run(_script_args(script), capture_output=True, timeout=timeout, creationflags=_NO_WINDOW, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired:
        return False, None, f"timed out after {timeout}s"
    except Exception as exc:
        return False, None, str(exc)
    out = (r.stdout or b"").decode("utf-8", "replace").strip()
    err = (r.stderr or b"").decode("utf-8", "replace").strip()
    if r.returncode != 0 and not out:
        return False, None, err[:300] or f"exit code {r.returncode}"
    if not out:
        return True, [], ""
    try:
        return True, json.loads(out), out
    except Exception:
        return False, None, (out + " " + err)[:300]


def _as_list(v) -> list:
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


# ── what is installed ────────────────────────────────────────────────────────
def snapshot() -> dict[str, dict]:
    """Every PnP driver that is bound to a device: {DeviceID: {name, cls, ver, date, inf, mfr}}."""
    ps = ("Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DeviceName -and $_.DeviceID } | ForEach-Object { [pscustomobject]@{"
          " id=[string]$_.DeviceID; name=[string]$_.DeviceName; cls=[string]$_.DeviceClass; ver=[string]$_.DriverVersion;"
          " date=$(if($_.DriverDate){$_.DriverDate.ToString('yyyy-MM-dd')}else{''}); inf=[string]$_.InfName; mfr=[string]$_.Manufacturer } }"
          " | ConvertTo-Json -Compress")
    ok, data, raw = _ps_json(ps, 120)
    if not ok:
        _log.warning("driver snapshot failed: %s", raw)
        return {}
    return {d["id"]: d for d in _as_list(data) if isinstance(d, dict) and d.get("id")}


def problem_devices() -> list[dict]:
    """Devices Device Manager marks with a problem code (10 / 28 'no driver' / 43 ...)."""
    ps = ("Get-CimInstance Win32_PnPEntity | Where-Object { $_.ConfigManagerErrorCode -ne 0 -and $_.ConfigManagerErrorCode -ne 22 } | ForEach-Object {"
          " [pscustomobject]@{ id=[string]$_.PNPDeviceID; name=[string]$_.Name; code=[int]$_.ConfigManagerErrorCode; cls=[string]$_.PNPClass } } | ConvertTo-Json -Compress")
    ok, data, _ = _ps_json(ps, 60)
    return [d for d in _as_list(data) if isinstance(d, dict)] if ok else []


# ── what Windows Update offers ───────────────────────────────────────────────
def find_updates() -> tuple[bool, list[dict], str]:
    """Search the Windows Update driver channel.  -> (ok, [update], error text)"""
    ps = r"""
$ErrorActionPreference='Stop'
$s=New-Object -ComObject Microsoft.Update.Session; $s.ClientApplicationID='DWUT'
$q=$s.CreateUpdateSearcher()
$r=$q.Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
$out=@()
foreach($u in $r.Updates){
  $d=''; try{ if($u.DriverVerDate){ $d=([datetime]$u.DriverVerDate).ToString('yyyy-MM-dd') } }catch{}
  $out += [pscustomobject]@{ id=[string]$u.Identity.UpdateID; title=[string]$u.Title; model=[string]$u.DriverModel; cls=[string]$u.DriverClass;
    mfr=[string]$u.DriverManufacturer; date=$d; size=[int64]$u.MaxDownloadSize; reboot=[bool]($u.InstallationBehavior.RebootBehavior -ne 0);
    hw=(@($u.DriverHardwareID) -join ';') }
}
ConvertTo-Json -Compress -InputObject @($out)
"""
    ok, data, raw = _ps_json(ps, 600)
    if not ok:
        return False, [], raw
    return True, [d for d in _as_list(data) if isinstance(d, dict)], ""


def check(log: Callable[[str], None] = lambda m: None) -> dict:
    """Everything the UI needs to show before installing: pending updates + devices with problems."""
    from modules.health import fixes
    admin = fixes._is_admin()
    log("Asking Windows Update for driver updates (this can take a minute or two)…")
    ok, ups, err = find_updates()
    problems = problem_devices()
    return {"ok": ok, "error": err, "admin": admin, "updates": ups, "problems": problems}


# ── installing ───────────────────────────────────────────────────────────────
_INSTALL_PS = r"""
$ErrorActionPreference='Stop'
$ids=@(%IDS%)
function Emit($o){ Write-Output ("EVT`t" + ($o | ConvertTo-Json -Compress)) }
$s=New-Object -ComObject Microsoft.Update.Session; $s.ClientApplicationID='DWUT'
$q=$s.CreateUpdateSearcher()
$r=$q.Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
$n=0
foreach($u in $r.Updates){
  $uid=[string]$u.Identity.UpdateID
  if($ids.Count -gt 0 -and ($ids -notcontains $uid)){ continue }
  $n++
  Emit @{t='start'; id=$uid; title=[string]$u.Title; n=$n}
  $res=@{t='result'; id=$uid; title=[string]$u.Title; code=-1; hr=0; stage=''; reboot=$false; msg=''}
  try{
    if(-not $u.EulaAccepted){ $u.AcceptEula() }
    $col=New-Object -ComObject Microsoft.Update.UpdateColl; [void]$col.Add($u)
    Emit @{t='stage'; id=$uid; stage='download'}
    $dl=$s.CreateUpdateDownloader(); $dl.Updates=$col
    $d=$dl.Download()
    if([int]$d.ResultCode -ne 2){ $res.stage='download'; $res.code=[int]$d.ResultCode; $res.hr=[int]$d.HResult }
    else{
      Emit @{t='stage'; id=$uid; stage='install'}
      $in=$s.CreateUpdateInstaller(); $in.Updates=$col; $in.AllowSourcePrompts=$false; $in.ForceQuiet=$true
      $i=$in.Install()
      $ur=$i.GetUpdateResult(0)
      $res.stage='install'; $res.code=[int]$ur.ResultCode; $res.hr=[int]$ur.HResult; $res.reboot=[bool]$i.RebootRequired
    }
  }catch{ $res.stage='error'; $res.msg=[string]$_.Exception.Message; $res.hr=[int]$_.Exception.HResult }
  Emit $res
}
Emit @{t='done'; count=$n}
"""


def _restore_point(log: Callable[[str], None]) -> str:
    ps = ("try{ Enable-ComputerRestore -Drive $env:SystemDrive -ErrorAction SilentlyContinue; "
          "Checkpoint-Computer -Description 'DWUT before driver updates' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop; 'created' }"
          "catch{ 'skipped: ' + $_.Exception.Message }")
    try:
        r = subprocess.run(_script_args(ps), capture_output=True, timeout=150, creationflags=_NO_WINDOW, stdin=subprocess.DEVNULL)
        out = (r.stdout or b"").decode("utf-8", "replace").strip()
    except Exception as exc:
        out = f"skipped: {exc}"
    if out.startswith("created"):
        log("Restore point created (you can roll back from System Restore).")
        return "created"
    log("No new restore point (" + (out.replace("skipped:", "").strip()[:90] or "Windows allows one per day") + ") - continuing.")
    return "skipped"


def diff(before: dict, after: dict) -> list[dict]:
    """Devices whose ACTIVE driver really changed (version, date or .inf)."""
    ch = []
    for k, b in before.items():
        a = after.get(k)
        if a and (a.get("ver") != b.get("ver") or a.get("date") != b.get("date") or a.get("inf") != b.get("inf")):
            ch.append({"name": a.get("name") or b.get("name"), "cls": a.get("cls", ""), "from": f"{b.get('ver', '?')} ({b.get('date', '?')})", "to": f"{a.get('ver', '?')} ({a.get('date', '?')})"})
    for k, a in after.items():
        if k not in before:
            ch.append({"name": a.get("name"), "cls": a.get("cls", ""), "from": "no driver", "to": f"{a.get('ver', '?')} ({a.get('date', '?')})"})
    return ch


def _hr(hr) -> str:
    try:
        return "0x%08X" % (int(hr) & 0xFFFFFFFF)
    except Exception:
        return str(hr)


def install(ids: list[str], log: Callable[[str], None] = lambda m: None, event: Callable[[dict], None] = lambda e: None) -> dict:
    """Install the chosen driver updates (ids = Windows Update UpdateIDs; empty list = every pending driver update).
    Returns an honest summary: per-update result, drivers whose active version really changed, devices still broken, reboot need."""
    from modules.health import fixes
    out = {"ok": False, "error": "", "results": [], "changed": [], "reboot": False, "problems_before": [], "problems_after": [], "restore_point": "", "duration": 0.0}
    if not fixes._is_admin():
        out["error"] = "Installing drivers needs Administrator. Restart DWUT as Administrator and try again."
        return out
    if not _busy.acquire(blocking=False):
        out["error"] = "A driver update is already running."
        return out
    t0 = time.time()
    try:
        log("Saving the current driver list (to prove afterwards what really changed)…")
        before = snapshot()
        out["problems_before"] = problem_devices()
        out["restore_point"] = _restore_point(log)
        script = _INSTALL_PS.replace("%IDS%", ",".join("'" + i.replace("'", "") + "'" for i in ids))
        proc = subprocess.Popen(_script_args(script), stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=_NO_WINDOW, stdin=subprocess.DEVNULL)
        killer = threading.Timer(4 * 3600, proc.kill)
        killer.daemon = True
        killer.start()
        got_done = False
        try:
            for raw in iter(proc.stdout.readline, b""):
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("EVT\t"):
                    continue
                try:
                    ev = json.loads(line[4:])
                except Exception:
                    continue
                t = ev.get("t")
                if t == "start":
                    log(f"[{ev.get('n')}] {ev.get('title', '')[:100]}")
                elif t == "stage":
                    log(f"    {'downloading' if ev.get('stage') == 'download' else 'installing'}…")
                elif t == "result":
                    code = int(ev.get("code", -1))
                    ev["ok"] = code in (2, 3)
                    ev["text"] = RESULT_TEXT.get(code, "no result")
                    if not ev["ok"]:
                        ev["detail"] = (ev.get("msg") or f"stage: {ev.get('stage') or '?'}, Windows Update code {_hr(ev.get('hr'))}")[:200]
                    out["results"].append(ev)
                    out["reboot"] = out["reboot"] or bool(ev.get("reboot"))
                    log(f"    -> {ev['text']}" + ("" if ev["ok"] else f" ({ev['detail']})"))
                elif t == "done":
                    got_done = True
                event(ev)
        finally:
            killer.cancel()
        proc.wait(timeout=30)
        err = (proc.stderr.read() or b"").decode("utf-8", "replace").strip() if proc.stderr else ""
        if not got_done:
            out["error"] = (err or "The Windows Update engine stopped before finishing.")[:300]
        log("Re-detecting devices and comparing driver versions…")
        subprocess.run(["pnputil", "/scan-devices"], capture_output=True, timeout=90, creationflags=_NO_WINDOW, stdin=subprocess.DEVNULL)
        after = snapshot()
        out["changed"] = diff(before, after) if before and after else []
        out["problems_after"] = problem_devices()
        out["ok"] = got_done
    except Exception as exc:
        _log.exception("driver install failed")
        out["error"] = f"{type(exc).__name__}: {str(exc)[:200]}"
    finally:
        out["duration"] = round(time.time() - t0, 1)
        _busy.release()
    return out


def summarize(res: dict) -> tuple[str, str]:
    """-> (state ok|warn|skip, honest one-line note) for the Fix & Optimize step."""
    if res.get("error") and not res.get("results"):
        return "warn", res["error"][:160]
    rs = res.get("results", [])
    if not rs:
        return "skip", "Windows Update has no newer drivers for this PC (maker-only drivers, e.g. latest graphics, are not offered there)"
    good = [r for r in rs if r.get("ok")]
    bad = [r for r in rs if not r.get("ok")]
    ch = res.get("changed", [])
    parts = [f"{len(good)} of {len(rs)} driver update(s) installed"]
    if ch:
        parts.append(f"{len(ch)} device(s) now run a different driver version")
    elif good:
        parts.append("active version changes after a restart" if res.get("reboot") else "no active version changed")
    if bad:
        parts.append(f"{len(bad)} failed")
    return ("ok" if good and not bad else "warn"), "; ".join(parts)
