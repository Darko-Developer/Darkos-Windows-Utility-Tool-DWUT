# Copyright © 2026 Darko / Darko.Dev
"""modules/games/scan.py - find the supported games that are actually installed (Steam, Epic, GOG, uninstall registry) and read their icons."""
from __future__ import annotations

import base64
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

from core.logger import get_logger
from modules.games.db import GAMES

_log = get_logger(__name__)
NO_WINDOW = 0x08000000


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _steam_roots() -> list[Path]:
    roots: list[Path] = []
    try:
        import winreg
        for hive, key, val in ((winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"), (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath")):
            try:
                with winreg.OpenKey(hive, key) as k:
                    roots.append(Path(winreg.QueryValueEx(k, val)[0]))
            except OSError:
                pass
    except ImportError:
        pass
    libs: list[Path] = []
    for r in roots:
        libs.append(r)
        vdf = r / "steamapps" / "libraryfolders.vdf"
        try:
            for m in re.finditer(r'"path"\s+"([^"]+)"', vdf.read_text("utf-8", "replace")):
                libs.append(Path(m.group(1).replace("\\\\", "\\")))
        except OSError:
            pass
    seen, out = set(), []
    for p in libs:
        if str(p).lower() not in seen and (p / "steamapps").is_dir():
            seen.add(str(p).lower()); out.append(p)
    return out


def _steam_installs() -> list[dict]:
    res = []
    for lib in _steam_roots():
        for f in (lib / "steamapps").glob("appmanifest_*.acf"):
            try:
                t = f.read_text("utf-8", "replace")
                appid = int(re.search(r'"appid"\s+"(\d+)"', t).group(1))
                name = re.search(r'"name"\s+"([^"]*)"', t).group(1)
                d = re.search(r'"installdir"\s+"([^"]*)"', t).group(1)
                path = lib / "steamapps" / "common" / d
                if path.is_dir():
                    res.append({"launcher": "Steam", "appid": appid, "name": name, "path": str(path)})
            except Exception:
                continue
    return res


def _epic_installs() -> list[dict]:
    res = []
    base = Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "Epic" / "EpicGamesLauncher" / "Data" / "Manifests"
    for f in base.glob("*.item") if base.is_dir() else []:
        try:
            j = json.loads(f.read_text("utf-8", "replace"))
            p = j.get("InstallLocation")
            if p and Path(p).is_dir():
                res.append({"launcher": "Epic", "name": j.get("DisplayName") or "", "path": p, "exe": j.get("LaunchExecutable") or ""})
        except Exception:
            continue
    return res


def _gog_and_uninstall() -> list[dict]:
    res = []
    try:
        import winreg
    except ImportError:
        return res
    def walk(hive, path, launcher, namekey, pathkey):
        try:
            with winreg.OpenKey(hive, path) as root:
                for i in range(winreg.QueryInfoKey(root)[0]):
                    try:
                        with winreg.OpenKey(root, winreg.EnumKey(root, i)) as k:
                            def g(n):
                                try: return winreg.QueryValueEx(k, n)[0]
                                except OSError: return None
                            nm, pth = g(namekey), g(pathkey)
                            if nm and pth and os.path.isdir(str(pth)):
                                res.append({"launcher": launcher, "name": nm, "path": str(pth), "exe": g("exe") or ""})
                    except OSError:
                        continue
        except OSError:
            pass
    walk(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\GOG.com\Games", "GOG", "gameName", "path")
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for sub in (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"):
            walk(hive, sub, "PC", "DisplayName", "InstallLocation")
    return res


def _find_exe(folder: str, names: list[str], hint: str = "") -> Optional[str]:
    want = {n.lower() for n in names}
    if hint:
        p = Path(folder) / hint
        if p.is_file():
            return str(p)
    base = Path(folder)
    for depth, pat in enumerate(("*.exe", "*/*.exe", "*/*/*.exe", "*/*/*/*.exe", "*/*/*/*/*.exe")):
        try:
            for f in base.glob(pat):
                if f.name.lower() in want:
                    return str(f)
        except OSError:
            continue
    return None


def _standalone_installs() -> list[dict]:
    res = []
    local = os.environ.get("LOCALAPPDATA", "")
    appdata = os.environ.get("APPDATA", "")
    prog_files = os.environ.get("ProgramFiles", r"C:\Program Files")
    prog_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")

    # Roblox Player
    if local:
        roblox_dir = Path(local) / "Roblox" / "Versions"
        if roblox_dir.is_dir():
            for v in roblox_dir.iterdir():
                if v.is_dir():
                    exe_candidate = v / "RobloxPlayerBeta.exe"
                    if exe_candidate.is_file():
                        res.append({"launcher": "Roblox", "name": "Roblox", "path": str(v), "exe": str(exe_candidate)})
                        break

    # Minecraft Launchers (Prism, Official, Lunar, Badlion, Modrinth)
    mc_candidates = [
        (Path(local) / "Programs" / "PrismLauncher" / "prismlauncher.exe", "Prism Launcher", "Minecraft"),
        (Path(appdata) / ".minecraft" / "launcher.exe", "Minecraft Launcher", "Minecraft"),
        (Path(local) / "Programs" / "lunarclient" / "Lunar Client.exe", "Lunar Client", "Minecraft"),
        (Path(prog_files) / "Minecraft Launcher" / "MinecraftLauncher.exe", "Minecraft Launcher", "Minecraft"),
        (Path(local) / "Programs" / "Modrinth App" / "Modrinth App.exe", "Modrinth App", "Minecraft"),
        (Path(prog_files_x86) / "Minecraft Launcher" / "MinecraftLauncher.exe", "Minecraft Launcher", "Minecraft"),
    ]
    for pth, dname, gname in mc_candidates:
        if pth.is_file():
            res.append({"launcher": dname, "name": gname, "path": str(pth.parent), "exe": str(pth)})

    # FiveM
    if local:
        fivem_exe = Path(local) / "FiveM" / "FiveM.exe"
        if fivem_exe.is_file():
            res.append({"launcher": "Cfx.re", "name": "FiveM (GTA V)", "path": str(fivem_exe.parent), "exe": str(fivem_exe)})

    # osu!
    if local:
        osu_exe = Path(local) / "osu!" / "osu!.exe"
        if osu_exe.is_file():
            res.append({"launcher": "ppy", "name": "osu!", "path": str(osu_exe.parent), "exe": str(osu_exe)})

    return res


def installed_games() -> list[dict]:
    if sys.platform != "win32":
        return []
    installs = _steam_installs() + _epic_installs() + _gog_and_uninstall() + _standalone_installs()
    out, seen = [], set()
    for key, name, appid, exes, alts in GAMES:
        nn = {_norm(name), *(_norm(a) for a in alts)}
        hit = next((i for i in installs if (appid and i.get("appid") == appid) or _norm(i.get("name", "")) in nn), None)
        if not hit:
            continue
        exe = hit.get("exe")
        if not exe or not os.path.isabs(exe) or not os.path.isfile(exe):
            exe = _find_exe(hit["path"], exes, hit.get("exe", ""))
            if not exe and hit["launcher"] in ("Epic", "GOG", "PC", "Roblox", "Cfx.re", "ppy", "Prism Launcher", "Minecraft Launcher", "Lunar Client"):
                exe = _find_exe(hit["path"], exes)
        if not exe:
            continue                                   # supported title but we cannot find its executable: do not list it
        if key in seen:
            continue
        seen.add(key)
        out.append({"id": key, "name": name, "launcher": hit["launcher"], "path": hit["path"], "exe": exe, "exe_name": os.path.basename(exe), "appid": hit.get("appid") or appid})
    return sorted(out, key=lambda g: g["name"].lower())


_ICON_PS = (
    "Add-Type -AssemblyName System.Drawing;$r=@{};"
    "foreach($p in @(%s)){try{$i=[System.Drawing.Icon]::ExtractAssociatedIcon($p);$b=New-Object System.Drawing.Bitmap 48,48;"
    "$g=[System.Drawing.Graphics]::FromImage($b);$g.InterpolationMode='HighQualityBicubic';$g.DrawImage($i.ToBitmap(),0,0,48,48);$g.Dispose();"
    "$m=New-Object IO.MemoryStream;$b.Save($m,[System.Drawing.Imaging.ImageFormat]::Png);$r[$p]='data:image/png;base64,'+[Convert]::ToBase64String($m.ToArray())}catch{}};"
    "$r|ConvertTo-Json -Compress"
)


def icons(paths: list[str]) -> dict[str, str]:
    """exe path -> data-URI PNG of the game's own icon (extracted from the executable)."""
    if sys.platform != "win32" or not paths:
        return {}
    lst = ",".join("'" + p.replace("'", "''") + "'" for p in paths[:80])
    try:
        r = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _ICON_PS % lst],
                           capture_output=True, timeout=60, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
        txt = (r.stdout or b"").decode("utf-8", "replace").strip()
        d = json.loads(txt.splitlines()[-1]) if txt else {}
        return {k: v for k, v in d.items() if isinstance(v, str)} if isinstance(d, dict) else {}
    except Exception as exc:
        _log.debug("icons: %s", exc)
        return {}
