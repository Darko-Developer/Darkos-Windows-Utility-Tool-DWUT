# Copyright © 2026 Darko / Darko.Dev
"""modules/games/profiles.py - apply / remove a per-game profile: NVIDIA driver profile (via NVIDIA Profile Inspector, imported silently)
plus Windows per-app settings (GPU preference, fullscreen optimisations, CPU priority).  Every Windows change records the previous value so it can be undone."""
from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from app.config import CACHE_DIR, SETTINGS_DIR
from core.logger import get_logger
from modules.games.db import PRESETS, nv_settings, amd_settings, AMD

_log = get_logger(__name__)
NO_WINDOW = 0x08000000
STATE = SETTINGS_DIR / "game_profiles.json"
NPI_DIR = CACHE_DIR / "npi"
NPI_API = "https://api.github.com/repos/Orbmu2k/nvidiaProfileInspector/releases/latest"
_LAYERS = r"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"
_GPUPREF = r"Software\Microsoft\DirectX\UserGpuPreferences"
_IFEO = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\%s\PerfOptions"


def load_state() -> dict:
    try:
        return json.loads(STATE.read_text("utf-8"))
    except Exception:
        return {}


def _save(st: dict) -> None:
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(st, indent=1), "utf-8")


def has_nvidia() -> bool:
    if sys.platform != "win32":
        return False
    try:
        r = subprocess.run(["nvidia-smi", "-L"], capture_output=True, timeout=10, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
        return r.returncode == 0 and b"GPU" in (r.stdout or b"")
    except Exception:
        return False


def has_amd() -> bool:
    if sys.platform != "win32":
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}") as k:
            for i in range(winreg.QueryInfoKey(k)[0]):
                try:
                    with winreg.OpenKey(k, winreg.EnumKey(k, i)) as sub:
                        drv = str(winreg.QueryValueEx(sub, "DriverDesc")[0]).lower()
                        if "radeon" in drv or "amd" in drv or "advanced micro devices" in drv:
                            return True
                except OSError:
                    continue
    except Exception:
        pass
    return False


def _npi_exe() -> Path | None:
    exe = NPI_DIR / "nvidiaProfileInspector.exe"
    if exe.is_file():
        return exe
    try:
        req = urllib.request.Request(NPI_API, headers={"User-Agent": "DWUT"})
        rel = json.loads(urllib.request.urlopen(req, timeout=20).read())
        asset = next(a for a in rel["assets"] if a["name"].lower().endswith(".zip"))
        data = urllib.request.urlopen(urllib.request.Request(asset["browser_download_url"], headers={"User-Agent": "DWUT"}), timeout=60).read()
        NPI_DIR.mkdir(parents=True, exist_ok=True)
        zipfile.ZipFile(io.BytesIO(data)).extractall(NPI_DIR)
        for f in NPI_DIR.rglob("nvidiaProfileInspector.exe"):
            return f
    except Exception as exc:
        _log.warning("NVIDIA Profile Inspector download failed: %s", exc)
    return exe if exe.is_file() else None


def _nip(profile: str, exes: list[str], settings: list[tuple]) -> str:
    rows = "".join(f"<ProfileSetting><SettingNameInfo /><SettingID>{i}</SettingID><SettingValue>{v}</SettingValue><ValueType>Dword</ValueType></ProfileSetting>" for i, v in settings)
    ex = "".join(f"<string>{escape(e)}</string>" for e in exes)
    return ('<?xml version="1.0" encoding="utf-16"?><ArrayOfProfile><Profile><ProfileName>%s</ProfileName><Executeables>%s</Executeables><Settings>%s</Settings></Profile></ArrayOfProfile>'
            % (escape(profile), ex, rows))


def _nvidia_apply(name: str, exe_name: str, choice: dict) -> tuple[bool, str]:
    if not has_nvidia():
        return False, "No NVIDIA GPU detected - driver profile skipped (Windows settings still apply)."
    npi = _npi_exe()
    if not npi:
        return False, "Could not download NVIDIA Profile Inspector (check your connection)."
    nip = NPI_DIR / f"DWUT_{exe_name}.nip"
    sets = nv_settings(choice)
    if not sets:
        return False, "No NVIDIA settings selected."
    nip.write_text(_nip(f"DWUT - {name}", [exe_name], sets), "utf-16")
    try:
        r = subprocess.run([str(npi), "-silentImport", str(nip)], capture_output=True, timeout=60, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL, cwd=str(npi.parent))
        if r.returncode == 0:
            return True, f"NVIDIA profile imported ({len(sets)} settings)."
        return False, "Profile Inspector reported an error - run DWUT as administrator and retry."
    except Exception as exc:
        return False, f"Could not run Profile Inspector: {exc}"


def _amd_apply(name: str, exe_name: str, choice: dict) -> tuple[bool, str]:
    if not has_amd():
        return False, "No AMD GPU detected - driver profile skipped."
    sets = amd_settings(choice)
    if not sets:
        return False, "No AMD settings selected."
    try:
        import winreg
        amd_base = r"Software\AMD\DVR\Profiles\%s" % exe_name
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, amd_base) as k:
            for sname, sval in sets:
                winreg.SetValueEx(k, sname, 0, winreg.REG_DWORD, int(sval))
        return True, f"AMD Radeon profile configured ({len(sets)} settings)."
    except Exception as exc:
        return False, f"Could not configure AMD profile: {exc}"


def _win_apply(exe: str, exe_name: str, win: dict, prev: dict) -> list[str]:
    import winreg
    notes = []
    if win.get("gpu"):
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _GPUPREF) as k:
                try: prev["gpu"] = winreg.QueryValueEx(k, exe)[0]
                except OSError: prev["gpu"] = None
                winreg.SetValueEx(k, exe, 0, winreg.REG_SZ, "GpuPreference=2;")
            notes.append("High-performance GPU preference set")
        except OSError as e:
            notes.append(f"GPU preference failed: {e}")
    if win.get("fso"):
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _LAYERS) as k:
                try: old = winreg.QueryValueEx(k, exe)[0]
                except OSError: old = None
                prev["fso"] = old
                toks = [t for t in (old or "").replace("~", "").split() if t]
                if "DISABLEDXMAXIMIZEDWINDOWEDMODE" not in toks:
                    toks.append("DISABLEDXMAXIMIZEDWINDOWEDMODE")
                winreg.SetValueEx(k, exe, 0, winreg.REG_SZ, "~ " + " ".join(toks))
            notes.append("Fullscreen optimisations disabled")
        except OSError as e:
            notes.append(f"Fullscreen optimisations failed: {e}")
    if win.get("dpi"):
        try:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _LAYERS) as k:
                try: old_dpi = winreg.QueryValueEx(k, exe)[0]
                except OSError: old_dpi = None
                prev["dpi"] = old_dpi
                toks = [t for t in (old_dpi or "").replace("~", "").split() if t]
                if "HIGHDPIAWARE" not in toks:
                    toks.append("HIGHDPIAWARE")
                winreg.SetValueEx(k, exe, 0, winreg.REG_SZ, "~ " + " ".join(toks))
            notes.append("High-DPI scaling override enabled (Crisp native)")
        except OSError as e:
            notes.append(f"High-DPI override failed: {e}")
    if win.get("resolution") and win.get("resolution") != "native":
        notes.append(f"Target display mode: {win.get('resolution').upper()}")
    if win.get("prio"):
        try:
            with winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, _IFEO % exe_name) as k:
                try: prev["prio"] = winreg.QueryValueEx(k, "CpuPriorityClass")[0]
                except OSError: prev["prio"] = None
                winreg.SetValueEx(k, "CpuPriorityClass", 0, winreg.REG_DWORD, 3)
            notes.append("High CPU priority set")
        except OSError:
            notes.append("CPU priority needs administrator rights - skipped")
    return notes


def apply(game: dict, nv: dict = None, amd: dict = None, win: dict = None) -> dict:
    if sys.platform != "win32":
        return {"ok": False, "notes": ["Windows only."]}
    st = load_state()
    gid = game["id"]
    old = st.get(gid, {})
    prev = dict(old.get("prev") or {})
    notes = []
    nv_ok, amd_ok = False, False
    if nv:
        nv_ok, msg = _nvidia_apply(game["name"], game["exe_name"], nv)
        notes.append(msg)
    if amd:
        amd_ok, msg = _amd_apply(game["name"], game["exe_name"], amd)
        notes.append(msg)
    notes += _win_apply(game["exe"], game["exe_name"], win or {}, prev)
    st[gid] = {
        "nv": nv if nv_ok else None,
        "amd": amd if amd_ok else None,
        "preset": True if (nv_ok or amd_ok) else None,
        "win": win or {},
        "prev": prev,
        "exe": game["exe"],
        "exe_name": game["exe_name"]
    }
    _save(st)
    return {"ok": True, "notes": notes, "state": st[gid]}


def remove(game: dict) -> dict:
    if sys.platform != "win32":
        return {"ok": False, "notes": ["Windows only."]}
    import winreg
    st = load_state()
    ent = st.get(game["id"])
    if not ent:
        return {"ok": True, "notes": ["Nothing to remove."]}
    exe, name, prev, win = ent.get("exe") or game["exe"], ent.get("exe_name") or game["exe_name"], ent.get("prev") or {}, ent.get("win") or {}
    notes = []
    def restore(hive, path, valname, old, kind=winreg.REG_SZ):
        try:
            with winreg.CreateKey(hive, path) as k:
                if old is None:
                    try: winreg.DeleteValue(k, valname)
                    except OSError: pass
                else:
                    winreg.SetValueEx(k, valname, 0, kind, old)
        except OSError as e:
            notes.append(f"Could not restore {valname}: {e}")
    if win.get("gpu"): restore(winreg.HKEY_CURRENT_USER, _GPUPREF, exe, prev.get("gpu"))
    if win.get("fso"): restore(winreg.HKEY_CURRENT_USER, _LAYERS, exe, prev.get("fso"))
    if win.get("dpi"): restore(winreg.HKEY_CURRENT_USER, _LAYERS, exe, prev.get("dpi"))
    if win.get("prio"): restore(winreg.HKEY_LOCAL_MACHINE, _IFEO % name, "CpuPriorityClass", prev.get("prio"), winreg.REG_DWORD)
    if ent.get("preset"):
        notes.append("Windows settings restored. To clear driver profiles, check NVIDIA Control Panel / AMD Adrenalin.")
    else:
        notes.append("Windows settings restored.")
    st.pop(game["id"], None)
    _save(st)
    return {"ok": True, "notes": notes}


def open_inspector() -> tuple[bool, str]:
    npi = _npi_exe()
    if not npi:
        return False, "Could not download NVIDIA Profile Inspector."
    subprocess.Popen([str(npi)], cwd=str(npi.parent))
    return True, "Opened NVIDIA Profile Inspector."
