# Copyright © 2026 Darko / Darko.Dev
"""modules/games/db.py - games DWUT has profiles for.  (key, name, steam_appid, [exe names], [alt display names])."""
GAMES = [
    ("cs2", "Counter-Strike 2", 730, ["cs2.exe"], []),
    ("dota2", "Dota 2", 570, ["dota2.exe"], []),
    ("tf2", "Team Fortress 2", 440, ["tf_win64.exe", "hl2.exe"], []),
    ("l4d2", "Left 4 Dead 2", 550, ["left4dead2.exe"], []),
    ("apex", "Apex Legends", 1172470, ["r5apex_dx12.exe", "r5apex.exe"], ["Apex Legends"]),
    ("pubg", "PUBG: BATTLEGROUNDS", 578080, ["TslGame.exe"], []),
    ("rust", "Rust", 252490, ["RustClient.exe"], []),
    ("rocketleague", "Rocket League", 252950, ["RocketLeague.exe"], ["Rocket League"]),
    ("fortnite", "Fortnite", None, ["FortniteClient-Win64-Shipping.exe"], ["Fortnite"]),
    ("valorant", "VALORANT", None, ["VALORANT-Win64-Shipping.exe"], ["VALORANT"]),
    ("lol", "League of Legends", None, ["League of Legends.exe"], ["League of Legends"]),
    ("marvelrivals", "Marvel Rivals", 2767030, ["Marvel-Win64-Shipping.exe"], []),
    ("thefinals", "THE FINALS", 2073850, ["Discovery.exe"], []),
    ("deltaforce", "Delta Force", 2507950, ["DeltaForceClient-Win64-Shipping.exe"], []),
    ("r6", "Rainbow Six Siege", 359550, ["RainbowSix.exe", "RainbowSix_Vulkan.exe"], []),
    ("cod", "Call of Duty: HQ (Warzone / MW)", 1938090, ["cod.exe"], []),
    ("ow2", "Overwatch 2", 2357570, ["Overwatch.exe"], ["Overwatch 2", "Overwatch"]),
    ("destiny2", "Destiny 2", 1085660, ["destiny2.exe"], []),
    ("tarkov", "Escape from Tarkov", None, ["EscapeFromTarkov.exe"], ["Escape from Tarkov"]),
    ("halo", "Halo Infinite", 1240440, ["HaloInfinite.exe"], []),
    ("helldivers2", "HELLDIVERS 2", 553850, ["helldivers2.exe"], []),
    ("cyberpunk", "Cyberpunk 2077", 1091500, ["Cyberpunk2077.exe"], []),
    ("eldenring", "ELDEN RING", 1245620, ["eldenring.exe"], []),
    ("bg3", "Baldur's Gate 3", 1086940, ["bg3_dx11.exe", "bg3.exe"], []),
    ("witcher3", "The Witcher 3: Wild Hunt", 292030, ["witcher3.exe"], []),
    ("gta5", "Grand Theft Auto V", 271590, ["GTA5.exe", "PlayGTAV.exe"], ["Grand Theft Auto V"]),
    ("rdr2", "Red Dead Redemption 2", 1174180, ["RDR2.exe"], ["Red Dead Redemption 2"]),
    ("starfield", "Starfield", 1716740, ["Starfield.exe"], []),
    ("fallout4", "Fallout 4", 377160, ["Fallout4.exe"], []),
    ("skyrim", "Skyrim Special Edition", 489830, ["SkyrimSE.exe"], []),
    ("hogwarts", "Hogwarts Legacy", 990080, ["HogwartsLegacy.exe"], []),
    ("wukong", "Black Myth: Wukong", 2358720, ["b1-Win64-Shipping.exe"], []),
    ("mhw", "Monster Hunter Wilds", 2246340, ["MonsterHunterWilds.exe"], []),
    ("palworld", "Palworld", 1623730, ["Palworld-Win64-Shipping.exe"], []),
    ("forza5", "Forza Horizon 5", 1551360, ["ForzaHorizon5.exe"], []),
    ("lethal", "Lethal Company", 1966720, ["Lethal Company.exe"], []),
    ("drg", "Deep Rock Galactic", 548430, ["FSD-Win64-Shipping.exe"], []),
    ("dbd", "Dead by Daylight", 381210, ["DeadByDaylight-Win64-Shipping.exe"], []),
    ("sot", "Sea of Thieves", 1172620, ["SoTGame.exe"], []),
    ("warthunder", "War Thunder", 236390, ["aces.exe"], []),
    ("poe", "Path of Exile", 238960, ["PathOfExile.exe", "PathOfExile_x64.exe"], []),
    ("poe2", "Path of Exile 2", 2694490, ["PathOfExile.exe"], []),
    ("diablo4", "Diablo IV", None, ["Diablo IV.exe"], ["Diablo IV"]),
    ("css", "Counter-Strike: Source", 240, ["hl2.exe"], []),
    ("battlefield2042", "Battlefield 2042", 1517290, ["BF2042.exe"], []),
    ("bf6", "Battlefield 6", 2807960, ["bf6.exe"], []),
    ("nms", "No Man's Sky", 275850, ["NMS.exe"], []),
    ("stalker2", "S.T.A.L.K.E.R. 2", 1643320, ["Stalker2-Win64-Shipping.exe"], []),
    ("ark", "ARK: Survival Evolved", 346110, ["ShooterGame.exe"], []),
    ("se5", "Sniper Elite 5", 1029690, ["SniperElite5.exe"], []),
    ("spiderman", "Marvel's Spider-Man Remastered", 1817070, ["Spider-Man.exe"], []),
    ("tlou", "The Last of Us Part I", 1888930, ["tlou-i.exe"], []),
    ("cities2", "Cities: Skylines II", 949230, ["Cities2.exe"], []),
    ("roblox", "Roblox", None, ["RobloxPlayerBeta.exe", "RobloxPlayerLauncher.exe"], ["Roblox"]),
    ("minecraft", "Minecraft", None, ["Minecraft.exe", "javaw.exe", "prismlauncher.exe", "Badlion Client.exe", "Lunar Client.exe", "MinecraftLauncher.exe"], ["Minecraft", "Prism Launcher", "Lunar Client", "Badlion Client"]),
    ("fivem", "FiveM (GTA V)", None, ["FiveM.exe", "FiveM_GTAProcess.exe"], ["FiveM"]),
    ("osu", "osu!", None, ["osu!.exe", "osu.exe"], ["osu!"]),
]

PUBLISHERS = {
    "cs2": "Valve", "dota2": "Valve", "tf2": "Valve", "l4d2": "Valve", "css": "Valve", "apex": "Respawn", "pubg": "Krafton", "rust": "Facepunch", "rocketleague": "Psyonix",
    "fortnite": "Epic Games", "valorant": "Riot Games", "lol": "Riot Games", "marvelrivals": "NetEase", "thefinals": "Embark", "deltaforce": "Timi Studio", "r6": "Ubisoft",
    "cod": "Activision", "ow2": "Blizzard", "destiny2": "Bungie", "tarkov": "Battlestate", "halo": "343 Industries", "helldivers2": "Arrowhead", "cyberpunk": "CD Projekt RED",
    "eldenring": "FromSoftware", "bg3": "Larian", "witcher3": "CD Projekt RED", "gta5": "Rockstar", "rdr2": "Rockstar", "starfield": "Bethesda", "fallout4": "Bethesda", "skyrim": "Bethesda",
    "hogwarts": "Avalanche", "wukong": "Game Science", "mhw": "Capcom", "palworld": "Pocketpair", "forza5": "Playground", "lethal": "Zeekerss", "drg": "Ghost Ship", "dbd": "Behaviour",
    "sot": "Rare", "warthunder": "Gaijin", "poe": "Grinding Gear", "poe2": "Grinding Gear", "diablo4": "Blizzard", "battlefield2042": "EA DICE", "bf6": "EA DICE", "nms": "Hello Games",
    "stalker2": "GSC Game World", "ark": "Studio Wildcard", "se5": "Rebellion", "spiderman": "Insomniac", "tlou": "Naughty Dog", "cities2": "Colossal Order",
    "roblox": "Roblox Corporation", "minecraft": "Mojang Studios", "fivem": "Cfx.re / Rockstar", "osu": "ppy",
}

# NVIDIA driver-profile settings the UI exposes.  key -> (label, section, setting id, {option key: (label, value)}).  "default" is never written.
NV = {
    "vsync": ("V-Sync", "core", 0x00A879CF, {"game": ("Game decides", 0x60925292), "off": ("Off", 0x08416747), "on": ("On", 0x47814940), "fast": ("Fast", 0x18888888)}),
    "fxaa": ("Anti-Aliasing (FXAA)", "core", 0x1074C972, {"off": ("Off", 0), "on": ("On", 1)}),
    "latency": ("Low latency (render queue)", "core", 0x007BA09E, {"on": ("1 frame", 1), "off": ("Driver default", None)}),
    "power": ("Power management", "adv", 0x1057EB71, {"max": ("Max performance", 1), "adaptive": ("Adaptive", 0)}),
    "threaded": ("Threaded optimisation", "adv", 0x20C1221E, {"on": ("On", 1), "off": ("Off", 2)}),
    "triple": ("Triple buffering", "adv", 0x20FDD1F9, {"on": ("On", 1), "off": ("Off", 0)}),
    "lod": ("Clamp negative LOD bias", "adv", 0x0019BB68, {"on": ("Clamp", 1), "off": ("Allow", 0)}),
    "aniso": ("Anisotropic sample optimisation", "adv", 0x00E73211, {"on": ("On", 1), "off": ("Off", 0)}),
    "trilinear": ("Trilinear optimisation", "adv", 0x002ECAF2, {"on": ("On", 1), "off": ("Off", 0)}),
    "p2": ("CUDA force P2 state", "adv", 0x50166C5E, {"on": ("Allow P2", 1), "off": ("Off (full clocks)", 0)}),
}

# AMD Software Adrenalin driver-profile settings
AMD = {
    "antilag": ("Radeon Anti-Lag", "core", "AntiLag", {"off": ("Off", 0), "on": ("On", 1)}),
    "boost": ("Radeon Boost", "core", "RadeonBoost", {"off": ("Off", 0), "on": ("On", 1)}),
    "ris": ("Radeon Image Sharpening", "core", "RadeonImageSharpening", {"off": ("Off", 0), "on": ("On", 1)}),
    "enhanced_sync": ("Enhanced Sync", "core", "EnhancedSync", {"off": ("Off", 0), "on": ("On", 1)}),
    "chill": ("Radeon Chill", "adv", "RadeonChill", {"off": ("Off", 0), "on": ("On", 1)}),
    "vsync": ("Wait for Vertical Refresh", "core", "WaitVerticalRefresh", {"off": ("Always off", 0), "on": ("Always on", 1), "app": ("Application controlled", 2)}),
}

PRESETS = {
    "performance": ("Max FPS", "Max GPU power, threaded optimisation, 1-frame render queue, V-Sync forced off.",
                    {"power": "max", "threaded": "on", "latency": "on", "vsync": "off", "p2": "off"}),
    "latency": ("Low latency", "Max power and the shortest render queue; V-Sync left to the game (pair with a frame cap).",
                {"power": "max", "threaded": "on", "latency": "on", "vsync": "game", "p2": "off"}),
    "balanced": ("Balanced", "Max power and threaded optimisation only; everything else stays at the driver default.",
                 {"power": "max", "threaded": "on"}),
    "quality": ("Image quality", "Max power, LOD bias clamped and texture-filtering optimisations off for sharper textures.",
                {"power": "max", "lod": "on", "aniso": "off", "trilinear": "off"}),
}


def nv_settings(choice: dict) -> list:
    """{key: option key} -> [(setting id, value)] (skips unknown keys and 'default' / None values)."""
    out = []
    for k, o in (choice or {}).items():
        spec = NV.get(k)
        if not spec or o not in spec[3] or spec[3][o][1] is None:
            continue
        out.append((spec[2], spec[3][o][1]))
    return out


def amd_settings(choice: dict) -> list:
    """{key: option key} -> [(setting name, value)] for AMD profiles."""
    out = []
    for k, o in (choice or {}).items():
        spec = AMD.get(k)
        if not spec or o not in spec[3] or spec[3][o][1] is None:
            continue
        out.append((spec[2], spec[3][o][1]))
    return out

