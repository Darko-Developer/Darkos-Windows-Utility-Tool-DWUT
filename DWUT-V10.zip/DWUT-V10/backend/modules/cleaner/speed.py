# Copyright © 2026 Darko / Darko.Dev
"""
modules/cleaner/speed.py - makes Light / Deep clean fast on ANY machine without dropping any of their work.

What it does
  * Runs steps that don't depend on each other at the same time (temp cleanup, service toggles, exports ...), with fewer workers
    on weak PCs so a Pentium isn't buried.  Anything with shared state (power plans, firewall/network, Windows Update services)
    is serialised by resource locks, and the real dependencies (restore point -> registry backup -> changes) keep their order.
  * SFC result is read; DISM RestoreHealth (10-30 min) only runs when it is actually needed, otherwise a 2-second health check proves
    the component store is fine - same outcome, minutes saved.
  * Steps that silently did nothing now really work: Disk Cleanup (its profile was never configured), RAM trim (only trimmed DWUT
    itself), DNS (hard-coded to an adapter called "Ethernet"), CHKDSK (waited for a Y/N prompt that could never be answered).
  * Heavy single steps are bounded: defrag only when fragmented enough to matter, Defender scans the places malware lives instead of
    a multi-hour full scan on a slow machine, cleanmgr skips the update-cleanup handler (the DISM step already does that work).
  * Security tools are downloaded in the background while earlier phases run, so the scan phase doesn't wait for the network.
"""
from __future__ import annotations

import os
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait

from core.logger import get_logger

_log = get_logger("cleaner.speed")
_NO_WINDOW = 0x08000000

# --------------------------------------------------------------------------------------------------------------------
# hardware class
# --------------------------------------------------------------------------------------------------------------------
_low: bool | None = None


def is_low_end() -> bool:
    global _low
    if _low is None:
        try:
            import psutil
            cores = psutil.cpu_count(logical=True) or 2
            ram = psutil.virtual_memory().total / 1024 ** 3
            _low = cores <= 2 or ram <= 4.5
        except Exception:
            _low = False
    return _low


def workers() -> int:
    try:
        import psutil
        c = psutil.cpu_count(logical=True) or 2
    except Exception:
        c = 2
    return 2 if is_low_end() else max(2, min(4, c))


# --------------------------------------------------------------------------------------------------------------------
# parallel step runner
# --------------------------------------------------------------------------------------------------------------------
# step ids that are independent of each other and safe to overlap (per phase)
PARALLEL = {
    0: {"export_programs", "export_network", "export_services", "clear_event_logs", "flush_dns", "reset_firewall", "reset_hosts", "power_high",
        "dis_telemetry", "dis_wd", "dis_wu_restart", "dis_superfetch", "dis_search", "dis_delivery_opt", "dis_sleep", "dis_remote", "dis_smb1",
        "dis_homegroup", "dis_appcompat"},
    1: {"tmp_windows", "tmp_prefetch", "tmp_wu", "tmp_crashes", "tmp_thumbs", "tmp_shaders", "tmp_browsers", "tmp_java", "tmp_logs",
        "tmp_old_windows", "tmp_recycle", "tmp_installers"},
    6: {"opt_startup", "opt_services", "opt_network", "opt_dns", "opt_power", "opt_pagefile", "opt_prefetch", "opt_memory", "opt_privacy",
        "opt_index", "opt_vis", "opt_onedrive", "opt_cortana"},
    7: {"re_defender", "re_wu", "re_telemetry", "re_superfetch", "re_search", "re_delivery", "re_sleep", "re_remote", "re_media"},
    8: {"uninstall_malwarebytes", "uninstall_adwcleaner", "uninstall_tdsskiller", "uninstall_hitmanpro", "uninstall_roguekiller",
        "uninstall_kaspersky_vrt", "uninstall_sophos_vrt", "uninstall_mcafee", "uninstall_eset", "uninstall_npe", "uninstall_mbar", "uninstall_rkill"},
}
# steps that touch the same thing must not overlap each other
_LOCK_GROUPS = {
    "power": {"power_high", "dis_sleep", "re_sleep", "opt_power"},
    "net": {"flush_dns", "reset_firewall", "opt_network", "opt_dns", "reset_hosts"},
    "wu": {"tmp_wu", "dis_wu_restart", "re_wu"},
    "defender": {"dis_wd", "re_defender"},
    "disk": {"tmp_old_windows", "tmp_windows", "tmp_logs"},
}
_locks = {k: threading.Lock() for k in _LOCK_GROUPS}


def _lock_for(step_id: str):
    for k, ids in _LOCK_GROUPS.items():
        if step_id in ids:
            return _locks[k]
    return None


def run_steps(eng, phase_number: int, steps: list) -> None:
    """Run `steps` in order, overlapping each run of consecutive 'independent' steps."""
    eligible = PARALLEL.get(phase_number, set())
    batch: list = []

    def flush():
        if not batch:
            return
        if len(batch) == 1:
            eng._run_step(batch[0])
        else:
            n = min(workers(), len(batch))
            eng.log(f"  (running {len(batch)} independent steps {n} at a time)")

            def one(st):
                lk = _lock_for(st.id)
                if lk:
                    with lk:
                        eng._run_step(st)
                else:
                    eng._run_step(st)

            with ThreadPoolExecutor(max_workers=n, thread_name_prefix="clean") as pool:
                futs = [pool.submit(one, s) for s in batch]
                wait(futs)
        batch.clear()

    for st in steps:
        if eng.cancelled:
            break
        if st.id in eligible and st.auto:
            batch.append(st)
        else:
            flush()
            if not eng.cancelled:
                eng._run_step(st)
    flush()


# --------------------------------------------------------------------------------------------------------------------
# background tool prefetch
# --------------------------------------------------------------------------------------------------------------------

def prefetch_tools(eng, enabled: set) -> None:
    """Download the scanners needed in Phase 3 while earlier phases are still working (the downloader caches the files)."""
    ids = [i for i in ("rkill", "adwcleaner", "tdsskiller", "msrt", "kaspersky_vrt") if i in enabled]
    if not ids:
        return

    def work():
        try:
            from modules.cleaner.downloader import download
            for tid in ids:
                if eng.cancelled:
                    return
                download(tid, on_log=lambda m: _log.debug("prefetch %s", m))
        except Exception as exc:
            _log.debug("prefetch failed: %s", exc)

    threading.Thread(target=work, daemon=True, name="clean-prefetch").start()


# --------------------------------------------------------------------------------------------------------------------
# executors
# --------------------------------------------------------------------------------------------------------------------

def exec_sfc(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    eng.log("    Running SFC (system file check) - minutes, not hours, on most PCs...")
    code, lines = run(["sfc", "/scannow"], on_line=eng.log, timeout=3600)
    text = " ".join(lines).lower().replace("\x00", "")
    if "did not find any integrity violations" in text:
        state = "clean"
    elif "successfully repaired" in text:
        state = "repaired"
    elif "unable to fix" in text or "could not perform the requested operation" in text:
        state = "unrepaired"
    else:
        state = "unknown"
    eng._session_state["sfc"] = state
    return code in (0, 1)


def exec_dism(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    sfc = eng._session_state.get("sfc")
    # 2-second health probe: if SFC found nothing AND the component store reports healthy, RestoreHealth has nothing to restore.
    if sfc in (None, "clean"):
        eng.log("    Checking component-store health (quick)...")
        code, lines = run(["dism", "/Online", "/Cleanup-Image", "/CheckHealth"], on_line=eng.log, timeout=300)
        out = " ".join(lines).lower()
        if "no component store corruption detected" in out and code == 0:
            eng.log("    [OK] Component store is healthy - the long RestoreHealth repair is not needed.")
            return True
    eng.log("    Repairing the component store (DISM RestoreHealth) - this is the slow one...")
    code, _ = run(["dism", "/Online", "/Cleanup-Image", "/RestoreHealth"], on_line=eng.log, timeout=7200)
    return code == 0


def exec_chkdsk(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    drive = os.environ.get("SystemDrive", "C:")
    eng.log(f"    Scanning {drive} for file-system errors (online scan, no reboot needed)...")
    code, lines = run(["chkdsk", drive, "/scan", "/perf"], on_line=eng.log, timeout=3600)
    out = " ".join(lines).lower()
    if "found no problems" in out or "no problems" in out:
        eng.log("    [OK] No file-system problems found.")
        return True
    if "problems" in out or "errors" in out or code not in (0, 1):
        eng.log("    Problems reported - trying an online spot-fix...")
        run(["chkdsk", drive, "/spotfix"], on_line=eng.log, timeout=600)
        run(["fsutil", "dirty", "set", drive], on_line=eng.log, timeout=30)       # a full check runs at the next boot
        eng.log("    A full CHKDSK is scheduled for the next restart.")
    return True


def _media_type() -> str:
    from modules.cleaner.runner import run_ps
    drive = os.environ.get("SystemDrive", "C:").rstrip(":\\")
    code, lines = run_ps(f"(Get-Partition -DriveLetter {drive} | Get-Disk | Get-PhysicalDisk).MediaType", timeout=60)
    t = " ".join(lines).strip().lower()
    if "ssd" in t or "solid" in t or "nvme" in t:
        return "ssd"
    return "hdd" if "hdd" in t else "unknown"          # unknown is treated like a hard disk: analyse before touching it


def exec_defrag(eng, step=None) -> bool:
    from modules.cleaner.runner import run
    drive = os.environ.get("SystemDrive", "C:").rstrip(":\\") + ":"
    media = _media_type()
    if media == "ssd":
        eng.log(f"    SSD detected - sending TRIM to {drive} (seconds)...")
        run(["defrag", drive, "/L"], on_line=eng.log, timeout=900)
        return True
    eng.log(f"    Analysing {drive} fragmentation first (a defrag only helps if it is actually fragmented)...")
    code, lines = run(["defrag", drive, "/A", "/V"], on_line=eng.log, timeout=600)
    m = re.search(r"total fragmented space\s*=\s*(\d+)\s*%", " ".join(lines), re.I)
    pct = int(m.group(1)) if m else None
    if pct is not None and pct < 8:
        eng.log(f"    [OK] Only {pct}% fragmented - defragmenting would gain nothing, skipped.")
        return True
    eng.log(f"    {'%d%% fragmented' % pct if pct is not None else 'Fragmentation unknown'} - defragmenting at normal priority...")
    run(["defrag", drive, "/O", "/H", "/U"], on_line=eng.log, timeout=5400)
    return True


_CLEANMGR_SKIP = {"Update Cleanup", "Downloads Folder", "Recycle Bin", "Windows Defender", "Previous Installations"}


def exec_disk_cleanup(eng, step=None) -> bool:
    """cleanmgr /sagerun does NOTHING unless the matching /sageset profile exists - so create it first."""
    from modules.cleaner.runner import run
    if sys.platform != "win32":
        return True
    try:
        import winreg
        base = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches"
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base, 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
        n = 0
        i = 0
        while True:
            try:
                name = winreg.EnumKey(k, i)
            except OSError:
                break
            i += 1
            if name in _CLEANMGR_SKIP:
                continue
            try:
                sk = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base + "\\" + name, 0, winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY)
                winreg.SetValueEx(sk, "StateFlags65535", 0, winreg.REG_DWORD, 2)
                winreg.CloseKey(sk)
                n += 1
            except OSError:
                continue
        winreg.CloseKey(k)
        eng.log(f"    Selected {n} Disk Cleanup categories (update cleanup is done by the Component Store step; Downloads and Recycle Bin are never touched here).")
    except Exception as exc:
        eng.log(f"    [WARN] could not prepare Disk Cleanup: {exc}")
    run(["cleanmgr", "/sagerun:65535"], on_line=eng.log, timeout=900)
    return True


def exec_ram_trim(eng, step=None) -> bool:
    """Trim the working set of every process we may touch and purge the standby list (what 'RAM optimisers' do)."""
    eng.log("    Trimming memory working sets of running programs...")
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        import psutil
        k32, psapi = ctypes.windll.kernel32, ctypes.windll.psapi
        k32.OpenProcess.restype = ctypes.c_void_p
        k32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
        psapi.EmptyWorkingSet.argtypes = [ctypes.c_void_p]
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        try:
            from modules.system import procctl
            procctl.enable_debug_privilege()
        except Exception:
            pass
        before = psutil.virtual_memory().available
        n = 0
        for p in psutil.process_iter(["pid"]):
            h = k32.OpenProcess(0x0100 | 0x0400, 0, p.info["pid"])          # SET_QUOTA | QUERY_INFORMATION
            if not h:
                continue
            try:
                if psapi.EmptyWorkingSet(h):
                    n += 1
            finally:
                k32.CloseHandle(h)
        try:                                                                  # purge the standby list (needs SeProfileSingleProcessPrivilege)
            _purge_standby()
        except Exception:
            pass
        time.sleep(0.4)
        gained = (psutil.virtual_memory().available - before) / 1048576
        eng.log(f"    [OK] Trimmed {n} processes - about {max(0, gained):.0f} MB more RAM is now available.")
    except Exception as exc:
        eng.log(f"    [WARN] RAM trim: {exc}")
    return True


def _purge_standby() -> None:
    import ctypes
    from ctypes import wintypes
    adv, k32, nt = ctypes.windll.advapi32, ctypes.windll.kernel32, ctypes.windll.ntdll

    class LUID(ctypes.Structure):
        _fields_ = [("Low", wintypes.DWORD), ("High", wintypes.LONG)]

    class TP(ctypes.Structure):
        _fields_ = [("Count", wintypes.DWORD), ("Luid", LUID), ("Attr", wintypes.DWORD)]

    k32.GetCurrentProcess.restype = ctypes.c_void_p
    tok = ctypes.c_void_p()
    adv.OpenProcessToken.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p)]
    if not adv.OpenProcessToken(k32.GetCurrentProcess(), 0x28, ctypes.byref(tok)):
        return
    luid = LUID()
    adv.LookupPrivilegeValueW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.POINTER(LUID)]
    adv.LookupPrivilegeValueW(None, "SeProfileSingleProcessPrivilege", ctypes.byref(luid))
    tp = TP(1, luid, 2)
    adv.AdjustTokenPrivileges.argtypes = [ctypes.c_void_p, wintypes.BOOL, ctypes.POINTER(TP), wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p]
    adv.AdjustTokenPrivileges(tok, False, ctypes.byref(tp), 0, None, None)
    cmd = ctypes.c_int(4)                                                     # MemoryPurgeStandbyList
    nt.NtSetSystemInformation.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong]
    nt.NtSetSystemInformation(80, ctypes.byref(cmd), ctypes.sizeof(cmd))      # SystemMemoryListInformation
    k32.CloseHandle.argtypes = [ctypes.c_void_p]
    k32.CloseHandle(tok)


def exec_dns(eng, step=None) -> bool:
    """Set the chosen DNS on EVERY connected adapter (the old code only knew an adapter literally named 'Ethernet')."""
    from modules.cleaner.runner import run_ps
    dns = getattr(step, "_dns_provider", None) or "1.1.1.1"
    if "94.140.14" in str(dns):
        second = "94.140.15.15"
    elif "76.76.2" in str(dns):
        second = "76.76.10.2"
    elif "194.242" in str(dns):
        second = "194.242.2.4"
    elif str(dns).startswith("8.8.8.8"):
        second = "8.8.4.4"
    elif str(dns).startswith("9.9.9.9"):
        second = "149.112.112.112"
    else:
        second = "1.0.0.1" if str(dns) != "1.0.0.1" else "8.8.8.8"
    script = (f"$n = Get-NetAdapter | Where-Object {{ $_.Status -eq 'Up' -and $_.HardwareInterface }}; "
              f"foreach ($a in $n) {{ Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ServerAddresses ('{dns}','{second}'); "
              "Write-Output ('DNS set on ' + $a.Name) }; if (-not $n) { Write-Output 'No active network adapter found' }")
    code, _ = run_ps(script, on_line=eng.log, timeout=60)
    eng.log(f"    DNS set to {dns} / {second}")
    return True


_HOT_FOLDERS = (r"%USERPROFILE%\Downloads", r"%USERPROFILE%\Desktop", r"%APPDATA%", r"%LOCALAPPDATA%\Temp", r"%TEMP%", r"%PROGRAMDATA%",
                r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup")


def exec_defender_scan(eng, step=None) -> bool:
    """Quick scan always; then the places malware actually lives; a multi-hour full scan only on machines that can afford it."""
    from modules.cleaner.runner import run
    mp = os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "Windows Defender", "MpCmdRun.exe")
    if not os.path.exists(mp):
        from modules.cleaner.runner import run_ps
        eng.log("    Windows Defender scan...")
        run_ps("Start-MpScan -ScanType QuickScan", on_line=eng.log, timeout=2400)
        return True
    eng.log("    Windows Defender quick scan...")
    run([mp, "-Scan", "-ScanType", "1"], on_line=eng.log, timeout=2400)
    if eng.cancelled:
        return True
    light = getattr(eng, "light", False)
    if light:
        return True
    low = is_low_end()
    eng.log("    Scanning Downloads, Desktop, AppData, Temp and Startup folders..." if low else "    Windows Defender full scan...")
    if low:
        for f in _HOT_FOLDERS:
            p = os.path.expandvars(f)
            if eng.cancelled:
                break
            if os.path.isdir(p):
                run([mp, "-Scan", "-ScanType", "3", "-File", p], on_line=eng.log, timeout=1500)
    else:
        run([mp, "-Scan", "-ScanType", "2"], on_line=eng.log, timeout=7200)
    return True


def install(executors: dict) -> None:
    executors.update({
        "sfc": exec_sfc, "dism": exec_dism, "chkdsk": exec_chkdsk, "opt_disk": exec_defrag, "opt_cleanup": exec_disk_cleanup,
        "opt_ram_trim": exec_ram_trim, "opt_dns": exec_dns, "defender": exec_defender_scan,
    })
