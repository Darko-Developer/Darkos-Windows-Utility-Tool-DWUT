# Copyright © 2026 Darko / Darko.Dev
"""
modules/system/visual_effects.py - the settings behind Windows' "Performance Options > Visual Effects" dialog.

DWUT shows its own copy of that dialog (renderer/js/perfopts.js).  This module reads and writes exactly the same settings the
Windows dialog does, so the two always agree:

  * most switches are real Windows settings changed with SystemParametersInfo (documented, persisted by Windows itself),
  * the rest (Peek, taskbar thumbnails, taskbar animations, thumbnails, selection rectangle, icon-label shadows) are the
    per-user registry values the Windows dialog writes,
  * "mode" is VisualFXSetting: 0 = let Windows choose, 1 = best appearance, 2 = best performance, 3 = custom.

"DWUT recommended" is stored as mode 3 (custom): every effect off (= best performance) and then the six listed in
DWUT_RECOMMENDED switched back on.
"""
from __future__ import annotations

import ctypes
import sys
from typing import Callable, Optional

try:
    import winreg
except ImportError:                                   # non-Windows (tests): a fake backend is injected
    winreg = None                                     # type: ignore[assignment]

from core.logger import get_logger

_log = get_logger(__name__)

# key -> label (same wording and order as the Windows dialog)
EFFECTS: list[tuple[str, str]] = [
    ("animate_controls", "Animate controls and elements inside windows"),
    ("animate_windows", "Animate windows when minimizing and maximizing"),
    ("taskbar_animations", "Animations in the taskbar"),
    ("peek", "Enable Peek"),
    ("fade_menus", "Fade or slide menus into view"),
    ("fade_tooltips", "Fade or slide ToolTips into view"),
    ("fade_menu_items", "Fade out menu items after clicking"),
    ("save_thumbnails", "Save taskbar thumbnail previews"),
    ("cursor_shadow", "Show shadows under mouse pointer"),
    ("window_shadows", "Show shadows under windows"),
    ("thumbnails", "Show thumbnails instead of icons"),
    ("translucent_selection", "Show translucent selection rectangle"),
    ("window_contents_drag", "Show window contents while dragging"),
    ("combo_slide", "Slide open combo boxes"),
    ("font_smoothing", "Smooth edges of screen fonts"),
    ("smooth_scroll", "Smooth-scroll list boxes"),
    ("icon_label_shadows", "Use drop shadows for icon labels on the desktop"),
]
KEYS = [k for k, _ in EFFECTS]
DWUT_RECOMMENDED = ("peek", "fade_menus", "save_thumbnails", "thumbnails", "translucent_selection", "window_contents_drag")
MODES = {"windows": 0, "appearance": 1, "performance": 2, "dwut": 3, "custom": 3}

# SystemParametersInfo ids: key -> (GET id, SET id, how the value is passed to SET)
#   "ptr"  - BOOL in pvParam         "ui"  - BOOL in uiParam
_SPI = {
    "animate_controls": (0x1042, 0x1043, "ptr"),      # SPI_{GET,SET}CLIENTAREAANIMATION
    "fade_menus": (0x1002, 0x1003, "ptr"),            # MENUANIMATION
    "fade_tooltips": (0x1016, 0x1017, "ptr"),         # TOOLTIPANIMATION
    "fade_menu_items": (0x1014, 0x1015, "ptr"),       # SELECTIONFADE
    "cursor_shadow": (0x101A, 0x101B, "ptr"),         # CURSORSHADOW
    "window_shadows": (0x1024, 0x1025, "ptr"),        # DROPSHADOW
    "combo_slide": (0x1004, 0x1005, "ptr"),           # COMBOBOXANIMATION
    "smooth_scroll": (0x1006, 0x1007, "ptr"),         # LISTBOXSMOOTHSCROLLING
    "window_contents_drag": (0x0026, 0x0025, "ui"),   # DRAGFULLWINDOWS
    "font_smoothing": (0x004A, 0x004B, "ui"),         # FONTSMOOTHING
}
_SPI_GETANIMATION, _SPI_SETANIMATION = 0x0048, 0x0049   # window minimise / maximise animation (ANIMATIONINFO)
_SPI_SETFONTSMOOTHINGTYPE = 0x200B                      # 2 = ClearType
_SPIF_UPDATEINIFILE_SENDCHANGE = 0x03

# key -> (registry path under HKCU, value name, inverted)
_EXPLORER_ADV = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
_DWM = r"Software\Microsoft\Windows\DWM"
_REG = {
    "peek": (_DWM, "EnableAeroPeek", False),
    "save_thumbnails": (_DWM, "AlwaysHibernateThumbnails", False),
    "taskbar_animations": (_EXPLORER_ADV, "TaskbarAnimations", False),
    "thumbnails": (_EXPLORER_ADV, "IconsOnly", True),            # IconsOnly=1 means "show icons, NOT thumbnails"
    "translucent_selection": (_EXPLORER_ADV, "ListviewAlphaSelect", False),
    "icon_label_shadows": (_EXPLORER_ADV, "ListviewShadow", False),
}
_VFX_PATH = r"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"


class _WinBackend:
    """The real thing (Windows only).  Tests replace this with a fake that has the same five methods."""

    def spi_get_bool(self, spi_id: int) -> Optional[bool]:
        v = ctypes.c_int(0)
        ok = ctypes.windll.user32.SystemParametersInfoW(spi_id, 0, ctypes.byref(v), 0)
        return bool(v.value) if ok else None

    def spi_set_bool(self, spi_id: int, value: bool, how: str) -> bool:
        u = ctypes.windll.user32
        u.SystemParametersInfoW.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
        if how == "ui":
            return bool(u.SystemParametersInfoW(spi_id, 1 if value else 0, None, _SPIF_UPDATEINIFILE_SENDCHANGE))
        return bool(u.SystemParametersInfoW(spi_id, 0, ctypes.c_void_p(1 if value else 0), _SPIF_UPDATEINIFILE_SENDCHANGE))

    def anim_get(self) -> Optional[bool]:
        class AI(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_uint), ("iMinAnimate", ctypes.c_int)]
        ai = AI(ctypes.sizeof(AI), 0)
        ok = ctypes.windll.user32.SystemParametersInfoW(_SPI_GETANIMATION, ctypes.sizeof(ai), ctypes.byref(ai), 0)
        return bool(ai.iMinAnimate) if ok else None

    def anim_set(self, value: bool) -> bool:
        class AI(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_uint), ("iMinAnimate", ctypes.c_int)]
        ai = AI(ctypes.sizeof(AI), 1 if value else 0)
        return bool(ctypes.windll.user32.SystemParametersInfoW(_SPI_SETANIMATION, ctypes.sizeof(ai), ctypes.byref(ai), _SPIF_UPDATEINIFILE_SENDCHANGE))

    def reg_get(self, path: str, name: str) -> Optional[int]:
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_READ) as k:
                v, _t = winreg.QueryValueEx(k, name)
            return int(v)
        except (OSError, ValueError):
            return None

    def reg_set(self, path: str, name: str, value: int) -> bool:
        try:
            with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, int(value))
            return True
        except OSError as exc:
            _log.debug("registry write failed %s\\%s: %s", path, name, exc)
            return False

    def broadcast(self) -> None:
        try:
            HWND_BROADCAST, WM_SETTINGCHANGE, SMTO_ABORTIFHUNG = 0xFFFF, 0x001A, 0x0002
            res = ctypes.c_ulong()
            ctypes.windll.user32.SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0, "WindowsThemeElement", SMTO_ABORTIFHUNG, 2000, ctypes.byref(res))
            ctypes.windll.user32.SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0x2F, "VisualEffects", SMTO_ABORTIFHUNG, 2000, ctypes.byref(res))
        except Exception:                                                  # cosmetic only
            pass

    def set_cleartype(self) -> None:
        try:
            ctypes.windll.user32.SystemParametersInfoW(_SPI_SETFONTSMOOTHINGTYPE, 0, ctypes.c_void_p(2), _SPIF_UPDATEINIFILE_SENDCHANGE)
        except Exception:
            pass


_backend = _WinBackend() if sys.platform == "win32" else None


def preset(name: str) -> dict[str, bool]:
    """The checkbox states for a named preset (what the dialog shows when you pick that radio button)."""
    if name == "performance":
        return {k: False for k in KEYS}
    if name == "dwut":
        return {k: (k in DWUT_RECOMMENDED) for k in KEYS}
    return {k: True for k in KEYS}                                          # "windows" and "appearance"


def read_state(be=None) -> dict:
    """-> {"mode": 0..3 or None, "fx": {key: bool|None}}  - the live state of this PC."""
    be = be or _backend
    fx: dict[str, Optional[bool]] = {}
    for k, (g, _s, _how) in _SPI.items():
        fx[k] = be.spi_get_bool(g)
    fx["animate_windows"] = be.anim_get()
    for k, (path, name, inv) in _REG.items():
        v = be.reg_get(path, name)
        if v is None:                                   # no value stored = Windows' default, which is ON for all of these
            fx[k] = True
        else:
            fx[k] = (v == 0) if inv else bool(v)
    mode = be.reg_get(_VFX_PATH, "VisualFXSetting")
    return {"mode": mode, "fx": {k: fx.get(k) for k in KEYS}}


def apply(mode: str, fx: dict, be=None) -> dict:
    """Write a complete selection.  -> {"ok": bool, "applied": n, "failed": [labels], "message": str}"""
    be = be or _backend
    if mode not in MODES:
        return {"ok": False, "applied": 0, "failed": [], "message": f"Unknown mode {mode!r}."}
    want = {k: bool(fx.get(k, False)) for k in KEYS}
    labels = dict(EFFECTS)
    failed: list[str] = []
    # VisualFXSetting first (as the Windows dialog does), so Windows sees a "custom" profile while we write the details
    be.reg_set(_VFX_PATH, "VisualFXSetting", MODES[mode])
    for k, (_g, s, how) in _SPI.items():
        if not be.spi_set_bool(s, want[k], how):
            failed.append(labels[k])
    if want["font_smoothing"]:
        be.set_cleartype()
    if not be.anim_set(want["animate_windows"]):
        failed.append(labels["animate_windows"])
    for k, (path, name, inv) in _REG.items():
        if not be.reg_set(path, name, int((not want[k]) if inv else want[k])):
            failed.append(labels[k])
    be.broadcast()
    n = len(KEYS) - len(failed)
    msg = f"{n} of {len(KEYS)} visual effects set" + (f"; Windows refused: {', '.join(failed[:4])}" if failed else "")
    msg += ". Taskbar / icon settings finish applying when Explorer restarts or you sign out."
    return {"ok": not failed, "applied": n, "failed": failed, "message": msg}


def describe(mode: str, fx: dict) -> str:
    on = [lbl for k, lbl in EFFECTS if fx.get(k)]
    name = {"windows": "Let Windows choose", "appearance": "Best appearance", "performance": "Best performance", "dwut": "DWUT recommended", "custom": "Custom"}.get(mode, mode)
    return f"{name} ({len(on)} of {len(KEYS)} effects on)"
