# Copyright © 2026 Darko / Darko.Dev
"""
modules/system/perfsample.py - ONE sampler for CPU / GPU load, shared by the Task Manager and the Dashboard.

Why: Windows performance counters are rates - a value only means something over the interval between two reads of the SAME
query.  The old code read the same counters from several places on different timers (process list, performance tab, dashboard),
so each read covered a random, often tiny interval and the numbers jumped around / disagreed with each other.  Here a single
background thread reads once a second and everybody else just takes the latest value.

Definitions match Windows Task Manager:
  CPU total / per thread   "% Processor Utility" (frequency-aware, what Task Manager shows), capped at 100.
  CPU frequency            base frequency x "% Processor Performance"  (real current clock, not the nominal one).
  GPU (per process)        the BUSIEST engine of that process (Task Manager: "highest utilization across all engines"), not the sum.
  GPU (adapter)            the busiest engine of the adapter.
  GPU engine rows          the busiest engine of each type (3D / Copy / Video Decode ...), not a sum of all instances.
  Disk                     "Active time" = 100 - \\PhysicalDisk(_Total)\\% Idle Time (what Task Manager's Disk column shows).
  Network                  all adapters, send + receive, in megabits per second.

system_totals() at the bottom is THE single set of live CPU / RAM / GPU / Disk / Network / temperature numbers.  The Task Manager
(Processes status bar + Performance), the Dashboard and the Game Booster all read it, so they can never disagree.
"""
from __future__ import annotations

import re
import sys
import threading
import time
from typing import Optional

from core.logger import get_logger

_log = get_logger("perfsample")

_GPU_RE = re.compile(r"pid_(\d+)_luid_(0x[0-9a-fA-F]+_0x[0-9a-fA-F]+)_phys_(\d+)_eng_(\d+)_engtype_(.+)$")


def _engine_class(raw: str) -> str:
    r = raw.lower()
    if "3d" in r:
        return "3D"
    if "copy" in r:
        return "Copy"
    if "decode" in r:
        return "Video Decode"
    if "encode" in r or "processing" in r:
        return "Video Processing"
    if "compute" in r or "vr" in r:
        return "Compute"
    return "3D"


def parse_gpu(items: dict) -> dict:
    """items: {counter instance name: utilization %}  ->  per-process / per-adapter / per-engine-type figures (pure function)."""
    eng_total: dict = {}            # (luid, phys, eng) -> summed % over processes
    eng_type: dict = {}             # (luid, phys, eng) -> engine class
    per_pid_eng: dict = {}          # pid -> {(luid,phys,eng): %}
    for inst, val in items.items():
        m = _GPU_RE.match(inst)
        if not m or val is None or val <= 0:
            continue
        pid, luid, phys, eng, typ = int(m.group(1)), m.group(2), m.group(3), m.group(4), m.group(5)
        key = (luid, phys, eng)
        eng_total[key] = eng_total.get(key, 0.0) + float(val)
        eng_type[key] = _engine_class(typ)
        d = per_pid_eng.setdefault(pid, {})
        d[key] = d.get(key, 0.0) + float(val)
    adapters: dict = {}
    for key, v in eng_total.items():
        a = adapters.setdefault(key[0], {"total": 0.0, "engines": {}})
        v = min(100.0, v)
        a["total"] = max(a["total"], v)
        t = eng_type[key]
        a["engines"][t] = max(a["engines"].get(t, 0.0), v)
    per_pid = {pid: round(min(100.0, max(d.values())), 1) for pid, d in per_pid_eng.items()}
    return {"adapters": adapters, "per_pid": per_pid}


class _Pdh:
    """Minimal ctypes PDH wrapper (no pywin32 needed)."""

    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self.ct, self.wt = ctypes, wintypes
        self.pdh = ctypes.windll.pdh
        self.pdh.PdhOpenQueryW.argtypes = [ctypes.c_wchar_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_void_p)]
        self.pdh.PdhAddEnglishCounterW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_void_p)]
        self.pdh.PdhCollectQueryData.argtypes = [ctypes.c_void_p]
        self.pdh.PdhCloseQuery.argtypes = [ctypes.c_void_p]
        self.pdh.PdhGetFormattedCounterArrayW.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
                                                          ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]
        self.pdh.PdhGetFormattedCounterValue.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p]

        class _FMT(ctypes.Structure):
            _fields_ = [("CStatus", wintypes.DWORD), ("v", ctypes.c_double)]

        class _ITEM(ctypes.Structure):
            _fields_ = [("name", ctypes.c_wchar_p), ("val", _FMT)]
        self.FMT, self.ITEM = _FMT, _ITEM

    def open(self, paths: list):
        ct = self.ct
        q = ct.c_void_p()
        if self.pdh.PdhOpenQueryW(None, 0, ct.byref(q)) != 0:
            return None, []
        cs = []
        for p in paths:
            c = ct.c_void_p()
            cs.append(c if self.pdh.PdhAddEnglishCounterW(q, p, 0, ct.byref(c)) == 0 else None)
        self.pdh.PdhCollectQueryData(q)
        return q, cs

    def close(self, q) -> None:
        try:
            self.pdh.PdhCloseQuery(q)
        except Exception:
            pass

    def collect(self, q) -> bool:
        return self.pdh.PdhCollectQueryData(q) == 0

    def array(self, c) -> dict:
        ct, wt = self.ct, self.wt
        FMT = 0x200 | 0x8000                                  # DOUBLE | NOCAP100
        size, count = wt.DWORD(0), wt.DWORD(0)
        r = self.pdh.PdhGetFormattedCounterArrayW(c, FMT, ct.byref(size), ct.byref(count), None)
        if (r & 0xFFFFFFFF) != 0x800007D2 or not size.value:  # PDH_MORE_DATA
            return {}
        buf = ct.create_string_buffer(size.value)
        if self.pdh.PdhGetFormattedCounterArrayW(c, FMT, ct.byref(size), ct.byref(count), buf) != 0:
            return {}
        items = ct.cast(buf, ct.POINTER(self.ITEM))
        out = {}
        for i in range(count.value):
            it = items[i]
            if it.val.CStatus in (0, 1) and it.name:
                out[it.name] = float(it.val.v)
        return out

    def single(self, c) -> Optional[float]:
        ct, wt = self.ct, self.wt
        v = self.FMT()
        if self.pdh.PdhGetFormattedCounterValue(c, 0x200 | 0x8000, ct.byref(wt.DWORD()), ct.byref(v)) != 0 or v.CStatus not in (0, 1):
            return None
        return float(v.v)


class PerfSampler:
    def __init__(self):
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._cpu: dict = {}
        self._gpu: dict = {}
        self._primary = ""
        self._vram_total = 0.0
        self._name = ""
        self._sys: dict = {}
        self._sys_prev = None            # (monotonic time, disk io counters, net io counters) of the previous tick
        self._cpu_prev = None            # previous psutil.cpu_times() - private baseline, nobody else touches it
        self._last_used = time.time()    # last time any page asked for a number: with nobody watching the sampler goes to sleep
        self._wake = threading.Event()

    def start(self) -> None:
        if sys.platform != "win32" or (self._thread and self._thread.is_alive()):
            return
        self._thread = threading.Thread(target=self._run, daemon=True, name="perfsample")
        self._thread.start()

    IDLE_AFTER = 20.0                    # seconds without any reader -> stop sampling (the per-process / GPU-engine counters are the costly part)

    def _touch(self) -> None:
        self._last_used = time.time()
        self._wake.set()
        self.start()

    def cpu(self) -> dict:
        self._touch()
        with self._lock:
            return dict(self._cpu)

    def gpu(self) -> dict:
        self._touch()
        with self._lock:
            return dict(self._gpu)

    def system(self) -> dict:
        """Latest whole-machine totals (CPU / RAM / GPU / Disk / Network), all taken in the same 1 Hz tick."""
        self._touch()
        with self._lock:
            return dict(self._sys)

    # ── sampling thread ──────────────────────────────────────────────────────
    def _run(self) -> None:
        try:
            pdh = _Pdh()
        except Exception as exc:
            _log.warning("PDH unavailable: %s", exc)
            return
        cq, cc = pdh.open([r"\Processor Information(*)\% Processor Utility",
                           r"\Processor Information(_Total)\% Processor Performance",
                           r"\Processor Information(_Total)\Processor Frequency",
                           r"\Process V2(*)\% Processor Utility",
                           r"\Processor Information(*)\% Processor Time"])
        gq = gc = None
        gopened = 0.0
        try:
            dq, dc = pdh.open([r"\PhysicalDisk(_Total)\% Idle Time"])
        except Exception as exc:
            _log.debug("disk counter: %s", exc)
            dq, dc = None, []
        while True:
            t0 = time.time()
            if t0 - self._last_used > self.IDLE_AFTER:          # nobody is looking (Dashboard / Task Manager / Game Booster closed): rest
                self._wake.clear()
                self._wake.wait(2.0)
                if time.time() - self._last_used > self.IDLE_AFTER:
                    continue
                pdh.collect(cq)                                  # fresh baseline so the first live reading is not averaged over the whole nap
                time.sleep(0.5)
                continue
            try:
                self._sample_cpu(pdh, cq, cc)
            except Exception as exc:
                _log.debug("cpu sample: %s", exc)
            try:
                if gq is None or t0 - gopened > 90:           # re-open now and then so new / exited GPU instances stay in step
                    if gq is not None:
                        pdh.close(gq)
                    gq, gc = pdh.open([r"\GPU Engine(*)\Utilization Percentage", r"\GPU Adapter Memory(*)\Dedicated Usage"])
                    gopened = t0
                else:
                    self._sample_gpu(pdh, gq, gc)
            except Exception as exc:
                _log.debug("gpu sample: %s", exc)
            try:
                self._sample_sys(pdh, dq, dc)                  # after CPU + GPU so it publishes this tick's values together
            except Exception as exc:
                _log.debug("system sample: %s", exc)
            time.sleep(max(0.2, 1.0 - (time.time() - t0)))

    @staticmethod
    def _split(items: dict):
        """{instance: value} -> ({(group, cpu): value}, _Total value)"""
        per, total = {}, None
        for nm, v in items.items():
            if nm == "_Total":
                total = v
            elif re.fullmatch(r"\d+,\d+", nm):
                g, i = nm.split(",")
                per[(int(g), int(i))] = v
        return per, total

    def _sample_cpu(self, pdh, q, cs) -> None:
        if not q or not pdh.collect(q) or not cs[0]:
            return
        u_per, u_total = self._split(pdh.array(cs[0]))               # "% Processor Utility"  (frequency-scaled, can read far above real busy time)
        t_per, t_total = self._split(pdh.array(cs[4])) if len(cs) > 4 and cs[4] else ({}, None)   # "% Processor Time" = real busy time
        if not u_per and not t_per:
            return
        perf = pdh.single(cs[1]) if cs[1] else None
        base_mhz = pdh.single(cs[2]) if cs[2] else None
        freq = round(base_mhz * perf / 100.0) if base_mhz and perf else None

        # HEADLINE = real busy time (what GetSystemTimes / Resource Monitor / psutil report).  Utility is only used to split the
        # load between processes, then rescaled so every number on screen adds up to the same total.
        if t_per and t_total is not None:
            per, total = t_per, t_total
        else:
            per, total = u_per, u_total
        u_tot = u_total if u_total is not None else (sum(u_per.values()) / len(u_per) if u_per else None)
        scale = 1.0
        if per is t_per and u_tot and u_tot > 0.5:
            scale = max(0.05, min(3.0, (total if total is not None else sum(per.values()) / len(per)) / u_tot))

        procs, div = {}, 1.0
        try:
            if len(cs) > 3 and cs[3]:                       # per-process utility (Windows 10 21H2+ / 11); older systems fall back to CPU-time deltas
                S = 0.0
                for nm, v in pdh.array(cs[3]).items():
                    pname, _, pid = nm.rpartition(":")      # (was `base`, which clobbered the base clock above and made this whole sample crash)
                    if not pid.isdigit() or not pname:
                        continue
                    pid = int(pid)
                    if pid == 0 or pname.lower() in ("idle", "system idle process", "_total"):
                        continue
                    procs[pid] = procs.get(pid, 0.0) + max(0.0, v)
                    S += max(0.0, v)
                n = max(1, len(u_per) or len(per))
                tot = u_tot if u_tot is not None else 0.0
                # the counter is on a "per logical CPU" scale on some builds and "whole machine" on others: pick the scale whose
                # sum over all processes matches the machine total
                if tot > 1.0 and S > 0:
                    div = float(n) if S / tot > n ** 0.5 else 1.0
        except Exception:
            procs = {}
        d = {"procs": {pid: round(min(100.0, v / div * scale), 1) for pid, v in procs.items()},
             "per": [round(max(0.0, min(100.0, per[k])), 1) for k in sorted(per)],
             "total": round(max(0.0, min(100.0, total)), 1) if total is not None else None,
             "utility_total": round(u_total, 1) if u_total is not None else None,
             "freq_mhz": freq, "base_mhz": round(base_mhz) if base_mhz else None, "ts": time.time()}
        with self._lock:
            self._cpu = d

    def _sample_gpu(self, pdh, q, cs) -> None:
        if not q or not pdh.collect(q) or not cs[0]:
            return
        parsed = parse_gpu(pdh.array(cs[0]))
        ads = parsed["adapters"]
        mem = pdh.array(cs[1]) if cs[1] else {}
        vram = {}
        for nm, v in mem.items():                              # e.g. luid_0x00000000_0x0000F3B2_phys_0
            m = re.match(r"luid_(0x[0-9a-fA-F]+_0x[0-9a-fA-F]+)_phys", nm)
            if m:
                vram[m.group(1)] = vram.get(m.group(1), 0.0) + v / 1048576.0
        for luid in vram:
            ads.setdefault(luid, {"total": 0.0, "engines": {}})
        if not ads:
            with self._lock:
                if self._gpu and (time.time() - self._gpu.get("ts", 0)) < 3.0:
                    return
                self._gpu = {"total": 0.0, "engines": {}, "per_pid": {}, "vram_mb": 0.0, "adapters": 0, "ts": time.time()}
            return
        cur = ads.get(self._primary)
        best = max(ads, key=lambda k: (ads[k]["total"], vram.get(k, 0.0)))
        if not cur or ads[best]["total"] > ads[self._primary]["total"] + 3.0:   # switch only on a clear difference (no flapping)
            self._primary = best
        a = ads[self._primary]
        eng = {k: round(v, 1) for k, v in a["engines"].items()}
        with self._lock:
            self._gpu = {"total": round(a["total"], 1), "engines": eng, "per_pid": parsed["per_pid"],
                         "vram_mb": round(vram.get(self._primary, 0.0), 1), "adapters": len(ads), "ts": time.time()}

    def _sample_sys(self, pdh, dq, dc) -> None:
        import psutil
        now = time.monotonic()
        vm = psutil.virtual_memory()
        try:
            dio = psutil.disk_io_counters()
        except Exception:
            dio = None
        try:
            nio = psutil.net_io_counters()
        except Exception:
            nio = None
        idle = None
        if dq and dc and dc[0] and pdh.collect(dq):
            idle = pdh.single(dc[0])
        prev, self._sys_prev = self._sys_prev, (now, dio, nio)

        rd = wr = sent = recv = None
        if prev and now - prev[0] > 0.05:
            dt = now - prev[0]
            if dio is not None and prev[1] is not None:
                rd = max(0, dio.read_bytes - prev[1].read_bytes) / dt / 1048576.0
                wr = max(0, dio.write_bytes - prev[1].write_bytes) / dt / 1048576.0
            if nio is not None and prev[2] is not None:
                sent = max(0, nio.bytes_sent - prev[2].bytes_sent) * 8 / dt / 1e6
                recv = max(0, nio.bytes_recv - prev[2].bytes_recv) * 8 / dt / 1e6
        if idle is not None:
            active = max(0.0, min(100.0, 100.0 - idle))        # Task Manager: Active time = 100 - Idle time
        elif rd is not None:
            active = min(100.0, (rd + (wr or 0.0)) * 2.5)      # only if the counter is unavailable: rough throughput estimate
        else:
            active = 0.0

        with self._lock:
            c, g = dict(self._cpu), dict(self._gpu)
        cpu = c.get("total")
        if cpu is None and c.get("per"):
            cpu = round(sum(c["per"]) / len(c["per"]), 1)
        try:                                                    # same busy-time maths as GetSystemTimes, on our OWN baseline
            ct = psutil.cpu_times()
            if self._cpu_prev is not None:
                tot_d = sum(ct) - sum(self._cpu_prev)
                idle_d = ct.idle - self._cpu_prev.idle
                if tot_d > 0 and cpu is None:
                    cpu = round(max(0.0, min(100.0, (1.0 - idle_d / tot_d) * 100.0)), 1)
            self._cpu_prev = ct
        except Exception:
            pass
        d = {"cpu_pct": cpu, "cpu_freq_mhz": c.get("freq_mhz"), "cpu_base_mhz": c.get("base_mhz"),
             "mem_pct": round(vm.percent, 1), "mem_used_gb": round(vm.used / 1e9, 2),
             "mem_avail_gb": round(vm.available / 1e9, 2), "mem_total_gb": round(vm.total / 1e9, 2),
             "gpu_pct": round(float(g["total"]), 1) if g else None, "gpu_vram_mb": round(float(g.get("vram_mb") or 0.0), 1) if g else None,
             "disk_active_pct": round(active, 1),
             "disk_read_mb_s": round(rd, 2) if rd is not None else 0.0, "disk_write_mb_s": round(wr, 2) if wr is not None else 0.0,
             "net_send_mbps": round(sent, 2) if sent is not None else 0.0, "net_recv_mbps": round(recv, 2) if recv is not None else 0.0,
             "ts": time.time()}
        with self._lock:
            self._sys = d


perf = PerfSampler()


def vram_total_mb() -> float:
    """Dedicated video memory of the primary adapter (registry qwMemorySize - works for NVIDIA / AMD / Intel)."""
    if perf._vram_total:
        return perf._vram_total
    try:
        import winreg
        best = 0.0
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base)
        i = 0
        while True:
            try:
                sub = winreg.EnumKey(k, i)
            except OSError:
                break
            i += 1
            try:
                sk = winreg.OpenKey(k, sub)
                val, typ = winreg.QueryValueEx(sk, "HardwareInformation.qwMemorySize")
                if isinstance(val, bytes):
                    val = int.from_bytes(val[:8], "little")
                mb = float(val) / 1048576.0
                if mb > best:
                    best = mb
                    try:
                        perf._name = str(winreg.QueryValueEx(sk, "DriverDesc")[0])
                    except OSError:
                        pass
            except OSError:
                continue
        perf._vram_total = best
    except Exception:
        pass
    return perf._vram_total


def gpu_name() -> str:
    vram_total_mb()
    return perf._name


def _nvml_util() -> Optional[float]:
    try:
        import pynvml
        pynvml.nvmlInit()
        try:
            return float(pynvml.nvmlDeviceGetUtilizationRates(pynvml.nvmlDeviceGetHandleByIndex(0)).gpu)
        finally:
            pynvml.nvmlShutdown()
    except Exception:
        return None


def system_totals() -> dict:
    """THE live system numbers.  The Task Manager (Processes status bar + Performance), the Dashboard and the Game Booster all
    call this, so the same percentages / rates / temperatures appear everywhere.  Never blocks."""
    s = perf.system()
    if not s or time.time() - (s.get("ts") or 0) > 5.0:          # sampler not running (non-Windows, PDH missing...) -> plain psutil
        s = {"source": "fallback"}
        try:
            import psutil
            vm = psutil.virtual_memory()
            s.update(cpu_pct=psutil.cpu_percent(interval=None), mem_pct=round(vm.percent, 1), mem_used_gb=round(vm.used / 1e9, 2),
                     mem_avail_gb=round(vm.available / 1e9, 2), mem_total_gb=round(vm.total / 1e9, 2), gpu_pct=None,
                     disk_active_pct=0.0, disk_read_mb_s=0.0, disk_write_mb_s=0.0, net_send_mbps=0.0, net_recv_mbps=0.0)
        except Exception:
            pass
    out = dict(s)
    if out.get("gpu_pct") is None:                                # no engine counters yet -> NVML, else 0 (same rule the Task Manager used)
        out["gpu_pct"] = round(_nvml_util() or 0.0, 1)
    if out.get("cpu_pct") is None:
        out["cpu_pct"] = 0.0
    try:
        from modules.system.temps import temps
        t = temps.read()
    except Exception:
        t = {}
    out.update(cpu_temp_c=t.get("cpu"), cpu_temp_src=t.get("cpu_src") or "", gpu_temp_c=t.get("gpu"), gpu_temp_src=t.get("gpu_src") or "")
    return out
