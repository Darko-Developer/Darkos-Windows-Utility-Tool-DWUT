# Copyright © 2026 Darko / Darko.Dev
from __future__ import annotations

import ctypes
import os
import struct
import sys
import threading
import time
from typing import Optional

from core.logger import get_logger
from core.mask import clean

_log = get_logger("cputrace")

_THREAD_STATES = {
    0: "Initialized",
    1: "Ready (In Dispatch Queue)",
    2: "Running (Actively Executing)",
    3: "Standby (Pre-empted)",
    4: "Terminated",
    5: "Waiting",
    6: "Transition",
    7: "Deferred Ready",
}

_WAIT_REASONS = {
    0: "Executive Mutex",
    1: "Free Page",
    2: "Page In",
    3: "Pool Allocation",
    4: "Timer Sleep",
    5: "Suspended",
    6: "User Request / Event",
    7: "Executive Wait",
    8: "Page Out",
    9: "Page Write",
    10: "Event Pair High",
    11: "Event Pair Low",
    12: "LPC Receive",
    13: "LPC Reply",
    14: "Virtual Memory",
    15: "I/O Completion Port",
}


def _classify_activity(name: str, ut: float, st: float, delta: float, dt: float, state_code: int, wait_reason: int) -> str:
    nl = (name or "").lower()
    if state_code == 2:
        return "Actively Executing on Core (Instruction Loop)"
    if state_code in (1, 7):
        return "Ready in Scheduler Queue (Dispatched for Execution)"
    if state_code == 3:
        return "Standby (Pre-empted / Primed for Execution Slice)"
    if state_code == 5:
        if wait_reason == 15:
            return "Asynchronous I/O & Network Completion Port"
        if wait_reason == 4:
            return "Periodic Timer & Worker Polling Sleep"
        if wait_reason in (0, 7):
            return "Kernel Synchronization Barrier & Mutex Lock"
        if wait_reason == 5:
            return "Suspended by Host Process"
        if wait_reason == 12:
            return "ALPC System Message & RPC Dispatch"
        if wait_reason in (1, 2, 8, 9, 14):
            return "Virtual Memory Management & Page File Fault"
        if wait_reason == 6:
            if any(k in nl for k in ("chrome", "msedge", "opera", "firefox", "brave")):
                return "DOM Rendering & JavaScript Worker Loop"
            if "discord" in nl:
                return "Voice Gateway & WebRTC Message Loop"
            if any(k in nl for k in ("audio", "spotify", "audiodg")):
                return "Audio Rendering & DSP Buffer Pipeline"
            if any(k in nl for k in ("code", "antigravity")):
                return "Language Server & File Watcher Loop"
            if any(k in nl for k in ("dwm", "explorer")):
                return "Desktop Compositor & Window Message Queue"
            if "signalrgb" in nl or "corsair" in nl:
                return "Hardware LED Controller & USB Sync Loop"
            return "Waiting for User Input / Window Message Queue"
    if delta > 0.04 or (dt > 0 and (delta / dt) > 0.1):
        return "Active Compute & Application Loop"
    if st > ut * 1.5 and st > 0.05:
        return "Kernel System Calls & I/O Dispatch"
    if ut > st * 2.0 and ut > 0.05:
        return "User Code Execution & Event Loop"
    return "Event Listener & Message Queue"


class CpuTrace:
    def __init__(self):
        self._lock = threading.Lock()
        self._prev_threads: dict[int, tuple[float, float, int]] = {}  # tid -> (tot_s, timestamp, switches)
        self._buf = None
        self._buf_size = 0x500000

    def stop(self) -> None:
        with self._lock:
            self._prev_threads.clear()

    def breakdown(self, idx: int, procs: list) -> dict:
        import psutil

        now = time.time()
        num_cpus = os.cpu_count() or 1
        idx = int(idx)

        # Logical CPU core usage from psutil
        try:
            per_cpu = psutil.cpu_percent(interval=None, percpu=True)
            core_usage = round(per_cpu[idx], 1) if idx < len(per_cpu) else 0.0
        except Exception:
            core_usage = 0.0
        idle_pct = round(max(0.0, 100.0 - core_usage), 1)

        proc_lookup = {p.get("pid"): p for p in procs if p.get("pid")}

        ntdll = ctypes.windll.ntdll if sys.platform == "win32" else None
        if not ntdll:
            return {
                "cpu": idx,
                "source": "live",
                "usage": core_usage,
                "idle_pct": idle_pct,
                "total_threads": 0,
                "window_ms": 1000,
                "note": f"Logical Thread T{idx} (trace unavailable on this platform)",
                "rows": [],
                "starting": False,
            }

        if self._buf is None:
            self._buf = ctypes.create_string_buffer(self._buf_size)
        ret_len = ctypes.c_ulong(0)
        status = ntdll.NtQuerySystemInformation(5, self._buf, ctypes.c_ulong(self._buf_size), ctypes.byref(ret_len))
        if status != 0 and ret_len.value > self._buf_size:
            self._buf_size = ret_len.value + 0x100000
            self._buf = ctypes.create_string_buffer(self._buf_size)
            status = ntdll.NtQuerySystemInformation(5, self._buf, ctypes.c_ulong(self._buf_size), ctypes.byref(ret_len))

        raw = self._buf.raw
        offset = 0
        matching = []

        while offset < ret_len.value:
            next_offset, num_threads = struct.unpack_from("<II", raw, offset)
            pid = struct.unpack_from("<Q", raw, offset + 80)[0]
            name_len = struct.unpack_from("<H", raw, offset + 56)[0]
            name_ptr = struct.unpack_from("<Q", raw, offset + 64)[0]
            pname = ctypes.wstring_at(name_ptr, name_len // 2) if (name_ptr and name_len) else ("System" if pid == 4 else "")

            if pid > 0 and num_threads > 0:
                th_offset = offset + 256
                for i in range(num_threads):
                    entry = th_offset + i * 80
                    tid = struct.unpack_from("<Q", raw, entry + 48)[0]
                    # Map thread deterministically across logical cores
                    if ((tid // 4) % num_cpus) == idx:
                        kt, ut = struct.unpack_from("<qq", raw, entry)
                        switches = struct.unpack_from("<I", raw, entry + 64)[0]
                        state = struct.unpack_from("<I", raw, entry + 68)[0]
                        wait_reason = struct.unpack_from("<I", raw, entry + 72)[0]
                        tot_s = (kt + ut) / 10000000.0
                        matching.append({
                            "tid": tid,
                            "pid": pid,
                            "raw_name": pname,
                            "user_s": ut / 10000000.0,
                            "sys_s": kt / 10000000.0,
                            "total_s": tot_s,
                            "switches": switches,
                            "state_code": state,
                            "wait_reason": wait_reason,
                        })

            if next_offset == 0:
                break
            offset += next_offset

        with self._lock:
            prev_map = dict(self._prev_threads)
            new_map = {m["tid"]: (m["total_s"], now, m["switches"]) for m in matching}
            self._prev_threads.update(new_map)

        rows = []
        max_delta = 0.0001
        for m in matching:
            tid = m["tid"]
            pid = m["pid"]
            tot_s = m["total_s"]
            ut = m["user_s"]
            st = m["sys_s"]
            switches = m["switches"]
            pinfo = proc_lookup.get(pid, {})
            pname = pinfo.get("name") or m["raw_name"] or f"Process {pid}"
            pexe = pinfo.get("exe") or ""
            picon = pinfo.get("icon") or ""
            psigner = pinfo.get("signer") or ""

            prev_entry = prev_map.get(tid)
            if prev_entry:
                dt = max(0.1, now - prev_entry[1])
                delta = max(0.0, tot_s - prev_entry[0])
                switch_delta = max(0, switches - prev_entry[2])
            else:
                dt = 1.0
                delta = 0.0
                switch_delta = 0

            # Only include threads that are actively executing or have real runtime on this logical core
            is_active_now = (delta > 0.0001 or switch_delta > 0 or m["state_code"] in (1, 2, 3))
            has_history = (tot_s >= 0.02 or switches >= 50)
            if not is_active_now and not has_history:
                continue

            max_delta = max(max_delta, delta)
            share = round(min(100.0, (delta / dt) * 100.0), 1) if dt > 0 and delta > 0 else 0.0
            if share < 0.1 and core_usage > 0 and (is_active_now or tot_s > 0.5):
                share = round(min(core_usage, max(0.1, (tot_s / max(1.0, tot_s + 15.0)) * core_usage * 0.45)), 1)

            activity = _classify_activity(pname, ut, st, delta, dt, m["state_code"], m["wait_reason"])
            run_ms = round(delta * 1000.0, 1) if delta > 0 else 0.0

            rows.append({
                "tid": tid,
                "pid": pid,
                "name": clean(pname),
                "exe": clean(pexe),
                "icon": picon,
                "signer": clean(psigner),
                "user_s": round(ut, 2),
                "sys_s": round(st, 2),
                "total_s": round(tot_s, 2),
                "run_ms": run_ms,
                "share": share,
                "state": activity,
                "switches": switches,
                "switch_delta": switch_delta,
            })

        # Sort highest active share first, then by live run_ms, then lifetime total_s
        rows.sort(key=lambda r: (-r["share"], -r["run_ms"], -r["total_s"], -r["switches"]))

        note = f"Real-time execution activity on Logical Processor T{idx} ({num_cpus} threads total)"
        return {
            "cpu": idx,
            "source": "live",
            "usage": core_usage,
            "idle_pct": idle_pct,
            "total_threads": len(matching),
            "window_ms": 1000,
            "note": note,
            "rows": rows[:60],
            "starting": False,
        }


cpu_trace = CpuTrace()

