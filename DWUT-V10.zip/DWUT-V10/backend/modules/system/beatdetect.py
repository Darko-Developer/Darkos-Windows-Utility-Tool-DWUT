# Copyright © 2026 Darko / Darko.Dev
"""
modules/system/beatdetect.py - real-time beat / onset detector for the music-reactive backgrounds.

Pure numpy, no Windows dependencies, so it can be unit-tested anywhere.

WHY NOT JUST "LOUDNESS WENT UP"?
  A volume meter sees the whole mix as one number.  As soon as a vocal or a synth pad is loud, a kick drum barely
  moves that number, so a loudness-based detector only fires on some hits.  This detector looks at the SPECTRUM:

    * audio is cut into overlapping 21 ms windows every ~5 ms,
    * each window is turned into a log-compressed spectrum (volume independent - quiet and loud playback behave
      the same),
    * "spectral flux" = how much NEW energy appeared compared with a few milliseconds ago, measured separately in
      three bands  ->  bass (kick / bass drops), mid (snare / clap / vocal attacks) and high (hats / cymbals),
    * every band has its own adaptive threshold (running mean + deviation of its own flux), so each one reacts to
      what is unusual FOR THAT BAND at that moment in the song,
    * a hit fires on the very first window that crosses the threshold (no look-ahead = no added delay), then the
      band is locked for a short refractory time and re-arms once the flux falls back below the threshold.

LATENCY
  Everything is driven by sample counts (not wall-clock), so it is exact and deterministic.  A hit is reported
  within ~one hop (about 5 ms) of the window that contains its attack.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

# band edges (Hz), refractory time (s), adaptive-threshold sensitivity k, minimum "flux / recent average" ratio, and the
# base/gain used to turn the hit into a 0..1 strength.  The ratio is what keeps steady noise and sustained notes from
# machine-gunning: a real drum hit is 5-30x above the band's recent average, steady content is 1-3x.
_BANDS = (
    # name,   lo,   hi,   refractory, k,    ratio, base, gain
    ("bass",   30.0,  170.0, 0.080, 1.9, 7.0, 0.50, 0.50),
    ("mid",   170.0, 1600.0, 0.060, 2.3, 3.4, 0.30, 0.45),
    ("high", 1600.0, 9500.0, 0.045, 2.6, 3.1, 0.16, 0.34),
)
# a hit must also make the band measurably LOUDER than its recent average (linear energy ratio) - this is what rejects the
# random wobble of the 3-4 FFT bins that make up the bass band
_RISE = {"bass": 2.7, "mid": 1.45, "high": 1.25}
_SMOOTH = 0.30          # share of the previous hop's flux mixed into the current one (calms random flicker, adds ~1 ms)


@dataclass
class Frame:
    """Result for one analysis hop (~5 ms)."""
    level: float = 0.0           # 0..1 smoothed, volume-independent loudness
    bass: float = 0.0            # 0..1 smoothed bass energy
    beat: bool = False           # a hit started in this hop
    strength: float = 0.0        # 0..1 how strong the strongest hit is (0 when beat is False)
    band: str = ""               # which band produced the strongest hit
    bands: tuple = field(default_factory=tuple)   # every band that fired in this hop
    silent: bool = False


class BeatDetector:
    def __init__(self, sample_rate: int = 48000) -> None:
        self.sr = int(sample_rate)
        self.hop = 256 if self.sr <= 50000 else 512
        self.win = 1024 if self.sr <= 50000 else 2048
        self.dt = self.hop / float(self.sr)
        self._hann = np.hanning(self.win).astype(np.float32)
        self._win = np.zeros(self.win, dtype=np.float32)
        self._pend = np.zeros(0, dtype=np.float32)
        binhz = self.sr / float(self.win)
        self._edges = []
        for name, lo, hi, refr, k, ratio, base, gain in _BANDS:
            a = max(1, int(math.floor(lo / binhz)))
            b = max(a + 1, int(math.ceil(hi / binhz)))
            b = min(b, self.win // 2)
            self._edges.append((name, a, b, refr, k, ratio, base, gain))
        n = len(self._edges)
        self._hist = [np.zeros(self.win // 2 + 1, dtype=np.float32) for _ in range(3)]   # last 3 log spectra
        self._mean = [0.0] * n
        self._dev = [0.0] * n
        self._pflux = [0.0] * n
        self._energy = [0.0] * n
        self._last = [-10.0] * n
        self._armed = [True] * n
        self._t = 0.0
        self._agc = 1e-3             # slow follower of the loudest spectral magnitude
        self._rms_peak = 1e-3
        self._lvl = 0.0
        self._bass = 0.0
        self._silent_for = 0.0
        self._warm = 0               # frames seen (stats need a moment to settle)

    # ------------------------------------------------------------------------------------------------
    @staticmethod
    def _a(dt: float, tau: float) -> float:
        return 1.0 - math.exp(-dt / tau)

    def reset(self) -> None:
        self.__init__(self.sr)

    def process(self, samples) -> list:
        """Feed mono float samples (any chunk size) -> list[Frame], one per completed hop."""
        x = np.asarray(samples, dtype=np.float32).ravel()
        if x.size == 0:
            return []
        self._pend = x if self._pend.size == 0 else np.concatenate((self._pend, x))
        out, pos, hop = [], 0, self.hop
        while self._pend.size - pos >= hop:
            self._win[:-hop] = self._win[hop:]
            self._win[-hop:] = self._pend[pos:pos + hop]
            pos += hop
            out.append(self._step())
        self._pend = self._pend[pos:]
        return out

    # ------------------------------------------------------------------------------------------------
    def _step(self) -> Frame:
        dt = self.dt
        self._t += dt
        self._warm += 1
        w = self._win
        rms = float(np.sqrt(np.mean(w * w)))

        # ---- silence gate ---------------------------------------------------------------------
        if rms < 2.5e-4:
            self._silent_for += dt
            self._lvl += (0.0 - self._lvl) * self._a(dt, 0.08)
            self._bass += (0.0 - self._bass) * self._a(dt, 0.08)
            self._hist = [self._hist[1], self._hist[2], np.zeros_like(self._hist[0])]
            if self._silent_for > 0.5:                     # long silence: forget the song, re-learn the next one
                self._mean = [0.0] * len(self._mean)
                self._dev = [0.0] * len(self._dev)
                self._energy = [0.0] * len(self._energy)
                self._agc = max(1e-3, self._agc * 0.5)
                self._warm = 0
            return Frame(level=self._lvl if self._lvl > 0.004 else 0.0, bass=self._bass if self._bass > 0.004 else 0.0, silent=True)
        self._silent_for = 0.0

        # ---- spectrum, volume-independent -------------------------------------------------------
        spec = np.abs(np.fft.rfft(w * self._hann)).astype(np.float32) * (2.0 / self.win)
        top = float(spec[1:self.win // 2].max())
        if top > self._agc:
            self._agc = top
        else:
            self._agc = max(2e-4, self._agc * math.exp(-dt / 7.0))
        logs = np.log1p(30.0 * spec / self._agc)

        ref = self._hist[1]                                 # 2 hops (~10 ms) ago
        ref = np.maximum(ref, np.maximum(np.roll(ref, 1), np.roll(ref, -1)))   # tolerate +-1 bin of pitch wobble
        diff = np.maximum(logs - ref, 0.0)
        self._hist = [self._hist[1], self._hist[2], logs]

        # ---- loudness / bass level --------------------------------------------------------------
        if rms > self._rms_peak:
            self._rms_peak = rms
        else:
            self._rms_peak = max(1.5e-3, self._rms_peak * math.exp(-dt / 5.0))
        x = min(1.0, rms / self._rms_peak)
        a0, b0 = self._edges[0][1], self._edges[0][2]
        bass_x = min(1.0, float(spec[a0:b0].max()) / max(self._agc, 1e-6))
        tgt = min(1.0, 0.7 * (x ** 0.9) + 0.3 * bass_x)
        self._lvl += (tgt - self._lvl) * self._a(dt, 0.018 if tgt > self._lvl else 0.11)
        self._bass += (bass_x - self._bass) * self._a(dt, 0.015 if bass_x > self._bass else 0.10)

        # ---- per-band onset detection -------------------------------------------------------------
        fired, best_s, best_band = [], 0.0, ""
        warm = self._warm > 40                              # ~0.2 s: enough to have a baseline (stats adapt fast until ~0.6 s)
        fast = self._warm < 120
        for i, (name, a, b, refr, k, ratio_min, base, gain) in enumerate(self._edges):
            raw = float(diff[a:b].mean())
            flux = (1.0 - _SMOOTH) * raw + _SMOOTH * self._pflux[i]
            self._pflux[i] = flux
            m, d = self._mean[i], self._dev[i]
            en = float(np.dot(spec[a:b], spec[a:b]))
            em = self._energy[i]
            self._energy[i] += (en - em) * self._a(dt, 0.40)
            thr = m + k * max(d, 0.22 * m, 0.012)
            if flux < thr:
                self._armed[i] = True
            if (warm and self._armed[i] and flux > thr and flux > 0.035 and flux > ratio_min * max(m, 0.008)
                    and en > _RISE[name] * max(em, 1e-9) and (self._t - self._last[i]) > refr):
                ratio = (flux - m) / max(thr - m, 1e-6)
                s = 1.0 - math.exp(-(ratio - 1.0) / 2.0)
                s = base + gain * max(0.0, min(1.0, s * 1.15))
                fired.append(name)
                self._armed[i] = False
                self._last[i] = self._t
                if s > best_s:
                    best_s, best_band = s, name
            # statistics: a hit must not instantly raise its own bar for the next one, so cap what enters the mean
            fl = min(flux, thr * 1.05) if fired and name in fired else flux
            self._mean[i] += (fl - m) * self._a(dt, 0.12 if fast else 0.70)
            self._dev[i] += (abs(fl - self._mean[i]) - d) * self._a(dt, 0.15 if fast else 0.90)

        return Frame(level=self._lvl, bass=self._bass, beat=bool(fired), strength=min(1.0, best_s),
                     band=best_band, bands=tuple(fired))
