# Copyright © 2026 Darko / Darko.Dev
"""
modules/system/procctl.py - ending processes for the Task Manager, as reliably as Windows allows.

A single TerminateProcess call fails for a lot of real-world cases (processes owned by another account / SYSTEM,
services, apps that ignore WM_CLOSE, handles that need SeDebugPrivilege ...).  So every request walks a LADDER of
methods and stops as soon as the process is really gone, then VERIFIES it:

    End Task  : ask nicely first (WM_CLOSE to its windows, like Windows' own Task Manager), then escalate
    Kill      : straight to force
    force     : psutil -> SeDebugPrivilege + TerminateProcess -> taskkill /F /T -> NtTerminateProcess
                -> PowerShell Stop-Process -> stop the owning service -> SYSTEM scheduled task

Two things are never attempted, because Windows itself would crash: the handful of CRITICAL system processes
(csrss, smss, wininit, winlogon, services, lsass, System ...).  Everything else is fair game, including DWUT (handled
by the caller through Electron so the app can shut down cleanly).
"""
from __future__ import annotations

import ctypes
import os
import subprocess
import sys
import time
from typing import Optional

import psutil

from core.logger import get_logger

_log = get_logger("procctl")
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# Killing any of these blue-screens or logs the user out of Windows.
CRITICAL = {
    "system", "registry", "memory compression", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe",
    "services.exe", "lsass.exe", "lsaiso.exe", "secure system", "system idle process", "system interrupts",
}
# never swept up in a "kill the whole family of same-named processes"
_NO_FAMILY = {"svchost.exe", "explorer.exe", "conhost.exe", "taskhostw.exe", "services.exe", "dllhost.exe", "runtimebroker.exe"}

_win = sys.platform == "win32"
_PROCESS_TERMINATE, _SYNCHRONIZE, _QUERY_LIMITED = 0x0001, 0x00100000, 0x1000
_dbg_done = False


# ------------------------------------------------------------------------------------------------------------------
# low-level helpers
# ------------------------------------------------------------------------------------------------------------------

def enable_debug_privilege() -> bool:
    """Turn on SeDebugPrivilege for this process (lets an administrator open protected processes)."""
    global _dbg_done
    if not _win:
        return False
    if _dbg_done:
        return True
    try:
        from ctypes import wintypes
        adv, k32 = ctypes.windll.advapi32, ctypes.windll.kernel32

        class LUID(ctypes.Structure):
            _fields_ = [("Low", wintypes.DWORD), ("High", wintypes.LONG)]

        class TP(ctypes.Structure):
            _fields_ = [("Count", wintypes.DWORD), ("Luid", LUID), ("Attr", wintypes.DWORD)]

        k32.GetCurrentProcess.restype = ctypes.c_void_p
        tok = ctypes.c_void_p()
        adv.OpenProcessToken.argtypes = [ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p)]
        if not adv.OpenProcessToken(k32.GetCurrentProcess(), 0x0020 | 0x0008, ctypes.byref(tok)):   # ADJUST_PRIVILEGES | QUERY
            return False
        luid = LUID()
        adv.LookupPrivilegeValueW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.POINTER(LUID)]
        if not adv.LookupPrivilegeValueW(None, "SeDebugPrivilege", ctypes.byref(luid)):
            return False
        tp = TP(1, luid, 0x2)                                                                          # SE_PRIVILEGE_ENABLED
        adv.AdjustTokenPrivileges.argtypes = [ctypes.c_void_p, wintypes.BOOL, ctypes.POINTER(TP), wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p]
        ok = bool(adv.AdjustTokenPrivileges(tok, False, ctypes.byref(tp), 0, None, None)) and ctypes.GetLastError() == 0
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        k32.CloseHandle(tok)
        _dbg_done = ok
        return ok
    except Exception as exc:
        _log.debug("SeDebugPrivilege: %s", exc)
        return False


def _open(pid: int, access: int):
    k32 = ctypes.windll.kernel32
    k32.OpenProcess.restype = ctypes.c_void_p
    k32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
    return k32.OpenProcess(access, 0, pid)


def _terminate_api(pid: int) -> bool:
    if not _win:
        return False
    enable_debug_privilege()
    h = _open(pid, _PROCESS_TERMINATE | _SYNCHRONIZE)
    if not h:
        return False
    k32 = ctypes.windll.kernel32
    k32.TerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    k32.CloseHandle.argtypes = [ctypes.c_void_p]
    ok = bool(k32.TerminateProcess(h, 1))
    k32.CloseHandle(h)
    return ok


def _nt_terminate(pid: int) -> bool:
    if not _win:
        return False
    try:
        enable_debug_privilege()
        h = _open(pid, _PROCESS_TERMINATE)
        if not h:
            return False
        nt = ctypes.windll.ntdll
        nt.NtTerminateProcess.argtypes = [ctypes.c_void_p, ctypes.c_long]
        ok = nt.NtTerminateProcess(h, 1) == 0
        ctypes.windll.kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        ctypes.windll.kernel32.CloseHandle(h)
        return ok
    except Exception:
        return False


def post_close(pid: int) -> int:
    """Send WM_CLOSE to every visible top-level window of `pid` (the polite 'please close')."""
    if not _win:
        return 0
    from ctypes import wintypes
    u32 = ctypes.windll.user32
    sent = [0]
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _lp):
        p = wintypes.DWORD()
        u32.GetWindowThreadProcessId(hwnd, ctypes.byref(p))
        if p.value == pid and u32.IsWindowVisible(hwnd):
            u32.PostMessageW(hwnd, 0x0010, 0, 0)         # WM_CLOSE
            sent[0] += 1
        return True

    try:
        u32.EnumWindows(WNDENUMPROC(cb), 0)
    except Exception:
        pass
    return sent[0]


def _gone(pid: int, wait: float = 0.0) -> bool:
    end = time.time() + wait
    while True:
        try:
            p = psutil.Process(pid)
            if p.status() == psutil.STATUS_ZOMBIE:
                return True
        except psutil.NoSuchProcess:
            return True
        except psutil.Error:
            pass
        if time.time() >= end:
            return False
        time.sleep(0.06)


def _run(cmd: list, timeout: int = 8) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WIN, errors="replace",
                           stdin=subprocess.DEVNULL)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as exc:
        return -1, str(exc)


def _service_name(pid: int) -> Optional[str]:
    try:
        for s in psutil.win_service_iter():
            try:
                if s.pid() == pid:
                    return s.name()
            except Exception:
                continue
    except Exception:
        pass
    return None


# ------------------------------------------------------------------------------------------------------------------
# public API
# ------------------------------------------------------------------------------------------------------------------

def force_kill(pid: int) -> tuple[bool, str]:
    """Walk the ladder until `pid` is gone.  -> (gone, method-or-last-error)."""
    if _gone(pid):
        return True, "already gone"
    last = "access denied"
    steps = [
        ("normal", lambda: psutil.Process(pid).kill()),
        ("privileged", lambda: _terminate_api(pid)),
        ("taskkill", lambda: _run(["taskkill", "/F", "/T", "/PID", str(pid)])),
        ("native", lambda: _nt_terminate(pid)),
        ("powershell", lambda: _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", f"Stop-Process -Id {pid} -Force -ErrorAction Stop"], 10)),
    ]
    for name, fn in steps:
        try:
            fn()
        except psutil.NoSuchProcess:
            return True, name
        except Exception as exc:
            last = str(exc) or last
        if _gone(pid, 0.7):
            return True, name
    svc = _service_name(pid)                                  # a service: ask the Service Control Manager to stop it
    if svc:
        _run(["sc", "stop", svc], 12)
        if _gone(pid, 4.0):
            return True, f"service {svc} stopped"
    # last resort: run taskkill as SYSTEM through a one-off scheduled task (beats ACL-protected processes)
    task = f"DWUT_end_{pid}"
    code, _ = _run(["schtasks", "/create", "/tn", task, "/tr", f"taskkill /F /T /PID {pid}", "/sc", "once", "/st", "00:00", "/ru", "SYSTEM", "/rl", "HIGHEST", "/f"], 12)
    if code == 0:
        _run(["schtasks", "/run", "/tn", task], 10)
        ok = _gone(pid, 3.0)
        _run(["schtasks", "/delete", "/tn", task, "/f"], 8)
        if ok:
            return True, "SYSTEM task"
    return _gone(pid), last


def end_task(pid: int, graceful_wait: float = 2.5) -> tuple[bool, str]:
    """Like Windows Task Manager's End Task: ask the app to close, and force it if it does not."""
    if _gone(pid):
        return True, "already gone"
    n = post_close(pid)
    if n and _gone(pid, graceful_wait):
        return True, "closed"
    return force_kill(pid)


def terminate(pid: int, *, force: bool = False, tree: bool = False, family: bool = False, protect: set[int] | None = None) -> dict:
    """End `pid` (and optionally its descendants / same-named siblings).  Never raises.
    -> {"ok", "killed": [...], "failed": [{"pid","name","error"}], "critical": bool}"""
    protect = protect or set()
    try:
        root = psutil.Process(pid)
        name = root.name()
    except psutil.NoSuchProcess:
        return {"ok": True, "killed": [], "failed": [], "critical": False, "note": "That process has already closed."}
    except psutil.Error as exc:
        return {"ok": False, "killed": [], "failed": [{"pid": pid, "name": "?", "error": str(exc)}], "critical": False}

    if name.lower() in CRITICAL:
        return {"ok": False, "killed": [], "critical": True,
                "failed": [{"pid": pid, "name": name, "error": f"{name} is a critical Windows process - ending it would crash Windows, so it is blocked."}]}

    targets: list[tuple[int, str]] = []
    if tree or family:
        try:
            for c in reversed(root.children(recursive=True)):         # deepest children first
                targets.append((c.pid, c.name()))
        except psutil.Error:
            pass
    if family and name.lower() not in _NO_FAMILY:
        for pr in psutil.process_iter(["pid", "name"]):
            try:
                if (pr.info["name"] or "").lower() == name.lower() and pr.info["pid"] != pid:
                    targets.append((pr.info["pid"], pr.info["name"]))
            except psutil.Error:
                continue
    targets.append((pid, name))

    killed, failed, seen = [], [], set()
    for tpid, tname in targets:
        if tpid in seen or tpid in protect or tname.lower() in CRITICAL:
            continue
        seen.add(tpid)
        ok, how = (force_kill(tpid) if force or tpid != pid else end_task(tpid))
        if ok:
            killed.append(tpid)
        else:
            failed.append({"pid": tpid, "name": tname, "error": how})
    root_gone = _gone(pid)
    return {"ok": root_gone, "killed": killed, "failed": failed, "critical": False}


def dwut_pids() -> set[int]:
    """Every process that is part of the running DWUT (Electron main + renderers/GPU/utility + this backend)."""
    pids: set[int] = {os.getpid()}
    try:
        me = psutil.Process()
        root = me
        par = me.parent()
        if par is not None:
            pids.add(par.pid)
            root = par
        pids |= {c.pid for c in root.children(recursive=True)}
    except Exception:
        pass
    return pids
