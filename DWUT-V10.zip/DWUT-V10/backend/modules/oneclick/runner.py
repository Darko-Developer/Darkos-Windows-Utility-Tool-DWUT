# Copyright © 2026 Darko / Darko.Dev
"""
modules/oneclick/runner.py - the "DWUT 1 CLICK BUTTON": every safe maintenance job in one run.

The user only chooses WHICH apps to debloat and WHICH tweaks to apply (three small popups in the UI: apps, tweaks, power mode); everything else is automatic:

   restore point -> debloat -> disk clean -> disk optimise -> RAM free/optimise -> CPU free/optimise -> GPU free/optimise
   -> tweaks -> TBOK-equivalent system optimizations (startup, services, system registry, bloat + tasks, per-user for ALL users, gaming)
   -> visual effects -> disable Recall (Windows 11) -> extra safe cleanups -> DISM + SFC -> High-CPU power repair -> optional Ultimate/Extreme power plan
   -> optional WinGet app updates -> network stack reset

The "system optimizations" are everything The Beard of Knowledge's TBOK Windows Optimizer does (see modules/oneclick/sysopt.py), each one a switch the user can turn off.

Order matters: DISM needs the internet, so the network reset is deliberately LAST; the restore point is first so the debloat/tweaks
can be undone.  Nothing here uses the cleaner's malware scanners or anything that closes the user's programs.
Xbox tweaks are always excluded, even if a caller sends them.
"""
from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Callable, Optional

from core.logger import get_logger

_log = get_logger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

NEVER_TWEAKS = frozenset({"xbox", "game_mode"})          # "no Xbox ones" - enforced here as well as in the popup


class Cancelled(Exception):
    pass


def _run(cmd, timeout: int = 120) -> tuple[bool, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WINDOW, errors="replace", stdin=subprocess.DEVNULL)
        return r.returncode == 0, ((r.stdout or "") + (r.stderr or "")).strip()
    except subprocess.TimeoutExpired:
        return False, f"timed out after {timeout}s"
    except Exception as exc:
        return False, str(exc)


def _ps(script: str, timeout: int = 120) -> tuple[bool, str]:
    return _run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script], timeout)


class Job:
    """One run.  `log(text)` and `step(id, label, state, idx, total, note)` are supplied by the API layer."""

    def __init__(self, bloat: list, tweaks: list, log: Callable[[str], None], step: Callable[..., None], cancel: threading.Event, power: str = "none",
                 visual: dict | None = None, sysopt: list | None = None):
        self.power = power if power in ("ultimate", "extreme") else "none"          # power plan chosen in the 3rd popup
        self.visual = visual if isinstance(visual, dict) and visual.get("mode") and isinstance(visual.get("fx"), dict) else None   # 4th popup
        self.bloat, self.tweaks = list(bloat or []), [k for k in (tweaks or []) if k not in NEVER_TWEAKS]
        from modules.oneclick import sysopt as _so
        self.sysopt = [k for k in (sysopt or []) if k in _so.ITEMS_BY_KEY]
        if self.visual:                                         # the user's own Visual-effects choice wins over TBOK's lighter-animations preset
            self.sysopt = [k for k in self.sysopt if k != "u_visual_tbok"]
        self.log, self._step, self.cancel = log, step, cancel
        self.results: list[dict] = []
        self.restart_needed = False

    # ── plumbing ──────────────────────────────────────────────────────────────
    def _plan(self) -> list[tuple[str, str, Callable[[], tuple[str, str]]]]:
        from modules.system.platform_info import is_windows_11
        p = [("restore", "Create a system restore point", self.s_restore)]
        p.append(("debloat", f"Debloat Windows ({len(self.bloat)} app(s) chosen)", self.s_debloat))
        p += [("disk_clean", "Clean all drives", self.s_disk_clean),
              ("disk_opt", "Optimize all drives (TRIM SSD / defrag HDD)", self.s_disk_opt),
              ("ram_free", "Clear and free RAM", self.s_ram_free),
              ("ram_opt", "Optimize RAM", self.s_ram_opt),
              ("cpu_free", "Clear and free CPU", self.s_cpu_free),
              ("cpu_opt", "Optimize CPU", self.s_cpu_opt),
              ("gpu_free", "Clear and free GPU", self.s_gpu_free),
              ("gpu_opt", "Optimize GPU", self.s_gpu_opt),
              ("gpu_apps", "Set every app to the high-performance GPU", self.s_gpu_apps),
              ("tweaks", f"Apply tweaks ({len(self.tweaks)} chosen)", self.s_tweaks)]
        from modules.oneclick import sysopt as _so
        for gid, label in _so.GROUPS:                           # TBOK-equivalent steps (winget is added near the end)
            n = sum(1 for k in self.sysopt if _so.ITEMS_BY_KEY[k]["group"] == gid)
            if n and gid != "winget":
                p.append((f"sys_{gid}", f"{label} - {n} chosen", lambda gid=gid: self.s_sysopt(gid)))
        if self.visual:                                         # after the tweaks, so a tweak can never undo the user's visual-effects choice
            p.append(("visual", "Adjust visual effects (Performance Options)", self.s_visual))
        if is_windows_11():
            p.append(("recall", "Disable Windows Recall", self.s_recall))
        p += [("extras", "Extra safe cleanups (update cache, recycle bin, component store, clock sync)", self.s_extras),
              ("dism", "DISM - repair the Windows component store", self.s_dism),
              ("sfc", "SFC - repair protected system files", self.s_sfc),
              ("cpu_repair", "High CPU power config repair", self.s_cpu_repair)]
        if self.power != "none":                                # after the repairs, so nothing above can undo the plan
            p.append(("power", f"Enable {self.power.title()} Performance power mode", self.s_power))
        if any(_so.ITEMS_BY_KEY[k]["group"] == "winget" for k in self.sysopt):
            p.append(("sys_winget", f"{dict(_so.GROUPS)['winget']}", lambda: self.s_sysopt("winget")))
        p.append(("network", "Network stack reset", self.s_network))
        return p

    def plan_labels(self) -> list[dict]:
        return [{"id": i, "label": l} for i, l, _ in self._plan()]

    def run(self) -> dict:
        plan = self._plan()
        total = len(plan)
        from core.events import Events, bus
        repair_cb = lambda line: self.log("    " + str(line)[:200]) if str(line).strip() and not str(line).strip().endswith("%") else None
        try:
            bus.subscribe(Events.REPAIR_PROGRESS, repair_cb)
        except Exception:
            pass
        try:
            for idx, (sid, label, fn) in enumerate(plan):
                if self.cancel.is_set():
                    self.results.append({"id": sid, "label": label, "state": "skip", "note": "stopped"})
                    self._step(sid, label, "skip", idx, total, "stopped")
                    continue
                self._step(sid, label, "run", idx, total, "")
                self.log(f"=== [{idx + 1}/{total}] {label} ===")
                t0 = time.monotonic()
                try:
                    state, note = fn()
                except Cancelled:
                    state, note = "skip", "stopped"
                except Exception as exc:                        # one broken step never ends the whole run
                    _log.exception("one-click step %s failed", sid)
                    state, note = "fail", str(exc)[:200]
                self.log(f"    -> {state.upper()}: {note}  ({time.monotonic() - t0:.0f}s)")
                self.results.append({"id": sid, "label": label, "state": state, "note": note})
                self._step(sid, label, state, idx, total, note)
        finally:
            try:
                bus.unsubscribe(Events.REPAIR_PROGRESS, repair_cb)
            except Exception:
                pass
        if self.power != "none" and not self.cancel.is_set():
            # Last word on the power plan: another step (or Windows) may have changed it since s_power ran - check again and fix it.
            try:
                from modules.system import power_modes as pm
                good, evidence = pm.verify_mode(self.power)
                if good:
                    self.log(f"Final check: {self.power.title()} Performance is still the active power plan.")
                else:
                    self.log(f"Final check: power plan changed ({evidence}) - setting it again.")
                    good, evidence = pm.ensure_mode(self.power, self.log)
                    if not good:
                        self.results.append({"id": "power_final", "label": f"{self.power.title()} Performance power plan", "state": "warn", "note": evidence[:200]})
            except Exception as exc:                                    # a failed check must never hide the run's results
                _log.exception("final power check failed")
                self.log(f"Final power check could not run: {exc}")
        ok = sum(1 for r in self.results if r["state"] == "ok")
        return {"results": self.results, "ok": ok, "total": total, "restart_needed": self.restart_needed, "cancelled": self.cancel.is_set()}

    def _check(self) -> None:
        if self.cancel.is_set():
            raise Cancelled()

    # ── steps ─────────────────────────────────────────────────────────────────
    def s_restore(self):
        """Same preparation TBOK does: make sure System Restore + VSS are on, lift the "one restore point per 24 h" limit for this one point,
        and - if Windows still refuses - back up every profile's NTUSER.DAT so the per-user changes can be undone."""
        import winreg
        from modules.debloat.operations import create_restore_point
        from modules.oneclick import sysopt as so
        _ps("Enable-ComputerRestore -Drive ($env:SystemDrive + '\\') -ErrorAction SilentlyContinue", 40)
        for svc in ("VSS", "swprv"):
            if so._service_mode(svc) == "disabled":
                _run(["sc.exe", "config", svc, "start=", "demand"], 20)
        _run(["sc.exe", "start", "VSS"], 20)
        key = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore"
        old = None
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key, 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                old = int(winreg.QueryValueEx(k, "SystemRestorePointCreationFrequency")[0])
        except OSError:
            old = None
        try:
            so._write(winreg.HKEY_LOCAL_MACHINE, key, "SystemRestorePointCreationFrequency", "dword", 0)
        except OSError:
            pass
        try:
            ok = create_restore_point("System Before DWUT 1 Click")
        finally:
            try:
                if old is None:
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key, 0, winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as k:
                        winreg.DeleteValue(k, "SystemRestorePointCreationFrequency")
                else:
                    so._write(winreg.HKEY_LOCAL_MACHINE, key, "SystemRestorePointCreationFrequency", "dword", old)
            except OSError:
                pass
        if ok:
            return "ok", "restore point created"
        self.log("    Windows would not create a restore point - saving a copy of every profile's registry file instead...")
        saved = 0
        try:
            dest = so._backup_dir() / f"1click-profiles-{time.strftime('%Y%m%d-%H%M%S')}"
            dest.mkdir(parents=True, exist_ok=True)
            users = Path(os.environ.get("SystemDrive", "C:") + "\\") / "Users"
            for d in users.iterdir():
                dat = d / "NTUSER.DAT"
                if d.is_dir() and d.name.lower() not in ("public", "all users", "default user") and dat.is_file():
                    try:
                        shutil.copyfile(dat, dest / f"{d.name}-NTUSER.DAT")
                        saved += 1
                    except OSError:
                        self.log(f"    {d.name}: profile is in use, could not copy its registry file")
            if saved:
                self.log(f"    Saved {saved} registry file(s) to {dest}")
        except OSError as exc:
            self.log(f"    Backup folder problem: {exc}")
        return "warn", "no restore point (System Protection off or blocked)" + (f"; {saved} profile registry file(s) backed up instead" if saved else "") + " - continuing"

    def s_sysopt(self, gid: str):
        from modules.oneclick import sysopt as so
        state, note, restart = so.run_group(gid, self.sysopt, self.log, self._check)
        if restart and state != "skip":
            self.restart_needed = True
        return state, note

    def s_debloat(self):
        if not self.bloat:
            return "skip", "no apps chosen"
        from modules.debloat.operations import remove_bloatware
        r = remove_bloatware(self.bloat, create_restore=False)
        note = f"removed {r.applied}/{len(self.bloat)}"
        if r.failed:
            note += f" ({len(r.failed)} not installed or failed: {', '.join(r.failed[:4])})"
        return "ok", note

    def s_disk_clean(self):
        from modules.system import disk_cleanup as dc
        keys = [c.key for c in dc._make_categories() if not c.aggressive]
        self.log(f"    Cleaning {len(keys)} safe categories on all drives…")
        r = dc.clean_categories(keys)
        mb = r.total_bytes_freed / 1048576
        self.log(f"    {r.files_deleted} files removed, {mb:.0f} MB freed" + (f", {len(r.errors)} items were in use" if r.errors else ""))
        return "ok", f"{mb:.0f} MB freed"

    def s_disk_opt(self):
        ok, out = _ps("Get-Volume | Where-Object { $_.DriveType -eq 'Fixed' -and $_.DriveLetter -and $_.FileSystem -in 'NTFS','ReFS' } | "
                      "ForEach-Object { $_.DriveLetter }", 40)
        letters = [l.strip() for l in out.splitlines() if len(l.strip()) == 1 and l.strip().isalpha()]
        if not letters:
            return "warn", "no NTFS drives found"
        done = 0
        for l in letters:
            self._check()
            self.log(f"    Optimizing {l}: (SSD = TRIM, hard disk = defrag; a big hard disk can take a while)…")
            ok, out = _ps(f"Optimize-Volume -DriveLetter {l} -ErrorAction Stop", 3600)
            self.log(f"    {l}: " + ("done" if ok else ("skipped - " + out.strip().splitlines()[-1][:120] if out.strip() else "skipped")))
            done += 1 if ok else 0
        return ("ok" if done else "warn"), f"{done}/{len(letters)} drives optimized"

    def s_ram_free(self):
        import psutil
        before = psutil.virtual_memory().available
        try:
            from modules.cleaner import speed

            class _E:
                log = staticmethod(self.log)
            speed.exec_ram_trim(_E())
        except Exception as exc:
            return "warn", f"RAM trim not possible: {exc}"
        gained = (psutil.virtual_memory().available - before) / 1048576
        return "ok", f"{max(gained, 0):.0f} MB more RAM available"

    def s_ram_opt(self):
        ok, out = _ps("if (Get-Command Enable-MMAgent -ErrorAction SilentlyContinue) { Enable-MMAgent -MemoryCompression -PageCombining -ErrorAction Stop; 'MM' }", 40)
        if "MM" in out:
            return "ok", "memory compression + page combining on (fully active after a restart)"
        return "warn", "this Windows build has no memory-agent settings"

    def s_cpu_free(self):
        import psutil
        me = os.getpid()
        protected = set()
        try:
            protected.add(me)
            cur = psutil.Process(me)
            protected.update(p.pid for p in cur.parents())
            protected.update(p.pid for p in cur.children(recursive=True))
        except Exception:
            pass
        fg = 0
        try:
            u32 = ctypes.windll.user32
            pid = ctypes.c_ulong(0)
            u32.GetWindowThreadProcessId(u32.GetForegroundWindow(), ctypes.byref(pid))
            fg = pid.value
        except Exception:
            pass
        keep = {"system", "system idle process", "registry", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe", "lsass.exe", "svchost.exe",
                "dwm.exe", "explorer.exe", "audiodg.exe", "sihost.exe", "ctfmon.exe", "fontdrvhost.exe", "taskmgr.exe", "searchhost.exe", "startmenuexperiencehost.exe",
                "shellexperiencehost.exe", "textinputhost.exe", "msmpeng.exe", "memcompression"}
        me_user = None
        try:
            me_user = psutil.Process(me).username()
        except Exception:
            pass
        procs = []
        for p in psutil.process_iter(["pid", "name", "username"]):
            try:
                p.cpu_percent(None)
                procs.append(p)
            except Exception:
                continue
        time.sleep(1.5)
        lowered, names = 0, []
        ncpu = psutil.cpu_count(logical=True) or 1
        for p in procs:
            try:
                if p.pid in protected or p.pid == fg or (p.info.get("name") or "").lower() in keep:
                    continue
                if me_user and p.info.get("username") and p.info["username"] != me_user:
                    continue
                if p.cpu_percent(None) / ncpu < 3.0:                          # only things that really use the CPU right now
                    continue
                if p.nice() == psutil.BELOW_NORMAL_PRIORITY_CLASS or p.nice() == psutil.IDLE_PRIORITY_CLASS:
                    continue
                p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
                lowered += 1
                names.append(p.info.get("name") or str(p.pid))
            except Exception:
                continue
        if lowered:
            self.log("    Lowered the priority (nothing was closed) of: " + ", ".join(sorted(set(names))[:8]))
        return "ok", (f"{lowered} busy background program(s) now yield to what you are using" if lowered else "no background program was hogging the CPU")

    def s_cpu_opt(self):
        cmds = [["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "CPMINCORES", "100"],      # un-park every core (plugged in only)
                ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR", "PERFBOOSTMODE", "2"],      # aggressive turbo (plugged in only)
                ["powercfg", "/setactive", "SCHEME_CURRENT"]]
        good = sum(1 for c in cmds if _run(c, 20)[0])
        return ("ok" if good == len(cmds) else "warn"), "all cores un-parked and turbo boost on while plugged in (battery settings untouched)" if good == len(cmds) else f"{good}/{len(cmds)} power settings applied"

    def s_gpu_free(self):
        local = Path(os.environ.get("LOCALAPPDATA", ""))
        dirs = [local / "D3DSCache", local / "NVIDIA" / "DXCache", local / "NVIDIA" / "GLCache", local / "AMD" / "DxCache", local / "AMD" / "GLCache",
                local / "AMD" / "VkCache", local / "Intel" / "ShaderCache"]
        freed = files = 0
        for d in dirs:
            if not d.is_dir():
                continue
            for item in list(d.iterdir()):
                try:
                    if item.is_dir():
                        sz = sum(f.stat().st_size for f in item.rglob("*") if f.is_file())
                        shutil.rmtree(item, ignore_errors=False)
                    else:
                        sz = item.stat().st_size
                        item.unlink()
                    freed += sz
                    files += 1
                except Exception:
                    continue                                                    # in use by a running game - leave it
        return "ok", f"{freed / 1048576:.0f} MB of GPU shader caches cleared ({files} items); games rebuild them on next launch"

    def s_gpu_opt(self):
        import winreg
        path = r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as k:
                try:
                    cur, _ = winreg.QueryValueEx(k, "HwSchMode")
                except FileNotFoundError:
                    return "skip", "this GPU/driver does not offer hardware-accelerated GPU scheduling"
                if cur == 2:
                    return "ok", "hardware-accelerated GPU scheduling is already on"
                winreg.SetValueEx(k, "HwSchMode", 0, winreg.REG_DWORD, 2)
                self.restart_needed = True
                return "ok", "hardware-accelerated GPU scheduling turned on (takes effect after a restart)"
        except PermissionError:
            return "warn", "needs administrator rights"
        except OSError as exc:
            return "warn", str(exc)[:100]

    def s_tweaks(self):
        if not self.tweaks:
            return "skip", "no tweaks chosen"
        from modules.debloat.operations import apply_features
        r = apply_features(self.tweaks, create_restore=False)
        self.restart_needed = True
        note = f"{r.applied} tweak(s) applied"
        if r.failed:
            note += f", {len(r.failed)} failed: {', '.join(r.failed[:3])}"
        return ("ok" if r.applied else "warn"), note

    def s_recall(self):
        from modules.debloat.operations import apply_features
        r = apply_features(["recall"], create_restore=False)
        self.restart_needed = True
        return ("ok", "Recall disabled") if r.applied else ("warn", "Recall could not be disabled: " + (r.message or "see log"))

    def s_extras(self):
        done = []
        try:
            from modules.system import winutil as wu
            r = wu.clear_update_cache()
            done.append(f"update cache ({r.mb_freed:.0f} MB)")
        except Exception as exc:
            self.log(f"    update cache: {exc}")
        self._check()
        if _ps("Clear-RecycleBin -Force -ErrorAction SilentlyContinue", 90)[0]:
            done.append("recycle bin")
        self._check()
        self.log("    Cleaning superseded Windows update files (component store)…")
        if _run(["dism", "/Online", "/Cleanup-Image", "/StartComponentCleanup"], 1800)[0]:
            done.append("component store")
        self._check()
        try:
            from modules.system import winutil as wu
            wu.enable_ntp_sync()
            done.append("clock sync")
        except Exception as exc:
            self.log(f"    clock sync: {exc}")
        return ("ok" if done else "warn"), ", ".join(done) if done else "nothing could be done"

    def s_dism(self):
        from modules.system import winutil as wu
        r = wu.run_dism()
        return ("ok", "component store is healthy") if r.success else ("warn", "DISM reported a problem (needs internet) - see the log")

    def s_sfc(self):
        from modules.system import winutil as wu
        r = wu.run_sfc()
        return ("ok", "system files checked/repaired") if r.success else ("warn", "SFC found files it could not repair - see C:\\Windows\\Logs\\CBS\\CBS.log")

    def s_cpu_repair(self):
        from modules.system import winutil as wu
        r = wu.repair_high_cpu_power_config()
        return ("ok", "processor idle states re-enabled") if r.success else ("warn", "some power settings were refused")

    def s_power(self):
        from modules.system import power_modes as pm
        ok, evidence = pm.ensure_mode(self.power, self.log)         # switches, reads it back from Windows, retries if it did not stick
        return ("ok", f"{self.power.title()} Performance is the active power plan (checked)") if ok else ("warn", f"could not confirm it: {evidence}"[:200])

    def s_gpu_apps(self):
        from modules.system import gpu_prefs
        self.log("    listing installed programs and Store apps...")
        r = gpu_prefs.set_all_high_performance(lambda m: self.log("    " + m))
        if not r["total"]:
            return "warn", "found no apps to set (the app list could not be read)"
        note = f"{r['changed']} app(s) switched to High performance, {r['already']} already were (of {r['total']})"
        return ("ok", note) if not r["failed"] else ("warn", f"{note}; {r['failed']} refused")

    def s_visual(self):
        from modules.system import visual_effects as vfx
        r = vfx.apply(self.visual["mode"], self.visual["fx"])
        self.log("    " + vfx.describe(self.visual["mode"], self.visual["fx"]))
        self.log("    " + r["message"])
        return ("ok", vfx.describe(self.visual["mode"], self.visual["fx"])) if r["ok"] else ("warn", r["message"][:200])

    def s_network(self):
        from modules.system import winutil as wu
        r = wu.reset_network_stack()
        self.restart_needed = True
        return ("ok" if r.success else "warn"), "network stack reset (restart to finish)" if r.success else "some network resets failed - see the log"
