r"""
modules/oneclick/sysopt.py - the "System optimizations" part of the DWUT 1 CLICK BUTTON.

Everything The Beard of Knowledge's TBOK Windows Optimizer (v1.6.2) changes is available here as an individual switch, so the 1 Click
does what TBOK does - and the user can still turn any single piece off.  Settings and values follow TBOK's script one-to-one
(see backend/vendor/tbok); the differences are deliberate and small:

  * Xbox services are never touched (DWUT's 1 Click never changes anything Xbox).
  * Visual effects are NOT changed here - DWUT's own "Visual effects" popup (Performance Options) already owns them.
  * HAGS / Ultimate power plan / Recall policy-off are already separate automatic DWUT steps, so they are not repeated.
  * Per-user settings are applied exactly like TBOK: every loaded user hive, every offline profile (NTUSER.DAT) and the Default
    profile (so accounts created later get them too).

Each item is a dict: key, group, name, desc, default, plus ONE payload kind:
    machine : list of (subkey_under_HKLM, value_name, type, data)
    user    : list of ops applied to every user hive: ("set", sub, name, type, data) | ("delkey", sub) | ("delval", sub, name) | ("key", sub)
    svc     : {service_name: start_mode}   start_mode in auto | delayed-auto | demand | disabled
    tasks   : list of "\\Task\\Folder\\|TaskName"
    appx    : list of (wildcard_pattern, friendly_name)
    fn      : name of a function in this module (custom logic)
Items may carry win11=True (hidden on Windows 10) and desktop=True (only applied when the chassis is a desktop).
"""
from __future__ import annotations

import gc
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable

from core.logger import get_logger

_log = get_logger(__name__)
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# ── groups = the steps shown in the progress list, in run order ───────────────────────────────────────────────
GROUPS = [
    ("startup", "Startup, boot and memory (TBOK)"),
    ("services", "Services tuning (TBOK)"),
    ("system", "System-wide registry improvements (TBOK)"),
    ("bloat", "Bloat removal and wasteful scheduled tasks (TBOK)"),
    ("user", "Per-user settings - every user + new accounts (TBOK)"),
    ("gaming", "Gaming improvements (TBOK)"),
    ("winget", "Update installed apps with WinGet (TBOK)"),
]
GROUP_TITLES = {
    "startup": "Startup, boot and memory", "services": "Services", "system": "System-wide registry", "bloat": "Bloat removal and scheduled tasks",
    "user": "Per-user settings (applied to every user and to new accounts)", "gaming": "Gaming improvements", "winget": "App updates",
}

_ADV = r"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
_CDM = r"SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"
_MM = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
_EDGE = r"Software\Policies\Microsoft\Edge"
_DC = r"Software\Policies\Microsoft\Windows\DataCollection"
_FM = r"SYSTEM\{cs}\Control\FeatureManagement\Overrides\8\1694661260"


def _both(template: str, name: str, typ: str, data):
    """The same machine value under CurrentControlSet and ControlSet001 (TBOK writes both)."""
    return [(template.format(cs="CurrentControlSet"), name, typ, data), (template.format(cs="ControlSet001"), name, typ, data)]


def _office(name_fmt: str, value: str, data, versions=("15.0", "16.0")):
    return [("set", name_fmt.format(v=v), value, "dword", data) for v in versions]


ITEMS: list[dict] = [
    # ── Startup, boot, memory ──────────────────────────────────────────────────────────────────────────────────
    dict(key="hibernation", group="startup", name="Hibernation / Fast Startup by PC type", default=True, fn="hibernation",
         desc="Desktop: hibernation + Fast Startup OFF (updates install properly, uptime is honest). Laptop/tablet: ON (a flat battery still saves your work). Unknown PC type: left alone."),
    dict(key="f8_menu", group="startup", name="Restore the F8 boot menu", default=True, fn="f8_menu",
         desc="bcdedit bootmenupolicy legacy - the old F8 Advanced Boot Options. Note: with BitLocker on, F8 will ask for the recovery key."),
    dict(key="virtual_memory", group="startup", name="Virtual memory (page file) sizing", default=True, fn="virtual_memory",
         desc="Under 32 GB RAM: a fixed 4 GB minimum page file (max 8/16/24 GB by RAM) so Windows never lags while growing it. 32 GB+: Windows manages it. Takes effect after a restart."),
    dict(key="svchost_split", group="startup", name="Service host grouping by installed RAM", default=True, fn="svchost_split",
         desc="Sets SvcHostSplitThresholdInKB to your RAM + 256 MB. Only changes how services are grouped into processes."),
    # ── Services ───────────────────────────────────────────────────────────────────────────────────────────────
    dict(key="svc_disable", group="services", name="Disable unused services", default=True,
         svc={"AppVClient": "disabled", "NetTcpPortSharing": "disabled", "DialogBlockingService": "disabled", "DiagTrack": "disabled",
              "UevAgentService": "disabled", "ssh-agent": "disabled"},
         desc="App-V client, Net.Tcp port sharing, dialog blocking, telemetry (DiagTrack), User Experience Virtualization, OpenSSH agent."),
    dict(key="sysmain", group="services", name="SysMain (Superfetch) by RAM and drive type", default=True, fn="sysmain",
         desc="SSD/NVMe: disabled. Hard disk with under 12 GB RAM: disabled; 12 GB+: on demand. RAID / unknown storage: left alone."),
    dict(key="svc_manual", group="services", name="Non-critical services to Manual (on demand)", default=True, fn="svc_manual",
         desc="About 130 services that only need to run when something asks for them (Bluetooth support, Fax, Remote Access, Volume Shadow Copy...). They still work when needed. Services you already disabled stay disabled. No Xbox services are touched."),
    dict(key="svc_auto", group="services", name="Make sure essential services start automatically", default=True, fn="svc_auto",
         desc="Audio, Themes, Event Log, DHCP, Wi-Fi, Print Spooler, Windows Management and friends - fixes the damage other 'optimizer' tools do."),
    dict(key="svc_delayed", group="services", name="Less essential services to Delayed start", default=True,
         svc={"BITS": "delayed-auto", "W32Time": "delayed-auto", "WSearch": "delayed-auto", "wudfsvc": "delayed-auto"},
         desc="Background Intelligent Transfer, Windows Time, Windows Search and the driver framework start a minute after boot."),
    # ── System-wide registry ───────────────────────────────────────────────────────────────────────────────────
    dict(key="net_throttle", group="system", name="Disable network throttling", default=True,
         machine=[(r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile", "NetworkThrottlingIndex", "dword", 0xFFFFFFFF)],
         desc="Stops Windows capping network throughput while multimedia is playing."),
    dict(key="irp_stack", group="system", name="Better IRP stack size (network)", default=True,
         machine=_both(r"SYSTEM\{cs}\Services\LanmanServer\Parameters", "IRPStackSize", "dword", 30),
         desc="IRPStackSize 30 (Windows default is 15; do not go above 32). Smoother file sharing on modern networks."),
    dict(key="responsiveness", group="system", name="System responsiveness 10", default=True,
         machine=[(r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile", "SystemResponsiveness", "dword", 10)],
         desc="10 is the documented optimum (0 is silently clamped to 20)."),
    dict(key="shutdown_speed", group="system", name="Faster shutdown", default=True,
         machine=_both(r"SYSTEM\{cs}\Control", "WaitToKillServiceTimeout", "sz", "5000"),
         desc="Services get 5 seconds to stop instead of 20 before Windows ends them."),
    dict(key="long_paths", group="system", name="Enable long file paths", default=True,
         machine=_both(r"SYSTEM\{cs}\Control\FileSystem", "LongPathsEnabled", "dword", 1),
         desc="Paths longer than 260 characters work in apps that support it."),
    dict(key="companion_sw", group="system", name="Block hardware 'companion software' downloads", default=True,
         machine=[(r"SOFTWARE\Policies\Microsoft\Windows\Device Metadata", "PreventDeviceMetadataFromNetwork", "dword", 1)],
         desc="Stops Windows installing vendor add-on apps when a device is plugged in."),
    dict(key="search_webview", group="system", name="Classic Windows Search (no WebView)", default=True,
         machine=sum([_both(_FM, n, "dword", v) for n, v in (("EnabledState", 1), ("EnabledStateOptions", 0), ("Variant", 0), ("VariantPayload", 0), ("VariantPayloadKind", 0))], []),
         desc="Puts Search back into the classic, lighter mode."),
    dict(key="telemetry", group="system", name="Turn off telemetry", default=True,
         machine=[(r"Software\Policies\Microsoft\Windows\DataCollection", "AllowDesktopAnalyticsProcessing", "dword", 0),
                  (r"Software\Policies\Microsoft\Windows\DataCollection", "AllowTelemetry", "dword", 0),
                  (r"Software\Policies\Microsoft\Windows\DataCollection", "DoNotShowFeedbackNotifications", "dword", 1),
                  (r"Software\Policies\Microsoft\Windows\DataCollection", "DiagTrack", "dword", 0),
                  (r"Software\Policies\Microsoft\Windows\DataCollection", "LimitEnhancedDiagnosticDataWindowsAnalytics", "dword", 1),
                  (r"SOFTWARE\Wow6432Node\Policies\Microsoft\Windows\DataCollection", "AllowTelemetry", "dword", 0),
                  (r"SYSTEM\CurrentControlSet\Control\WMI\AutoLogger\Diagtrack-Listener", "Start", "dword", 0),
                  (r"SYSTEM\ControlSet001\Services\DiagTrack", "Start", "dword", 4), (r"SYSTEM\CurrentControlSet\Services\DiagTrack", "Start", "dword", 4),
                  (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection", "AllowTelemetry", "dword", 0),
                  (r"SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo", "DisabledByGroupPolicy", "dword", 1),
                  (r"SOFTWARE\Policies\Microsoft\Windows\WindowsAI", "DisableAIDataAnalysis", "dword", 1)],
         desc="Windows data collection policies, the DiagTrack service and logger, advertising-ID policy, PowerShell/AI data analysis."),
    dict(key="do_wer", group="system", name="Delivery Optimization (P2P) and Error Reporting off", default=True,
         machine=[(r"SOFTWARE\Microsoft\Windows\Windows Error Reporting", "Disabled", "dword", 1),
                  (r"SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config", "DODownloadMode", "dword", 0),
                  (r"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization", "DODownloadMode", "dword", 0)],
         desc="No uploading Windows updates to other PCs, no crash-report uploads."),
    dict(key="oobe", group="system", name="Skip the privacy / setup experience for new users", default=True,
         machine=[(r"SOFTWARE\Policies\Microsoft\Windows\OOBE", n, "dword", v) for n, v in
                  (("DisablePrivacyExperience", 1), ("BypassNRO", 1), ("SkipMachineOOBE", 1), ("DisableVoice", 1), ("PrivacyConsentStatus", 1), ("Protectyourpc", 3), ("HideEULAPage", 1))],
         desc="New accounts go straight to the desktop. Also allows offline-account setup (BypassNRO)."),
    dict(key="wpbt", group="system", name="Disable WPBT (vendor code at boot)", default=True,
         machine=[(r"SYSTEM\CurrentControlSet\Control\Session Manager", "DisableWpbtExecution", "dword", 1), (r"SYSTEM\CurrentControlSet\Control\FirmwareResources", "WPBT", "binary", b"\x00"),
                  (r"SYSTEM\ControlSet001\Control\Session Manager", "DisableWpbtExecution", "dword", 1), (r"SYSTEM\ControlSet001\Control\FirmwareResources", "WPBT", "binary", b"\x00")],
         desc="Stops PC makers' firmware from silently running programs inside Windows at boot."),
    dict(key="ndu", group="system", name="Fix the Network Data Usage graph", default=True,
         machine=_both(r"SYSTEM\{cs}\Services\Ndu", "Start", "dword", 2), desc="Re-enables the Ndu service so Settings > Network > Data usage works."),
    dict(key="edge", group="system", name="Edge: no background start, no first-run, no shopping ads", default=True,
         machine=[(r"Software\Policies\Microsoft\Edge", n, "dword", v) for n, v in
                  (("StartupBoostEnabled", 0), ("BackgroundModeEnabled", 0), ("HideFirstRunExperience", 1), ("UserFeedbackAllowed", 0), ("EdgeShoppingAssistantEnabled", 0), ("GamerModeEnabled", 1), ("DiagnosticData", 0))],
         desc="Edge stops starting with Windows and running after you close it, drops its first-run page, feedback and shopping assistant, and uses Efficiency Mode for games."),
    dict(key="recall_policy", group="system", name="Stop Recall being enabled later", default=True, win11=True,
         machine=[(r"SOFTWARE\Policies\Microsoft\Windows\WindowsAI", "AllowRecallEnablement", "dword", 0)],
         desc="Policy that stops Windows Recall from being switched on by an update."),
    dict(key="verbose_logon", group="system", name="Verbose logon / logoff messages", default=True,
         machine=[(r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", "VerboseStatus", "dword", 1)],
         desc="Shows what Windows is actually doing instead of 'Please wait'."),
    # ── Bloat + tasks ──────────────────────────────────────────────────────────────────────────────────────────
    dict(key="b_copilot", group="bloat", name="Remove Windows Copilot (not M365 Copilot)", default=True, fn="b_copilot",
         desc="Turns it off by policy, removes the Microsoft.Copilot app for all users and the provisioned copy, and blocks it coming back."),
    dict(key="b_bing", group="bloat", name="Remove Bing Search package", default=True, appx=[("*Microsoft.BingSearch*", "Microsoft Bing Search")],
         desc="Removes the Bing Search app for all users and from new accounts."),
    dict(key="b_widgets", group="bloat", name="Remove taskbar Widgets (runs a whole browser in RAM)", default=True, fn="b_widgets",
         desc="Stops the Widgets processes and removes the Widgets Platform Runtime and Web Experience packages for all users."),
    dict(key="t_office", group="bloat", name="Disable Office telemetry scheduled tasks", default=True,
         tasks=[r"\Microsoft\Office\|OfficeTelemetryAgent", r"\Microsoft\Office\|OfficeTelemetryAgentFallBack", r"\Microsoft\Office\|OfficeTelemetryAgentLogon",
                r"\Microsoft\Office\|OfficeTelemetryAgentFallBack2016", r"\Microsoft\Office\|OfficeTelemetryAgentLogOn2016"],
         desc="Only if Office 2013-2019 is installed - otherwise there is nothing to disable."),
    dict(key="t_windows", group="bloat", name="Disable wasteful Windows scheduled tasks", default=True,
         tasks=[r"\Microsoft\Windows\Application Experience\|Microsoft Compatibility Appraiser", r"\Microsoft\Windows\Autochk\|Proxy",
                r"\Microsoft\Windows\Customer Experience Improvement Program\|Consolidator", r"\Microsoft\Windows\Customer Experience Improvement Program\|UsbCeip",
                r"\Microsoft\Windows\DiskDiagnostic\|Microsoft-Windows-DiskDiagnosticDataCollector", r"\Microsoft\Windows\Feedback\Siuf\|DmClient",
                r"\Microsoft\Windows\Feedback\Siuf\|DmClientOnScenarioDownload", r"\Microsoft\Windows\Maps\|MapsUpdateTask", r"\Microsoft\Windows\Windows Error Reporting\|QueueReporting"],
         desc="Compatibility appraiser, CEIP, disk diagnostics data collector, feedback, maps updates, error-report queue."),
    # ── Per-user (all users + Default profile) ────────────────────────────────────────────────────────────────
    dict(key="u_explorer_speed", group="user", name="Faster Explorer: stop folder auto-discovery", default=True,
         user=[("delkey", r"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags"), ("delkey", r"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU"),
               ("set", r"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell", "FolderType", "sz", "NotSpecified")],
         desc="Resets saved folder views so Explorer stops re-detecting each folder's type (big folders open and save faster)."),
    dict(key="u_explorer_prefs", group="user", name="Explorer opens to This PC, detailed copy dialog", default=True,
         user=[("set", _ADV, "LaunchTo", "dword", 1), ("set", r"Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager", "EnthusiastMode", "dword", 1)],
         desc="File Explorer starts at This PC instead of Quick access; file operations show the detailed dialog."),
    dict(key="u_bg_apps", group="user", name="Stop apps running in the background", default=True,
         user=[("set", r"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications", "GlobalUserDisabled", "dword", 1)],
         desc="Store apps no longer run when closed."),
    dict(key="u_game_mode", group="user", name="Game Mode always on", default=True,
         user=[("set", r"Software\Microsoft\GameBar", "AutoGameModeEnabled", "dword", 1)],
         desc="Windows reduces background work while a game is in front. (This only turns Game Mode on - it does not touch Xbox.)"),
    dict(key="u_end_task", group="user", name="'End task' in the taskbar right-click menu", default=True,
         user=[("set", _ADV + r"\TaskbarDeveloperSettings", "TaskbarEndTask", "dword", 1), ("set", r"Control Panel\Desktop", "AutoEndTasks", "sz", "1")],
         desc="Right-click a stuck app on the taskbar and end it without opening Task Manager."),
    dict(key="u_classic_menu", group="user", name="Full right-click menu (no 'Show more options')", default=True, win11=True,
         user=[("key", r"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32")],
         desc="Windows 11 shows the complete classic context menu straight away."),
    dict(key="u_web_search", group="user", name="No web results in Start search", default=True,
         user=[("set", r"Software\Microsoft\Windows\CurrentVersion\Search", "BingSearchEnabled", "dword", 0)], desc="The Start menu searches only your PC."),
    dict(key="u_start_pins", group="user", name="More pins in the Start menu", default=True, user=[("set", _ADV, "Start_Layout", "dword", 1)],
         desc="Start shows more pinned apps and fewer recommendations."),
    dict(key="u_menu_delay", group="user", name="Faster menus (10 ms delay)", default=True,
         user=[("set", r"Control Panel\Desktop", "MenuShowDelay", "sz", "10")], desc="Windows waits 400 ms before opening menus by default."),
    dict(key="u_taskbar_icons", group="user", name="Tidy taskbar: no Task View, People, Meet Now; icon-only search", default=True,
         user=[("set", _ADV, "ShowTaskViewButton", "dword", 0), ("set", _ADV + r"\People", "PeopleBand", "dword", 0),
               ("set", r"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer", "HideSCAMeetNow", "dword", 1),
               ("set", r"Software\Microsoft\Windows\CurrentVersion\Search", "SearchboxTaskbarMode", "dword", 1)],
         desc="Removes buttons that duplicate Alt+Tab and Teams launchers, and shrinks the search box to an icon."),
    dict(key="u_taskbar_widgets", group="user", name="Taskbar: no Widgets, Chat or Copilot buttons", default=True,
         user=[("set", _ADV, "TaskbarAI", "dword", 0), ("set", _ADV, "ShowCopilotButton", "dword", 0), ("set", _ADV, "TaskbarMn", "dword", 0), ("set", _ADV, "TaskbarDa", "dword", 0)],
         desc="Hides the Widgets, Chat and Copilot taskbar buttons (Windows protects one of these on some builds - a refusal is normal)."),
    dict(key="u_ads_explorer", group="user", name="No ads in Explorer, search box and 'finish setup' nags", default=True,
         user=[("set", r"Software\Policies\Microsoft\Windows\Explorer", "DisableSearchBoxSuggestions", "dword", 1), ("set", _ADV, "ShowSyncProviderNotifications", "dword", 0),
               ("set", r"Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement", "ScoobeSystemSettingEnabled", "dword", 0)],
         desc="Search-box suggestions, sync-provider banners, 'Suggest ways to get the most out of Windows'."),
    dict(key="u_ads_lock", group="user", name="No lock screen tips and ads", default=True,
         user=[("set", _CDM, "RotatingLockScreenOverlayEnabled", "dword", 0)], desc="Spotlight overlay tips and ads on the lock screen."),
    dict(key="u_ads_content", group="user", name="No ads in Start, Settings, home and 'suggested apps'", default=True,
         user=[("set", _CDM, n, "dword", 0) for n in ("SubscribedContent-310093Enabled", "SubscribedContent-338387Enabled", "SubscribedContent-353694Enabled", "SubscribedContent-353696Enabled",
               "SystemPaneSuggestionsEnabled", "SubscribedContent-338388Enabled", "SubscribedContent-338389Enabled", "SubscribedContent-338393Enabled", "SubscribedContent-353698Enabled",
               "SilentInstalledAppsEnabled", "ContentDeliveryAllowed", "OemPreInstalledAppsEnabled", "PreInstalledAppsEnabled", "PreInstalledAppsEverEnabled")],
         desc="Welcome experience, settings ads, auto-installed suggested apps, tips, timeline suggestions, OEM / pre-installed app re-enabling."),
    dict(key="u_ads_tracking", group="user", name="No ad personalisation or tailored experiences", default=True,
         user=[("set", r"Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo", "Enabled", "dword", 0), ("set", r"SOFTWARE\Microsoft\Siuf\Rules", "NumberOfSIUFInPeriod", "dword", 0),
               ("delval", r"SOFTWARE\Microsoft\Siuf\Rules", "PeriodInNanoSeconds"), ("set", r"SOFTWARE\Policies\Microsoft\Windows\CloudContent", "DisableTailoredExperiencesWithDiagnosticData", "dword", 1),
               ("set", r"Software\Microsoft\Windows\CurrentVersion\Privacy", "TailoredExperiencesWithDiagnosticDataEnabled", "dword", 0)],
         desc="Advertising ID, diagnostic feedback frequency, tailored experiences with telemetry."),
    dict(key="u_feeds", group="user", name="No Windows Feeds, no Start recommendations ads", default=True,
         user=[("set", r"SOFTWARE\Policies\Microsoft\Windows\Windows Feeds", "EnableFeeds", "dword", 0), ("set", r"Software\Microsoft\Windows\CurrentVersion\Feeds", "ShellFeedsTaskbarViewMode", "dword", 2),
               ("set", _ADV, "Start_IrisRecommendations", "dword", 0)],
         desc="News and Interests feed and the Start menu's promoted recommendations."),
    dict(key="u_crossdevice", group="user", name="Disable Cross-Device Resume", default=True,
         user=[("set", r"Software\Microsoft\Windows\CurrentVersion\CrossDeviceResume\Configuration", "IsResumeAllowed", "dword", 0)],
         desc="Turn this OFF if you sync a phone to this PC (Phone Link): it is the 'continue on PC' feature."),
    dict(key="u_copilot", group="user", name="Copilot off for every user", default=True,
         user=[("set", r"Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", "dword", 1), ("set", _ADV, "ShowCopilotButton", "dword", 0),
               ("set", r"SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsCopilot", "AllowCopilotRuntime", "dword", 0)], desc="Per-user Copilot policy and button (standard Copilot, not M365)."),
    dict(key="u_office", group="user", name="Office logging, telemetry, CEIP and feedback off", default=True,
         user=(_office(r"SOFTWARE\Microsoft\Office\{v}\Outlook\Options\Mail", "EnableLogging", 0) + _office(r"SOFTWARE\Microsoft\Office\{v}\Outlook\Options\Calendar", "EnableCalendarLogging", 0)
               + _office(r"SOFTWARE\Microsoft\Office\{v}\Word\Options", "EnableLogging", 0) + _office(r"SOFTWARE\Policies\Microsoft\Office\{v}\OSM", "EnableLogging", 0)
               + _office(r"SOFTWARE\Policies\Microsoft\Office\{v}\OSM", "EnableUpload", 0)
               + [("set", r"SOFTWARE\Microsoft\Office\Common\ClientTelemetry", "DisableTelemetry", "dword", 1), ("set", r"SOFTWARE\Microsoft\Office\16.0\Common\ClientTelemetry", "DisableTelemetry", "dword", 1),
                  ("set", r"SOFTWARE\Microsoft\Office\Common\ClientTelemetry", "VerboseLogging", "dword", 0), ("set", r"SOFTWARE\Microsoft\Office\16.0\Common\ClientTelemetry", "VerboseLogging", "dword", 0)]
               + _office(r"SOFTWARE\Microsoft\Office\{v}\Common", "QMEnable", 0) + _office(r"SOFTWARE\Microsoft\Office\{v}\Common\Feedback", "Enabled", 0)),
         desc="Harmless if Office is not installed."),
    dict(key="u_visual_tbok", group="user", name="Lighter animations (TBOK visual effects)", default=True,
         user=[("set", r"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", "VisualFXSetting", "dword", 3), ("set", _ADV, "TaskbarAnimations", "dword", 0),
               ("set", _ADV, "ListviewAlphaSelect", "dword", 1), ("set", _ADV, "ListviewShadow", "dword", 1), ("set", r"Control Panel\Desktop", "DragFullWindows", "sz", "1"),
               ("set", r"Control Panel\Desktop\WindowMetrics", "MinAnimate", "sz", "0"), ("set", r"Control Panel\Keyboard", "KeyboardDelay", "sz", "0"),
               ("set", r"Software\Microsoft\Windows\DWM", "EnableAeroPeek", "dword", 0)],
         desc="Custom visual-effects mode: no taskbar / window animations, no Aero Peek, shortest keyboard delay. Skipped automatically when you pick your own visual effects in the Visual effects step."),
    dict(key="u_sticky", group="user", name="Disable the Sticky Keys shortcut", default=True,
         user=[("set", r"Control Panel\Accessibility\StickyKeys", "Flags", "sz", "58")], desc="Pressing Shift five times no longer pops up the Sticky Keys prompt."),
    # ── Gaming ─────────────────────────────────────────────────────────────────────────────────────────────────
    dict(key="g_hpet", group="gaming", name="Reset HPET detection", default=True, fn="g_hpet",
         desc="Removes a forced 'useplatformclock' boot setting so Windows re-detects the High Precision Event Timer on the next boot."),
    dict(key="g_windowed", group="gaming", name="Optimizations for windowed games", default=True,
         machine=[(r"SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR\Graphics", "OptimizationsForWindowedGames", "dword", 1)], desc="Better frame timing for windowed / borderless games."),
    dict(key="g_mmcs", group="gaming", name="Multimedia scheduler for games and audio", default=True,
         machine=[(_MM + r"\Tasks\Games", "SystemResponsiveness", "dword", 10), (_MM + r"\Tasks\Games", "Priority", "dword", 6), (_MM + r"\Tasks\Games", "Scheduling Category", "sz", "Medium"),
                  (_MM + r"\Tasks\Games", "Latency Sensitive", "sz", "True"), (_MM + r"\Tasks\Audio", "Priority", "dword", 6), (_MM + r"\Tasks\Audio", "Scheduling Category", "sz", "Medium"),
                  (_MM + r"\Tasks\Audio", "Latency Sensitive", "sz", "True")],
         desc="Microsoft-documented MMCS values: games and audio get steady CPU scheduling."),
    dict(key="g_power_throttle", group="gaming", name="Disable power throttling (desktops only)", default=True, desktop=True,
         machine=[(r"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", "PowerThrottlingOff", "dword", 1), (r"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", "NoLazyMode", "dword", 0),
                  (r"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", "AlwaysOn", "dword", 0)],
         desc="Skipped automatically on laptops and tablets."),
    # ── WinGet ─────────────────────────────────────────────────────────────────────────────────────────────────
    dict(key="winget_update", group="winget", name="Update all installed apps with WinGet", default=False, fn="winget_update",
         desc="Installs/updates the WinGet client, then updates every app it can (silent). Can take a long time and may restart apps - OFF by default."),
]
ITEMS_BY_KEY = {i["key"]: i for i in ITEMS}

# ── big static lists (verbatim from TBOK, minus the four Xbox services) ────────────────────────────────────────
SERVICES_MANUAL = (
    "ALG AppMgmt AppReadiness Appinfo AssignedAccessManagerSvc AxInstSV BDESVC BTAGService bthserv CertPropSvc cloudidsvc COMSysApp CscService DcpSvc dcsvc defragsvc DevQueryBroker "
    "DeviceAssociationService DeviceInstall diagnosticshub.standardcollector.service diagsvc DisplayEnhancementService DmEnrollmentSvc dmwappushservice dot3svc fdPHost fhsvc hidserv icssvc "
    "EapHost edgeupdate edgeupdatem EFS FDResPub Fax FrameServer FrameServerMonitor GraphicsPerfSvc HvHost IEEtwCollectorService IKEEXT IpxlatCfgSvc lfsvc lltdsvc lmhosts LxpSvc "
    "McpManagementService MicrosoftEdgeElevationService MixedRealityOpenXRSvc MSDTC MsKeyboardFilter MSiSCSI NaturalAuthentication NcaSvc NcbService NcdAutoSetup NetSetupSvc Netman p2pimsvc "
    "p2psvc PcaSvc PeerDistSvc perceptionsimulation PerfHost PhoneSvc pla PlugPlay PNRPAutoReg PNRPsvc PolicyAgent PrintNotify PushToInstall QWAVE RasAuto RasMan RetailDemo RmSvc RpcLocator "
    "SCPolicySvc ScDeviceEnum SCardSvr SDRSVC seclogon SEMgrSvc SensorDataService SensorService SensrSvc SharedAccess SharedRealitySvc shpamsvc SmsRouter smphost SNMPTrap spectrum SstpSvc "
    "StiSvc StorSvc svsvc swprv TabletInputService TapiSrv TieringEngineService TimeBroker TroubleshootingSvc tzautoupdate UI0Detect upnphost VacSvc vds vmicguestinterface vmicheartbeat "
    "vmickvpexchange vmicshutdown vmictimesync vmicvmsession vmicvss VSS WalletService wbengine WcsPlugInService wcncsvc WdiServiceHost WdiSystemHost WebClient Wecsvc wercplsupport WEPHOSTSVC "
    "WerSvc WFDSConMgrSvc WiaRpc wisvc wlidsvc wlpasvc wmiApSrv WMPNetworkSvc WManSvc WPDBusEnum WpcMonSvc workfolderssvc wuauserv").split()
SERVICES_AUTO = (
    "AudioEndpointBuilder AudioSrv BthHFSrv CryptSvc DPS Dhcp DispBrokerDesktopSvc dusmsvc EventLog EventSystem FontCache iphlpsvc LanmanServer LanmanWorkstation nsi Power ProfSvc SENS SamSs "
    "ShellHWDetection Spooler Themes tiledatamodelsvc TrkWks uhssvc UserManager Wcmsvc Winmgmt WlanSvc").split()
XBOX_SERVICES = {"XblAuthManager", "XblGameSave", "XboxGipSvc", "XboxNetApiSvc"}           # never touched, even if someone edits the lists above
assert not (set(SERVICES_MANUAL) | set(SERVICES_AUTO)) & XBOX_SERVICES


# ── helpers ───────────────────────────────────────────────────────────────────────────────────────────────────
def _run(cmd, timeout: int = 120) -> tuple[bool, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WINDOW, errors="replace", stdin=subprocess.DEVNULL)
        return r.returncode == 0, ((r.stdout or "") + (r.stderr or "")).strip()
    except subprocess.TimeoutExpired:
        return False, f"timed out after {timeout}s"
    except Exception as exc:                                                          # noqa: BLE001
        return False, str(exc)


def _ps(script: str, timeout: int = 120) -> tuple[bool, str]:
    return _run(["powershell", "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script], timeout)


def _log_lines(log: Callable[[str], None], text: str, limit: int = 40) -> None:
    for ln in [l.rstrip() for l in (text or "").splitlines() if l.strip()][:limit]:
        log("      " + ln[:200])


_chassis_cache: list[str] = []


def chassis_type() -> str:
    """'Laptop' | 'Desktop' | 'Unknown' - the same enclosure-type test TBOK uses."""
    if _chassis_cache:
        return _chassis_cache[0]
    ok, out = _ps("$ct=@((Get-CimInstance -ClassName Win32_SystemEnclosure -ErrorAction SilentlyContinue).ChassisTypes); "
                  "if($null -ne ($ct -as [array])){if($ct -match '^(8|9|10|11|12|14|18|21|30|31|32)$'){'Laptop'}"
                  "elseif($ct -match '^(3|4|5|6|7|13|15|16|24|35|36)$'){'Desktop'}else{'Unknown'}}else{'Unknown'}", 30)
    word = (out.strip().splitlines() or ["Unknown"])[-1].strip() if ok else "Unknown"
    _chassis_cache.append(word if word in ("Laptop", "Desktop") else "Unknown")
    return _chassis_cache[0]


def _ram_kb() -> int:
    ok, out = _ps("$t=(Get-CimInstance Win32_PhysicalMemory -ErrorAction Stop | Measure-Object Capacity -Sum).Sum; if($t){[int64]($t/1KB)}", 30)
    try:
        return int((out.strip().splitlines() or ["0"])[-1]) if ok else 0
    except ValueError:
        return 0


def available_items(is_win11: bool) -> list[dict]:
    """The catalog for this Windows version, as plain data for the popup."""
    return [{"key": i["key"], "group": i["group"], "name": i["name"], "desc": i["desc"], "default": bool(i.get("default")), "desktop": bool(i.get("desktop")),
             "group_title": GROUP_TITLES[i["group"]]} for i in ITEMS if is_win11 or not i.get("win11")]


# ── registry writers ──────────────────────────────────────────────────────────────────────────────────────────
def _type(winreg, typ: str):
    return {"dword": winreg.REG_DWORD, "sz": winreg.REG_SZ, "binary": winreg.REG_BINARY}[typ]


def _write(root, sub: str, name: str, typ: str, data) -> None:
    import winreg
    with winreg.CreateKeyEx(root, sub, 0, winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as k:
        winreg.SetValueEx(k, name, 0, _type(winreg, typ), data)


def apply_machine(ops, log: Callable[[str], None]) -> tuple[int, int]:
    import winreg
    ok = bad = 0
    for sub, name, typ, data in ops:
        try:
            _write(winreg.HKEY_LOCAL_MACHINE, sub, name, typ, data)
            ok += 1
        except OSError as exc:
            bad += 1
            log(f"      could not set HKLM\\{sub} [{name}]: {exc}")
    return ok, bad


def _apply_user_ops(root_sub: str, ops, log: Callable[[str], None]) -> tuple[int, int]:
    """root_sub = 'S-1-5-21-...' (loaded) or 'DWUT_TMP' (a mounted NTUSER.DAT), both under HKEY_USERS."""
    import winreg
    ok = bad = 0
    for op in ops:
        kind = op[0]
        try:
            if kind == "set":
                _write(winreg.HKEY_USERS, f"{root_sub}\\{op[1]}", op[2], op[3], op[4])
            elif kind == "key":                                              # create the key and give it an empty default value
                with winreg.CreateKeyEx(winreg.HKEY_USERS, f"{root_sub}\\{op[1]}", 0, winreg.KEY_SET_VALUE | winreg.KEY_WOW64_64KEY) as k:
                    winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "")
            elif kind == "delkey":
                _run(["reg.exe", "delete", f"HKU\\{root_sub}\\{op[1]}", "/f"], 30)           # absent key = nothing to do
            elif kind == "delval":
                _run(["reg.exe", "delete", f"HKU\\{root_sub}\\{op[1]}", "/v", op[2], "/f"], 30)
            ok += 1
        except OSError as exc:
            bad += 1
            log(f"      {kind} {op[1]}: {exc}")
    return ok, bad


def _loaded_user_sids() -> dict[str, str]:
    """{sid: profile path} for every user hive currently loaded (real accounts only)."""
    import winreg
    out: dict[str, str] = {}
    try:
        with winreg.OpenKey(winreg.HKEY_USERS, "") as k:
            i = 0
            while True:
                try:
                    sid = winreg.EnumKey(k, i)
                except OSError:
                    break
                i += 1
                if (sid.startswith("S-1-5-21-") or sid.startswith("S-1-12-1-")) and not sid.endswith("_Classes"):
                    out[sid] = ""
    except OSError:
        pass
    for sid in list(out):
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\{sid}") as pk:
                out[sid] = os.path.normcase(os.path.expandvars(str(winreg.QueryValueEx(pk, "ProfileImagePath")[0])))
        except OSError:
            continue
    return out


def _mount(hive_name: str, dat: Path, log) -> bool:
    _run(["reg.exe", "unload", f"HKU\\{hive_name}"], 20)                             # a leftover mount from a crashed run
    ok, out = _run(["reg.exe", "load", f"HKU\\{hive_name}", str(dat)], 30)
    if not ok:
        log(f"      could not load {dat}: {out.splitlines()[-1][:120] if out else 'unknown error'}")
    return ok


def _unmount(hive_name: str, log) -> None:
    gc.collect()                                                                      # drop every open handle before unloading
    for _ in range(5):
        if _run(["reg.exe", "unload", f"HKU\\{hive_name}"], 20)[0]:
            return
        time.sleep(0.6)
        gc.collect()
    log(f"      WARNING: could not unload HKU\\{hive_name} - Windows will release it at the next restart")


def apply_user_everywhere(ops, log: Callable[[str], None]) -> tuple[int, int, int]:
    """Apply per-user ops to every loaded user, every offline profile, and the Default profile.  Returns (ok, bad, profiles_touched)."""
    ok = bad = profiles = 0
    loaded = _loaded_user_sids()
    for sid in loaded:
        a, b = _apply_user_ops(sid, ops, log)
        ok, bad, profiles = ok + a, bad + b, profiles + 1
        log(f"    user {sid}: {a} setting(s)")
    users_dir = Path(os.environ.get("SystemDrive", "C:") + "\\") / "Users"
    loaded_paths = {p for p in loaded.values() if p}
    skip = {"public", "default", "default user", "all users"}
    try:
        profile_dirs = [d for d in users_dir.iterdir() if d.is_dir() and d.name.lower() not in skip]
    except OSError:
        profile_dirs = []
    for d in profile_dirs:
        dat = d / "NTUSER.DAT"
        if not dat.is_file() or os.path.normcase(str(d)) in loaded_paths:
            continue
        if _mount("DWUT_TMP", dat, log):
            try:
                a, b = _apply_user_ops("DWUT_TMP", ops, log)
                ok, bad, profiles = ok + a, bad + b, profiles + 1
                log(f"    profile {d.name}: {a} setting(s)")
            finally:
                _unmount("DWUT_TMP", log)
    default_dat = users_dir / "Default" / "NTUSER.DAT"
    if default_dat.is_file():
        if _mount("DWUT_DEFAULT", default_dat, log):
            try:
                a, b = _apply_user_ops("DWUT_DEFAULT", ops, log)
                ok, bad, profiles = ok + a, bad + b, profiles + 1
                log(f"    Default profile (new accounts): {a} setting(s)")
            finally:
                _unmount("DWUT_DEFAULT", log)
    else:
        log("    WARNING: the Default profile's NTUSER.DAT was not found - new accounts will not get these settings.")
    return ok, bad, profiles


# ── services / tasks / appx ───────────────────────────────────────────────────────────────────────────────────
_START = {2: "auto", 3: "demand", 4: "disabled"}


def _service_mode(name: str):
    """(current_mode, exists) read straight from the registry (delayed start is Start=2 + DelayedAutoStart=1)."""
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, rf"SYSTEM\CurrentControlSet\Services\{name}", 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
            start = int(winreg.QueryValueEx(k, "Start")[0])
            try:
                delayed = int(winreg.QueryValueEx(k, "DelayedAutoStart")[0])
            except OSError:
                delayed = 0
    except OSError:
        return None
    mode = _START.get(start, f"start={start}")
    return "delayed-auto" if mode == "auto" and delayed == 1 else mode


def _backup_dir() -> Path:
    d = Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT" / "Backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def apply_services(plan: dict[str, str], log: Callable[[str], None], check: Callable[[], None]) -> tuple[int, int]:
    """plan = {service: mode}.  Returns (changed_or_ok, failed).  Disabled services are never re-enabled to 'demand' (same rule as TBOK)."""
    plan = {n: m for n, m in plan.items() if n not in XBOX_SERVICES}
    before = {}
    for name in plan:
        cur = _service_mode(name)
        if cur is not None:
            before[name] = cur
    try:                                                                              # a snapshot so the changes can be undone by hand
        if len(plan) < 2:
            raise OSError("single-service plan: no snapshot needed")
        snap = _backup_dir() / f"services-before-{time.strftime('%Y%m%d-%H%M%S')}.json"
        snap.write_text(json.dumps(before, indent=1), encoding="utf-8")
        log(f"    Saved the old service start modes to {snap}")
    except OSError:
        pass
    changed = already = missing = preserved = failed = 0
    for name, want in plan.items():
        check()
        cur = before.get(name)
        if cur is None:
            missing += 1
            continue
        if cur == "disabled" and want == "demand":
            preserved += 1
            continue
        if cur == want:
            already += 1
            continue
        ok, out = _run(["sc.exe", "config", name, "start=", want], 30)
        if ok:
            changed += 1
            log(f"    {name}: {cur} -> {want}")
        else:
            failed += 1
            log(f"    FAILED {name} ({cur} -> {want}): {out.splitlines()[-1][:100] if out else ''}")
    log(f"    Services: {changed} changed, {already} already right, {preserved} kept disabled, {missing} not installed, {failed} failed")
    return changed + already + preserved, failed


def disable_tasks(entries: list[str], log: Callable[[str], None]) -> tuple[int, int]:
    plan = ",".join("'" + e.replace("'", "''") + "'" for e in entries)
    script = (f"$plan=@({plan}); $ok=0;$bad=0; foreach($e in $plan){{ $p,$n=$e.Split('|',2); $t=@(Get-ScheduledTask -TaskPath $p -TaskName $n -ErrorAction SilentlyContinue); "
              "if($t.Count -eq 0){ 'SKIPPED: not found ' + $p + $n; continue }; foreach($x in $t){ if($x.State -eq 'Disabled'){ 'SKIPPED: already disabled ' + $x.TaskPath + $x.TaskName; $ok++ } "
              "else { try { $x | Disable-ScheduledTask -ErrorAction Stop | Out-Null; 'DISABLED: ' + $x.TaskPath + $x.TaskName; $ok++ } catch { 'FAILED: ' + $x.TaskPath + $x.TaskName + ' - ' + $_.Exception.Message; $bad++ } } } }; "
              "'RESULT ' + $ok + ' ' + $bad")
    ok, out = _ps(script, 180)
    _log_lines(log, out)
    last = [l for l in out.splitlines() if l.startswith("RESULT ")]
    if ok and last:
        _, a, b = last[-1].split()
        return int(a), int(b)
    return 0, len(entries)


def remove_appx(pattern: str, label: str, log: Callable[[str], None]) -> bool:
    """Remove an app for every user AND from the provisioning list (so new accounts never get it).  Same approach as TBOK's RemoveAppxPattern."""
    pat = pattern.replace("'", "''")
    script = (f"$pattern='{pat}'; $fail=0; try {{ $cur=@(Get-AppxPackage -Name $pattern -ErrorAction Stop) }} catch {{ 'ERROR: query failed: ' + $_.Exception.Message; $fail++; $cur=@() }}; "
              "if($cur.Count -eq 0){ 'SKIPPED: not installed for this account' } else { $all=$true; try { $pk=@(Get-AppxPackage -AllUsers -Name $pattern -ErrorAction Stop) } catch { $all=$false; $pk=$cur; 'WARNING: all-user query failed, using this account only' }; "
              "foreach($p in $pk){ try { if($all){ Remove-AppxPackage -Package $p.PackageFullName -AllUsers -ErrorAction Stop } else { Remove-AppxPackage -Package $p.PackageFullName -ErrorAction Stop }; 'REMOVED: ' + $p.PackageFullName } catch { 'ERROR: ' + $p.PackageFullName + ' - ' + $_.Exception.Message; $fail++ } } }; "
              "try { $pr=@(Get-AppxProvisionedPackage -Online | Where-Object DisplayName -Like $pattern); if($pr.Count -eq 0){ 'SKIPPED: no provisioned copy' } else { foreach($q in $pr){ $q | Remove-AppxProvisionedPackage -Online -ErrorAction Stop | Out-Null; 'REMOVED provisioned: ' + $q.DisplayName } } } catch { 'ERROR: provisioned removal: ' + $_.Exception.Message; $fail++ }; "
              "if($fail -gt 0){ exit 1 } else { exit 0 }")
    log(f"    {label}")
    ok, out = _ps(script, 300)
    _log_lines(log, out, 12)
    return ok


# ── custom items ──────────────────────────────────────────────────────────────────────────────────────────────
def hibernation(log, check):
    kind = chassis_type()
    log(f"    PC type: {kind}")
    if kind == "Laptop":
        ok, out = _run(["powercfg", "/hibernate", "on"], 30)
        return ok, "laptop: hibernation + Fast Startup left ON" if ok else "could not enable hibernation"
    if kind == "Desktop":
        ok, out = _run(["powercfg", "/hibernate", "off"], 30)
        return ok, "desktop: hibernation + Fast Startup OFF" if ok else "could not disable hibernation"
    return True, "PC type unknown - left unchanged"


def f8_menu(log, check):
    ok, out = _run(["bcdedit.exe", "/set", "{default}", "bootmenupolicy", "legacy"], 30)
    if not ok:
        log("    " + out[:160])
    return ok, "F8 boot menu restored" if ok else "bcdedit refused (UEFI/BIOS setup may block it)"


def virtual_memory(log, check):
    script = ("try { $ramMB=[Math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1MB,0); 'Detected RAM: ' + $ramMB + ' MB'; "
              "if($ramMB -ge 32768){ Set-CimInstance -Query 'SELECT * FROM Win32_ComputerSystem' -Property @{AutomaticManagedPageFile=$true} | Out-Null; 'Windows manages the page file (32 GB+ RAM).'; exit 0 }; "
              "$min=[uint32]4096; switch($ramMB){ {$_ -lt 8192}{$max=[uint32]8192;break}; {$_ -lt 16384}{$max=[uint32]16384;break}; default{$max=[uint32]24576} }; "
              "Set-CimInstance -Query 'SELECT * FROM Win32_ComputerSystem' -Property @{AutomaticManagedPageFile=$false} | Out-Null; "
              "$pf=Get-CimInstance Win32_PageFileSetting -Filter 'Name=''C:\\\\pagefile.sys'''; "
              "if($pf){ if(($pf.InitialSize -eq $min) -and ($pf.MaximumSize -eq $max)){ 'Already configured. Min=' + $min + ' MB Max=' + $max + ' MB'; exit 0 }; Set-CimInstance -InputObject $pf -Property @{InitialSize=$min;MaximumSize=$max} | Out-Null } "
              "else { New-CimInstance -ClassName Win32_PageFileSetting -Property @{Name='C:\\pagefile.sys';InitialSize=$min;MaximumSize=$max} | Out-Null }; "
              "'Configured page file: Initial=' + $min + ' MB Maximum=' + $max + ' MB'; exit 0 } catch { Write-Error $_.Exception.Message; exit 1 }")
    ok, out = _ps(script, 90)
    _log_lines(log, out, 6)
    return ok, "page file configured (restart to apply)" if ok else "page file could not be configured"


def svchost_split(log, check):
    kb = _ram_kb()
    if not kb:
        return False, "could not read the installed RAM"
    a, b = apply_machine([(r"SYSTEM\CurrentControlSet\Control", "SvcHostSplitThresholdInKB", "dword", min(kb + 262144, 0xFFFFFFFF))], log)
    return b == 0, f"threshold set from {kb // 1048576} GB RAM"


def sysmain(log, check):
    script = ("$ErrorActionPreference='Stop'; try { $dl=$env:SystemDrive.TrimEnd(':'); $part=Get-Partition -DriveLetter $dl; $disk=$part | Get-Disk; $pd=@(Get-PhysicalDisk -ErrorAction SilentlyContinue); "
              "$m=@($pd | Where-Object { [string]$_.DeviceId -eq [string]$disk.Number }); if($m.Count -eq 0 -and $pd.Count -eq 1){ $m=$pd }; $rot=$false;$ssd=$false; "
              "if([string]$disk.MediaType -eq 'HDD'){$rot=$true}elseif([string]$disk.MediaType -match 'SSD|SCM'){$ssd=$true}; "
              "foreach($p in $m){ if([string]$p.MediaType -eq 'HDD'){$rot=$true}elseif([string]$p.MediaType -match 'SSD|SCM'){$ssd=$true}; if($null -ne $p.SpindleSpeed -and [uint64]$p.SpindleSpeed -gt 0){$rot=$true} }; "
              "'DETAIL: Bus=' + $disk.BusType + ' Media=' + $disk.MediaType; if($rot){'RESULT=HDD'}elseif($ssd){'RESULT=SSD'}elseif([string]$disk.BusType -eq 'NVMe'){'RESULT=SSD'}else{'RESULT=UNKNOWN'} } catch { 'ERROR=' + $_.Exception.Message }")
    ok, out = _ps(script, 60)
    kind = next((l.split("=", 1)[1].strip() for l in out.splitlines() if l.startswith("RESULT=")), "UNKNOWN")
    _log_lines(log, out, 4)
    gb = _ram_kb() / 1048576
    log(f"    System drive: {kind}, RAM: {gb:.0f} GB")
    if kind == "HDD":
        want = "demand" if gb >= 11.5 else "disabled"
    elif kind == "SSD":
        want = "disabled"
    else:
        return True, "drive type unknown (RAID?) - SysMain left unchanged"
    a, b = apply_services({"SysMain": want}, log, check)
    return b == 0, f"SysMain set to {want}"


def svc_manual(log, check):
    a, b = apply_services({n: "demand" for n in SERVICES_MANUAL}, log, check)
    return b == 0, f"{a} services checked, {b} failed"


def svc_auto(log, check):
    a, b = apply_services({n: "auto" for n in SERVICES_AUTO}, log, check)
    return b == 0, f"{a} services checked, {b} failed"


def b_copilot(log, check):
    a, b = apply_machine([(r"SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", "dword", 1),
                          (r"SOFTWARE\Microsoft\Windows\Shell\Copilot", "IsCopilotAvailable", "dword", 0),
                          (r"SOFTWARE\Microsoft\Windows\Shell\Copilot", "CopilotDisabledReason", "sz", "IsEnabledForGeographicRegionFailed"),
                          (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked", "{CB3B0003-8088-4EDE-8769-8B354AB2FF8C}", "sz", "1"),
                          (r"SOFTWARE\Microsoft\Windows\Shell\Copilot\BingChat", "IsUserEligible", "dword", 0)], log)
    pk = remove_appx("*Microsoft.Copilot*", "Removing Microsoft Copilot (all users + provisioned)", log)
    return b == 0 and pk, "Copilot removed and blocked"


def b_widgets(log, check):
    ok, out = _ps("$p=@(Get-Process -Name 'Widgets','WidgetService' -ErrorAction SilentlyContinue); if($p.Count -eq 0){'no Widgets process running'}else{$p | Stop-Process -Force -ErrorAction Stop; 'stopped ' + $p.Count + ' Widgets process(es)'}", 40)
    _log_lines(log, out, 3)
    r1 = remove_appx("Microsoft.WidgetsPlatformRuntime", "Removing the Widgets Platform Runtime", log)
    check()
    r2 = remove_appx("MicrosoftWindows.Client.WebExperience", "Removing the Windows Web Experience pack", log)
    return r1 and r2, "Widgets removed"


def g_hpet(log, check):
    ok, out = _run(["bcdedit.exe", "/deletevalue", "useplatformclock"], 30)
    return True, "forced HPET setting removed" if ok else "no forced HPET setting was present"


def winget_update(log, check):
    log("    Installing / updating the WinGet client (NuGet + Microsoft.WinGet.Client)...")
    _log_lines(log, _ps("Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force | Out-Null; Install-Module -Name Microsoft.WinGet.Client -Force -ErrorAction Stop; 'ok'", 600)[1], 4)
    check()
    exe = shutil.which("winget")
    if not exe:
        return False, "winget is not available on this PC"
    log("    Updating every installed app (silent) - this can take a while...")
    ok, out = _run([exe, "update", "--all", "--include-unknown", "--accept-source-agreements", "--accept-package-agreements", "--silent"], 3600)
    _log_lines(log, out, 12)
    return ok, "apps updated" if ok else "winget finished with warnings - see the log"


_FUNCS = {f.__name__: f for f in (hibernation, f8_menu, virtual_memory, svchost_split, sysmain, svc_manual, svc_auto, b_copilot, b_widgets, g_hpet, winget_update)}


# ── run one group (= one progress step) ───────────────────────────────────────────────────────────────────────
def run_group(group: str, selected: list[str], log: Callable[[str], None], check: Callable[[], None]) -> tuple[str, str, bool]:
    """Apply the chosen items of one group.  Returns (state, note, restart_needed)."""
    items = [ITEMS_BY_KEY[k] for k in selected if k in ITEMS_BY_KEY and ITEMS_BY_KEY[k]["group"] == group]
    if not items:
        return "skip", "nothing chosen", False
    desktop = None
    if any(i.get("desktop") for i in items):
        desktop = chassis_type() == "Desktop"
    good = bad = 0
    restart = group in ("startup", "services", "system", "gaming")
    user_ops: list = []
    for it in items:
        check()
        name = it["name"]
        if it.get("desktop") and not desktop:
            log(f"  - {name}: skipped (not a desktop PC)")
            continue
        if it.get("user"):
            user_ops += it["user"]
            log(f"  - {name}: queued for every user")
            continue
        log(f"  - {name}")
        try:
            if it.get("fn"):
                ok, note = _FUNCS[it["fn"]](log, check)
            elif it.get("machine"):
                a, b = apply_machine(it["machine"], log)
                ok, note = b == 0, f"{a} setting(s)"
            elif it.get("svc"):
                a, b = apply_services(it["svc"], log, check)
                ok, note = b == 0, f"{a} service(s) checked"
            elif it.get("tasks"):
                a, b = disable_tasks(it["tasks"], log)
                ok, note = b == 0, f"{a} task(s) disabled or already off"
            elif it.get("appx"):
                ok = all(remove_appx(p, lbl, log) for p, lbl in it["appx"])
                note = "removed"
            else:
                ok, note = True, ""
        except Exception as exc:                                                      # noqa: BLE001 - one bad item never stops the rest
            if exc.__class__.__name__ == "Cancelled":
                raise
            _log.exception("sysopt item %s failed", it["key"])
            ok, note = False, str(exc)[:120]
        log(f"      {'OK' if ok else 'PROBLEM'}: {note}")
        good, bad = good + (1 if ok else 0), bad + (0 if ok else 1)
    if user_ops:
        check()
        log(f"  Applying {len(user_ops)} per-user setting(s) to every user, every offline profile and the Default profile...")
        try:
            a, b, profiles = apply_user_everywhere(user_ops, log)
            good += 1 if b <= 3 else 0                                                # a few protected values (e.g. TaskbarDa) always refuse - TBOK just warns too
            bad += 1 if b > 3 else 0
            log(f"    {profiles} profile(s) updated; {b} individual setting(s) refused (normal for a few protected ones)")
        except Exception as exc:                                                      # noqa: BLE001
            if exc.__class__.__name__ == "Cancelled":
                raise
            _log.exception("per-user deployment failed")
            bad += 1
            log(f"    ERROR: {exc}")
    total = good + bad
    if bad == 0:
        return "ok", f"{good} item(s) applied", restart
    return "warn", f"{good} of {total} items fully applied - see the log", restart
