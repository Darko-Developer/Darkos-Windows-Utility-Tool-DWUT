# Copyright © 2026 Darko / Darko.Dev
"""
term_host.py - tiny helper process that hosts ONE terminal session and relays it to the DWUT backend over a loopback socket.

Why it exists: a process cannot hand out a terminal with a different privilege level than its own.  To open an ADMINISTRATOR
terminal while DWUT runs normally (or a normal one while DWUT runs elevated) the shell is hosted by this helper, which the
backend starts elevated (UAC prompt) or de-elevated.  It only ever starts cmd.exe or powershell.exe - never anything else.

usage:  term_host.py <port> <token> <kind> <cols> <rows> <admin 0|1>
protocol (JSON lines):  helper -> backend  {"hello": token}  {"d": output}  {"x": exit code}
                        backend -> helper  {"w": input}  {"r": [cols, rows]}  {"k": 1}
"""
import json
import os
import socket
import sys
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main() -> int:
    port, token, kind, cols, rows, admin = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5]), sys.argv[6] == "1"
    if kind not in ("cmd", "powershell"):
        return 2
    sock = socket.create_connection(("127.0.0.1", int(port)), timeout=10)
    sock.settimeout(None)
    lock = threading.Lock()

    def send(obj) -> None:
        with lock:
            try:
                sock.sendall((json.dumps(obj) + "\n").encode("utf-8"))
            except OSError:
                pass

    send({"hello": token})
    from modules.system.termpty import LocalPty
    done = threading.Event()
    pty = LocalPty(kind, cols, rows, admin, lambda d: send({"d": d}), lambda c: (send({"x": c}), done.set()))
    buf = b""
    try:
        while not done.is_set():
            chunk = sock.recv(65536)
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                try:
                    m = json.loads(line.decode("utf-8"))
                except Exception:
                    continue
                if "w" in m:
                    pty.write(m["w"])
                elif "r" in m:
                    pty.resize(*m["r"])
                elif m.get("k"):
                    done.set()
                    break
    except OSError:
        pass
    pty.close()
    try:
        sock.close()
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    try:
        rc = main()
    except BaseException:
        rc = 1
    os._exit(rc)           # never linger: the shell is closed, the socket is closed, nothing may keep this helper alive
