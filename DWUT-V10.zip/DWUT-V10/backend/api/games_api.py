# Copyright © 2026 Darko / Darko.Dev
"""api/games_api.py - Game Profiles page backend."""
from __future__ import annotations

from server import rpc
from modules.games import scan, profiles
from server import rpc
from modules.games import scan, profiles
from modules.games.db import PRESETS, NV, AMD, PUBLISHERS

_cache: dict = {"games": None}


@rpc("games.scan")
def games_scan(force: bool = False):
    if force or _cache["games"] is None:
        games = scan.installed_games()
        ic = scan.icons([g["exe"] for g in games])
        for g in games:
            g["icon"] = ic.get(g["exe"]); g["publisher"] = PUBLISHERS.get(g["id"], "")
        _cache["games"] = games
    st = profiles.load_state()
    return {
        "games": [{**g, "applied": st.get(g["id"])} for g in _cache["games"]],
        "nvidia": profiles.has_nvidia(),
        "amd": profiles.has_amd(),
        "presets": {k: {"name": v[0], "desc": v[1], "nv": v[2]} for k, v in PRESETS.items()},
        "schema": {k: {"label": v[0], "section": v[1], "options": {ok: ov[0] for ok, ov in v[3].items()}} for k, v in NV.items()},
        "amd_schema": {k: {"label": v[0], "section": v[1], "options": {ok: ov[0] for ok, ov in v[3].items()}} for k, v in AMD.items()},
    }


def _game(gid: str):
    return next((g for g in (_cache["games"] or []) if g["id"] == gid), None)


@rpc("games.apply")
def games_apply(id: str, nv: dict | None = None, amd: dict | None = None, win: dict | None = None):
    g = _game(id)
    if not g:
        return {"ok": False, "notes": ["Game not found - rescan."]}
    return profiles.apply(g, nv or {}, amd or {}, win or {})


@rpc("games.remove")
def games_remove(id: str):
    g = _game(id)
    if not g:
        return {"ok": False, "notes": ["Game not found - rescan."]}
    return profiles.remove(g)


@rpc("games.launch")
def games_launch(id: str, exe: str = "", appid: int | None = None):
    import os
    g = _game(id)
    if g:
        appid = appid or g.get("appid")
        exe = exe or g.get("exe")
    if appid:
        try:
            os.startfile(f"steam://run/{appid}")
            return {"ok": True, "notes": [f"Launched Steam game (AppID {appid})"]}
        except Exception:
            pass
    if exe and os.path.isfile(exe):
        try:
            os.startfile(exe)
            return {"ok": True, "notes": [f"Launched {os.path.basename(exe)}"]}
        except Exception as e:
            return {"ok": False, "notes": [f"Launch failed: {e}"]}
    return {"ok": False, "notes": ["Could not launch game executable."]}


@rpc("games.open_inspector")
def games_open_inspector():
    ok, note = profiles.open_inspector()
    return {"ok": ok, "notes": [note]}

