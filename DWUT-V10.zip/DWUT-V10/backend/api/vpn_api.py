# Copyright © 2026 Darko / Darko.Dev
"""api/vpn_api.py - free full-system VPN (DWUTVPN) over Cloudflare WARP.

100% free, no account. WARP protects your traffic (public Wi-Fi, ISP snooping) but Cloudflare picks the exit near
you, so it does not change your location. Privacy options (kill switch, DNS, IPv6, browser leaks) are real and applied
when connecting.
"""
from __future__ import annotations

import ipaddress
import json
import re
import subprocess
import threading
import time
import winreg
from pathlib import Path

from core.events import Events, bus
from core.mask import clean
from core.logger import get_logger
from server import emit, rpc
from modules.vpn import servers, tunconf, tunnel
from modules.usb.engine import FlashError

_log = get_logger("api.vpn")
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)

DEFAULT_OPTS = {
    "kill_switch": True,        # block all traffic outside the tunnel (tunnel service firewall rules)
    "dns_protect": True,        # DNS only through the tunnel, using Cloudflare's resolvers
    "ipv6_block": True,         # IPv6 can't leak around the tunnel
    "browser_protect": True,    # Chrome/Edge/Brave: stop WebRTC + QUIC leaking your real IP
    "auto_reconnect": True,     # bring the tunnel back if it drops
}

_st = {
    "on": False, "busy": False, "status": "off", "since": 0.0, "server": None, "ip": "", "country": "",
    "country_code": "", "city": "", "provider": "warp", "opts": dict(DEFAULT_OPTS), "notes": [],
    "server_name": "", "latency": None, "profile": "", "profile_name": "",
}
_profile: str | None = None                             # imported location the user picked (None = automatic)
_bad: set[str] = set()                                  # connection points that did not answer this session
_dns_cache = {"t": 0.0, "v": []}
_PROFILE_DIR = tunnel.BASE / "profiles"
_CC_RE = re.compile(r"^(?:wg[-_ ]?)?([A-Z]{2})(?=$|[-#_ .\d])")
_endpoint: str | None = None                            # the connection point the user settled on (None = default)
_stop = threading.Event()
_ctx = {"conf": "", "real_ip": ""}                      # what the running tunnel was built from
_autostart_done = False
_POLICY_BACKUP = tunnel.BASE / "browser_policy_backup.json"


# ── helpers ───────────────────────────────────────────────────────────────────

def _is_admin() -> bool:
    try:
        from app.state import state
        return bool(state.is_admin)
    except Exception:
        import ctypes
        try:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False


def _push() -> None:
    emit("vpn.state", dict(_st))


_op_lock = threading.Lock()
_mon_thread: threading.Thread | None = None            # the ONE tunnel monitor


def _claim(status: str) -> bool:
    """Mark the VPN busy RIGHT NOW (before the worker thread even starts).  Previously busy was only set inside the worker, so
    two quick clicks (page + tray, or a double click) started two overlapping connect / switch threads that fought over the tunnel."""
    with _op_lock:
        if _st["busy"]:
            return False
        _st.update(busy=True, status=status)
    _push()
    return True


def _start_monitor() -> None:
    global _mon_thread
    if _mon_thread is None or not _mon_thread.is_alive():
        _mon_thread = threading.Thread(target=_tunnel_monitor, daemon=True, name="vpn-monitor")
        _mon_thread.start()


def _prog(msg: str, pct: float | None = None) -> None:
    emit("vpn.progress", {"msg": clean(re.sub(r"[\U00010000-\U0010ffff]|[\u2600-\u27bf]", "", msg)), "pct": pct})


def _run_cmd(cmd: list[str], timeout: int = 30) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WIN, stdin=subprocess.DEVNULL)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as exc:
        return -1, str(exc)


def _cfg():
    from app.config import config
    return config


def _load_prefs() -> None:
    global _endpoint, _profile
    try:
        pr = _cfg().vpn_prefs or {}
        pid = pr.get("profile")
        _profile = pid if pid and _pid_ok(pid) and _profile_path(pid).exists() else None
        _st.update(profile=_profile or "", profile_name=_profile or "")
        _st["opts"] = {**DEFAULT_OPTS, **{k: v for k, v in (pr.get("opts") or {}).items() if k in DEFAULT_OPTS}}
        ep = pr.get("endpoint")
        _endpoint = ep if ep in servers.ENDPOINTS else None
    except Exception:
        pass
def _save_prefs() -> None:
    try:
        c = _cfg()
        c.vpn_prefs = {"opts": dict(_st["opts"]), "endpoint": _endpoint, "profile": _profile}
        c.save()
    except Exception as exc:
        _log.debug("save prefs: %s", exc)
def _adopt_running() -> None:
    """DWUT was restarted while the tunnel kept running: pick the session back up."""
    if _st["on"] or _st["busy"]:
        return
    try:
        if tunnel.service_exists() and tunnel.is_up():
            info = tunnel.exit_info()
            _st.update(on=True, status="connected", since=time.time(), ip=info["ip"],
                       country=info["country"] or info["cc"], country_code=info["cc"], city=info["city"])
            _stop.clear()
            threading.Thread(target=_tunnel_monitor, daemon=True, name="vpn-monitor").start()
    except Exception:
        pass


# ── browser leak protection (Chrome / Edge / Brave policies) ──────────────────

_BROWSERS = {
    "Chrome": r"SOFTWARE\Policies\Google\Chrome",
    "Edge": r"SOFTWARE\Policies\Microsoft\Edge",
    "Brave": r"SOFTWARE\Policies\BraveSoftware\Brave",
}
_POLICIES = [("WebRtcIPHandling", winreg.REG_SZ, "disable_non_proxied_udp"),     # WebRTC may not reveal real/LAN IPs
             ("WebRtcLocalhostIpHandling", winreg.REG_SZ, "DisableNonProxiedUdp"),
             ("QuicAllowed", winreg.REG_DWORD, 0)]                               # QUIC/HTTP3 is UDP: keep it inside the tunnel


def _apply_browser_policies() -> list[str]:
    done, backup = [], {}
    for browser, path in _BROWSERS.items():
        try:
            key = winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_READ | winreg.KEY_WRITE | winreg.KEY_WOW64_64KEY)
            for name, typ, val in _POLICIES:
                if browser != "Edge" and name == "WebRtcLocalhostIpHandling":
                    continue
                try:
                    old = winreg.QueryValueEx(key, name)
                    backup[f"{path}|{name}"] = [old[0], old[1]]
                except OSError:
                    backup[f"{path}|{name}"] = None
                winreg.SetValueEx(key, name, 0, typ, val)
            winreg.CloseKey(key)
            done.append(browser)
        except OSError:
            continue
    try:
        if not _POLICY_BACKUP.exists():            # keep the ORIGINAL values if we get applied twice
            _POLICY_BACKUP.write_text(json.dumps(backup), encoding="utf-8")
    except Exception:
        pass
    return done


def _restore_browser_policies() -> None:
    try:
        backup = json.loads(_POLICY_BACKUP.read_text(encoding="utf-8"))
    except Exception:
        return
    for k, old in backup.items():
        path, name = k.split("|", 1)
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, path, 0, winreg.KEY_WRITE | winreg.KEY_WOW64_64KEY)
            if old is None:
                try:
                    winreg.DeleteValue(key, name)
                except OSError:
                    pass
            else:
                winreg.SetValueEx(key, name, 0, old[1], old[0])
            winreg.CloseKey(key)
        except OSError:
            continue
    try:
        _POLICY_BACKUP.unlink()
    except Exception:
        pass


# ── imported locations (optional: your own server files, e.g. from a free Proton account) ──────────────────

def _pid_ok(pid: str | None) -> bool:
    return bool(pid) and bool(re.fullmatch(r"[A-Za-z0-9._#\- ]{1,60}", pid)) and ".." not in pid


def _profile_path(pid: str) -> Path:
    return _PROFILE_DIR / f"{pid}.conf"


def _profiles() -> list[dict]:
    out: list[dict] = []
    try:
        files = sorted(_PROFILE_DIR.glob("*.conf"), key=lambda p: p.name.lower())
    except Exception:
        return out
    for f in files:
        try:
            if tunconf.validate(tunconf.parse_conf(f.read_text(encoding="utf-8"))):
                continue
        except Exception:
            continue
        m = _CC_RE.match(f.stem)
        out.append({"id": f.stem, "name": f.stem, "cc": m.group(1).upper() if m else ""})
    return out


@rpc("vpn.profiles")
def vpn_profiles():
    return {"profiles": _profiles(), "selected": _profile or ""}


@rpc("vpn.profile_import")
def vpn_profile_import(paths: list | None = None):
    added: list[str] = []
    errors: list[str] = []
    try:
        _PROFILE_DIR.mkdir(parents=True, exist_ok=True)
        tunnel._secure_dir()
    except Exception:
        pass
    for path in paths or []:
        name = Path(str(path)).name
        try:
            fp = Path(str(path))
            if fp.stat().st_size > 65536:
                raise ValueError("file is too large to be a server file")
            p = tunconf.parse_conf(fp.read_text(encoding="utf-8-sig", errors="replace"))
            err = tunconf.validate(p)
            if err:
                raise ValueError(err)
            if not tunconf.is_full_tunnel(p):
                raise ValueError("this file only covers part of your traffic - use a full-VPN server file")
            base = re.sub(r"[^A-Za-z0-9._#\- ]", "_", fp.stem).strip(" .")[:56] or "Location"
            pid, n = base, 2
            while _profile_path(pid).exists():
                pid, n = f"{base}-{n}", n + 1
            _profile_path(pid).write_text(tunconf.serialize(p), encoding="utf-8")
            added.append(pid)
        except Exception as exc:
            errors.append(f"{name}: {clean(str(exc))}")
    return {"added": added, "errors": errors, "profiles": _profiles(), "selected": _profile or ""}


@rpc("vpn.profile_remove")
def vpn_profile_remove(pid: str = ""):
    global _profile
    if not _pid_ok(pid):
        return {"ok": False, "error": "unknown location"}
    if _st["on"] and _profile == pid:
        return {"ok": False, "error": "Disconnect first, then remove this location."}
    try:
        _profile_path(pid).unlink(missing_ok=True)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if _profile == pid:
        _profile = None
        _st.update(profile="", profile_name="")
        _save_prefs()
        _push()
    return {"ok": True, "profiles": _profiles(), "selected": _profile or ""}


@rpc("vpn.profile_select")
def vpn_profile_select(pid: str = ""):
    """Pick a location ('' = automatic).  If the VPN is on it switches right away."""
    global _profile
    if _st["busy"]:
        return {"ok": False, "error": "Please wait for the current connection step to finish."}
    new = pid if _pid_ok(pid) and _profile_path(pid).exists() else None
    if new == _profile:
        return {"ok": True, "switching": False}
    _profile = new
    _st.update(profile=new or "", profile_name=new or "")
    _save_prefs()
    _push()
    if _st["on"]:
        if not _claim("reconnecting"):
            return {"ok": False, "error": "Please wait for the current connection step to finish."}
        threading.Thread(target=_do_reconnect, args=("Switching location…",), daemon=True, name="vpn-location").start()
        return {"ok": True, "switching": True}
    return {"ok": True, "switching": False}


# ── building the tunnel config ────────────────────────────────────────────────

def _system_public_dns() -> list[str]:
    """The user's own non-router DNS servers (e.g. 8.8.8.8 they set on their adapter)."""
    if time.time() - _dns_cache["t"] < 120:
        return list(_dns_cache["v"])
    code, out = _run_cmd(["powershell", "-NoProfile", "-NonInteractive", "-Command",
                          "Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notmatch 'DWUTVPN|Loopback|vEthernet' } | ForEach-Object { $_.ServerAddresses }"], 20)
    found: list[str] = []
    for line in out.split():
        try:
            ip = ipaddress.ip_address(line.strip())
            if not (ip.is_private or ip.is_loopback or ip.is_link_local) and line.strip() not in found:
                found.append(line.strip())
        except ValueError:
            continue
    _dns_cache.update(t=time.time(), v=found[:2])
    return found[:2]


def _dns_for(opts: dict) -> list[str]:
    v6 = not opts.get("ipv6_block", True)
    cloudflare = ["1.1.1.1", "1.0.0.1"] + (["2606:4700:4700::1111", "2606:4700:4700::1001"] if v6 else [])
    if opts.get("dns_protect", True):
        return cloudflare
    return _system_public_dns() or cloudflare    # "off" = keep the DNS servers you chose yourself (a router-only setup can't resolve inside a full tunnel)


def _prepare_ex(opts: dict, endpoint: str | None = None, profile_id: str | None = None) -> tuple[str, dict]:
    """(config text, parsed profile) for either the free built-in network or an imported location."""
    if profile_id:
        profile = tunconf.parse_conf(_profile_path(profile_id).read_text(encoding="utf-8"))
        dns = profile["dns"] if (opts.get("dns_protect", True) and profile.get("dns")) else _dns_for(opts)
    else:
        tunnel.ensure_profile(lambda m: _log.info(m), lambda f: _prog("Preparing your free profile…", 0.2 + 0.15 * f))
        profile = tunconf.parse_conf(tunnel.WARP_PROFILE.read_text(encoding="utf-8"))
        ep = endpoint or _endpoint
        profile["endpoint"] = ep if (ep and ep in servers.ENDPOINTS) else servers.ENDPOINTS[0]
        dns = _dns_for(opts)
    conf = tunconf.render_conf(profile, kill_switch=opts.get("kill_switch", True), ipv6_block=opts.get("ipv6_block", True),
                               dns=dns, mtu=profile.get("mtu") or 1280)
    return conf, profile


def _prepare(opts: dict, endpoint: str | None = None) -> str:
    return _prepare_ex(opts, endpoint)[0]


def _ip_only(eps: list[str], opts: dict) -> list[str]:
    """With the kill switch on, only literal-IP connection points are used: a host NAME would need a DNS lookup
    outside the tunnel, which the kill switch (rightly) blocks."""
    if not opts.get("kill_switch", True):
        return eps
    out = []
    for ep in eps:
        try:
            ipaddress.ip_address(ep.rpartition(":")[0])
            out.append(ep)
        except ValueError:
            continue
    return out or eps


def _carried(t: dict) -> bool:
    """Is traffic really leaving through the tunnel, judged from a trace result?"""
    if not _profile:
        return bool(t.get("on"))                   # built-in network: the provider tells us itself
    ip = t.get("ip") or ""
    return bool(ip) and ip != _ctx.get("real_ip")  # imported location: our exit IP must differ from the real one


def _dial(opts: dict, real_ip: str) -> tuple[dict, str | None, str, str | None]:
    """Bring the tunnel up as fast as possible and return (trace, endpoint, conf, profile_id).

    Imported location: one server, a few seconds to answer.
    Built-in network: the chosen connection point first; if it does not answer within a few seconds the next
    distinct points are tried by moving the running tunnel live (no teardown), so a blocked port/address costs
    seconds, not minutes."""
    pid = _profile if (_profile and _pid_ok(_profile) and _profile_path(_profile).exists()) else None
    if pid:
        _prog("Connecting…", 0.7)
        conf, _p = _prepare_ex(opts, profile_id=pid)
        t = tunnel.connect(conf, lambda m: _log.info(m), real_ip=real_ip, handshake_timeout=9.0)
        return t, None, conf, pid
    first = _endpoint or servers.ENDPOINTS[0]
    order = _ip_only([first] + servers.next_candidates(first, 5, _bad), opts)[:4]
    last: Exception | None = None
    for i, ep in enumerate(order):
        _prog("Connecting…" if i == 0 else f"Trying {servers.label(ep)}…", 0.65 + 0.07 * i)
        try:
            conf, prof = _prepare_ex(opts, ep)
            if i == 0 or not tunnel.is_up():
                t = tunnel.connect(conf, lambda m: _log.info(m), expect_warp=True, real_ip=real_ip,
                                   handshake_timeout=6.0 if i == 0 else 4.0)
            else:
                try:
                    t = tunnel.retarget(ep, prof["public_key"], tunconf.allowed_for_run(prof, opts.get("kill_switch", True)), real_ip=real_ip)
                except tunnel.HandshakeTimeout:
                    raise
                except FlashError:
                    t = tunnel.connect(conf, lambda m: _log.info(m), expect_warp=True, real_ip=real_ip, handshake_timeout=4.0)
            _bad.discard(ep)
            return t, ep, conf, None
        except Exception as exc:
            _log.warning("connection point %s failed: %s", ep, exc)
            _bad.add(ep)
            last = exc
    raise last or FlashError("no connection point answered")


def _set_connected(t: dict, ep: str | None, conf: str, pid: str | None, notes: list[str], keep_since: bool = False) -> None:
    global _endpoint
    _ctx["conf"] = conf
    loc = (t.get("loc") or "").upper()
    if pid:
        _st.update(server={"hostname": pid, "ip": "", "port": 0, "protocol": "DWUT Tunnel"}, server_name=pid,
                   profile=pid, profile_name=pid, country=loc, country_code=loc)
    else:
        if ep:
            new_ep = None if ep == servers.ENDPOINTS[0] else ep
            if new_ep != _endpoint:
                _endpoint = new_ep
                _save_prefs()
        ep_chosen = ep or _endpoint or servers.ENDPOINTS[0]
        ep_host, _, ep_port = ep_chosen.partition(":")
        _st.update(server={"hostname": "Cloudflare WARP", "ip": ep_host, "port": int(ep_port) if ep_port.isdigit() else 2408, "protocol": "DWUT Tunnel"},
                   server_name=servers.label(ep_chosen), profile="", profile_name="",
                   country=loc or "Cloudflare WARP", country_code=loc)
    _st.update(on=True, busy=False, status="connected", ip=t.get("ip", ""), city="", latency=None, notes=notes,
               since=(_st.get("since") or time.time()) if keep_since else time.time())


# ── connect / disconnect ──────────────────────────────────────────────────────

def _connect(opts: dict) -> None:
    notes: list[str] = []
    try:
        _st.update(busy=True, status="connecting", notes=[], opts=opts)
        _push()
        if not _is_admin():
            raise RuntimeError("Administrator rights are required to run the VPN tunnel.")
        _bad.clear()
        _prog("Preparing…", 0.05)
        # what the network sees WITHOUT the tunnel - measured in the background while the rest is prepared
        box = {"ip": ""}
        rt = None
        if not tunnel.service_exists():
            def _ri():
                try:
                    box["ip"] = tunnel.trace(timeout=1.2).get("ip", "")
                except Exception:
                    pass
            rt = threading.Thread(target=_ri, daemon=True, name="vpn-realip")
            rt.start()
        tunnel.migrate_legacy(lambda m: _log.info(m))
        tunnel.ensure_client(lambda m: _log.info(m), lambda f: _prog("Installing the VPN component…", 0.05 + 0.25 * f))
        _prog("Building your connection…", 0.4)
        if _profile is None:                       # make sure the free profile exists before we start the clock
            tunnel.ensure_profile(lambda m: _log.info(m), lambda f: _prog("Preparing your free profile…", 0.2 + 0.15 * f))
        if rt:
            rt.join(3.0)
            real_ip = box["ip"] or _ctx["real_ip"]
        else:
            real_ip = _ctx["real_ip"]
        _ctx["real_ip"] = real_ip or _ctx["real_ip"]
        t, ep, conf, pid = _dial(opts, real_ip)
        _stop.clear()
        if opts.get("browser_protect", True):
            done = _apply_browser_policies()
            if done:
                notes.append("Browser protection on for " + ", ".join(done) + " - restart the browser to apply.")
        else:
            _restore_browser_policies()
        _set_connected(t, ep, conf, pid, notes)
        _prog("Connected", 1.0)
        _push()
        _start_monitor()
        threading.Thread(target=_measure_latency, daemon=True, name="vpn-latency").start()
    except Exception as exc:
        _log.error("VPN connect failed: %s", exc)
        try:
            tunnel.disconnect()
        except Exception:
            pass
        msg = str(exc)
        if "handshake" in msg or "did not flow" in msg:
            msg = "no VPN server answered - your network may be blocking it. Try again, or switch networks."
        _st.update(on=False, busy=False, status="off", server=None, notes=[clean(f"Connection failed: {msg}")])
        _prog("", None)
        _push()


def _tunnel_monitor() -> None:
    bad = 0
    while not _stop.wait(15):
        if not _st["on"]:
            return
        if _st["busy"]:
            continue
        up = tunnel.is_up()
        if up:
            try:
                t = tunnel.trace()
                up = _carried(t)
                if up and t["ip"] and t["ip"] != _st.get("ip"):
                    _st["ip"] = t["ip"]
                    _push()
            except Exception:
                up = False
        if up:
            bad = 0
            if _st["status"] != "connected":
                _st["status"] = "connected"
                _push()
            continue
        bad += 1
        if bad < 2:
            continue
        if not _st["opts"].get("auto_reconnect", True):
            _st.update(status="degraded", notes=["Connection lost" + (" - the kill switch keeps your traffic blocked." if _st["opts"].get("kill_switch", True) else ".") + " Reconnect when ready, or use Restore internet."])
            _push()
            continue
        _st["status"] = "reconnecting"
        _push()
        try:
            t = tunnel.connect(_ctx["conf"], lambda m: None, real_ip=_ctx["real_ip"], handshake_timeout=8.0)
            _st.update(status="connected", ip=t.get("ip", ""), notes=[])
            bad = 0
        except Exception:
            _st.update(status="degraded", notes=["Connection lost" + (" - kill switch active" if _st["opts"].get("kill_switch", True) else "") + ". Retrying..."])
        _push()


def _disconnect() -> None:
    _stop.set()
    _st.update(busy=True, status="off")
    _push()
    try:
        tunnel.disconnect()
    except Exception as exc:
        _log.warning("disconnect: %s", exc)
    try:
        _restore_browser_policies()
    except Exception:
        pass
    _st.update(on=False, busy=False, status="off", server=None, notes=[], ip="", country="", country_code="", city="", server_name="", latency=None)
    _prog("", None)
    _push()


def shutdown_vpn() -> None:
    """DWUT is closing. The tunnel is left as the user had it (it is a normal Windows service)."""
    _stop.set()


# ── RPC ───────────────────────────────────────────────────────────────────────

@rpc("vpn.state")
def vpn_state():
    return dict(_st)


@rpc("vpn.connect")
def vpn_connect(opts: dict | None = None):
    if _st["on"] and not _st["busy"]:
        return False                                   # already connected (a stale tray menu must not restart the tunnel)
    if not _claim("connecting"):
        return False
    o = {**_st["opts"], **{k: v for k, v in (opts or {}).items() if k in DEFAULT_OPTS}}
    _st["opts"] = o
    _save_prefs()
    threading.Thread(target=_connect, args=(o,), daemon=True, name="vpn-connect").start()
    return True


@rpc("vpn.disconnect")
def vpn_disconnect():
    if not _claim("off"):
        return False                                   # a connect / switch step is still running - "Restore internet" is the emergency exit
    threading.Thread(target=_disconnect, daemon=True, name="vpn-disconnect").start()
    return True


@rpc("vpn.panic")
def vpn_panic():
    """Emergency: remove every tunnel + browser rule and restore normal internet right now."""
    _disconnect()
    return True


@rpc("vpn.ip")
@rpc("vpn.check_ip")
def vpn_check_ip():
    try:
        info = tunnel.exit_info()
        if info["ip"] and _st["on"]:
            _st["ip"] = info["ip"]
            _push()
        return info
    except Exception as exc:
        return {"ip": _st.get("ip", ""), "cc": "", "country": "", "city": "", "error": clean(str(exc))}


@rpc("vpn.set_opts")
def vpn_set_opts(opts: dict):
    """Remember privacy options; they take effect on the next connect (use Reconnect if already on)."""
    _st["opts"] = {**_st["opts"], **{k: v for k, v in (opts or {}).items() if k in DEFAULT_OPTS}}
    _save_prefs()
    _push()
    return dict(_st["opts"])


def _measure_latency() -> None:
    try:
        try:
            info = tunnel.exit_info()
            if _st["on"] and (info.get("city") or info.get("country")):
                _st.update(city=info.get("city", _st.get("city", "")),
                           country=info.get("country") or _st.get("country", ""))
                _push()
        except Exception:
            pass
        ms = tunnel.latency()
        if _st["on"]:
            _st["latency"] = ms
            _push()
    except Exception:
        pass


def _fail_off(exc: Exception, what: str) -> None:
    """A switch/reconnect that could not be completed: never leave a half-working tunnel swallowing traffic."""
    _log.error("%s failed: %s", what, exc)
    try:
        tunnel.disconnect()
    except Exception:
        pass
    msg = str(exc)
    if "handshake" in msg or "did not flow" in msg:
        msg = "no VPN server answered - your network may be blocking it"
    _st.update(on=False, busy=False, status="off", server=None, ip="", notes=[clean(f"{what} failed: {msg}. The VPN was turned off so your internet keeps working.")])
    _prog("", None)
    _push()


def _change_server() -> None:
    """Fast server hop.  Imported locations: next one in the list.  Built-in network: another connection point,
    moved to live on the running tunnel (a dead one is skipped after a few seconds)."""
    opts = dict(_st["opts"])
    try:
        _st.update(busy=True, status="switching", notes=[])
        _push()
        if _profile:
            ids = [p["id"] for p in _profiles()]
            if len(ids) < 2:
                _st.update(busy=False, status="connected", notes=["Add more locations to switch between them."])
                _prog("", None)
                _push()
                return
            nxt = ids[(ids.index(_profile) + 1) % len(ids)] if _profile in ids else ids[0]
            _set_profile_and_reconnect(nxt, "Switching location…")
            return
        cur = _endpoint or servers.ENDPOINTS[0]
        _prog("Selecting next connection server...", 0.2)
        cands = _ip_only(servers.next_candidates(cur, 6, _bad), opts)[:4]
        if not cands:
            _bad.clear()
            cands = _ip_only(servers.next_candidates(cur, 6), opts)[:4]
        t = None
        next_ep = None
        conf = ""
        for idx, cand in enumerate(cands):
            _prog(f"Connecting to {servers.label(cand)}...", 0.3 + 0.5 * ((idx + 1) / len(cands)))
            try:
                conf, prof = _prepare_ex(opts, cand)
                try:
                    t = tunnel.retarget(cand, prof["public_key"], tunconf.allowed_for_run(prof, opts.get("kill_switch", True)), real_ip=_ctx["real_ip"])
                except tunnel.HandshakeTimeout:
                    raise
                except FlashError:
                    t = tunnel.connect(conf, lambda m: _log.info(m), expect_warp=True, real_ip=_ctx["real_ip"], handshake_timeout=4.0)
                next_ep = cand
                _bad.discard(cand)
                break
            except Exception as exc:
                _log.warning("Candidate %s failed: %s", cand, exc)
                _bad.add(cand)
        if not t or not next_ep:
            # nothing else answered: go back to the point that was working
            _prog("Restoring previous server...", 0.9)
            conf, prof = _prepare_ex(opts, cur)
            try:
                t = tunnel.retarget(cur, prof["public_key"], tunconf.allowed_for_run(prof, opts.get("kill_switch", True)), real_ip=_ctx["real_ip"])
            except Exception:
                t = tunnel.connect(conf, lambda m: _log.info(m), expect_warp=True, real_ip=_ctx["real_ip"], handshake_timeout=6.0)
            _set_connected(t, cur, conf, None, ["No other server answered on this network - staying on the current one."], keep_since=True)
            _prog("", None)
            _push()
            threading.Thread(target=_measure_latency, daemon=True, name="vpn-latency").start()
            return
        _prog("Connected", 1.0)
        _set_connected(t, next_ep, conf, None, [f"Switched to {servers.label(next_ep)}."], keep_since=True)
        _push()
        threading.Thread(target=_measure_latency, daemon=True, name="vpn-latency").start()
    except Exception as exc:
        _fail_off(exc, "Change server")


@rpc("vpn.change_server")
def vpn_change_server():
    if not _st["on"] or not _claim("switching"):
        return False
    threading.Thread(target=_change_server, daemon=True, name="vpn-change-server").start()
    return True


def _set_profile_and_reconnect(pid: str | None, msg: str) -> None:
    global _profile
    _profile = pid
    _st.update(profile=pid or "", profile_name=pid or "")
    _save_prefs()
    _do_reconnect(msg)


def _do_reconnect(msg: str = "Reconnecting with updated protections…") -> None:
    try:
        _st.update(busy=True, status="reconnecting", notes=[])
        _push()
        _prog(msg, 0.35)
        if not _is_admin():
            raise RuntimeError("Administrator rights are required to run the VPN tunnel.")
        _bad.clear()
        opts = dict(_st["opts"])
        t, ep, conf, pid = _dial(opts, _ctx["real_ip"])
        if opts.get("browser_protect", True):
            _apply_browser_policies()
        else:
            _restore_browser_policies()
        _set_connected(t, ep, conf, pid, [], keep_since=True)
        _prog("Connected", 1.0)
        _push()
        threading.Thread(target=_measure_latency, daemon=True, name="vpn-latency").start()
    except Exception as exc:
        _fail_off(exc, "Reconnect")


@rpc("vpn.reconnect")
def vpn_reconnect():
    if not _claim("reconnecting"):
        return False
    threading.Thread(target=_do_reconnect, daemon=True, name="vpn-reconnect").start()
    return True


@rpc("vpn.live")
def vpn_live(deep: bool = True):
    """The VPN's REAL state right now - not a cached flag.  Used by the tray menu, which must never be wrong.

    * service RUNNING        -> the tunnel is up
    * deep=True: Cloudflare says warp=on over the normal route -> traffic really leaves through the tunnel
      (a tunnel that is up but not carrying traffic is reported as NOT protecting you)
    * if the state we remembered disagrees with reality (e.g. the tunnel was stopped from outside), reality wins."""
    busy = bool(_st["busy"])
    svc = False
    try:
        svc = tunnel.service_exists() and tunnel.is_up()
    except Exception:
        svc = False
    carried = None                                       # None = could not tell (offline / slow)
    if svc and deep and not busy:
        try:
            carried = _carried(tunnel.trace(2.5))
        except Exception:
            carried = None
    if svc and not _st["on"] and not busy:               # tunnel is running but we lost track of it: pick the session back up
        _adopt_running()
    if busy:
        status = _st.get("status") or "working"
        on = bool(_st["on"])
    elif svc and carried is not False:
        status, on = "connected", True
    elif svc and carried is False:
        status, on = "not_protecting", False
    elif _st["on"] and _st.get("status") in ("reconnecting", "degraded"):
        status, on = _st["status"], False                # remembered as connected, tunnel gone, and the monitor is dealing with it
    else:
        status, on = "off", False
    return {"on": on, "status": status, "busy": busy, "verified": carried, "service_up": svc,
            "server": _st.get("server_name", "") if on else "", "latency": _st.get("latency") if on else None,
            "ip": _st.get("ip", "") if on else "", "can_switch": bool(on and not busy)}


# ── auto-connect at DWUT start ───────────────────────────────────────────────

@rpc("vpn.autostart_get")
def vpn_autostart_get():
    try:
        return bool(_cfg().vpn_autostart)
    except Exception:
        return False


@rpc("vpn.autostart_set")
def vpn_autostart_set(on: bool):
    c = _cfg()
    c.vpn_autostart = bool(on)
    c.save()
    return True


@rpc("vpn.autostart_run")
def vpn_autostart_run():
    """Called once per DWUT launch by the UI: reconnect if the user turned auto-connect on."""
    global _autostart_done
    if _autostart_done:
        return False
    _autostart_done = True
    _load_prefs()
    _adopt_running()
    if _cfg().vpn_autostart and not _st["on"] and not _st["busy"]:
        if not _is_admin():
            _st["notes"] = ["Auto-connect needs Administrator rights - restart DWUT as administrator."]
            _push()
            return False
        if not _claim("connecting"):                   # main.js also auto-connects at startup - only one of them may run
            return False
        threading.Thread(target=_connect, args=(dict(_st["opts"]),), daemon=True, name="vpn-autostart").start()
        return True
    return False


@rpc("vpn.startup_status")
def vpn_startup_status():
    """Is DWUT already set to start with Windows? (checks Run keys, Startup folder and Task Scheduler)."""
    try:
        from modules.system.startup import get_startup_entries
        for e in get_startup_entries():
            blob = " ".join(str(getattr(e, a, "")) for a in ("name", "command", "path", "target")).lower()
            if "dwut" in blob or "darko" in blob:
                return {"registered": True, "enabled": bool(getattr(e, "enabled", True)), "where": str(getattr(e, "location", "") or getattr(e, "source", ""))}
    except Exception as exc:
        _log.debug("startup scan: %s", exc)
    return {"registered": False, "enabled": False, "where": ""}


@rpc("vpn.startup_enable_existing")
def vpn_startup_enable_existing():
    try:
        from modules.system.startup import get_startup_entries, enable_startup_entry
        for e in get_startup_entries():
            blob = " ".join(str(getattr(e, a, "")) for a in ("name", "command", "path", "target")).lower()
            if ("dwut" in blob or "darko" in blob) and not getattr(e, "enabled", True):
                return bool(enable_startup_entry(e))
    except Exception:
        pass
    return False


@rpc("vpn.connect_stacked")
def vpn_connect_stacked():
    if not _st["on"]:
        return vpn_connect()
    return True


_load_prefs()
