# Copyright © 2026 Darko / Darko.Dev
"""api/usb_api.py — USB Flasher jobs (flash, restore, backup, ISO library)."""
from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path

from core.logger import get_logger
from modules.usb import catalog, engine
from modules.usb.engine import CACHE, Cancelled, FlashError
from server import emit, rpc

_log = get_logger("api.usb")
_cancel = threading.Event()
_user = threading.Event()
_busy = threading.Lock()

PLANS = {
    "dd": [("resolve", 2), ("download", 46), ("checksum", 5), ("prepare", 3), ("write", 36), ("verify", 8)],
    "winiso": [("resolve", 2), ("download", 45), ("prepare", 4), ("copy", 38), ("split", 8), ("boot", 3)],
    "ventoy": [("resolve", 2), ("download", 38), ("install", 14), ("copy", 46)],
    "ventoy_only": [("resolve", 2), ("download", 30), ("install", 68)],
    "simple": [("work", 100)],
}


class Prog:
    def __init__(self, plan: list, event: str = "usb.progress"):
        self.event = event
        self.plan, self.idx, self.msg, self.indet, self._f = plan, -1, "", False, 0.0

    def stage(self, name: str, msg: str = "", indeterminate: bool = False) -> None:
        for i, (n, _) in enumerate(self.plan):
            if n == name:
                self.idx = i
        self.msg, self.indet, self._f = msg or self.msg, indeterminate, 0.0
        if msg:
            emit(self.event.replace(".progress", ".log"), f"[{name}] {msg}")
        self._push(0, 0)

    def frac(self, f: float, speed: float = 0, eta: float = 0) -> None:
        self._f = f
        self._push(speed, eta)

    dl = frac

    def _push(self, speed, eta) -> None:
        total = sum(w for _, w in self.plan) or 1
        before = sum(w for _, w in self.plan[:max(self.idx, 0)])
        w = self.plan[self.idx][1] if 0 <= self.idx < len(self.plan) else 0
        emit(self.event, {"stage": self.plan[self.idx][0] if self.idx >= 0 else "", "msg": self.msg, "indeterminate": self.indet,
                              "stage_frac": self._f, "overall": min(1.0, (before + w * self._f) / total), "speed": speed, "eta": eta,
                              "stages": [n for n, wt in self.plan if wt]})


def _log_line(m: str) -> None:
    emit("usb.log", m)


def _detect_mode(iso: Path) -> str:
    if engine.is_hybrid(iso):
        return "dd"
    _log_line(f"Looking inside {iso.name} to decide how to write it…")
    code, out = engine.ps(f"$i=Mount-DiskImage -ImagePath '{engine.psq(iso)}' -PassThru; Start-Sleep 1; $l=($i|Get-Volume).DriveLetter; "
                          "if($l){ if(Test-Path \"$($l):\\sources\\boot.wim\"){'WIN'} } ; Dismount-DiskImage -ImagePath '" + engine.psq(iso) + "' | Out-Null", 90,
                          log=_log_line, label=f"PowerShell: peek inside {iso.name}")
    _log_line("  -> Windows installer image" if "WIN" in out else "  -> not a hybrid Linux image and not a Windows installer: will use Ventoy")
    return "winiso" if "WIN" in out else "ventoy"


def _flash(params: dict) -> None:
    from app.state import state
    disk, verify = params["disk"], bool(params.get("verify", True))
    entry = catalog.get(params.get("os_id", "")) if params.get("os_id") else None
    custom = params.get("iso_path")
    ok, msg = False, ""
    prog = Prog(PLANS["dd"])
    _log_line(f"Starting: {entry['name'] if entry else (Path(custom).name if custom else 'image')} -> Disk {disk.get('number')} ({disk.get('name', 'USB drive')}, {disk.get('size', 0) / 1e9:.1f} GB)")
    try:
        if not state.is_admin:
            raise FlashError("DWUT must run as Administrator to write to a USB drive. Restart it as admin and try again.")
        engine.revalidate(disk, _log_line)
        mode = entry["mode"] if entry else "dd"
        if custom:
            iso = Path(custom)
            if not iso.exists():
                raise FlashError("That ISO file no longer exists.")
            mode = _detect_mode(iso)
        prog = Prog(PLANS[mode])
        _log_line(f"Method: {({'dd': 'raw image write', 'winiso': 'Windows installer (FAT32 + boot code)', 'ventoy': 'Ventoy + ISO', 'ventoy_only': 'Ventoy'}).get(mode, mode)}")
        sha = None
        if not custom:
            prog.stage("resolve", f"Finding the latest {entry['name']}…", True)
            r = engine.resolve(entry, _log_line)
            iso = CACHE / r["filename"]
            sha = r["sha256"]
            _log_line(f"Latest: {r['filename']}" + ("" if sha else "  (no published checksum found)"))
            _log_line(f"Source: {r['urls'][0].split('//', 1)[-1][:90]}")
            cached_ok = iso.exists() and iso.stat().st_size > 1_000_000
            if cached_ok and sha:
                prog.stage("checksum", "Checking your previously downloaded copy…")
                cached_ok = engine.sha256_file(iso, prog.frac, _cancel) == sha
            if not cached_ok:
                prog.stage("download", f"Downloading {r['filename']}")
                engine.download(r["urls"], iso, prog.dl, _cancel, _log_line)
            else:
                _log_line("Using the already-downloaded ISO from the library.")
                prog.stage("download", "Already downloaded")
                prog.frac(1.0)
            if sha and mode == "dd":
                prog.stage("checksum", "Verifying download integrity (SHA-256)…")
                got = engine.sha256_file(iso, prog.frac, _cancel)
                if got != sha:
                    iso.unlink(missing_ok=True)
                    raise FlashError("The downloaded file failed its checksum - it was deleted. Please try again.")
                _log_line("Checksum OK.")
        elif mode == "dd":
            _log_line("Custom image detected as a bootable hybrid image (raw write).")
        # ── point of no return ──
        engine.revalidate(disk, _log_line)
        _log_line((f"Preparing Disk {disk['number']} ({disk['name']}, {disk['size'] / 1e9:.1f} GB) - a stick that already has Ventoy is kept as it is"
                   if mode in ("ventoy", "ventoy_only") else f"ERASING Disk {disk['number']} ({disk['name']}, {disk['size'] / 1e9:.1f} GB)"))
        if mode == "dd":
            if iso.stat().st_size > disk["size"]:
                raise FlashError(f"The image ({iso.stat().st_size / 1e9:.1f} GB) is larger than the USB stick ({disk['size'] / 1e9:.1f} GB).")
            prog.stage("prepare", "Clearing the stick…", True)
            engine.wipe(disk, _log_line)
            prog.stage("write", "Writing the image to the stick - do not unplug it!")
            _log_line(f"Writing {iso.stat().st_size / 1e9:.2f} GB to {engine.raw_path(disk['number'])} in 4 MB blocks…")
            t0 = time.monotonic()
            engine.write_image(iso, engine.raw_path(disk["number"]), prog.frac, _cancel)
            _log_line(f"Write finished in {time.monotonic() - t0:.0f} s.")
            if verify:
                prog.stage("verify", "Verifying what was written…")
                engine.verify_image(iso, engine.raw_path(disk["number"]), prog.frac, _cancel)
                _log_line("Verification OK - every byte on the stick matches the image.")
            engine.ps(f"Update-Disk -Number {int(disk['number'])} -ErrorAction SilentlyContinue", 30, _log_line, label="PowerShell: refresh the disk so Windows sees the new layout")
        elif mode == "winiso":
            engine.flash_winiso(iso, disk, prog, _cancel, _log_line)
        else:
            letter = engine.install_ventoy(disk, prog, _cancel, _log_line, _need_user)
            if mode == "ventoy":
                prog.stage("copy", f"Copying {iso.name} onto the Ventoy stick…")
                engine.copy_file(iso, Path(f"{letter}:\\") / iso.name, prog.frac, _cancel, _log_line)
        ok, msg = True, f"{entry['name'] if entry else iso.name} is on the stick. Safely eject it, then boot from USB (usually F12 / F2 / Esc at power-on)."
        if mode == "ventoy_only":
            msg = "Ventoy is installed. Copy as many ISO files as you like onto the stick's big partition, then boot from it and pick one."
        if params.get("delete_iso") and not custom:
            iso.unlink(missing_ok=True)
    except Cancelled:
        msg = "Cancelled. If the write had started, the stick is now incomplete - flash it again or use 'Restore USB' to make it usable as normal storage."
        _log_line("Cancelled by user.")
    except FlashError as exc:
        msg = str(exc)
        _log_line("ERROR: " + msg)
    except Exception as exc:
        _log.exception("usb flash failed")
        import traceback
        msg = f"Unexpected error: {exc}"
        _log_line("ERROR: " + msg)
        for line in traceback.format_exc().strip().splitlines()[-4:]:
            _log_line("  " + line.strip())
    else:
        _log_line("Finished successfully.")
    emit("usb.done", {"ok": ok, "message": msg})


def _need_user(text: str) -> None:
    _user.clear()
    emit("usb.need_user", {"message": text})
    _user.wait(1800)


def _guard(fn, params) -> bool:
    if not _busy.acquire(blocking=False):
        return False
    _cancel.clear()

    def run():
        try:
            fn(params)
        finally:
            _busy.release()
    threading.Thread(target=run, daemon=True, name="usb-job").start()
    return True


_check_lock = threading.Lock()


def run_link_check(log) -> dict:
    """Shared by the USB Flasher and the VM Builder: tests every OS download, prints each result to that page's Activity log."""
    if not _check_lock.acquire(blocking=False):
        log("A link check is already running - wait for it to finish.")
        return {"ok": 0, "bad": 0, "busy": True}
    try:
        n = len(catalog.OS_LIST)
        log(f"--- Checking {n} ISO download links (takes up to a minute) ---")
        rows = engine.check_links(log)
        good = sum(1 for r in rows if r["ok"])
        log(f"--- link check finished: {good} OK, {len(rows) - good} BAD ---")
        return {"ok": good, "bad": len(rows) - good, "busy": False}
    finally:
        _check_lock.release()


@rpc("usb.check_links")
def usb_check_links():
    return run_link_check(_log_line)


@rpc("usb.drives")
def usb_drives():
    _log_line("Scanning for USB drives…")
    return engine.list_usb_drives(_log_line)


@rpc("usb.catalog")
def usb_catalog():
    return {"os": catalog.public(), "groups": catalog.GROUPS, "cache": str(CACHE)}


@rpc("usb.start")
def usb_start(disk: dict, os_id: str = "", iso_path: str = "", verify: bool = True, delete_iso: bool = False):
    return _guard(_flash, {"disk": disk, "os_id": os_id, "iso_path": iso_path, "verify": verify, "delete_iso": delete_iso})


@rpc("usb.cancel")
def usb_cancel():
    _cancel.set()
    _user.set()
    return True


@rpc("usb.continue")
def usb_continue():
    _user.set()
    return True


def _restore(p: dict) -> None:
    from app.state import state
    ok, msg = False, ""
    try:
        if not state.is_admin:
            raise FlashError("DWUT must run as Administrator.")
        d, fs, label = p["disk"], p["fs"], re.sub(r'[^A-Za-z0-9_ -]', '', p.get("label") or "USB")[:11] or "USB"
        engine.revalidate(d, _log_line)
        _log_line(f"Restoring Disk {d['number']} ({d.get('name', 'USB drive')}) to a normal {fs.upper()} drive named '{label}'")
        letter = engine.free_letter()
        if fs == "fat32" and d["size"] > 32 * 1024 ** 3:
            fs = "exfat"
        pr = Prog(PLANS["simple"])
        pr.stage("work", "Erasing and formatting…", True)
        engine.diskpart([f"select disk {int(d['number'])}", "attributes disk clear readonly noerr", "online disk noerr", "clean", "convert mbr",
                         "create partition primary", f'format fs={fs} quick label="{label}"', f"assign letter={letter}"], 900, _log_line, _cancel)
        ok, msg = True, f"Done - the stick is now a normal {fs.upper()} drive ({letter}:). Name: {label}."
        _log_line("Finished successfully.")
    except Cancelled:
        msg = "Cancelled."
        _log_line("Cancelled by user.")
    except FlashError as exc:
        msg = str(exc)
        _log_line("ERROR: " + msg)
    except Exception as exc:
        _log.exception("usb restore failed")
        msg = f"Unexpected error: {exc}"
        _log_line("ERROR: " + msg)
    emit("usb.done", {"ok": ok, "message": msg})


@rpc("usb.restore")
def usb_restore(disk: dict, fs: str = "exfat", label: str = "USB"):
    return _guard(_restore, {"disk": disk, "fs": fs, "label": label})


def _backup(p: dict) -> None:
    ok, msg = False, ""
    try:
        d, dest = p["disk"], Path(p["path"])
        engine.revalidate(d, _log_line)
        _log_line(f"Backing up Disk {d['number']} ({d.get('name', 'USB drive')}, {int(d['size']) / 1e9:.1f} GB) to {dest}")
        pr = Prog(PLANS["simple"])
        pr.stage("work", "Reading the whole stick into an image file…")
        size, done, t0, last = int(d["size"]), 0, time.monotonic(), 0.0
        if dest.anchor and dest.parent.exists():
            free = __import__("shutil").disk_usage(dest.parent).free
            if free < size:
                raise FlashError(f"Not enough free space for the image ({size / 1e9:.1f} GB needed).")
        with open(engine.raw_path(d["number"]), "rb", buffering=0) as src, open(dest, "wb") as out:
            while done < size:
                if _cancel.is_set():
                    raise Cancelled()
                b = src.read(min(engine.CHUNK, size - done))
                if not b:
                    break
                out.write(b)
                done += len(b)
                now = time.monotonic()
                if now - last > 0.3:
                    last = now
                    sp = done / max(now - t0, 0.001)
                    pr.frac(done / size, sp, (size - done) / sp if sp else 0)
        ok, msg = True, f"Saved {done / 1e9:.1f} GB to {dest}. Restore it later with 'Flash a USB stick' > 'Use my own ISO/IMG file'."
        _log_line(f"Read {done / 1e9:.2f} GB in {time.monotonic() - t0:.0f} s. Finished successfully.")
    except Cancelled:
        msg = "Cancelled - the partial image file was kept."
        _log_line("Cancelled by user (partial image kept).")
    except FlashError as exc:
        msg = str(exc)
        _log_line("ERROR: " + msg)
    except Exception as exc:
        _log.exception("usb backup failed")
        msg = f"Unexpected error: {exc}"
        _log_line("ERROR: " + msg)
    emit("usb.done", {"ok": ok, "message": msg})


@rpc("usb.backup")
def usb_backup(disk: dict, path: str):
    return _guard(_backup, {"disk": disk, "path": path})


# ── download ISOs straight onto a Ventoy stick ────────────────────────────────

class _MultiProg(Prog):
    """Progress for a many-ISO job: every stage reports 0..1 inside a window (lo..hi) of the overall bar that the job moves along."""
    def __init__(self):
        super().__init__([("install", 1), ("resolve", 1), ("download", 1), ("checksum", 1), ("copy", 1)])
        self.lo, self.hi = 0.0, 0.0

    def span(self, lo: float, hi: float) -> None:
        self.lo, self.hi = lo, hi

    def _push(self, speed, eta) -> None:
        emit(self.event, {"stage": self.plan[self.idx][0] if self.idx >= 0 else "", "msg": self.msg, "indeterminate": self.indet,
                          "stage_frac": self._f, "overall": min(1.0, self.lo + (self.hi - self.lo) * self._f), "speed": speed, "eta": eta,
                          "stages": [n for n, _ in self.plan]})


def _ventoy_isos(params: dict) -> None:
    from app.state import state
    disk, ids, delete_iso = params["disk"], params.get("os_ids") or [], bool(params.get("delete_iso"))
    ok, msg = False, ""
    prog = _MultiProg()
    part = None
    try:
        if not state.is_admin:
            raise FlashError("DWUT must run as Administrator to prepare a USB drive. Restart it as admin and try again.")
        entries = [e for e in (catalog.get(i) for i in ids) if e and e["id"] != "ventoy"]
        if not entries:
            raise FlashError("No operating systems were selected.")
        engine.revalidate(disk, _log_line)
        _log_line(f"Starting: {len(entries)} ISO(s) -> Ventoy stick on Disk {disk.get('number')} ({disk.get('name', 'USB drive')}, {disk.get('size', 0) / 1e9:.1f} GB)")
        prog.span(0.0, 0.08)
        letter = engine.install_ventoy(disk, prog, _cancel, _log_line, _need_user)      # reuses Ventoy when the stick has it, installs it otherwise
        root = Path(f"{letter}:\\")
        done_names, failed = [], []
        each = 0.92 / len(entries)
        for k, entry in enumerate(entries):
            base = 0.08 + each * k
            name = entry["name"]
            _log_line(f"── {k + 1} of {len(entries)}: {name} ──")
            try:
                prog.span(base, base)
                prog.stage("resolve", f"Finding the latest {name}…", True)
                r = engine.resolve(entry, _log_line)
                iso, sha = CACHE / r["filename"], r["sha256"]
                _log_line(f"Latest: {r['filename']}" + ("" if sha else "  (no published checksum found)"))
                prog.span(base, base + each * 0.6)
                cached_ok = iso.exists() and iso.stat().st_size > 1_000_000
                if cached_ok and sha:
                    prog.stage("checksum", "Checking your previously downloaded copy…")
                    cached_ok = engine.sha256_file(iso, prog.frac, _cancel) == sha
                if not cached_ok:
                    prog.stage("download", f"Downloading {r['filename']} ({k + 1} of {len(entries)})")
                    engine.download(r["urls"], iso, prog.dl, _cancel, _log_line)
                    if sha:
                        prog.span(base + each * 0.6, base + each * 0.7)
                        prog.stage("checksum", "Verifying download integrity (SHA-256)…")
                        if engine.sha256_file(iso, prog.frac, _cancel) != sha:
                            iso.unlink(missing_ok=True)
                            raise FlashError("the download failed its checksum and was deleted - try again")
                        _log_line("Checksum OK.")
                else:
                    _log_line("Using the already-downloaded ISO from the library.")
                dst = root / r["filename"]
                size = iso.stat().st_size
                if dst.exists() and dst.stat().st_size == size:
                    _log_line(f"{r['filename']} is already on the stick - skipping the copy.")
                else:
                    prog.span(base + each * 0.7, base + each)
                    prog.stage("copy", f"Copying {r['filename']} onto the Ventoy stick…")
                    part = root / (r["filename"] + ".part")                 # Ventoy ignores .part, so a half-copied file never shows up in its menu
                    try:
                        engine.copy_file(iso, part, prog.frac, _cancel, _log_line)
                        if dst.exists():
                            dst.unlink()
                        part.replace(dst)
                    finally:
                        if part.exists():
                            try:
                                part.unlink()
                            except OSError:
                                pass
                        part = None
                done_names.append(r["filename"])
                if delete_iso:
                    iso.unlink(missing_ok=True)
                    _log_line(f"Removed {iso.name} from this PC's ISO library.")
            except FlashError as exc:
                failed.append(f"{name}: {exc}")
                _log_line(f"  ! {name} failed - {exc}")
        prog.span(1.0, 1.0)
        prog.stage("copy", "Done")
        if done_names:
            ok = True
            msg = f"{len(done_names)} ISO(s) are on the Ventoy stick ({letter}:). Safely eject it, boot from USB and pick one in Ventoy's menu."
            if failed:
                msg += f"\n\n{len(failed)} failed:\n" + "\n".join("• " + f for f in failed[:6])
        else:
            msg = "Nothing was copied.\n" + "\n".join("• " + f for f in failed[:6])
    except Cancelled:
        msg = "Cancelled. ISOs already copied stay on the stick; a half-copied one was removed."
        _log_line("Cancelled by user.")
    except FlashError as exc:
        msg = str(exc)
        _log_line("ERROR: " + msg)
    except Exception as exc:
        _log.exception("ventoy iso job failed")
        msg = f"Unexpected error: {exc}"
        _log_line("ERROR: " + msg)
    else:
        _log_line("Finished." if ok else "Finished with errors.")
    emit("usb.done", {"ok": ok, "message": msg})


@rpc("usb.ventoy_check")
def usb_ventoy_check(disk: dict):
    """True when the chosen stick already has Ventoy (so nothing will be erased); None when that cannot be told."""
    mbr = engine._read_mbr(int(disk["number"]))
    return None if mbr is None else bool(engine._mbr_is_ventoy(mbr))


@rpc("usb.ventoy_isos")
def usb_ventoy_isos(disk: dict, os_ids: list, delete_iso: bool = False):
    return _guard(_ventoy_isos, {"disk": disk, "os_ids": os_ids, "delete_iso": delete_iso})


@rpc("usb.library")
def usb_library():
    out = []
    if CACHE.exists():
        for f in sorted(CACHE.iterdir(), key=lambda x: -x.stat().st_mtime):
            if f.is_file():
                out.append({"name": f.name, "size": f.stat().st_size, "partial": f.suffix == ".part", "mtime": f.stat().st_mtime})
    return {"path": str(CACHE), "files": out}


@rpc("usb.delete_iso")
def usb_delete_iso(name: str):
    p = (CACHE / name).resolve()
    if p.parent == CACHE.resolve() and p.exists():
        size = p.stat().st_size
        p.unlink()
        _log_line(f"Deleted {name} from the ISO library ({size / 1e9:.2f} GB freed).")
    else:
        _log_line(f"Could not delete {name}: not found in the ISO library.")
    return True
