# Copyright © 2026 Darko / Darko.Dev
"""api/oneclick_api.py - the DWUT 1 CLICK BUTTON (see modules/oneclick/runner.py)."""
from __future__ import annotations

import threading

from core.logger import get_logger
from server import emit, rpc

_log = get_logger("api.oneclick")
_cancel = threading.Event()
_lock = threading.Lock()
_state = {"running": False, "steps": [], "log": []}


def _log_line(m: str) -> None:
    _state["log"].append(str(m))
    del _state["log"][:-400]
    emit("oneclick.log", str(m))


def _step(sid, label, state, idx, total, note="") -> None:
    for s in _state["steps"]:
        if s["id"] == sid:
            s["state"], s["note"] = state, note
    emit("oneclick.step", {"id": sid, "label": label, "state": state, "idx": idx, "total": total, "note": note})


@rpc("oneclick.static")
def oneclick_static():
    """Everything the two popups need: the bloat list (this PC's OS only), installed packages, and the tweak list - all pre-filtered
    exactly like the Debloat and Tweaks pages, plus which entries are ticked by default."""
    from modules.debloat.operations import BLOATWARE_DB, FEATURES, feature_applies, scan_installed_appx
    from modules.oneclick.runner import NEVER_TWEAKS
    from modules.system.platform_info import is_windows_11
    win11 = is_windows_11()
    mine = "Windows 11" if win11 else "Windows 10"
    try:
        installed = scan_installed_appx()
    except Exception:
        installed = {}
    keep_pkgs = ("microsoft.windows.photos", "microsoft.zunemusic", "xbox", "microsoft.powerautomatedesktop")   # Photos, Groove, anything Xbox, Power Automate
    bloat, seen = [], set()
    for e in BLOATWARE_DB.get(mine, []):
        pk = e["pkg"].lower()
        if pk in seen:
            continue
        seen.add(pk)
        keep = any(k in pk for k in keep_pkgs)
        inst = installed.get(pk)
        bloat.append(dict(e, installed=inst, default=bool(inst is not False and not keep), protected=keep))
    # same hiding rules as the Tweaks page
    hide = {"xbox", "game_mode", "recall", "copilot", "telemetry", "telemetry_tasks", "advertising", "location", "activity_history", "onedrive",
            "onedrive_remove", "widgets", "phonelink", "start_menu_bing_search", "consumer_features", "dark_mode"}
    tweaks = []
    for f in FEATURES:
        if not feature_applies(f) or f.key in hide or f.key in NEVER_TWEAKS:
            continue
        tweaks.append(dict(key=f.key, name=f.name, desc=f.desc, recommended=f.recommended, severity=f.severity, category=f.category,
                           default=bool(f.recommended)))
    power_active, battery = None, False
    try:
        from modules.system import power_modes as pm
        power_active = "extreme" if pm.is_extreme_performance_active() else "ultimate" if pm.is_ultimate_performance_active() else None
    except Exception:
        pass
    try:
        import psutil
        battery = psutil.sensors_battery() is not None            # laptop / tablet
    except Exception:
        pass
    sysopt, chassis = [], "Unknown"
    try:
        from modules.oneclick import sysopt as so
        sysopt = so.available_items(win11)
        chassis = so.chassis_type()
    except Exception:
        _log.exception("could not build the system-optimizations list")
    return {"sysopt": sysopt, "chassis": chassis, "bloat": bloat, "tweaks": tweaks, "is_win11": win11, "running": _state["running"], "power_active": power_active, "has_battery": battery}


@rpc("oneclick.start")
def oneclick_start(bloat: list | None = None, tweaks: list | None = None, power: str = "none", visual: dict | None = None, sysopt: list | None = None):
    from app.state import state
    from modules.oneclick.runner import Job
    if not state.is_admin:
        return {"ok": False, "error": "DWUT must run as Administrator for the 1 Click Button. Restart it as admin and try again."}
    if not _lock.acquire(blocking=False):
        return {"ok": False, "error": "A 1 Click run is already in progress."}
    _cancel.clear()
    job = Job(bloat or [], tweaks or [], _log_line, _step, _cancel, power, visual, sysopt)
    _state.update(running=True, steps=[dict(s, state="wait", note="") for s in job.plan_labels()], log=[])

    def work():
        summary = {}
        try:
            _log_line("DWUT 1 CLICK BUTTON started.")
            summary = job.run()
            _log_line("Finished." if not summary.get("cancelled") else "Stopped.")
        except BaseException as exc:                                                    # noqa: BLE001
            _log.exception("one-click crashed")
            _log_line(f"ERROR: {exc}")
            summary = {"results": job.results, "ok": 0, "total": len(job.results), "restart_needed": job.restart_needed, "error": str(exc)}
        finally:
            _state["running"] = False
            _lock.release()
            emit("oneclick.done", summary)

    threading.Thread(target=work, daemon=True, name="oneclick").start()
    return {"ok": True, "steps": _state["steps"]}


@rpc("oneclick.cancel")
def oneclick_cancel():
    _cancel.set()
    return True


@rpc("oneclick.state")
def oneclick_state():
    return {"running": _state["running"], "steps": _state["steps"], "log": _state["log"][-200:]}
