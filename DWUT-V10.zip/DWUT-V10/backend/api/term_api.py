# Copyright © 2026 Darko / Darko.Dev
"""api/term_api.py - backend for the custom (reskinned) Command Prompt / PowerShell windows.

The window is only a skin; the shell is the real one.  See modules/system/termpty.py.

  term.start   {kind, cols, rows, admin, wid}  -> {ok, sid, title, admin, note?}   (wid = Electron window id, added by main.js)
  term.write   {sid, data}
  term.resize  {sid, cols, rows}
  term.close   {sid}
  term.close_window {wid}
events:  term.data {wid, sid, data}   term.exit {wid, sid, code}
"""
from __future__ import annotations

import json
import os
import secrets
import socket
import subprocess
import sys
import threading
import uuid
from pathlib import Path

from core.logger import get_logger
from modules.system.termpty import KINDS, LocalPty, _is_admin
from server import emit, rpc

_log = get_logger("api.term")
_sessions: dict = {}
_lock = threading.Lock()
_HOST = Path(__file__).resolve().parent.parent / "term_host.py"


class _Session:
    def __init__(self, sid: str, wid, kind: str, admin: bool) -> None:
        self.sid, self.wid, self.kind, self.admin = sid, wid, kind, admin
        self.pty = None          # LocalPty (same privilege level as DWUT)
        self.conn = None         # socket to a helper process (different privilege level)
        self.helper_lock = threading.Lock()
        self.dead = False

    def on_data(self, d: str) -> None:
        emit("term.data", {"wid": self.wid, "sid": self.sid, "data": d})

    def on_exit(self, code: int) -> None:
        if self.dead:
            return
        self.dead = True
        emit("term.exit", {"wid": self.wid, "sid": self.sid, "code": int(code)})
        with _lock:
            _sessions.pop(self.sid, None)

    def send_helper(self, obj: dict) -> None:
        if self.conn is None:
            return
        with self.helper_lock:
            try:
                self.conn.sendall((json.dumps(obj) + "\n").encode("utf-8"))
            except OSError:
                pass


def _py_for_helper() -> str:
    exe = sys.executable
    w = os.path.join(os.path.dirname(exe), "pythonw.exe")
    return w if os.name == "nt" and os.path.exists(w) else exe


def _launch_helper(port: int, token: str, kind: str, cols: int, rows: int, admin: bool, elevate: bool) -> str:
    """Start term_host.py.  -> '' on success, else a human-readable error."""
    py = _py_for_helper()
    args = [str(_HOST), str(port), token, kind, str(cols), str(rows), "1" if admin else "0"]
    if os.name != "nt":                                           # development fallback: plain child process
        subprocess.Popen([py, *args])
        return ""
    if elevate:                                                   # UAC prompt
        import ctypes
        params = subprocess.list2cmdline(args)
        rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", py, params, str(_HOST.parent), 0)
        if rc <= 32:
            return "Administrator access was cancelled (or blocked), so the terminal was not opened."
        return ""
    cmdline = subprocess.list2cmdline([py, *args])                # de-elevate: run the helper with a normal user token
    try:
        subprocess.Popen(["runas.exe", "/trustlevel:0x20000", cmdline], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return ""
    except Exception as exc:
        return f"Could not start a non-administrator shell: {exc}"


def _start_via_helper(s: _Session, cols: int, rows: int, elevate: bool) -> str:
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port, token = srv.getsockname()[1], secrets.token_hex(24)
    err = _launch_helper(port, token, s.kind, cols, rows, s.admin, elevate)
    if err:
        srv.close()
        return err
    srv.settimeout(90)                                            # time to answer the UAC prompt
    try:
        conn, _ = srv.accept()
    except OSError:
        srv.close()
        return "The terminal helper did not start in time."
    finally:
        try:
            srv.close()
        except OSError:
            pass
    conn.settimeout(10)
    buf = b""
    try:
        while b"\n" not in buf:
            c = conn.recv(4096)
            if not c:
                return "The terminal helper closed the connection."
            buf += c
        first, buf = buf.split(b"\n", 1)
        if json.loads(first.decode("utf-8")).get("hello") != token:
            conn.close()
            return "The terminal helper failed authentication."
    except Exception as exc:
        return f"Terminal helper handshake failed: {exc}"
    conn.settimeout(None)
    s.conn = conn

    def reader(rest: bytes = buf) -> None:
        b = rest
        try:
            while True:
                while b"\n" in b:
                    line, b = b.split(b"\n", 1)
                    try:
                        m = json.loads(line.decode("utf-8"))
                    except Exception:
                        continue
                    if "d" in m:
                        s.on_data(m["d"])
                    elif "x" in m:
                        s.on_exit(m["x"])
                        return
                c = conn.recv(65536)
                if not c:
                    break
                b += c
        except OSError:
            pass
        s.on_exit(0)

    threading.Thread(target=reader, daemon=True, name="term-helper-rx").start()
    return ""


@rpc("term.info")
def term_info(**_ignored):
    return {"is_admin": _is_admin(), "kinds": KINDS}


@rpc("term.start")
def term_start(kind: str = "cmd", cols: int = 80, rows: int = 24, admin: bool = False, wid=None, **_ignored):
    if kind not in KINDS:
        return {"ok": False, "message": f"Unknown shell: {kind}"}
    app_admin = _is_admin()
    sid = uuid.uuid4().hex[:12]
    s = _Session(sid, wid, kind, bool(admin))
    note = ""
    try:
        if bool(admin) == app_admin:                              # same privilege level as DWUT -> host it right here
            s.pty = LocalPty(kind, cols, rows, bool(admin), s.on_data, s.on_exit)
        else:
            err = _start_via_helper(s, cols, rows, elevate=bool(admin))
            if err:
                if admin:
                    return {"ok": False, "message": err}
                note = "Could not drop administrator rights, so this shell is elevated."   # de-elevation failed: say so, keep working
                s.admin = True
                s.pty = LocalPty(kind, cols, rows, True, s.on_data, s.on_exit)
    except Exception as exc:
        _log.error("term.start failed: %s", exc)
        return {"ok": False, "message": str(exc)}
    with _lock:
        _sessions[sid] = s
    title = KINDS[kind] + ("  (Administrator)" if s.admin else "")
    return {"ok": True, "sid": sid, "title": title, "admin": s.admin, "note": note}


@rpc("term.write")
def term_write(sid: str, data: str, **_ignored):
    s = _sessions.get(sid)
    if not s:
        return False
    if s.pty:
        s.pty.write(data)
    else:
        s.send_helper({"w": data})
    return True


@rpc("term.resize")
def term_resize(sid: str, cols: int, rows: int, **_ignored):
    s = _sessions.get(sid)
    if not s:
        return False
    if s.pty:
        s.pty.resize(cols, rows)
    else:
        s.send_helper({"r": [int(cols), int(rows)]})
    return True


def _close(s: _Session) -> None:
    s.dead = True
    if s.pty:
        s.pty.close()
    else:
        s.send_helper({"k": 1})
        try:
            s.conn and s.conn.close()
        except OSError:
            pass
    with _lock:
        _sessions.pop(s.sid, None)


@rpc("term.close")
def term_close(sid: str, **_ignored):
    s = _sessions.get(sid)
    if s:
        _close(s)
    return True


@rpc("term.close_window")
def term_close_window(wid):
    for s in [x for x in list(_sessions.values()) if x.wid == wid]:
        _close(s)
    return True


def shutdown_terminals() -> None:
    for s in list(_sessions.values()):
        try:
            _close(s)
        except Exception:
            pass
