# Copyright © 2026 Darko / Darko.Dev
"""api/health_api.py - the Tools > Health tab.  The scan is real (see modules/health/scanner.py); results stream to the UI as each check finishes."""
from __future__ import annotations

import threading
import uuid

from core.logger import get_logger
from modules.health import motherboard, scanner
from server import emit, rpc

_log = get_logger("api.health")
_state = {"id": None}
_lock = threading.Lock()


@rpc("health.scan")
def health_scan():
    """Start a scan in the background (returns at once); progress arrives as 'health.progress', the finished report as 'health.done'."""
    with _lock:
        if _state["id"]:
            return {"ok": True, "scan": _state["id"], "already_running": True}
        sid = uuid.uuid4().hex[:8]
        _state["id"] = sid

    def run():
        try:
            res = scanner.scan(emit, sid)
            emit("health.done", {"scan": sid, "result": res})
        except Exception as exc:
            _log.exception("health scan failed")
            emit("health.done", {"scan": sid, "error": str(exc)})
        finally:
            with _lock:
                _state["id"] = None

    threading.Thread(target=run, daemon=True, name="health-scan").start()
    return {"ok": True, "scan": sid}


@rpc("health.last")
def health_last():
    return {"ok": True, "result": scanner.last_result(), "running": _state["id"]}


@rpc("health.motherboard")
def health_motherboard():
    """Motherboard / BIOS / firmware detection on its own - the data a future BIOS category will use."""
    return {"ok": True, "board": motherboard.detect()}


# ── Fix & Optimize (modules/health/fixes.py) ───────────────────────────────────────────────────────────────────────
@rpc("health.fix_plan")
def health_fix_plan(category: str = "all", card: str | None = None):
    """What a Fix & Optimize run would do for one component (card), one category, or 'all' - each step marked 'fixes a found problem' or 'routine'."""
    from modules.health import fixes
    return {"ok": True, **fixes.plan(category, card), "running": fixes.running()}


@rpc("health.fix")
def health_fix(category: str = "all", card: str | None = None, only: list | None = None):
    """Run the chosen steps in the background.  Progress: 'health.fix_progress' / 'health.fix_log'; the end (with the re-scanned result): 'health.fix_done'."""
    from modules.health import fixes
    rid = uuid.uuid4().hex[:8]
    if not fixes.start(category, card, only, emit, rid):
        return {"ok": False, "error": "A fix is already running - wait for it to finish."}
    return {"ok": True, "run": rid}


@rpc("health.fix_running")
def health_fix_running():
    from modules.health import fixes
    return {"ok": True, "running": fixes.running()}


@rpc("health.restart")
def health_restart():
    from modules.health import fixes
    return {"ok": fixes.restart_now(20)}


@rpc("health.restart_uefi")
def health_restart_uefi():
    from modules.health import fixes
    return {"ok": fixes.restart_to_uefi(15)}


@rpc("health.bios_page")
def health_bios_page(card: dict | None = None):
    from modules.health import fixes
    state, note = fixes.bios_page(card)
    return {"ok": True, "note": note}


# ── real driver updates (modules/health/driver_update.py) ─────────────────────────────────────────────────────────
@rpc("health.driver_check")
def health_driver_check():
    """Ask Windows Update what driver updates exist (can take a minute or two).  Result arrives as the event 'health.drv_check'."""
    from modules.health import driver_update as du
    if du.busy():
        return {"ok": False, "error": "A driver update is running - wait for it to finish."}

    def work():
        try:
            emit("health.drv_check", du.check(lambda m: emit("health.drv_log", {"text": m})))
        except Exception as exc:
            _log.exception("driver check failed")
            emit("health.drv_check", {"ok": False, "error": str(exc)[:200], "updates": [], "problems": [], "admin": False})
    threading.Thread(target=work, daemon=True, name="drv-check").start()
    return {"ok": True}


@rpc("health.driver_install")
def health_driver_install(ids: list | None = None):
    """Install the chosen Windows Update driver updates (ids = UpdateIDs from health.driver_check; empty = all).
    Events: 'health.drv_event' (per update: start / stage / result), 'health.drv_log', and at the end 'health.drv_done' with the verified summary."""
    from modules.health import driver_update as du
    if du.busy():
        return {"ok": False, "error": "A driver update is already running."}

    def work():
        try:
            res = du.install(list(ids or []), lambda m: emit("health.drv_log", {"text": m}), lambda e: emit("health.drv_event", e))
        except Exception as exc:
            _log.exception("driver install failed")
            res = {"ok": False, "error": str(exc)[:200], "results": [], "changed": [], "reboot": False, "problems_before": [], "problems_after": []}
        emit("health.drv_done", res)
    threading.Thread(target=work, daemon=True, name="drv-install").start()
    return {"ok": True}
