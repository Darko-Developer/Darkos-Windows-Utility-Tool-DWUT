r"""api/tbok_api.py - the "TBOK (CORPORATE AND BUSINESS)" button: runs The Beard of Knowledge's TBOK Windows Performance Optimizer.

The tool is bundled UNMODIFIED in backend/vendor/tbok/ (see SOURCE.txt there).  A packaged app keeps its files read-only and the tool writes its
log next to itself, so the .bat is copied to %LOCALAPPDATA%\DWUT\TBOK\ first and run from there in its own console window - exactly as its author
intended: it asks for administrator rights itself (when DWUT is not already elevated), shows its own menu, makes a restore point, and logs.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

from core.logger import get_logger
from server import rpc

_log = get_logger("api.tbok")
BAT = "TBOKwinOptimizer_v1-6-2.bat"
SRC_DIR = Path(__file__).resolve().parents[1] / "vendor" / "tbok"
CREATE_NEW_CONSOLE = getattr(subprocess, "CREATE_NEW_CONSOLE", 0x00000010)


def work_dir() -> Path:
    return Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT" / "TBOK"


def command_line(bat: Path) -> str:
    # `/s` makes cmd always strip exactly the outer pair of quotes, so paths containing spaces, ( ) or & survive.
    return f'cmd.exe /d /s /c ""{bat}""'


@rpc("tbok.run")
def tbok_run():
    src = SRC_DIR / BAT
    if not src.is_file():
        return {"ok": False, "error": f"The TBOK tool is missing from this DWUT install ({src}). Reinstall DWUT to restore it."}
    try:
        dst_dir = work_dir()
        dst_dir.mkdir(parents=True, exist_ok=True)
        dst = dst_dir / BAT
        shutil.copyfile(src, dst)                                   # fresh, unmodified copy every time
        subprocess.Popen(command_line(dst), cwd=str(dst_dir), creationflags=CREATE_NEW_CONSOLE, close_fds=True)
    except OSError as exc:
        _log.exception("could not start TBOK")
        return {"ok": False, "error": f"Windows would not start the TBOK tool: {exc}"}
    _log.info("TBOK started: %s", dst)
    return {"ok": True, "path": str(dst), "log_dir": str(dst_dir)}
