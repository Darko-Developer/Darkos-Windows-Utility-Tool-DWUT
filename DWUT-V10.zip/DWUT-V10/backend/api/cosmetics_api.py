# Copyright © 2026 Darko / Darko.Dev
"""
api/cosmetics_api.py - personalisation: imported images / GIFs / videos / sounds and the audio-reactive meter.
Everything here is free for everyone.

AUDIO SYNC  (backgrounds only)
  Reads the loudness of individual apps' audio sessions (Windows audio session meters) and uses ONLY browsers and games.
  Calls/voice apps (Discord, Teams, Zoom, Skype ...) are never read: they are excluded by name, and if one of them has live
  audio the sync pauses.  Only the loudness number is read - never the audio itself.
"""
from __future__ import annotations

import hashlib
import math
import os
import re
import shutil
import threading
import time
from pathlib import Path

from core.logger import get_logger
from server import emit, rpc

_log = get_logger("api.cosmetics")

BASE = Path(os.environ.get("LOCALAPPDATA", ".")) / "DWUT"
ASSET_DIR = BASE / "cosmetics"

# ----------------------------------------------------------------------------------------------------------------------
# imported assets (images / GIFs / videos / sounds)
# ----------------------------------------------------------------------------------------------------------------------

_KINDS = {
    "image": ({".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".mp4", ".webm"}, 120 * 1024 * 1024),
    "sound": ({".wav", ".mp3", ".ogg", ".m4a", ".flac"}, 8 * 1024 * 1024),
}


@rpc("cosmetics.import_asset")
def cosmetics_import_asset(path: str, kind: str):
    exts, limit = _KINDS.get(kind, (set(), 0))
    src = Path(path)
    if not src.is_file() or src.suffix.lower() not in exts:
        return {"ok": False, "error": f"Pick a {'/'.join(sorted(exts))} file."}
    if src.stat().st_size > limit:
        return {"ok": False, "error": f"That file is too large (limit {limit // 1048576} MB)."}
    folder = ASSET_DIR / kind
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / (re.sub(r"[^A-Za-z0-9._-]", "_", src.stem)[:40] + "_" + hashlib.sha1(str(src).encode()).hexdigest()[:6] + src.suffix.lower())
    shutil.copy2(src, dest)
    return {"ok": True, "path": str(dest), "name": src.name}


@rpc("cosmetics.assets")
def cosmetics_assets(kind: str):
    folder = ASSET_DIR / kind
    out = []
    if folder.is_dir():
        for f in sorted(folder.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
            out.append({"path": str(f), "name": re.sub(r"_[0-9a-f]{6}(\.[^.]+)$", r"\1", f.name)})
    return out


@rpc("cosmetics.delete_asset")
def cosmetics_delete_asset(path: str):
    p = Path(path)
    try:
        if ASSET_DIR in p.resolve().parents:
            p.unlink()
            return True
    except OSError:
        pass
    return False


PREFS_FILE = ASSET_DIR / "prefs.json"


@rpc("cosmetics.get_prefs")
def cosmetics_get_prefs():
    try:
        if PREFS_FILE.is_file():
            import json
            return {"ok": True, "prefs": json.loads(PREFS_FILE.read_text(encoding="utf-8"))}
    except Exception as e:
        _log.warning(f"Failed to read cosmetics prefs: {e}")
    return {"ok": False, "prefs": {}}


@rpc("cosmetics.set_prefs")
def cosmetics_set_prefs(prefs: dict):
    try:
        import json
        ASSET_DIR.mkdir(parents=True, exist_ok=True)
        PREFS_FILE.write_text(json.dumps(prefs, indent=2), encoding="utf-8")
        return {"ok": True}
    except Exception as e:
        _log.warning(f"Failed to write cosmetics prefs: {e}")
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------------------------------------------------
# audio-reactive meter: browsers + games only
# ----------------------------------------------------------------------------------------------------------------------

_BROWSERS = {"chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe", "opera_gx.exe", "vivaldi.exe", "arc.exe", "chromium.exe",
             "librewolf.exe", "waterfox.exe", "tor.exe", "yandex.exe", "iexplore.exe"}
_MUSIC_APPS = {"spotify.exe", "itunes.exe", "applemusic.exe", "vlc.exe", "foobar2000.exe", "musicbee.exe",
               "tidal.exe", "deezer.exe", "wmplayer.exe", "mediaplayer.exe", "aimp.exe", "winamp.exe",
               "qobuz.exe", "amazon music.exe", "amazonmusic.exe", "plexamp.exe"}
# NEVER read: voice / video call apps (matched on the exe name, ignoring case)
_CALLS = {"discord.exe", "discordptb.exe", "discordcanary.exe", "discorddevelopment.exe", "update.exe", "teams.exe", "ms-teams.exe", "msteams.exe",
          "zoom.exe", "zoomit.exe", "skype.exe", "skypeapp.exe", "slack.exe", "webex.exe", "webexmta.exe", "telegram.exe", "whatsapp.exe",
          "signal.exe", "viber.exe", "mumble.exe", "ts3client_win64.exe", "teamspeak.exe", "teamspeak3.exe", "ventrilo.exe", "element.exe",
          "line.exe", "wechat.exe", "dingtalk.exe", "lark.exe", "feishu.exe", "guilded.exe", "revolt.exe", "jitsi meet.exe", "gotomeeting.exe",
          "bluejeans.exe", "ringcentral.exe", "messenger.exe", "meetingsapp.exe"}
_GAME_PATH = re.compile(r"\\(steamapps\\common|epic games|gog galaxy\\games|gog games|riot games|battle\.net|xboxgames|ubisoft game launcher\\games|"
                        r"ea games|origin games|rockstar games|games|itch\\apps|heroic)\\", re.I)
_CALL_TITLE = re.compile(r"meet\s[-\u2013]|google meet|zoom meeting|zoom\.us|microsoft teams|\bteams\b.*\bmeeting|discord|skype|whereby|jitsi|webex|"
                         r"huddle|facetime|messenger call|whatsapp.*call|on a call|video call|voice chat|telegram.*call", re.I)

_audio_thread: threading.Thread | None = None
_audio_stop = threading.Event()
_audio_status = {"running": False, "source": "", "paused": "", "available": True}


def _window_titles_by_pid(pids: set[int]) -> dict[int, list[str]]:
    import ctypes
    from ctypes import wintypes
    u32 = ctypes.windll.user32
    out: dict[int, list[str]] = {}
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _lp):
        if not u32.IsWindowVisible(hwnd):
            return True
        pid = wintypes.DWORD()
        u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value in pids:
            n = u32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                u32.GetWindowTextW(hwnd, buf, n + 1)
                out.setdefault(pid.value, []).append(buf.value)
        return True

    try:
        u32.EnumWindows(proc(cb), 0)
    except Exception:
        pass
    return out


def _classify(name: str, exe: str) -> str:
    """'call' | 'browser' | 'game' | ''  - only browser/music/game are measured."""
    n = (name or "").lower()
    if n in _CALLS:
        return "call"
    if n in _BROWSERS or n in _MUSIC_APPS:
        return "browser"
    if exe and _GAME_PATH.search(exe):
        return "game"
    return ""


def _get_master_meter():
    try:
        from pycaw.pycaw import AudioUtilities, IAudioMeterInformation
        import comtypes
        try:
            comtypes.CoInitialize()
        except Exception:
            pass
        sp = AudioUtilities.GetSpeakers()
        if sp and getattr(sp, "_dev", None):
            return sp._dev.Activate(IAudioMeterInformation._iid_, comtypes.CLSCTX_ALL, None).QueryInterface(IAudioMeterInformation)
    except Exception:
        pass
    return None


class _BeatDetector:
    """Frame-rate independent loudness follower + onset (beat) detector.

    Everything is driven by real elapsed time (not loop iterations), so the result is the same whether the loop
    runs at 60 or 110 Hz.  A beat needs: a fast envelope that jumps clearly above the short-term average
    (adaptive threshold = mean + k*deviation), a positive slope, a minimum gap, and a re-arm below the threshold -
    so one drum hit fires once, and sustained loud notes do not machine-gun."""

    def __init__(self) -> None:
        self.peak = 0.10        # slow peak follower (volume invariance)
        self.fast = 0.0         # fast envelope
        self.mean = 0.0         # short-term average (~0.5 s)
        self.dev = 0.0          # short-term mean deviation
        self.prev_fast = 0.0
        self.last_beat = 0.0
        self.armed = True
        self.last_t = 0.0

    @staticmethod
    def _a(dt: float, tau: float) -> float:
        return 1.0 - math.exp(-dt / tau)

    def update(self, raw: float, now: float) -> tuple[float, bool, float]:
        """-> (level 0..1, beat, beat strength 0..1)"""
        dt = min(0.08, max(0.001, now - self.last_t)) if self.last_t else 0.01
        self.last_t = now
        if raw > self.peak:
            self.peak = raw
        else:
            self.peak = max(0.03, self.peak - 0.22 * dt)
        x = min(1.0, raw / self.peak) if (self.peak > 0.004 and raw > 0.002) else 0.0
        self.fast += (x - self.fast) * self._a(dt, 0.012 if x > self.fast else 0.060)
        self.mean += (self.fast - self.mean) * self._a(dt, 0.45)
        self.dev += (abs(self.fast - self.mean) - self.dev) * self._a(dt, 0.60)
        thr = self.mean + max(0.07, 1.5 * self.dev)
        slope = (self.fast - self.prev_fast) / dt
        self.prev_fast = self.fast
        beat, strength = False, 0.0
        if self.fast < thr * 0.92:
            self.armed = True
        if (self.armed and self.fast > 0.14 and self.fast > thr and slope > 0.35
                and (now - self.last_beat) > 0.11):
            beat = True
            self.armed = False
            self.last_beat = now
            strength = max(0.55, min(1.0, (self.fast - self.mean) / 0.45 + 0.35))
        return x, beat, strength


def _peak_loop() -> None:
    try:
        import ctypes
        import comtypes
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioMeterInformation
        import psutil
    except Exception as exc:
        _audio_status.update(running=False, available=False, paused="Audio sync needs the 'pycaw' package (re-run the installer).")
        _log.info("audio sync unavailable: %s", exc)
        emit("cosmetics.audio_status", dict(_audio_status))
        return

    # Enable 1ms high-precision Windows multimedia timer
    try:
        ctypes.windll.winmm.timeBeginPeriod(1)
    except Exception:
        pass

    comtypes.CoInitialize()
    _audio_status.update(running=True, available=True, paused="", source="")
    emit("cosmetics.audio_status", dict(_audio_status))

    master_meter = _get_master_meter()
    active_src = ""
    call_active = False
    last_emit = 0.0
    last_level = 0.0
    last_session_scan = 0.0

    def scan_sessions():
        nonlocal active_src, call_active
        try:
            import comtypes
            comtypes.CoInitialize()
            from pycaw.pycaw import AudioUtilities, IAudioMeterInformation
            loudest_src = ""
            loudest_pk = 0.0
            call_speaking = False
            for s in AudioUtilities.GetAllSessions():
                try:
                    pr = s.Process
                    if pr is None:
                        continue
                    pname = pr.name()
                    try:
                        exe = pr.exe()
                    except Exception:
                        exe = ""
                    kind = _classify(pname, exe)
                    meter = s._ctl.QueryInterface(IAudioMeterInformation)
                    pk = float(meter.GetPeakValue())
                    if kind == "call":
                        if pk > 0.06:
                            call_speaking = True
                    else:
                        if pk > loudest_pk:
                            loudest_pk = pk
                            loudest_src = pname.replace(".exe", "").capitalize()
                except Exception:
                    continue
            if loudest_src and loudest_pk > 0.005:
                active_src = loudest_src
            call_active = call_speaking
        except Exception:
            pass
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass

    det = _BeatDetector()

    try:
        scan_sessions()
        while not _audio_stop.is_set():
            try:
                now = time.time()

                # Periodic non-blocking session scan every 3s for app source names and call apps
                if now - last_session_scan > 3.0:
                    last_session_scan = now
                    threading.Thread(target=scan_sessions, daemon=True, name="audio-session-scan").start()

                # Re-acquire master meter if needed (e.g. device switch or initial failure)
                if master_meter is None:
                    master_meter = _get_master_meter()
                    if master_meter is None:
                        time.sleep(0.08)
                        continue

                try:
                    raw_pk = float(master_meter.GetPeakValue())
                except Exception:
                    master_meter = None
                    time.sleep(0.04)
                    continue

                paused = ""
                if call_active and raw_pk < 0.04:
                    # Only voice call is active — pause reaction
                    raw_pk = 0.0
                    paused = "Call active (voice ignored)"

                norm, is_beat, strength = det.update(raw_pk, now)

                # Stream to Electron: ~60 Hz level updates (cheap, never floods the UI), beats go out IMMEDIATELY.
                # Every message carries its capture time so the UI can drop anything that arrived late.
                if is_beat or (norm > 0 and now - last_emit >= 0.016) or (norm == 0 and last_level > 0):
                    last_emit, last_level = now, norm
                    emit("cosmetics.audio", {"level": round(norm, 4), "beat": is_beat, "s": round(strength, 2), "t": round(now * 1000), "src": active_src})
                elif norm == 0 and now - last_emit > 0.25:
                    last_emit = now
                    emit("cosmetics.audio", {"level": 0.0, "beat": False, "s": 0, "t": round(now * 1000), "src": active_src})

                if paused != _audio_status["paused"] or active_src != _audio_status["source"]:
                    _audio_status.update(paused=paused, source=active_src)
                    emit("cosmetics.audio_status", dict(_audio_status))

                # ~125 Hz sampling (peak meter reports the max since the last read, so nothing is missed)
                time.sleep(0.008 if norm > 0 else 0.016)

            except Exception as loop_exc:
                _log.debug("audio loop error, auto-recovering: %s", loop_exc)
                master_meter = None
                time.sleep(0.08)

    finally:
        _audio_status.update(running=False, source="")
        emit("cosmetics.audio", {"level": 0.0, "beat": False, "src": ""})
        emit("cosmetics.audio_status", dict(_audio_status))
        try:
            ctypes.windll.winmm.timeEndPeriod(1)
        except Exception:
            pass
        try:
            comtypes.CoUninitialize()
        except Exception:
            pass



# ----------------------------------------------------------------------------------------------------------------------
# Loopback engine (preferred): captures what the speakers play, runs the spectral beat detector (modules/system/beatdetect)
# ----------------------------------------------------------------------------------------------------------------------

_deps_tried = False


def _ensure_audio_deps() -> bool:
    """numpy + PyAudioWPatch are needed for real beat detection.  Install them once, in the background, if missing."""
    global _deps_tried
    try:
        import numpy  # noqa: F401
        import pyaudiowpatch  # noqa: F401
        return True
    except Exception:
        pass
    if _deps_tried:
        return False
    _deps_tried = True
    try:
        import subprocess
        import sys
        _log.info("audio sync: installing numpy + PyAudioWPatch ...")
        subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-q", "--prefer-binary", "numpy", "PyAudioWPatch"],
                       capture_output=True, timeout=240, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        import importlib
        importlib.invalidate_caches()
        import numpy  # noqa: F401,F811
        import pyaudiowpatch  # noqa: F401,F811
        return True
    except Exception as exc:
        _log.info("audio sync: could not install loopback dependencies: %s", exc)
        return False


def _default_loopback(pa):
    """-> device-info dict of the loopback twin of the current default output device."""
    try:
        return pa.get_default_wasapi_loopback()
    except Exception:
        pass
    import pyaudiowpatch as pyaudio
    wasapi = pa.get_host_api_info_by_type(pyaudio.paWASAPI)
    spk = pa.get_device_info_by_index(wasapi["defaultOutputDevice"])
    if spk.get("isLoopbackDevice"):
        return spk
    for lb in pa.get_loopback_device_info_generator():
        if spk["name"] in lb["name"]:
            return lb
    raise RuntimeError("no loopback device for the default speakers")


def _loopback_loop() -> bool:
    """Runs until stopped.  Returns False if loopback capture cannot be used at all (caller falls back to the peak meter)."""
    import numpy as np
    import pyaudiowpatch as pyaudio
    from modules.system.beatdetect import BeatDetector

    state = {"call": False, "music": False, "src": "", "last_cb": 0.0, "last_emit": 0.0, "last_lvl": 0.0, "paused": ""}
    scan_stop = threading.Event()

    def scanner():                                  # which app is audible + is a voice call active (names only, ~1 Hz)
        import comtypes
        comtypes.CoInitialize()
        try:
            from pycaw.pycaw import AudioUtilities, IAudioMeterInformation
        except Exception:
            return
        try:
            while not scan_stop.is_set():
                call, music, src, best = False, False, "", 0.0
                try:
                    for ses in AudioUtilities.GetAllSessions():
                        try:
                            pr = ses.Process
                            if pr is None:
                                continue
                            name = pr.name()
                            try:
                                exe = pr.exe()
                            except Exception:
                                exe = ""
                            kind = _classify(name, exe)
                            pk = float(ses._ctl.QueryInterface(IAudioMeterInformation).GetPeakValue())
                            if kind == "call":
                                call = call or pk > 0.05
                            elif pk > 0.01:
                                music = True
                                if pk > best:
                                    best, src = pk, name.replace(".exe", "").capitalize()
                        except Exception:
                            continue
                except Exception:
                    pass
                state.update(call=call, music=music)
                if src:
                    state["src"] = src
                scan_stop.wait(1.0)
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass

    threading.Thread(target=scanner, daemon=True, name="audio-session-scan").start()

    def publish_status():
        paused = "Call active (voice ignored)" if state["call"] and not state["music"] else ""
        if paused != _audio_status["paused"] or state["src"] != _audio_status["source"]:
            _audio_status.update(paused=paused, source=state["src"])
            emit("cosmetics.audio_status", dict(_audio_status))
        state["paused"] = paused

    pa = None
    stream = None
    det = None
    dev_name = ""
    opened = False
    try:
        while not _audio_stop.is_set():
            # (re)open the capture on the current default output device
            try:
                if pa is not None:
                    pa.terminate()
                pa = pyaudio.PyAudio()
                info = _default_loopback(pa)
            except Exception as exc:
                if stream is None and dev_name == "":
                    _log.info("loopback capture unavailable: %s", exc)
                    return False
                time.sleep(1.0)
                continue
            dev_name = info["name"]
            rate, ch = int(info["defaultSampleRate"]), max(1, int(info["maxInputChannels"]))
            det = BeatDetector(rate)

            def cb(in_data, frame_count, time_info, status, _det=det, _ch=ch):
                try:
                    now = time.time()
                    state["last_cb"] = now
                    x = np.frombuffer(in_data, dtype=np.float32)
                    if _ch > 1:
                        x = x[: (len(x) // _ch) * _ch].reshape(-1, _ch).mean(axis=1)
                    paused = state["paused"]
                    for fr in _det.process(x):
                        beat = fr.beat and not paused
                        lvl = 0.0 if paused else fr.level
                        # beats leave IMMEDIATELY; the level stream is limited to ~100 Hz
                        if beat or now - state["last_emit"] >= 0.010 or (lvl == 0.0 and state["last_lvl"] > 0.0):
                            state["last_emit"], state["last_lvl"] = now, lvl
                            emit("cosmetics.audio", {"level": round(lvl, 3), "beat": bool(beat), "s": round(fr.strength, 2) if beat else 0,
                                                     "b": fr.band if beat else "", "t": round(now * 1000), "src": state["src"]})
                except Exception as exc:                       # never let an exception kill the audio thread
                    _log.debug("audio callback: %s", exc)
                return (None, pyaudio.paContinue)

            try:
                stream = pa.open(format=pyaudio.paFloat32, channels=ch, rate=rate, input=True, input_device_index=info["index"],
                                 frames_per_buffer=256, stream_callback=cb)
                stream.start_stream()
            except Exception as exc:
                _log.info("loopback open failed on %s: %s", dev_name, exc)
                if not opened:
                    return False
                time.sleep(1.5)
                continue
            opened = True
            _audio_status.update(running=True, available=True, paused="", source=state["src"])
            emit("cosmetics.audio_status", dict(_audio_status))
            _log.info("audio sync: loopback capture on '%s' (%d Hz, %d ch)", dev_name, rate, ch)

            # supervise: silence watchdog, call gating, device switch (headphones plugged in, etc.)
            last_check = time.time()
            while not _audio_stop.is_set():
                time.sleep(0.05)
                now = time.time()
                publish_status()
                if now - state["last_cb"] > 0.30:             # nothing is playing: loopback delivers no packets at all
                    if state["last_lvl"] > 0.0:
                        state["last_lvl"] = 0.0
                        det.reset()
                        emit("cosmetics.audio", {"level": 0.0, "beat": False, "s": 0, "b": "", "t": round(now * 1000), "src": state["src"]})
                if not stream.is_active():
                    break
                if now - last_check > 2.0:
                    last_check = now
                    try:
                        p2 = pyaudio.PyAudio()
                        cur = _default_loopback(p2)["name"]
                        p2.terminate()
                        if cur != dev_name:
                            _log.info("audio sync: output device changed (%s -> %s)", dev_name, cur)
                            break
                    except Exception:
                        pass
            try:
                stream.stop_stream()
                stream.close()
            except Exception:
                pass
            stream = None
        return True
    finally:
        scan_stop.set()
        try:
            if stream is not None:
                stream.stop_stream()
                stream.close()
        except Exception:
            pass
        try:
            if pa is not None:
                pa.terminate()
        except Exception:
            pass


def _audio_loop() -> None:
    """Preferred: loopback capture + spectral beat detection.  Fallback: Windows peak meter."""
    ok = False
    try:
        if _ensure_audio_deps():
            _audio_status.update(running=True, available=True, paused="", source="")
            ok = _loopback_loop()
    except Exception as exc:
        _log.info("loopback audio sync failed, using the peak meter instead: %s", exc)
    finally:
        if ok:
            _audio_status.update(running=False, source="")
            emit("cosmetics.audio", {"level": 0.0, "beat": False, "s": 0, "t": round(time.time() * 1000)})
            emit("cosmetics.audio_status", dict(_audio_status))
    if not ok and not _audio_stop.is_set():
        _log.info("audio sync: running on the Windows peak meter (less accurate)")
        _peak_loop()


@rpc("cosmetics.audio")
def cosmetics_audio(enable: bool):
    """Start / stop the audio-reactive meter."""
    global _audio_thread
    if enable:
        _audio_stop.clear()
        if _audio_thread is not None and _audio_thread.is_alive():
            return {"ok": True, **_audio_status}
        _audio_thread = threading.Thread(target=_audio_loop, daemon=True, name="cosmetics-audio")
        _audio_thread.start()
    else:
        _audio_stop.set()
        if _audio_thread is not None and _audio_thread.is_alive():
            try:
                _audio_thread.join(timeout=0.25)
            except Exception:
                pass
        _audio_thread = None
    return {"ok": True, **_audio_status}
