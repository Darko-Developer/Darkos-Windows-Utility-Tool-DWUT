# Copyright © 2026 Darko / Darko.Dev
"""api/bios_api.py - BIOS & Firmware page backend: detection, update assist, Windows-side firmware tweaks."""
from __future__ import annotations

import subprocess
import sys

from server import rpc
from core.logger import get_logger
from modules.health.psrun import NO_WINDOW

_log = get_logger(__name__)

VENDOR_SUPPORT = {
    "asus": "https://www.asus.com/support/download-center/", "asustek": "https://www.asus.com/support/download-center/",
    "msi": "https://www.msi.com/support/download/", "micro-star": "https://www.msi.com/support/download/",
    "gigabyte": "https://www.gigabyte.com/Support/Consumer/Download", "asrock": "https://www.asrock.com/support/index.asp",
    "dell": "https://www.dell.com/support/home/", "hp": "https://support.hp.com/drivers", "hewlett": "https://support.hp.com/drivers",
    "lenovo": "https://support.lenovo.com/", "acer": "https://www.acer.com/support", "alienware": "https://www.dell.com/support/home/",
    "razer": "https://www.razer.com/support", "biostar": "https://www.biostar.com.tw/app/en/support/download.php",
    "evga": "https://www.evga.com/support/download/", "supermicro": "https://www.supermicro.com/en/support/resources/downloadcenter/firmware/",
    "intel": "https://www.intel.com/content/www/us/en/download-center/home.html", "framework": "https://knowledgebase.frame.work/bios-and-drivers-downloads-rJ3PaCexh",
    "microsoft": "https://support.microsoft.com/surface",
}
# per-vendor flash method guidance (shown as steps)
FLASH_NOTES = {
    "asus": "ASUS boards: use EZ Flash 3 inside the BIOS (Advanced > Tool > EZ Flash) or BIOS FlashBack (rear-panel button, FAT32 USB, file renamed per the manual) - FlashBack works even without a CPU.",
    "msi": "MSI boards: use M-FLASH (BIOS > M-FLASH) or Flash BIOS Button on the rear I/O. Extract the zip to a FAT32 USB first.",
    "gigabyte": "Gigabyte boards: use Q-Flash (press End in BIOS) or Q-Flash Plus on the rear I/O (FAT32 USB, file renamed to gigabyte.bin).",
    "asrock": "ASRock boards: use Instant Flash (BIOS > Tool) from a FAT32 USB. Some boards also have BIOS Flashback.",
    "dell": "Dell/Alienware: run the .exe BIOS update inside Windows (suspend BitLocker first) or use F12 > BIOS Flash Update.",
    "hp": "HP: run the SoftPaq .exe inside Windows; the PC restarts and flashes by itself. Keep AC power connected.",
    "lenovo": "Lenovo: run the BIOS Update Utility .exe inside Windows; keep the AC adapter plugged in.",
    "acer": "Acer: run the Windows flash utility from the support page, with AC power connected.",
}

_SAFETY = [
    "Plug in AC power (laptops: charger connected, battery above 50%). Never flash on a UPS-less unstable supply.",
    "Write down your current BIOS settings (XMP/EXPO, fan curves, boot order) - an update resets them to defaults.",
    "Suspend BitLocker / device encryption first, or have your recovery key ready.",
    "Download ONLY from the board/PC maker's support page for your exact model and revision.",
    "Do not turn the PC off or reset it while flashing. It can take several minutes and the screen may go blank.",
]


def _key(s: str) -> str | None:
    s = (s or "").lower()
    for k in VENDOR_SUPPORT:
        if k in s:
            return k
    return None


@rpc("bios.scan")
def bios_scan():
    from modules.bios import detect
    return detect.scan()


@rpc("bios.assist")
def bios_assist(info: dict | None = None):
    """Build update-assist guidance from the health.motherboard detect() payload."""
    info = info or {}
    b, s, bi = info.get("board") or {}, info.get("system") or {}, info.get("bios") or {}
    is_oem = bool(s.get("manufacturer")) and (s.get("is_laptop") or _key(s.get("manufacturer") or "") in ("dell", "hp", "hewlett", "lenovo", "acer", "alienware"))
    vendor = _key((s.get("manufacturer") if is_oem else b.get("manufacturer")) or "") or _key(b.get("manufacturer") or "") or _key(s.get("manufacturer") or "")
    model = (s.get("model") if is_oem else b.get("product")) or b.get("product") or s.get("model") or ""
    url = VENDOR_SUPPORT.get(vendor or "")
    from urllib.parse import quote
    search = "https://www.google.com/search?q=" + quote(f"{(b.get('manufacturer') or s.get('manufacturer') or '')} {model} BIOS update download".strip())
    age = bi.get("age_days")
    verdict = "unknown"
    if age is not None:
        verdict = "old" if age > 730 else "aging" if age > 365 else "recent"
    return {"vendor": vendor, "model": model, "support_url": url, "search_url": search, "flash_note": FLASH_NOTES.get(vendor or "", "Check the maker's manual for the built-in flash tool (usually under Tools/Advanced in the BIOS)."),
            "age_verdict": verdict, "safety": _SAFETY, "current": {"version": bi.get("version"), "date": bi.get("release_date"), "age_days": age}}


@rpc("bios.restart_uefi")
def bios_restart_uefi(seconds: int = 15):
    from modules.health import fixes
    return {"ok": fixes.restart_to_uefi(int(seconds))}


@rpc("bios.cancel_restart")
def bios_cancel_restart():
    if sys.platform != "win32":
        return {"ok": False}
    r = subprocess.run(["shutdown", "/a"], capture_output=True, timeout=15, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
    return {"ok": r.returncode == 0}


# ── Windows-side firmware-adjacent tweaks (each has apply + revert, all verifiable) ──
def _bcd(*args):
    r = subprocess.run(["bcdedit", *args], capture_output=True, timeout=20, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
    return r.returncode == 0, (r.stdout or b"").decode("utf-8", "replace").strip()


def _reg(path, name, val):
    r = subprocess.run(["reg", "add", path, "/v", name, "/t", "REG_DWORD", "/d", str(val), "/f"], capture_output=True, timeout=20, creationflags=NO_WINDOW, stdin=subprocess.DEVNULL)
    return r.returncode == 0, ""


_GFX = r"HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
_PWR = r"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Power"
TWEAKS = {
    "hpet_off": (lambda: _bcd("/deletevalue", "useplatformclock"), lambda: _bcd("/set", "useplatformclock", "yes")),
    "dyntick_off": (lambda: _bcd("/set", "disabledynamictick", "yes"), lambda: _bcd("/deletevalue", "disabledynamictick")),
    "hags_on": (lambda: _reg(_GFX, "HwSchMode", 2), lambda: _reg(_GFX, "HwSchMode", 1)),
    "fast_startup_off": (lambda: _reg(_PWR, "HiberbootEnabled", 0), lambda: _reg(_PWR, "HiberbootEnabled", 1)),
    "game_mode_on": (lambda: _reg(r"HKCU\Software\Microsoft\GameBar", "AutoGameModeEnabled", 1), lambda: _reg(r"HKCU\Software\Microsoft\GameBar", "AutoGameModeEnabled", 0)),
}


@rpc("bios.tweak")
def bios_tweak(id: str, revert: bool = False):
    if sys.platform != "win32" or id not in TWEAKS:
        return {"ok": False, "note": "Not available on this system."}
    try:
        ok, out = TWEAKS[id][1 if revert else 0]()
        return {"ok": bool(ok), "note": out or ("Done. Restart for it to fully take effect." if ok else "Command failed - run DWUT as administrator.")}
    except Exception as exc:
        return {"ok": False, "note": str(exc)}


@rpc("bios.export_plan")
def bios_export_plan(text: str):
    """Save the user's BIOS checklist to the Desktop (or home) as a text file."""
    from pathlib import Path
    base = Path.home() / "Desktop"
    if not base.is_dir():
        base = Path.home()
    p = base / "DWUT-BIOS-plan.txt"
    p.write_text(str(text or ""), "utf-8")
    return {"ok": True, "path": str(p)}
