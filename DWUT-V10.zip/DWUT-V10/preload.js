// Copyright © 2026 Darko / Darko.Dev
'use strict';
const { contextBridge, ipcRenderer, clipboard } = require('electron');
const listeners = new Map();      // event -> Set<fn>

ipcRenderer.on('backend:event', (_e, name, data) => {
  const set = listeners.get(name);
  if (set) for (const fn of [...set]) { try { fn(data); } catch (err) { console.error('event handler', name, err); } }
  const all = listeners.get('*');
  if (all) for (const fn of [...all]) { try { fn(name, data); } catch { /* ignore */ } }
});
ipcRenderer.on('win:state', (_e, s) => { const set = listeners.get('win:state'); if (set) for (const fn of set) fn(s); });
ipcRenderer.on('app:suspend-render', () => { const set = listeners.get('app:suspend-render'); if (set) for (const fn of set) fn(); });
ipcRenderer.on('app:resume-render', () => { const set = listeners.get('app:resume-render'); if (set) for (const fn of set) fn(); });
ipcRenderer.on('app:request-theme-icon', () => {
  const set = listeners.get('app:request-theme-icon');
  if (set) for (const fn of set) fn();
  window.dispatchEvent(new Event('dwut-theme'));
});

contextBridge.exposeInMainWorld('dwut', {
  call: (method, params) => ipcRenderer.invoke('backend:call', method, params || {}),
  ready: () => ipcRenderer.invoke('backend:ready'),
  on: (name, fn) => { if (!listeners.has(name)) listeners.set(name, new Set()); listeners.get(name).add(fn); return () => listeners.get(name).delete(fn); },
  win: {
    minimize:   () => ipcRenderer.send('win:minimize'),
    maximize:   () => ipcRenderer.send('win:maximize'),
    close:      () => ipcRenderer.send('win:close'),
    resize:     (dw, dh, ow, oh) => ipcRenderer.send('win:resize', dw, dh, ow, oh),
    size:       () => ipcRenderer.invoke('win:size'),
    setOpacity: (v) => ipcRenderer.send('win:set-opacity', v),
  },
  dialog: { save: (o) => ipcRenderer.invoke('dialog:save', o), open: (o) => ipcRenderer.invoke('dialog:open', o) },
  openExternal: (u) => ipcRenderer.invoke('shell:open', u),
  notify: (title, body, url) => ipcRenderer.invoke('app:notify', title, body, url),
  updateNow: () => ipcRenderer.invoke('app:update-now'),
  relaunchAdmin: () => ipcRenderer.invoke('app:relaunch-admin'),
  perf: () => ipcRenderer.invoke('app:perf'),
  self: (action) => ipcRenderer.invoke('app:self', action),
  hasStartup: () => ipcRenderer.invoke('app:has-startup'),
  addToStartup: () => ipcRenderer.invoke('app:add-startup'),
  removeFromStartup: () => ipcRenderer.invoke('app:remove-startup'),
  startupState: () => ipcRenderer.invoke('app:startup-state'),
  copy: (t) => clipboard.writeText(String(t)),
  openTaskManager: (page) => ipcRenderer.send('tm:open', page),
  openTerminal: (kind, admin) => ipcRenderer.send('term:open', kind, admin),
  openPerfOptions: () => ipcRenderer.send('perf:open'),
  pushTheme: (themeData) => ipcRenderer.send('tm:theme-push', themeData),
  setThemeIcon: (dataUrl) => ipcRenderer.send('app:set-theme-icon', dataUrl),
});
